import {
  __commonJS,
  __esm,
  __export,
  __require,
  __toCommonJS
} from "./chunk-WXPTAMPH.js";

// node_modules/underscore/modules/_setup.js
var VERSION, root, ArrayProto, ObjProto, SymbolProto, push, slice, toString, hasOwnProperty, supportsArrayBuffer, supportsDataView, nativeIsArray, nativeKeys, nativeCreate, nativeIsView, _isNaN, _isFinite, hasEnumBug, nonEnumerableProps, MAX_ARRAY_INDEX;
var init_setup = __esm({
  "node_modules/underscore/modules/_setup.js"() {
    VERSION = "1.13.7";
    root = typeof self == "object" && self.self === self && self || typeof global == "object" && global.global === global && global || Function("return this")() || {};
    ArrayProto = Array.prototype;
    ObjProto = Object.prototype;
    SymbolProto = typeof Symbol !== "undefined" ? Symbol.prototype : null;
    push = ArrayProto.push;
    slice = ArrayProto.slice;
    toString = ObjProto.toString;
    hasOwnProperty = ObjProto.hasOwnProperty;
    supportsArrayBuffer = typeof ArrayBuffer !== "undefined";
    supportsDataView = typeof DataView !== "undefined";
    nativeIsArray = Array.isArray;
    nativeKeys = Object.keys;
    nativeCreate = Object.create;
    nativeIsView = supportsArrayBuffer && ArrayBuffer.isView;
    _isNaN = isNaN;
    _isFinite = isFinite;
    hasEnumBug = !{
      toString: null
    }.propertyIsEnumerable("toString");
    nonEnumerableProps = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"];
    MAX_ARRAY_INDEX = Math.pow(2, 53) - 1;
  }
});

// node_modules/underscore/modules/restArguments.js
function restArguments(func, startIndex) {
  startIndex = startIndex == null ? func.length - 1 : +startIndex;
  return function() {
    var length = Math.max(arguments.length - startIndex, 0), rest2 = Array(length), index = 0;
    for (; index < length; index++) {
      rest2[index] = arguments[index + startIndex];
    }
    switch (startIndex) {
      case 0:
        return func.call(this, rest2);
      case 1:
        return func.call(this, arguments[0], rest2);
      case 2:
        return func.call(this, arguments[0], arguments[1], rest2);
    }
    var args = Array(startIndex + 1);
    for (index = 0; index < startIndex; index++) {
      args[index] = arguments[index];
    }
    args[startIndex] = rest2;
    return func.apply(this, args);
  };
}
var init_restArguments = __esm({
  "node_modules/underscore/modules/restArguments.js"() {
  }
});

// node_modules/underscore/modules/isObject.js
function isObject2(obj2) {
  var type = typeof obj2;
  return type === "function" || type === "object" && !!obj2;
}
var init_isObject = __esm({
  "node_modules/underscore/modules/isObject.js"() {
  }
});

// node_modules/underscore/modules/isNull.js
function isNull(obj2) {
  return obj2 === null;
}
var init_isNull = __esm({
  "node_modules/underscore/modules/isNull.js"() {
  }
});

// node_modules/underscore/modules/isUndefined.js
function isUndefined(obj2) {
  return obj2 === void 0;
}
var init_isUndefined = __esm({
  "node_modules/underscore/modules/isUndefined.js"() {
  }
});

// node_modules/underscore/modules/isBoolean.js
function isBoolean(obj2) {
  return obj2 === true || obj2 === false || toString.call(obj2) === "[object Boolean]";
}
var init_isBoolean = __esm({
  "node_modules/underscore/modules/isBoolean.js"() {
    init_setup();
  }
});

// node_modules/underscore/modules/isElement.js
function isElement(obj2) {
  return !!(obj2 && obj2.nodeType === 1);
}
var init_isElement = __esm({
  "node_modules/underscore/modules/isElement.js"() {
  }
});

// node_modules/underscore/modules/_tagTester.js
function tagTester(name) {
  var tag = "[object " + name + "]";
  return function(obj2) {
    return toString.call(obj2) === tag;
  };
}
var init_tagTester = __esm({
  "node_modules/underscore/modules/_tagTester.js"() {
    init_setup();
  }
});

// node_modules/underscore/modules/isString.js
var isString_default;
var init_isString = __esm({
  "node_modules/underscore/modules/isString.js"() {
    init_tagTester();
    isString_default = tagTester("String");
  }
});

// node_modules/underscore/modules/isNumber.js
var isNumber_default;
var init_isNumber = __esm({
  "node_modules/underscore/modules/isNumber.js"() {
    init_tagTester();
    isNumber_default = tagTester("Number");
  }
});

// node_modules/underscore/modules/isDate.js
var isDate_default;
var init_isDate = __esm({
  "node_modules/underscore/modules/isDate.js"() {
    init_tagTester();
    isDate_default = tagTester("Date");
  }
});

// node_modules/underscore/modules/isRegExp.js
var isRegExp_default;
var init_isRegExp = __esm({
  "node_modules/underscore/modules/isRegExp.js"() {
    init_tagTester();
    isRegExp_default = tagTester("RegExp");
  }
});

// node_modules/underscore/modules/isError.js
var isError_default;
var init_isError = __esm({
  "node_modules/underscore/modules/isError.js"() {
    init_tagTester();
    isError_default = tagTester("Error");
  }
});

// node_modules/underscore/modules/isSymbol.js
var isSymbol_default;
var init_isSymbol = __esm({
  "node_modules/underscore/modules/isSymbol.js"() {
    init_tagTester();
    isSymbol_default = tagTester("Symbol");
  }
});

// node_modules/underscore/modules/isArrayBuffer.js
var isArrayBuffer_default;
var init_isArrayBuffer = __esm({
  "node_modules/underscore/modules/isArrayBuffer.js"() {
    init_tagTester();
    isArrayBuffer_default = tagTester("ArrayBuffer");
  }
});

// node_modules/underscore/modules/isFunction.js
var isFunction, nodelist, isFunction_default;
var init_isFunction = __esm({
  "node_modules/underscore/modules/isFunction.js"() {
    init_tagTester();
    init_setup();
    isFunction = tagTester("Function");
    nodelist = root.document && root.document.childNodes;
    if (typeof /./ != "function" && typeof Int8Array != "object" && typeof nodelist != "function") {
      isFunction = function(obj2) {
        return typeof obj2 == "function" || false;
      };
    }
    isFunction_default = isFunction;
  }
});

// node_modules/underscore/modules/_hasObjectTag.js
var hasObjectTag_default;
var init_hasObjectTag = __esm({
  "node_modules/underscore/modules/_hasObjectTag.js"() {
    init_tagTester();
    hasObjectTag_default = tagTester("Object");
  }
});

// node_modules/underscore/modules/_stringTagBug.js
var hasDataViewBug, isIE11;
var init_stringTagBug = __esm({
  "node_modules/underscore/modules/_stringTagBug.js"() {
    init_setup();
    init_hasObjectTag();
    hasDataViewBug = supportsDataView && (!/\[native code\]/.test(String(DataView)) || hasObjectTag_default(new DataView(new ArrayBuffer(8))));
    isIE11 = typeof Map !== "undefined" && hasObjectTag_default(/* @__PURE__ */ new Map());
  }
});

// node_modules/underscore/modules/isDataView.js
function alternateIsDataView(obj2) {
  return obj2 != null && isFunction_default(obj2.getInt8) && isArrayBuffer_default(obj2.buffer);
}
var isDataView, isDataView_default;
var init_isDataView = __esm({
  "node_modules/underscore/modules/isDataView.js"() {
    init_tagTester();
    init_isFunction();
    init_isArrayBuffer();
    init_stringTagBug();
    isDataView = tagTester("DataView");
    isDataView_default = hasDataViewBug ? alternateIsDataView : isDataView;
  }
});

// node_modules/underscore/modules/isArray.js
var isArray_default;
var init_isArray = __esm({
  "node_modules/underscore/modules/isArray.js"() {
    init_setup();
    init_tagTester();
    isArray_default = nativeIsArray || tagTester("Array");
  }
});

// node_modules/underscore/modules/_has.js
function has(obj2, key) {
  return obj2 != null && hasOwnProperty.call(obj2, key);
}
var init_has = __esm({
  "node_modules/underscore/modules/_has.js"() {
    init_setup();
  }
});

// node_modules/underscore/modules/isArguments.js
var isArguments, isArguments_default;
var init_isArguments = __esm({
  "node_modules/underscore/modules/isArguments.js"() {
    init_tagTester();
    init_has();
    isArguments = tagTester("Arguments");
    (function() {
      if (!isArguments(arguments)) {
        isArguments = function(obj2) {
          return has(obj2, "callee");
        };
      }
    })();
    isArguments_default = isArguments;
  }
});

// node_modules/underscore/modules/isFinite.js
function isFinite2(obj2) {
  return !isSymbol_default(obj2) && _isFinite(obj2) && !isNaN(parseFloat(obj2));
}
var init_isFinite = __esm({
  "node_modules/underscore/modules/isFinite.js"() {
    init_setup();
    init_isSymbol();
  }
});

// node_modules/underscore/modules/isNaN.js
function isNaN2(obj2) {
  return isNumber_default(obj2) && _isNaN(obj2);
}
var init_isNaN = __esm({
  "node_modules/underscore/modules/isNaN.js"() {
    init_setup();
    init_isNumber();
  }
});

// node_modules/underscore/modules/constant.js
function constant(value) {
  return function() {
    return value;
  };
}
var init_constant = __esm({
  "node_modules/underscore/modules/constant.js"() {
  }
});

// node_modules/underscore/modules/_createSizePropertyCheck.js
function createSizePropertyCheck(getSizeProperty) {
  return function(collection) {
    var sizeProperty = getSizeProperty(collection);
    return typeof sizeProperty == "number" && sizeProperty >= 0 && sizeProperty <= MAX_ARRAY_INDEX;
  };
}
var init_createSizePropertyCheck = __esm({
  "node_modules/underscore/modules/_createSizePropertyCheck.js"() {
    init_setup();
  }
});

// node_modules/underscore/modules/_shallowProperty.js
function shallowProperty(key) {
  return function(obj2) {
    return obj2 == null ? void 0 : obj2[key];
  };
}
var init_shallowProperty = __esm({
  "node_modules/underscore/modules/_shallowProperty.js"() {
  }
});

// node_modules/underscore/modules/_getByteLength.js
var getByteLength_default;
var init_getByteLength = __esm({
  "node_modules/underscore/modules/_getByteLength.js"() {
    init_shallowProperty();
    getByteLength_default = shallowProperty("byteLength");
  }
});

// node_modules/underscore/modules/_isBufferLike.js
var isBufferLike_default;
var init_isBufferLike = __esm({
  "node_modules/underscore/modules/_isBufferLike.js"() {
    init_createSizePropertyCheck();
    init_getByteLength();
    isBufferLike_default = createSizePropertyCheck(getByteLength_default);
  }
});

// node_modules/underscore/modules/isTypedArray.js
function isTypedArray(obj2) {
  return nativeIsView ? nativeIsView(obj2) && !isDataView_default(obj2) : isBufferLike_default(obj2) && typedArrayPattern.test(toString.call(obj2));
}
var typedArrayPattern, isTypedArray_default;
var init_isTypedArray = __esm({
  "node_modules/underscore/modules/isTypedArray.js"() {
    init_setup();
    init_isDataView();
    init_constant();
    init_isBufferLike();
    typedArrayPattern = /\[object ((I|Ui)nt(8|16|32)|Float(32|64)|Uint8Clamped|Big(I|Ui)nt64)Array\]/;
    isTypedArray_default = supportsArrayBuffer ? isTypedArray : constant(false);
  }
});

// node_modules/underscore/modules/_getLength.js
var getLength_default;
var init_getLength = __esm({
  "node_modules/underscore/modules/_getLength.js"() {
    init_shallowProperty();
    getLength_default = shallowProperty("length");
  }
});

// node_modules/underscore/modules/_collectNonEnumProps.js
function emulatedSet(keys2) {
  var hash = {};
  for (var l2 = keys2.length, i = 0; i < l2; ++i) hash[keys2[i]] = true;
  return {
    contains: function(key) {
      return hash[key] === true;
    },
    push: function(key) {
      hash[key] = true;
      return keys2.push(key);
    }
  };
}
function collectNonEnumProps(obj2, keys2) {
  keys2 = emulatedSet(keys2);
  var nonEnumIdx = nonEnumerableProps.length;
  var constructor = obj2.constructor;
  var proto = isFunction_default(constructor) && constructor.prototype || ObjProto;
  var prop = "constructor";
  if (has(obj2, prop) && !keys2.contains(prop)) keys2.push(prop);
  while (nonEnumIdx--) {
    prop = nonEnumerableProps[nonEnumIdx];
    if (prop in obj2 && obj2[prop] !== proto[prop] && !keys2.contains(prop)) {
      keys2.push(prop);
    }
  }
}
var init_collectNonEnumProps = __esm({
  "node_modules/underscore/modules/_collectNonEnumProps.js"() {
    init_setup();
    init_isFunction();
    init_has();
  }
});

// node_modules/underscore/modules/keys.js
function keys(obj2) {
  if (!isObject2(obj2)) return [];
  if (nativeKeys) return nativeKeys(obj2);
  var keys2 = [];
  for (var key in obj2) if (has(obj2, key)) keys2.push(key);
  if (hasEnumBug) collectNonEnumProps(obj2, keys2);
  return keys2;
}
var init_keys = __esm({
  "node_modules/underscore/modules/keys.js"() {
    init_isObject();
    init_setup();
    init_has();
    init_collectNonEnumProps();
  }
});

// node_modules/underscore/modules/isEmpty.js
function isEmpty(obj2) {
  if (obj2 == null) return true;
  var length = getLength_default(obj2);
  if (typeof length == "number" && (isArray_default(obj2) || isString_default(obj2) || isArguments_default(obj2))) return length === 0;
  return getLength_default(keys(obj2)) === 0;
}
var init_isEmpty = __esm({
  "node_modules/underscore/modules/isEmpty.js"() {
    init_getLength();
    init_isArray();
    init_isString();
    init_isArguments();
    init_keys();
  }
});

// node_modules/underscore/modules/isMatch.js
function isMatch(object2, attrs) {
  var _keys = keys(attrs), length = _keys.length;
  if (object2 == null) return !length;
  var obj2 = Object(object2);
  for (var i = 0; i < length; i++) {
    var key = _keys[i];
    if (attrs[key] !== obj2[key] || !(key in obj2)) return false;
  }
  return true;
}
var init_isMatch = __esm({
  "node_modules/underscore/modules/isMatch.js"() {
    init_keys();
  }
});

// node_modules/underscore/modules/underscore.js
function _(obj2) {
  if (obj2 instanceof _) return obj2;
  if (!(this instanceof _)) return new _(obj2);
  this._wrapped = obj2;
}
var init_underscore = __esm({
  "node_modules/underscore/modules/underscore.js"() {
    init_setup();
    _.VERSION = VERSION;
    _.prototype.value = function() {
      return this._wrapped;
    };
    _.prototype.valueOf = _.prototype.toJSON = _.prototype.value;
    _.prototype.toString = function() {
      return String(this._wrapped);
    };
  }
});

// node_modules/underscore/modules/_toBufferView.js
function toBufferView(bufferSource) {
  return new Uint8Array(bufferSource.buffer || bufferSource, bufferSource.byteOffset || 0, getByteLength_default(bufferSource));
}
var init_toBufferView = __esm({
  "node_modules/underscore/modules/_toBufferView.js"() {
    init_getByteLength();
  }
});

// node_modules/underscore/modules/isEqual.js
function eq(a, b, aStack, bStack) {
  if (a === b) return a !== 0 || 1 / a === 1 / b;
  if (a == null || b == null) return false;
  if (a !== a) return b !== b;
  var type = typeof a;
  if (type !== "function" && type !== "object" && typeof b != "object") return false;
  return deepEq(a, b, aStack, bStack);
}
function deepEq(a, b, aStack, bStack) {
  if (a instanceof _) a = a._wrapped;
  if (b instanceof _) b = b._wrapped;
  var className = toString.call(a);
  if (className !== toString.call(b)) return false;
  if (hasDataViewBug && className == "[object Object]" && isDataView_default(a)) {
    if (!isDataView_default(b)) return false;
    className = tagDataView;
  }
  switch (className) {
    // These types are compared by value.
    case "[object RegExp]":
    // RegExps are coerced to strings for comparison (Note: '' + /a/i === '/a/i')
    case "[object String]":
      return "" + a === "" + b;
    case "[object Number]":
      if (+a !== +a) return +b !== +b;
      return +a === 0 ? 1 / +a === 1 / b : +a === +b;
    case "[object Date]":
    case "[object Boolean]":
      return +a === +b;
    case "[object Symbol]":
      return SymbolProto.valueOf.call(a) === SymbolProto.valueOf.call(b);
    case "[object ArrayBuffer]":
    case tagDataView:
      return deepEq(toBufferView(a), toBufferView(b), aStack, bStack);
  }
  var areArrays = className === "[object Array]";
  if (!areArrays && isTypedArray_default(a)) {
    var byteLength = getByteLength_default(a);
    if (byteLength !== getByteLength_default(b)) return false;
    if (a.buffer === b.buffer && a.byteOffset === b.byteOffset) return true;
    areArrays = true;
  }
  if (!areArrays) {
    if (typeof a != "object" || typeof b != "object") return false;
    var aCtor = a.constructor, bCtor = b.constructor;
    if (aCtor !== bCtor && !(isFunction_default(aCtor) && aCtor instanceof aCtor && isFunction_default(bCtor) && bCtor instanceof bCtor) && "constructor" in a && "constructor" in b) {
      return false;
    }
  }
  aStack = aStack || [];
  bStack = bStack || [];
  var length = aStack.length;
  while (length--) {
    if (aStack[length] === a) return bStack[length] === b;
  }
  aStack.push(a);
  bStack.push(b);
  if (areArrays) {
    length = a.length;
    if (length !== b.length) return false;
    while (length--) {
      if (!eq(a[length], b[length], aStack, bStack)) return false;
    }
  } else {
    var _keys = keys(a), key;
    length = _keys.length;
    if (keys(b).length !== length) return false;
    while (length--) {
      key = _keys[length];
      if (!(has(b, key) && eq(a[key], b[key], aStack, bStack))) return false;
    }
  }
  aStack.pop();
  bStack.pop();
  return true;
}
function isEqual(a, b) {
  return eq(a, b);
}
var tagDataView;
var init_isEqual = __esm({
  "node_modules/underscore/modules/isEqual.js"() {
    init_underscore();
    init_setup();
    init_getByteLength();
    init_isTypedArray();
    init_isFunction();
    init_stringTagBug();
    init_isDataView();
    init_keys();
    init_has();
    init_toBufferView();
    tagDataView = "[object DataView]";
  }
});

// node_modules/underscore/modules/allKeys.js
function allKeys(obj2) {
  if (!isObject2(obj2)) return [];
  var keys2 = [];
  for (var key in obj2) keys2.push(key);
  if (hasEnumBug) collectNonEnumProps(obj2, keys2);
  return keys2;
}
var init_allKeys = __esm({
  "node_modules/underscore/modules/allKeys.js"() {
    init_isObject();
    init_setup();
    init_collectNonEnumProps();
  }
});

// node_modules/underscore/modules/_methodFingerprint.js
function ie11fingerprint(methods) {
  var length = getLength_default(methods);
  return function(obj2) {
    if (obj2 == null) return false;
    var keys2 = allKeys(obj2);
    if (getLength_default(keys2)) return false;
    for (var i = 0; i < length; i++) {
      if (!isFunction_default(obj2[methods[i]])) return false;
    }
    return methods !== weakMapMethods || !isFunction_default(obj2[forEachName]);
  };
}
var forEachName, hasName, commonInit, mapTail, mapMethods, weakMapMethods, setMethods;
var init_methodFingerprint = __esm({
  "node_modules/underscore/modules/_methodFingerprint.js"() {
    init_getLength();
    init_isFunction();
    init_allKeys();
    forEachName = "forEach";
    hasName = "has";
    commonInit = ["clear", "delete"];
    mapTail = ["get", hasName, "set"];
    mapMethods = commonInit.concat(forEachName, mapTail);
    weakMapMethods = commonInit.concat(mapTail);
    setMethods = ["add"].concat(commonInit, forEachName, hasName);
  }
});

// node_modules/underscore/modules/isMap.js
var isMap_default;
var init_isMap = __esm({
  "node_modules/underscore/modules/isMap.js"() {
    init_tagTester();
    init_stringTagBug();
    init_methodFingerprint();
    isMap_default = isIE11 ? ie11fingerprint(mapMethods) : tagTester("Map");
  }
});

// node_modules/underscore/modules/isWeakMap.js
var isWeakMap_default;
var init_isWeakMap = __esm({
  "node_modules/underscore/modules/isWeakMap.js"() {
    init_tagTester();
    init_stringTagBug();
    init_methodFingerprint();
    isWeakMap_default = isIE11 ? ie11fingerprint(weakMapMethods) : tagTester("WeakMap");
  }
});

// node_modules/underscore/modules/isSet.js
var isSet_default;
var init_isSet = __esm({
  "node_modules/underscore/modules/isSet.js"() {
    init_tagTester();
    init_stringTagBug();
    init_methodFingerprint();
    isSet_default = isIE11 ? ie11fingerprint(setMethods) : tagTester("Set");
  }
});

// node_modules/underscore/modules/isWeakSet.js
var isWeakSet_default;
var init_isWeakSet = __esm({
  "node_modules/underscore/modules/isWeakSet.js"() {
    init_tagTester();
    isWeakSet_default = tagTester("WeakSet");
  }
});

// node_modules/underscore/modules/values.js
function values(obj2) {
  var _keys = keys(obj2);
  var length = _keys.length;
  var values2 = Array(length);
  for (var i = 0; i < length; i++) {
    values2[i] = obj2[_keys[i]];
  }
  return values2;
}
var init_values = __esm({
  "node_modules/underscore/modules/values.js"() {
    init_keys();
  }
});

// node_modules/underscore/modules/pairs.js
function pairs(obj2) {
  var _keys = keys(obj2);
  var length = _keys.length;
  var pairs2 = Array(length);
  for (var i = 0; i < length; i++) {
    pairs2[i] = [_keys[i], obj2[_keys[i]]];
  }
  return pairs2;
}
var init_pairs = __esm({
  "node_modules/underscore/modules/pairs.js"() {
    init_keys();
  }
});

// node_modules/underscore/modules/invert.js
function invert(obj2) {
  var result2 = {};
  var _keys = keys(obj2);
  for (var i = 0, length = _keys.length; i < length; i++) {
    result2[obj2[_keys[i]]] = _keys[i];
  }
  return result2;
}
var init_invert = __esm({
  "node_modules/underscore/modules/invert.js"() {
    init_keys();
  }
});

// node_modules/underscore/modules/functions.js
function functions(obj2) {
  var names = [];
  for (var key in obj2) {
    if (isFunction_default(obj2[key])) names.push(key);
  }
  return names.sort();
}
var init_functions = __esm({
  "node_modules/underscore/modules/functions.js"() {
    init_isFunction();
  }
});

// node_modules/underscore/modules/_createAssigner.js
function createAssigner(keysFunc, defaults) {
  return function(obj2) {
    var length = arguments.length;
    if (defaults) obj2 = Object(obj2);
    if (length < 2 || obj2 == null) return obj2;
    for (var index = 1; index < length; index++) {
      var source = arguments[index], keys2 = keysFunc(source), l2 = keys2.length;
      for (var i = 0; i < l2; i++) {
        var key = keys2[i];
        if (!defaults || obj2[key] === void 0) obj2[key] = source[key];
      }
    }
    return obj2;
  };
}
var init_createAssigner = __esm({
  "node_modules/underscore/modules/_createAssigner.js"() {
  }
});

// node_modules/underscore/modules/extend.js
var extend_default;
var init_extend = __esm({
  "node_modules/underscore/modules/extend.js"() {
    init_createAssigner();
    init_allKeys();
    extend_default = createAssigner(allKeys);
  }
});

// node_modules/underscore/modules/extendOwn.js
var extendOwn_default;
var init_extendOwn = __esm({
  "node_modules/underscore/modules/extendOwn.js"() {
    init_createAssigner();
    init_keys();
    extendOwn_default = createAssigner(keys);
  }
});

// node_modules/underscore/modules/defaults.js
var defaults_default;
var init_defaults = __esm({
  "node_modules/underscore/modules/defaults.js"() {
    init_createAssigner();
    init_allKeys();
    defaults_default = createAssigner(allKeys, true);
  }
});

// node_modules/underscore/modules/_baseCreate.js
function ctor() {
  return function() {
  };
}
function baseCreate(prototype) {
  if (!isObject2(prototype)) return {};
  if (nativeCreate) return nativeCreate(prototype);
  var Ctor = ctor();
  Ctor.prototype = prototype;
  var result2 = new Ctor();
  Ctor.prototype = null;
  return result2;
}
var init_baseCreate = __esm({
  "node_modules/underscore/modules/_baseCreate.js"() {
    init_isObject();
    init_setup();
  }
});

// node_modules/underscore/modules/create.js
function create(prototype, props) {
  var result2 = baseCreate(prototype);
  if (props) extendOwn_default(result2, props);
  return result2;
}
var init_create = __esm({
  "node_modules/underscore/modules/create.js"() {
    init_baseCreate();
    init_extendOwn();
  }
});

// node_modules/underscore/modules/clone.js
function clone(obj2) {
  if (!isObject2(obj2)) return obj2;
  return isArray_default(obj2) ? obj2.slice() : extend_default({}, obj2);
}
var init_clone = __esm({
  "node_modules/underscore/modules/clone.js"() {
    init_isObject();
    init_isArray();
    init_extend();
  }
});

// node_modules/underscore/modules/tap.js
function tap(obj2, interceptor) {
  interceptor(obj2);
  return obj2;
}
var init_tap = __esm({
  "node_modules/underscore/modules/tap.js"() {
  }
});

// node_modules/underscore/modules/toPath.js
function toPath(path) {
  return isArray_default(path) ? path : [path];
}
var init_toPath = __esm({
  "node_modules/underscore/modules/toPath.js"() {
    init_underscore();
    init_isArray();
    _.toPath = toPath;
  }
});

// node_modules/underscore/modules/_toPath.js
function toPath2(path) {
  return _.toPath(path);
}
var init_toPath2 = __esm({
  "node_modules/underscore/modules/_toPath.js"() {
    init_underscore();
    init_toPath();
  }
});

// node_modules/underscore/modules/_deepGet.js
function deepGet(obj2, path) {
  var length = path.length;
  for (var i = 0; i < length; i++) {
    if (obj2 == null) return void 0;
    obj2 = obj2[path[i]];
  }
  return length ? obj2 : void 0;
}
var init_deepGet = __esm({
  "node_modules/underscore/modules/_deepGet.js"() {
  }
});

// node_modules/underscore/modules/get.js
function get(object2, path, defaultValue) {
  var value = deepGet(object2, toPath2(path));
  return isUndefined(value) ? defaultValue : value;
}
var init_get = __esm({
  "node_modules/underscore/modules/get.js"() {
    init_toPath2();
    init_deepGet();
    init_isUndefined();
  }
});

// node_modules/underscore/modules/has.js
function has2(obj2, path) {
  path = toPath2(path);
  var length = path.length;
  for (var i = 0; i < length; i++) {
    var key = path[i];
    if (!has(obj2, key)) return false;
    obj2 = obj2[key];
  }
  return !!length;
}
var init_has2 = __esm({
  "node_modules/underscore/modules/has.js"() {
    init_has();
    init_toPath2();
  }
});

// node_modules/underscore/modules/identity.js
function identity(value) {
  return value;
}
var init_identity = __esm({
  "node_modules/underscore/modules/identity.js"() {
  }
});

// node_modules/underscore/modules/matcher.js
function matcher(attrs) {
  attrs = extendOwn_default({}, attrs);
  return function(obj2) {
    return isMatch(obj2, attrs);
  };
}
var init_matcher = __esm({
  "node_modules/underscore/modules/matcher.js"() {
    init_extendOwn();
    init_isMatch();
  }
});

// node_modules/underscore/modules/property.js
function property(path) {
  path = toPath2(path);
  return function(obj2) {
    return deepGet(obj2, path);
  };
}
var init_property = __esm({
  "node_modules/underscore/modules/property.js"() {
    init_deepGet();
    init_toPath2();
  }
});

// node_modules/underscore/modules/_optimizeCb.js
function optimizeCb(func, context, argCount) {
  if (context === void 0) return func;
  switch (argCount == null ? 3 : argCount) {
    case 1:
      return function(value) {
        return func.call(context, value);
      };
    // The 2-argument case is omitted because we’re not using it.
    case 3:
      return function(value, index, collection) {
        return func.call(context, value, index, collection);
      };
    case 4:
      return function(accumulator, value, index, collection) {
        return func.call(context, accumulator, value, index, collection);
      };
  }
  return function() {
    return func.apply(context, arguments);
  };
}
var init_optimizeCb = __esm({
  "node_modules/underscore/modules/_optimizeCb.js"() {
  }
});

// node_modules/underscore/modules/_baseIteratee.js
function baseIteratee(value, context, argCount) {
  if (value == null) return identity;
  if (isFunction_default(value)) return optimizeCb(value, context, argCount);
  if (isObject2(value) && !isArray_default(value)) return matcher(value);
  return property(value);
}
var init_baseIteratee = __esm({
  "node_modules/underscore/modules/_baseIteratee.js"() {
    init_identity();
    init_isFunction();
    init_isObject();
    init_isArray();
    init_matcher();
    init_property();
    init_optimizeCb();
  }
});

// node_modules/underscore/modules/iteratee.js
function iteratee(value, context) {
  return baseIteratee(value, context, Infinity);
}
var init_iteratee = __esm({
  "node_modules/underscore/modules/iteratee.js"() {
    init_underscore();
    init_baseIteratee();
    _.iteratee = iteratee;
  }
});

// node_modules/underscore/modules/_cb.js
function cb(value, context, argCount) {
  if (_.iteratee !== iteratee) return _.iteratee(value, context);
  return baseIteratee(value, context, argCount);
}
var init_cb = __esm({
  "node_modules/underscore/modules/_cb.js"() {
    init_underscore();
    init_baseIteratee();
    init_iteratee();
  }
});

// node_modules/underscore/modules/mapObject.js
function mapObject(obj2, iteratee2, context) {
  iteratee2 = cb(iteratee2, context);
  var _keys = keys(obj2), length = _keys.length, results = {};
  for (var index = 0; index < length; index++) {
    var currentKey = _keys[index];
    results[currentKey] = iteratee2(obj2[currentKey], currentKey, obj2);
  }
  return results;
}
var init_mapObject = __esm({
  "node_modules/underscore/modules/mapObject.js"() {
    init_cb();
    init_keys();
  }
});

// node_modules/underscore/modules/noop.js
function noop() {
}
var init_noop = __esm({
  "node_modules/underscore/modules/noop.js"() {
  }
});

// node_modules/underscore/modules/propertyOf.js
function propertyOf(obj2) {
  if (obj2 == null) return noop;
  return function(path) {
    return get(obj2, path);
  };
}
var init_propertyOf = __esm({
  "node_modules/underscore/modules/propertyOf.js"() {
    init_noop();
    init_get();
  }
});

// node_modules/underscore/modules/times.js
function times(n, iteratee2, context) {
  var accum = Array(Math.max(0, n));
  iteratee2 = optimizeCb(iteratee2, context, 1);
  for (var i = 0; i < n; i++) accum[i] = iteratee2(i);
  return accum;
}
var init_times = __esm({
  "node_modules/underscore/modules/times.js"() {
    init_optimizeCb();
  }
});

// node_modules/underscore/modules/random.js
function random(min2, max2) {
  if (max2 == null) {
    max2 = min2;
    min2 = 0;
  }
  return min2 + Math.floor(Math.random() * (max2 - min2 + 1));
}
var init_random = __esm({
  "node_modules/underscore/modules/random.js"() {
  }
});

// node_modules/underscore/modules/now.js
var now_default;
var init_now = __esm({
  "node_modules/underscore/modules/now.js"() {
    now_default = Date.now || function() {
      return (/* @__PURE__ */ new Date()).getTime();
    };
  }
});

// node_modules/underscore/modules/_createEscaper.js
function createEscaper(map2) {
  var escaper = function(match) {
    return map2[match];
  };
  var source = "(?:" + keys(map2).join("|") + ")";
  var testRegexp = RegExp(source);
  var replaceRegexp = RegExp(source, "g");
  return function(string) {
    string = string == null ? "" : "" + string;
    return testRegexp.test(string) ? string.replace(replaceRegexp, escaper) : string;
  };
}
var init_createEscaper = __esm({
  "node_modules/underscore/modules/_createEscaper.js"() {
    init_keys();
  }
});

// node_modules/underscore/modules/_escapeMap.js
var escapeMap_default;
var init_escapeMap = __esm({
  "node_modules/underscore/modules/_escapeMap.js"() {
    escapeMap_default = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#x27;",
      "`": "&#x60;"
    };
  }
});

// node_modules/underscore/modules/escape.js
var escape_default;
var init_escape = __esm({
  "node_modules/underscore/modules/escape.js"() {
    init_createEscaper();
    init_escapeMap();
    escape_default = createEscaper(escapeMap_default);
  }
});

// node_modules/underscore/modules/_unescapeMap.js
var unescapeMap_default;
var init_unescapeMap = __esm({
  "node_modules/underscore/modules/_unescapeMap.js"() {
    init_invert();
    init_escapeMap();
    unescapeMap_default = invert(escapeMap_default);
  }
});

// node_modules/underscore/modules/unescape.js
var unescape_default;
var init_unescape = __esm({
  "node_modules/underscore/modules/unescape.js"() {
    init_createEscaper();
    init_unescapeMap();
    unescape_default = createEscaper(unescapeMap_default);
  }
});

// node_modules/underscore/modules/templateSettings.js
var templateSettings_default;
var init_templateSettings = __esm({
  "node_modules/underscore/modules/templateSettings.js"() {
    init_underscore();
    templateSettings_default = _.templateSettings = {
      evaluate: /<%([\s\S]+?)%>/g,
      interpolate: /<%=([\s\S]+?)%>/g,
      escape: /<%-([\s\S]+?)%>/g
    };
  }
});

// node_modules/underscore/modules/template.js
function escapeChar(match) {
  return "\\" + escapes[match];
}
function template(text, settings, oldSettings) {
  if (!settings && oldSettings) settings = oldSettings;
  settings = defaults_default({}, settings, _.templateSettings);
  var matcher2 = RegExp([(settings.escape || noMatch).source, (settings.interpolate || noMatch).source, (settings.evaluate || noMatch).source].join("|") + "|$", "g");
  var index = 0;
  var source = "__p+='";
  text.replace(matcher2, function(match, escape, interpolate, evaluate, offset) {
    source += text.slice(index, offset).replace(escapeRegExp, escapeChar);
    index = offset + match.length;
    if (escape) {
      source += "'+\n((__t=(" + escape + "))==null?'':_.escape(__t))+\n'";
    } else if (interpolate) {
      source += "'+\n((__t=(" + interpolate + "))==null?'':__t)+\n'";
    } else if (evaluate) {
      source += "';\n" + evaluate + "\n__p+='";
    }
    return match;
  });
  source += "';\n";
  var argument = settings.variable;
  if (argument) {
    if (!bareIdentifier.test(argument)) throw new Error("variable is not a bare identifier: " + argument);
  } else {
    source = "with(obj||{}){\n" + source + "}\n";
    argument = "obj";
  }
  source = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + source + "return __p;\n";
  var render;
  try {
    render = new Function(argument, "_", source);
  } catch (e) {
    e.source = source;
    throw e;
  }
  var template2 = function(data) {
    return render.call(this, data, _);
  };
  template2.source = "function(" + argument + "){\n" + source + "}";
  return template2;
}
var noMatch, escapes, escapeRegExp, bareIdentifier;
var init_template = __esm({
  "node_modules/underscore/modules/template.js"() {
    init_defaults();
    init_underscore();
    init_templateSettings();
    noMatch = /(.)^/;
    escapes = {
      "'": "'",
      "\\": "\\",
      "\r": "r",
      "\n": "n",
      "\u2028": "u2028",
      "\u2029": "u2029"
    };
    escapeRegExp = /\\|'|\r|\n|\u2028|\u2029/g;
    bareIdentifier = /^\s*(\w|\$)+\s*$/;
  }
});

// node_modules/underscore/modules/result.js
function result(obj2, path, fallback) {
  path = toPath2(path);
  var length = path.length;
  if (!length) {
    return isFunction_default(fallback) ? fallback.call(obj2) : fallback;
  }
  for (var i = 0; i < length; i++) {
    var prop = obj2 == null ? void 0 : obj2[path[i]];
    if (prop === void 0) {
      prop = fallback;
      i = length;
    }
    obj2 = isFunction_default(prop) ? prop.call(obj2) : prop;
  }
  return obj2;
}
var init_result = __esm({
  "node_modules/underscore/modules/result.js"() {
    init_isFunction();
    init_toPath2();
  }
});

// node_modules/underscore/modules/uniqueId.js
function uniqueId(prefix) {
  var id = ++idCounter + "";
  return prefix ? prefix + id : id;
}
var idCounter;
var init_uniqueId = __esm({
  "node_modules/underscore/modules/uniqueId.js"() {
    idCounter = 0;
  }
});

// node_modules/underscore/modules/chain.js
function chain(obj2) {
  var instance = _(obj2);
  instance._chain = true;
  return instance;
}
var init_chain = __esm({
  "node_modules/underscore/modules/chain.js"() {
    init_underscore();
  }
});

// node_modules/underscore/modules/_executeBound.js
function executeBound(sourceFunc, boundFunc, context, callingContext, args) {
  if (!(callingContext instanceof boundFunc)) return sourceFunc.apply(context, args);
  var self2 = baseCreate(sourceFunc.prototype);
  var result2 = sourceFunc.apply(self2, args);
  if (isObject2(result2)) return result2;
  return self2;
}
var init_executeBound = __esm({
  "node_modules/underscore/modules/_executeBound.js"() {
    init_baseCreate();
    init_isObject();
  }
});

// node_modules/underscore/modules/partial.js
var partial, partial_default;
var init_partial = __esm({
  "node_modules/underscore/modules/partial.js"() {
    init_restArguments();
    init_executeBound();
    init_underscore();
    partial = restArguments(function(func, boundArgs) {
      var placeholder = partial.placeholder;
      var bound = function() {
        var position = 0, length = boundArgs.length;
        var args = Array(length);
        for (var i = 0; i < length; i++) {
          args[i] = boundArgs[i] === placeholder ? arguments[position++] : boundArgs[i];
        }
        while (position < arguments.length) args.push(arguments[position++]);
        return executeBound(func, bound, this, this, args);
      };
      return bound;
    });
    partial.placeholder = _;
    partial_default = partial;
  }
});

// node_modules/underscore/modules/bind.js
var bind_default;
var init_bind = __esm({
  "node_modules/underscore/modules/bind.js"() {
    init_restArguments();
    init_isFunction();
    init_executeBound();
    bind_default = restArguments(function(func, context, args) {
      if (!isFunction_default(func)) throw new TypeError("Bind must be called on a function");
      var bound = restArguments(function(callArgs) {
        return executeBound(func, bound, context, this, args.concat(callArgs));
      });
      return bound;
    });
  }
});

// node_modules/underscore/modules/_isArrayLike.js
var isArrayLike_default;
var init_isArrayLike = __esm({
  "node_modules/underscore/modules/_isArrayLike.js"() {
    init_createSizePropertyCheck();
    init_getLength();
    isArrayLike_default = createSizePropertyCheck(getLength_default);
  }
});

// node_modules/underscore/modules/_flatten.js
function flatten(input, depth, strict, output) {
  output = output || [];
  if (!depth && depth !== 0) {
    depth = Infinity;
  } else if (depth <= 0) {
    return output.concat(input);
  }
  var idx = output.length;
  for (var i = 0, length = getLength_default(input); i < length; i++) {
    var value = input[i];
    if (isArrayLike_default(value) && (isArray_default(value) || isArguments_default(value))) {
      if (depth > 1) {
        flatten(value, depth - 1, strict, output);
        idx = output.length;
      } else {
        var j = 0, len = value.length;
        while (j < len) output[idx++] = value[j++];
      }
    } else if (!strict) {
      output[idx++] = value;
    }
  }
  return output;
}
var init_flatten = __esm({
  "node_modules/underscore/modules/_flatten.js"() {
    init_getLength();
    init_isArrayLike();
    init_isArray();
    init_isArguments();
  }
});

// node_modules/underscore/modules/bindAll.js
var bindAll_default;
var init_bindAll = __esm({
  "node_modules/underscore/modules/bindAll.js"() {
    init_restArguments();
    init_flatten();
    init_bind();
    bindAll_default = restArguments(function(obj2, keys2) {
      keys2 = flatten(keys2, false, false);
      var index = keys2.length;
      if (index < 1) throw new Error("bindAll must be passed function names");
      while (index--) {
        var key = keys2[index];
        obj2[key] = bind_default(obj2[key], obj2);
      }
      return obj2;
    });
  }
});

// node_modules/underscore/modules/memoize.js
function memoize(func, hasher) {
  var memoize2 = function(key) {
    var cache = memoize2.cache;
    var address = "" + (hasher ? hasher.apply(this, arguments) : key);
    if (!has(cache, address)) cache[address] = func.apply(this, arguments);
    return cache[address];
  };
  memoize2.cache = {};
  return memoize2;
}
var init_memoize = __esm({
  "node_modules/underscore/modules/memoize.js"() {
    init_has();
  }
});

// node_modules/underscore/modules/delay.js
var delay_default;
var init_delay = __esm({
  "node_modules/underscore/modules/delay.js"() {
    init_restArguments();
    delay_default = restArguments(function(func, wait, args) {
      return setTimeout(function() {
        return func.apply(null, args);
      }, wait);
    });
  }
});

// node_modules/underscore/modules/defer.js
var defer_default;
var init_defer = __esm({
  "node_modules/underscore/modules/defer.js"() {
    init_partial();
    init_delay();
    init_underscore();
    defer_default = partial_default(delay_default, _, 1);
  }
});

// node_modules/underscore/modules/throttle.js
function throttle(func, wait, options) {
  var timeout, context, args, result2;
  var previous = 0;
  if (!options) options = {};
  var later = function() {
    previous = options.leading === false ? 0 : now_default();
    timeout = null;
    result2 = func.apply(context, args);
    if (!timeout) context = args = null;
  };
  var throttled = function() {
    var _now = now_default();
    if (!previous && options.leading === false) previous = _now;
    var remaining = wait - (_now - previous);
    context = this;
    args = arguments;
    if (remaining <= 0 || remaining > wait) {
      if (timeout) {
        clearTimeout(timeout);
        timeout = null;
      }
      previous = _now;
      result2 = func.apply(context, args);
      if (!timeout) context = args = null;
    } else if (!timeout && options.trailing !== false) {
      timeout = setTimeout(later, remaining);
    }
    return result2;
  };
  throttled.cancel = function() {
    clearTimeout(timeout);
    previous = 0;
    timeout = context = args = null;
  };
  return throttled;
}
var init_throttle = __esm({
  "node_modules/underscore/modules/throttle.js"() {
    init_now();
  }
});

// node_modules/underscore/modules/debounce.js
function debounce(func, wait, immediate) {
  var timeout, previous, args, result2, context;
  var later = function() {
    var passed = now_default() - previous;
    if (wait > passed) {
      timeout = setTimeout(later, wait - passed);
    } else {
      timeout = null;
      if (!immediate) result2 = func.apply(context, args);
      if (!timeout) args = context = null;
    }
  };
  var debounced = restArguments(function(_args) {
    context = this;
    args = _args;
    previous = now_default();
    if (!timeout) {
      timeout = setTimeout(later, wait);
      if (immediate) result2 = func.apply(context, args);
    }
    return result2;
  });
  debounced.cancel = function() {
    clearTimeout(timeout);
    timeout = args = context = null;
  };
  return debounced;
}
var init_debounce = __esm({
  "node_modules/underscore/modules/debounce.js"() {
    init_restArguments();
    init_now();
  }
});

// node_modules/underscore/modules/wrap.js
function wrap(func, wrapper) {
  return partial_default(wrapper, func);
}
var init_wrap = __esm({
  "node_modules/underscore/modules/wrap.js"() {
    init_partial();
  }
});

// node_modules/underscore/modules/negate.js
function negate(predicate) {
  return function() {
    return !predicate.apply(this, arguments);
  };
}
var init_negate = __esm({
  "node_modules/underscore/modules/negate.js"() {
  }
});

// node_modules/underscore/modules/compose.js
function compose() {
  var args = arguments;
  var start = args.length - 1;
  return function() {
    var i = start;
    var result2 = args[start].apply(this, arguments);
    while (i--) result2 = args[i].call(this, result2);
    return result2;
  };
}
var init_compose = __esm({
  "node_modules/underscore/modules/compose.js"() {
  }
});

// node_modules/underscore/modules/after.js
function after(times2, func) {
  return function() {
    if (--times2 < 1) {
      return func.apply(this, arguments);
    }
  };
}
var init_after = __esm({
  "node_modules/underscore/modules/after.js"() {
  }
});

// node_modules/underscore/modules/before.js
function before(times2, func) {
  var memo;
  return function() {
    if (--times2 > 0) {
      memo = func.apply(this, arguments);
    }
    if (times2 <= 1) func = null;
    return memo;
  };
}
var init_before = __esm({
  "node_modules/underscore/modules/before.js"() {
  }
});

// node_modules/underscore/modules/once.js
var once_default;
var init_once = __esm({
  "node_modules/underscore/modules/once.js"() {
    init_partial();
    init_before();
    once_default = partial_default(before, 2);
  }
});

// node_modules/underscore/modules/findKey.js
function findKey(obj2, predicate, context) {
  predicate = cb(predicate, context);
  var _keys = keys(obj2), key;
  for (var i = 0, length = _keys.length; i < length; i++) {
    key = _keys[i];
    if (predicate(obj2[key], key, obj2)) return key;
  }
}
var init_findKey = __esm({
  "node_modules/underscore/modules/findKey.js"() {
    init_cb();
    init_keys();
  }
});

// node_modules/underscore/modules/_createPredicateIndexFinder.js
function createPredicateIndexFinder(dir) {
  return function(array, predicate, context) {
    predicate = cb(predicate, context);
    var length = getLength_default(array);
    var index = dir > 0 ? 0 : length - 1;
    for (; index >= 0 && index < length; index += dir) {
      if (predicate(array[index], index, array)) return index;
    }
    return -1;
  };
}
var init_createPredicateIndexFinder = __esm({
  "node_modules/underscore/modules/_createPredicateIndexFinder.js"() {
    init_cb();
    init_getLength();
  }
});

// node_modules/underscore/modules/findIndex.js
var findIndex_default;
var init_findIndex = __esm({
  "node_modules/underscore/modules/findIndex.js"() {
    init_createPredicateIndexFinder();
    findIndex_default = createPredicateIndexFinder(1);
  }
});

// node_modules/underscore/modules/findLastIndex.js
var findLastIndex_default;
var init_findLastIndex = __esm({
  "node_modules/underscore/modules/findLastIndex.js"() {
    init_createPredicateIndexFinder();
    findLastIndex_default = createPredicateIndexFinder(-1);
  }
});

// node_modules/underscore/modules/sortedIndex.js
function sortedIndex(array, obj2, iteratee2, context) {
  iteratee2 = cb(iteratee2, context, 1);
  var value = iteratee2(obj2);
  var low = 0, high = getLength_default(array);
  while (low < high) {
    var mid = Math.floor((low + high) / 2);
    if (iteratee2(array[mid]) < value) low = mid + 1;
    else high = mid;
  }
  return low;
}
var init_sortedIndex = __esm({
  "node_modules/underscore/modules/sortedIndex.js"() {
    init_cb();
    init_getLength();
  }
});

// node_modules/underscore/modules/_createIndexFinder.js
function createIndexFinder(dir, predicateFind, sortedIndex2) {
  return function(array, item, idx) {
    var i = 0, length = getLength_default(array);
    if (typeof idx == "number") {
      if (dir > 0) {
        i = idx >= 0 ? idx : Math.max(idx + length, i);
      } else {
        length = idx >= 0 ? Math.min(idx + 1, length) : idx + length + 1;
      }
    } else if (sortedIndex2 && idx && length) {
      idx = sortedIndex2(array, item);
      return array[idx] === item ? idx : -1;
    }
    if (item !== item) {
      idx = predicateFind(slice.call(array, i, length), isNaN2);
      return idx >= 0 ? idx + i : -1;
    }
    for (idx = dir > 0 ? i : length - 1; idx >= 0 && idx < length; idx += dir) {
      if (array[idx] === item) return idx;
    }
    return -1;
  };
}
var init_createIndexFinder = __esm({
  "node_modules/underscore/modules/_createIndexFinder.js"() {
    init_getLength();
    init_setup();
    init_isNaN();
  }
});

// node_modules/underscore/modules/indexOf.js
var indexOf_default;
var init_indexOf = __esm({
  "node_modules/underscore/modules/indexOf.js"() {
    init_sortedIndex();
    init_findIndex();
    init_createIndexFinder();
    indexOf_default = createIndexFinder(1, findIndex_default, sortedIndex);
  }
});

// node_modules/underscore/modules/lastIndexOf.js
var lastIndexOf_default;
var init_lastIndexOf = __esm({
  "node_modules/underscore/modules/lastIndexOf.js"() {
    init_findLastIndex();
    init_createIndexFinder();
    lastIndexOf_default = createIndexFinder(-1, findLastIndex_default);
  }
});

// node_modules/underscore/modules/find.js
function find(obj2, predicate, context) {
  var keyFinder = isArrayLike_default(obj2) ? findIndex_default : findKey;
  var key = keyFinder(obj2, predicate, context);
  if (key !== void 0 && key !== -1) return obj2[key];
}
var init_find = __esm({
  "node_modules/underscore/modules/find.js"() {
    init_isArrayLike();
    init_findIndex();
    init_findKey();
  }
});

// node_modules/underscore/modules/findWhere.js
function findWhere(obj2, attrs) {
  return find(obj2, matcher(attrs));
}
var init_findWhere = __esm({
  "node_modules/underscore/modules/findWhere.js"() {
    init_find();
    init_matcher();
  }
});

// node_modules/underscore/modules/each.js
function each(obj2, iteratee2, context) {
  iteratee2 = optimizeCb(iteratee2, context);
  var i, length;
  if (isArrayLike_default(obj2)) {
    for (i = 0, length = obj2.length; i < length; i++) {
      iteratee2(obj2[i], i, obj2);
    }
  } else {
    var _keys = keys(obj2);
    for (i = 0, length = _keys.length; i < length; i++) {
      iteratee2(obj2[_keys[i]], _keys[i], obj2);
    }
  }
  return obj2;
}
var init_each = __esm({
  "node_modules/underscore/modules/each.js"() {
    init_optimizeCb();
    init_isArrayLike();
    init_keys();
  }
});

// node_modules/underscore/modules/map.js
function map(obj2, iteratee2, context) {
  iteratee2 = cb(iteratee2, context);
  var _keys = !isArrayLike_default(obj2) && keys(obj2), length = (_keys || obj2).length, results = Array(length);
  for (var index = 0; index < length; index++) {
    var currentKey = _keys ? _keys[index] : index;
    results[index] = iteratee2(obj2[currentKey], currentKey, obj2);
  }
  return results;
}
var init_map = __esm({
  "node_modules/underscore/modules/map.js"() {
    init_cb();
    init_isArrayLike();
    init_keys();
  }
});

// node_modules/underscore/modules/_createReduce.js
function createReduce(dir) {
  var reducer = function(obj2, iteratee2, memo, initial2) {
    var _keys = !isArrayLike_default(obj2) && keys(obj2), length = (_keys || obj2).length, index = dir > 0 ? 0 : length - 1;
    if (!initial2) {
      memo = obj2[_keys ? _keys[index] : index];
      index += dir;
    }
    for (; index >= 0 && index < length; index += dir) {
      var currentKey = _keys ? _keys[index] : index;
      memo = iteratee2(memo, obj2[currentKey], currentKey, obj2);
    }
    return memo;
  };
  return function(obj2, iteratee2, memo, context) {
    var initial2 = arguments.length >= 3;
    return reducer(obj2, optimizeCb(iteratee2, context, 4), memo, initial2);
  };
}
var init_createReduce = __esm({
  "node_modules/underscore/modules/_createReduce.js"() {
    init_isArrayLike();
    init_keys();
    init_optimizeCb();
  }
});

// node_modules/underscore/modules/reduce.js
var reduce_default;
var init_reduce = __esm({
  "node_modules/underscore/modules/reduce.js"() {
    init_createReduce();
    reduce_default = createReduce(1);
  }
});

// node_modules/underscore/modules/reduceRight.js
var reduceRight_default;
var init_reduceRight = __esm({
  "node_modules/underscore/modules/reduceRight.js"() {
    init_createReduce();
    reduceRight_default = createReduce(-1);
  }
});

// node_modules/underscore/modules/filter.js
function filter(obj2, predicate, context) {
  var results = [];
  predicate = cb(predicate, context);
  each(obj2, function(value, index, list) {
    if (predicate(value, index, list)) results.push(value);
  });
  return results;
}
var init_filter = __esm({
  "node_modules/underscore/modules/filter.js"() {
    init_cb();
    init_each();
  }
});

// node_modules/underscore/modules/reject.js
function reject(obj2, predicate, context) {
  return filter(obj2, negate(cb(predicate)), context);
}
var init_reject = __esm({
  "node_modules/underscore/modules/reject.js"() {
    init_filter();
    init_negate();
    init_cb();
  }
});

// node_modules/underscore/modules/every.js
function every(obj2, predicate, context) {
  predicate = cb(predicate, context);
  var _keys = !isArrayLike_default(obj2) && keys(obj2), length = (_keys || obj2).length;
  for (var index = 0; index < length; index++) {
    var currentKey = _keys ? _keys[index] : index;
    if (!predicate(obj2[currentKey], currentKey, obj2)) return false;
  }
  return true;
}
var init_every = __esm({
  "node_modules/underscore/modules/every.js"() {
    init_cb();
    init_isArrayLike();
    init_keys();
  }
});

// node_modules/underscore/modules/some.js
function some(obj2, predicate, context) {
  predicate = cb(predicate, context);
  var _keys = !isArrayLike_default(obj2) && keys(obj2), length = (_keys || obj2).length;
  for (var index = 0; index < length; index++) {
    var currentKey = _keys ? _keys[index] : index;
    if (predicate(obj2[currentKey], currentKey, obj2)) return true;
  }
  return false;
}
var init_some = __esm({
  "node_modules/underscore/modules/some.js"() {
    init_cb();
    init_isArrayLike();
    init_keys();
  }
});

// node_modules/underscore/modules/contains.js
function contains(obj2, item, fromIndex, guard) {
  if (!isArrayLike_default(obj2)) obj2 = values(obj2);
  if (typeof fromIndex != "number" || guard) fromIndex = 0;
  return indexOf_default(obj2, item, fromIndex) >= 0;
}
var init_contains = __esm({
  "node_modules/underscore/modules/contains.js"() {
    init_isArrayLike();
    init_values();
    init_indexOf();
  }
});

// node_modules/underscore/modules/invoke.js
var invoke_default;
var init_invoke = __esm({
  "node_modules/underscore/modules/invoke.js"() {
    init_restArguments();
    init_isFunction();
    init_map();
    init_deepGet();
    init_toPath2();
    invoke_default = restArguments(function(obj2, path, args) {
      var contextPath, func;
      if (isFunction_default(path)) {
        func = path;
      } else {
        path = toPath2(path);
        contextPath = path.slice(0, -1);
        path = path[path.length - 1];
      }
      return map(obj2, function(context) {
        var method = func;
        if (!method) {
          if (contextPath && contextPath.length) {
            context = deepGet(context, contextPath);
          }
          if (context == null) return void 0;
          method = context[path];
        }
        return method == null ? method : method.apply(context, args);
      });
    });
  }
});

// node_modules/underscore/modules/pluck.js
function pluck(obj2, key) {
  return map(obj2, property(key));
}
var init_pluck = __esm({
  "node_modules/underscore/modules/pluck.js"() {
    init_map();
    init_property();
  }
});

// node_modules/underscore/modules/where.js
function where(obj2, attrs) {
  return filter(obj2, matcher(attrs));
}
var init_where = __esm({
  "node_modules/underscore/modules/where.js"() {
    init_filter();
    init_matcher();
  }
});

// node_modules/underscore/modules/max.js
function max(obj2, iteratee2, context) {
  var result2 = -Infinity, lastComputed = -Infinity, value, computed;
  if (iteratee2 == null || typeof iteratee2 == "number" && typeof obj2[0] != "object" && obj2 != null) {
    obj2 = isArrayLike_default(obj2) ? obj2 : values(obj2);
    for (var i = 0, length = obj2.length; i < length; i++) {
      value = obj2[i];
      if (value != null && value > result2) {
        result2 = value;
      }
    }
  } else {
    iteratee2 = cb(iteratee2, context);
    each(obj2, function(v, index, list) {
      computed = iteratee2(v, index, list);
      if (computed > lastComputed || computed === -Infinity && result2 === -Infinity) {
        result2 = v;
        lastComputed = computed;
      }
    });
  }
  return result2;
}
var init_max = __esm({
  "node_modules/underscore/modules/max.js"() {
    init_isArrayLike();
    init_values();
    init_cb();
    init_each();
  }
});

// node_modules/underscore/modules/min.js
function min(obj2, iteratee2, context) {
  var result2 = Infinity, lastComputed = Infinity, value, computed;
  if (iteratee2 == null || typeof iteratee2 == "number" && typeof obj2[0] != "object" && obj2 != null) {
    obj2 = isArrayLike_default(obj2) ? obj2 : values(obj2);
    for (var i = 0, length = obj2.length; i < length; i++) {
      value = obj2[i];
      if (value != null && value < result2) {
        result2 = value;
      }
    }
  } else {
    iteratee2 = cb(iteratee2, context);
    each(obj2, function(v, index, list) {
      computed = iteratee2(v, index, list);
      if (computed < lastComputed || computed === Infinity && result2 === Infinity) {
        result2 = v;
        lastComputed = computed;
      }
    });
  }
  return result2;
}
var init_min = __esm({
  "node_modules/underscore/modules/min.js"() {
    init_isArrayLike();
    init_values();
    init_cb();
    init_each();
  }
});

// node_modules/underscore/modules/toArray.js
function toArray(obj2) {
  if (!obj2) return [];
  if (isArray_default(obj2)) return slice.call(obj2);
  if (isString_default(obj2)) {
    return obj2.match(reStrSymbol);
  }
  if (isArrayLike_default(obj2)) return map(obj2, identity);
  return values(obj2);
}
var reStrSymbol;
var init_toArray = __esm({
  "node_modules/underscore/modules/toArray.js"() {
    init_isArray();
    init_setup();
    init_isString();
    init_isArrayLike();
    init_map();
    init_identity();
    init_values();
    reStrSymbol = /[^\ud800-\udfff]|[\ud800-\udbff][\udc00-\udfff]|[\ud800-\udfff]/g;
  }
});

// node_modules/underscore/modules/sample.js
function sample(obj2, n, guard) {
  if (n == null || guard) {
    if (!isArrayLike_default(obj2)) obj2 = values(obj2);
    return obj2[random(obj2.length - 1)];
  }
  var sample2 = toArray(obj2);
  var length = getLength_default(sample2);
  n = Math.max(Math.min(n, length), 0);
  var last2 = length - 1;
  for (var index = 0; index < n; index++) {
    var rand = random(index, last2);
    var temp = sample2[index];
    sample2[index] = sample2[rand];
    sample2[rand] = temp;
  }
  return sample2.slice(0, n);
}
var init_sample = __esm({
  "node_modules/underscore/modules/sample.js"() {
    init_isArrayLike();
    init_values();
    init_getLength();
    init_random();
    init_toArray();
  }
});

// node_modules/underscore/modules/shuffle.js
function shuffle(obj2) {
  return sample(obj2, Infinity);
}
var init_shuffle = __esm({
  "node_modules/underscore/modules/shuffle.js"() {
    init_sample();
  }
});

// node_modules/underscore/modules/sortBy.js
function sortBy(obj2, iteratee2, context) {
  var index = 0;
  iteratee2 = cb(iteratee2, context);
  return pluck(map(obj2, function(value, key, list) {
    return {
      value,
      index: index++,
      criteria: iteratee2(value, key, list)
    };
  }).sort(function(left, right) {
    var a = left.criteria;
    var b = right.criteria;
    if (a !== b) {
      if (a > b || a === void 0) return 1;
      if (a < b || b === void 0) return -1;
    }
    return left.index - right.index;
  }), "value");
}
var init_sortBy = __esm({
  "node_modules/underscore/modules/sortBy.js"() {
    init_cb();
    init_pluck();
    init_map();
  }
});

// node_modules/underscore/modules/_group.js
function group(behavior, partition) {
  return function(obj2, iteratee2, context) {
    var result2 = partition ? [[], []] : {};
    iteratee2 = cb(iteratee2, context);
    each(obj2, function(value, index) {
      var key = iteratee2(value, index, obj2);
      behavior(result2, value, key);
    });
    return result2;
  };
}
var init_group = __esm({
  "node_modules/underscore/modules/_group.js"() {
    init_cb();
    init_each();
  }
});

// node_modules/underscore/modules/groupBy.js
var groupBy_default;
var init_groupBy = __esm({
  "node_modules/underscore/modules/groupBy.js"() {
    init_group();
    init_has();
    groupBy_default = group(function(result2, value, key) {
      if (has(result2, key)) result2[key].push(value);
      else result2[key] = [value];
    });
  }
});

// node_modules/underscore/modules/indexBy.js
var indexBy_default;
var init_indexBy = __esm({
  "node_modules/underscore/modules/indexBy.js"() {
    init_group();
    indexBy_default = group(function(result2, value, key) {
      result2[key] = value;
    });
  }
});

// node_modules/underscore/modules/countBy.js
var countBy_default;
var init_countBy = __esm({
  "node_modules/underscore/modules/countBy.js"() {
    init_group();
    init_has();
    countBy_default = group(function(result2, value, key) {
      if (has(result2, key)) result2[key]++;
      else result2[key] = 1;
    });
  }
});

// node_modules/underscore/modules/partition.js
var partition_default;
var init_partition = __esm({
  "node_modules/underscore/modules/partition.js"() {
    init_group();
    partition_default = group(function(result2, value, pass) {
      result2[pass ? 0 : 1].push(value);
    }, true);
  }
});

// node_modules/underscore/modules/size.js
function size(obj2) {
  if (obj2 == null) return 0;
  return isArrayLike_default(obj2) ? obj2.length : keys(obj2).length;
}
var init_size = __esm({
  "node_modules/underscore/modules/size.js"() {
    init_isArrayLike();
    init_keys();
  }
});

// node_modules/underscore/modules/_keyInObj.js
function keyInObj(value, key, obj2) {
  return key in obj2;
}
var init_keyInObj = __esm({
  "node_modules/underscore/modules/_keyInObj.js"() {
  }
});

// node_modules/underscore/modules/pick.js
var pick_default;
var init_pick = __esm({
  "node_modules/underscore/modules/pick.js"() {
    init_restArguments();
    init_isFunction();
    init_optimizeCb();
    init_allKeys();
    init_keyInObj();
    init_flatten();
    pick_default = restArguments(function(obj2, keys2) {
      var result2 = {}, iteratee2 = keys2[0];
      if (obj2 == null) return result2;
      if (isFunction_default(iteratee2)) {
        if (keys2.length > 1) iteratee2 = optimizeCb(iteratee2, keys2[1]);
        keys2 = allKeys(obj2);
      } else {
        iteratee2 = keyInObj;
        keys2 = flatten(keys2, false, false);
        obj2 = Object(obj2);
      }
      for (var i = 0, length = keys2.length; i < length; i++) {
        var key = keys2[i];
        var value = obj2[key];
        if (iteratee2(value, key, obj2)) result2[key] = value;
      }
      return result2;
    });
  }
});

// node_modules/underscore/modules/omit.js
var omit_default;
var init_omit = __esm({
  "node_modules/underscore/modules/omit.js"() {
    init_restArguments();
    init_isFunction();
    init_negate();
    init_map();
    init_flatten();
    init_contains();
    init_pick();
    omit_default = restArguments(function(obj2, keys2) {
      var iteratee2 = keys2[0], context;
      if (isFunction_default(iteratee2)) {
        iteratee2 = negate(iteratee2);
        if (keys2.length > 1) context = keys2[1];
      } else {
        keys2 = map(flatten(keys2, false, false), String);
        iteratee2 = function(value, key) {
          return !contains(keys2, key);
        };
      }
      return pick_default(obj2, iteratee2, context);
    });
  }
});

// node_modules/underscore/modules/initial.js
function initial(array, n, guard) {
  return slice.call(array, 0, Math.max(0, array.length - (n == null || guard ? 1 : n)));
}
var init_initial = __esm({
  "node_modules/underscore/modules/initial.js"() {
    init_setup();
  }
});

// node_modules/underscore/modules/first.js
function first(array, n, guard) {
  if (array == null || array.length < 1) return n == null || guard ? void 0 : [];
  if (n == null || guard) return array[0];
  return initial(array, array.length - n);
}
var init_first = __esm({
  "node_modules/underscore/modules/first.js"() {
    init_initial();
  }
});

// node_modules/underscore/modules/rest.js
function rest(array, n, guard) {
  return slice.call(array, n == null || guard ? 1 : n);
}
var init_rest = __esm({
  "node_modules/underscore/modules/rest.js"() {
    init_setup();
  }
});

// node_modules/underscore/modules/last.js
function last(array, n, guard) {
  if (array == null || array.length < 1) return n == null || guard ? void 0 : [];
  if (n == null || guard) return array[array.length - 1];
  return rest(array, Math.max(0, array.length - n));
}
var init_last = __esm({
  "node_modules/underscore/modules/last.js"() {
    init_rest();
  }
});

// node_modules/underscore/modules/compact.js
function compact(array) {
  return filter(array, Boolean);
}
var init_compact = __esm({
  "node_modules/underscore/modules/compact.js"() {
    init_filter();
  }
});

// node_modules/underscore/modules/flatten.js
function flatten2(array, depth) {
  return flatten(array, depth, false);
}
var init_flatten2 = __esm({
  "node_modules/underscore/modules/flatten.js"() {
    init_flatten();
  }
});

// node_modules/underscore/modules/difference.js
var difference_default;
var init_difference = __esm({
  "node_modules/underscore/modules/difference.js"() {
    init_restArguments();
    init_flatten();
    init_filter();
    init_contains();
    difference_default = restArguments(function(array, rest2) {
      rest2 = flatten(rest2, true, true);
      return filter(array, function(value) {
        return !contains(rest2, value);
      });
    });
  }
});

// node_modules/underscore/modules/without.js
var without_default;
var init_without = __esm({
  "node_modules/underscore/modules/without.js"() {
    init_restArguments();
    init_difference();
    without_default = restArguments(function(array, otherArrays) {
      return difference_default(array, otherArrays);
    });
  }
});

// node_modules/underscore/modules/uniq.js
function uniq(array, isSorted, iteratee2, context) {
  if (!isBoolean(isSorted)) {
    context = iteratee2;
    iteratee2 = isSorted;
    isSorted = false;
  }
  if (iteratee2 != null) iteratee2 = cb(iteratee2, context);
  var result2 = [];
  var seen = [];
  for (var i = 0, length = getLength_default(array); i < length; i++) {
    var value = array[i], computed = iteratee2 ? iteratee2(value, i, array) : value;
    if (isSorted && !iteratee2) {
      if (!i || seen !== computed) result2.push(value);
      seen = computed;
    } else if (iteratee2) {
      if (!contains(seen, computed)) {
        seen.push(computed);
        result2.push(value);
      }
    } else if (!contains(result2, value)) {
      result2.push(value);
    }
  }
  return result2;
}
var init_uniq = __esm({
  "node_modules/underscore/modules/uniq.js"() {
    init_isBoolean();
    init_cb();
    init_getLength();
    init_contains();
  }
});

// node_modules/underscore/modules/union.js
var union_default;
var init_union = __esm({
  "node_modules/underscore/modules/union.js"() {
    init_restArguments();
    init_uniq();
    init_flatten();
    union_default = restArguments(function(arrays) {
      return uniq(flatten(arrays, true, true));
    });
  }
});

// node_modules/underscore/modules/intersection.js
function intersection(array) {
  var result2 = [];
  var argsLength = arguments.length;
  for (var i = 0, length = getLength_default(array); i < length; i++) {
    var item = array[i];
    if (contains(result2, item)) continue;
    var j;
    for (j = 1; j < argsLength; j++) {
      if (!contains(arguments[j], item)) break;
    }
    if (j === argsLength) result2.push(item);
  }
  return result2;
}
var init_intersection = __esm({
  "node_modules/underscore/modules/intersection.js"() {
    init_getLength();
    init_contains();
  }
});

// node_modules/underscore/modules/unzip.js
function unzip(array) {
  var length = array && max(array, getLength_default).length || 0;
  var result2 = Array(length);
  for (var index = 0; index < length; index++) {
    result2[index] = pluck(array, index);
  }
  return result2;
}
var init_unzip = __esm({
  "node_modules/underscore/modules/unzip.js"() {
    init_max();
    init_getLength();
    init_pluck();
  }
});

// node_modules/underscore/modules/zip.js
var zip_default;
var init_zip = __esm({
  "node_modules/underscore/modules/zip.js"() {
    init_restArguments();
    init_unzip();
    zip_default = restArguments(unzip);
  }
});

// node_modules/underscore/modules/object.js
function object(list, values2) {
  var result2 = {};
  for (var i = 0, length = getLength_default(list); i < length; i++) {
    if (values2) {
      result2[list[i]] = values2[i];
    } else {
      result2[list[i][0]] = list[i][1];
    }
  }
  return result2;
}
var init_object = __esm({
  "node_modules/underscore/modules/object.js"() {
    init_getLength();
  }
});

// node_modules/underscore/modules/range.js
function range(start, stop, step) {
  if (stop == null) {
    stop = start || 0;
    start = 0;
  }
  if (!step) {
    step = stop < start ? -1 : 1;
  }
  var length = Math.max(Math.ceil((stop - start) / step), 0);
  var range2 = Array(length);
  for (var idx = 0; idx < length; idx++, start += step) {
    range2[idx] = start;
  }
  return range2;
}
var init_range = __esm({
  "node_modules/underscore/modules/range.js"() {
  }
});

// node_modules/underscore/modules/chunk.js
function chunk(array, count) {
  if (count == null || count < 1) return [];
  var result2 = [];
  var i = 0, length = array.length;
  while (i < length) {
    result2.push(slice.call(array, i, i += count));
  }
  return result2;
}
var init_chunk = __esm({
  "node_modules/underscore/modules/chunk.js"() {
    init_setup();
  }
});

// node_modules/underscore/modules/_chainResult.js
function chainResult(instance, obj2) {
  return instance._chain ? _(obj2).chain() : obj2;
}
var init_chainResult = __esm({
  "node_modules/underscore/modules/_chainResult.js"() {
    init_underscore();
  }
});

// node_modules/underscore/modules/mixin.js
function mixin(obj2) {
  each(functions(obj2), function(name) {
    var func = _[name] = obj2[name];
    _.prototype[name] = function() {
      var args = [this._wrapped];
      push.apply(args, arguments);
      return chainResult(this, func.apply(_, args));
    };
  });
  return _;
}
var init_mixin = __esm({
  "node_modules/underscore/modules/mixin.js"() {
    init_underscore();
    init_each();
    init_functions();
    init_setup();
    init_chainResult();
  }
});

// node_modules/underscore/modules/underscore-array-methods.js
var underscore_array_methods_default;
var init_underscore_array_methods = __esm({
  "node_modules/underscore/modules/underscore-array-methods.js"() {
    init_underscore();
    init_each();
    init_setup();
    init_chainResult();
    each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(name) {
      var method = ArrayProto[name];
      _.prototype[name] = function() {
        var obj2 = this._wrapped;
        if (obj2 != null) {
          method.apply(obj2, arguments);
          if ((name === "shift" || name === "splice") && obj2.length === 0) {
            delete obj2[0];
          }
        }
        return chainResult(this, obj2);
      };
    });
    each(["concat", "join", "slice"], function(name) {
      var method = ArrayProto[name];
      _.prototype[name] = function() {
        var obj2 = this._wrapped;
        if (obj2 != null) obj2 = method.apply(obj2, arguments);
        return chainResult(this, obj2);
      };
    });
    underscore_array_methods_default = _;
  }
});

// node_modules/underscore/modules/index.js
var modules_exports = {};
__export(modules_exports, {
  VERSION: () => VERSION,
  after: () => after,
  all: () => every,
  allKeys: () => allKeys,
  any: () => some,
  assign: () => extendOwn_default,
  before: () => before,
  bind: () => bind_default,
  bindAll: () => bindAll_default,
  chain: () => chain,
  chunk: () => chunk,
  clone: () => clone,
  collect: () => map,
  compact: () => compact,
  compose: () => compose,
  constant: () => constant,
  contains: () => contains,
  countBy: () => countBy_default,
  create: () => create,
  debounce: () => debounce,
  default: () => underscore_array_methods_default,
  defaults: () => defaults_default,
  defer: () => defer_default,
  delay: () => delay_default,
  detect: () => find,
  difference: () => difference_default,
  drop: () => rest,
  each: () => each,
  escape: () => escape_default,
  every: () => every,
  extend: () => extend_default,
  extendOwn: () => extendOwn_default,
  filter: () => filter,
  find: () => find,
  findIndex: () => findIndex_default,
  findKey: () => findKey,
  findLastIndex: () => findLastIndex_default,
  findWhere: () => findWhere,
  first: () => first,
  flatten: () => flatten2,
  foldl: () => reduce_default,
  foldr: () => reduceRight_default,
  forEach: () => each,
  functions: () => functions,
  get: () => get,
  groupBy: () => groupBy_default,
  has: () => has2,
  head: () => first,
  identity: () => identity,
  include: () => contains,
  includes: () => contains,
  indexBy: () => indexBy_default,
  indexOf: () => indexOf_default,
  initial: () => initial,
  inject: () => reduce_default,
  intersection: () => intersection,
  invert: () => invert,
  invoke: () => invoke_default,
  isArguments: () => isArguments_default,
  isArray: () => isArray_default,
  isArrayBuffer: () => isArrayBuffer_default,
  isBoolean: () => isBoolean,
  isDataView: () => isDataView_default,
  isDate: () => isDate_default,
  isElement: () => isElement,
  isEmpty: () => isEmpty,
  isEqual: () => isEqual,
  isError: () => isError_default,
  isFinite: () => isFinite2,
  isFunction: () => isFunction_default,
  isMap: () => isMap_default,
  isMatch: () => isMatch,
  isNaN: () => isNaN2,
  isNull: () => isNull,
  isNumber: () => isNumber_default,
  isObject: () => isObject2,
  isRegExp: () => isRegExp_default,
  isSet: () => isSet_default,
  isString: () => isString_default,
  isSymbol: () => isSymbol_default,
  isTypedArray: () => isTypedArray_default,
  isUndefined: () => isUndefined,
  isWeakMap: () => isWeakMap_default,
  isWeakSet: () => isWeakSet_default,
  iteratee: () => iteratee,
  keys: () => keys,
  last: () => last,
  lastIndexOf: () => lastIndexOf_default,
  map: () => map,
  mapObject: () => mapObject,
  matcher: () => matcher,
  matches: () => matcher,
  max: () => max,
  memoize: () => memoize,
  methods: () => functions,
  min: () => min,
  mixin: () => mixin,
  negate: () => negate,
  noop: () => noop,
  now: () => now_default,
  object: () => object,
  omit: () => omit_default,
  once: () => once_default,
  pairs: () => pairs,
  partial: () => partial_default,
  partition: () => partition_default,
  pick: () => pick_default,
  pluck: () => pluck,
  property: () => property,
  propertyOf: () => propertyOf,
  random: () => random,
  range: () => range,
  reduce: () => reduce_default,
  reduceRight: () => reduceRight_default,
  reject: () => reject,
  rest: () => rest,
  restArguments: () => restArguments,
  result: () => result,
  sample: () => sample,
  select: () => filter,
  shuffle: () => shuffle,
  size: () => size,
  some: () => some,
  sortBy: () => sortBy,
  sortedIndex: () => sortedIndex,
  tail: () => rest,
  take: () => first,
  tap: () => tap,
  template: () => template,
  templateSettings: () => templateSettings_default,
  throttle: () => throttle,
  times: () => times,
  toArray: () => toArray,
  toPath: () => toPath,
  transpose: () => unzip,
  unescape: () => unescape_default,
  union: () => union_default,
  uniq: () => uniq,
  unique: () => uniq,
  uniqueId: () => uniqueId,
  unzip: () => unzip,
  values: () => values,
  where: () => where,
  without: () => without_default,
  wrap: () => wrap,
  zip: () => zip_default
});
var init_modules = __esm({
  "node_modules/underscore/modules/index.js"() {
    init_setup();
    init_restArguments();
    init_isObject();
    init_isNull();
    init_isUndefined();
    init_isBoolean();
    init_isElement();
    init_isString();
    init_isNumber();
    init_isDate();
    init_isRegExp();
    init_isError();
    init_isSymbol();
    init_isArrayBuffer();
    init_isDataView();
    init_isArray();
    init_isFunction();
    init_isArguments();
    init_isFinite();
    init_isNaN();
    init_isTypedArray();
    init_isEmpty();
    init_isMatch();
    init_isEqual();
    init_isMap();
    init_isWeakMap();
    init_isSet();
    init_isWeakSet();
    init_keys();
    init_allKeys();
    init_values();
    init_pairs();
    init_invert();
    init_functions();
    init_extend();
    init_extendOwn();
    init_defaults();
    init_create();
    init_clone();
    init_tap();
    init_get();
    init_has2();
    init_mapObject();
    init_identity();
    init_constant();
    init_noop();
    init_toPath();
    init_property();
    init_propertyOf();
    init_matcher();
    init_times();
    init_random();
    init_now();
    init_escape();
    init_unescape();
    init_templateSettings();
    init_template();
    init_result();
    init_uniqueId();
    init_chain();
    init_iteratee();
    init_partial();
    init_bind();
    init_bindAll();
    init_memoize();
    init_delay();
    init_defer();
    init_throttle();
    init_debounce();
    init_wrap();
    init_negate();
    init_compose();
    init_after();
    init_before();
    init_once();
    init_findKey();
    init_findIndex();
    init_findLastIndex();
    init_sortedIndex();
    init_indexOf();
    init_lastIndexOf();
    init_find();
    init_findWhere();
    init_each();
    init_map();
    init_reduce();
    init_reduceRight();
    init_filter();
    init_reject();
    init_every();
    init_some();
    init_contains();
    init_invoke();
    init_pluck();
    init_where();
    init_max();
    init_min();
    init_shuffle();
    init_sample();
    init_sortBy();
    init_groupBy();
    init_indexBy();
    init_countBy();
    init_partition();
    init_toArray();
    init_size();
    init_pick();
    init_omit();
    init_first();
    init_initial();
    init_last();
    init_rest();
    init_compact();
    init_flatten2();
    init_without();
    init_uniq();
    init_union();
    init_intersection();
    init_difference();
    init_unzip();
    init_zip();
    init_object();
    init_range();
    init_chunk();
    init_mixin();
    init_underscore_array_methods();
  }
});

// node_modules/underscore/modules/index-default.js
var _2, index_default_default;
var init_index_default = __esm({
  "node_modules/underscore/modules/index-default.js"() {
    init_modules();
    init_modules();
    _2 = mixin(modules_exports);
    _2._ = _2;
    index_default_default = _2;
  }
});

// node_modules/underscore/modules/index-all.js
var index_all_exports = {};
__export(index_all_exports, {
  VERSION: () => VERSION,
  after: () => after,
  all: () => every,
  allKeys: () => allKeys,
  any: () => some,
  assign: () => extendOwn_default,
  before: () => before,
  bind: () => bind_default,
  bindAll: () => bindAll_default,
  chain: () => chain,
  chunk: () => chunk,
  clone: () => clone,
  collect: () => map,
  compact: () => compact,
  compose: () => compose,
  constant: () => constant,
  contains: () => contains,
  countBy: () => countBy_default,
  create: () => create,
  debounce: () => debounce,
  default: () => index_default_default,
  defaults: () => defaults_default,
  defer: () => defer_default,
  delay: () => delay_default,
  detect: () => find,
  difference: () => difference_default,
  drop: () => rest,
  each: () => each,
  escape: () => escape_default,
  every: () => every,
  extend: () => extend_default,
  extendOwn: () => extendOwn_default,
  filter: () => filter,
  find: () => find,
  findIndex: () => findIndex_default,
  findKey: () => findKey,
  findLastIndex: () => findLastIndex_default,
  findWhere: () => findWhere,
  first: () => first,
  flatten: () => flatten2,
  foldl: () => reduce_default,
  foldr: () => reduceRight_default,
  forEach: () => each,
  functions: () => functions,
  get: () => get,
  groupBy: () => groupBy_default,
  has: () => has2,
  head: () => first,
  identity: () => identity,
  include: () => contains,
  includes: () => contains,
  indexBy: () => indexBy_default,
  indexOf: () => indexOf_default,
  initial: () => initial,
  inject: () => reduce_default,
  intersection: () => intersection,
  invert: () => invert,
  invoke: () => invoke_default,
  isArguments: () => isArguments_default,
  isArray: () => isArray_default,
  isArrayBuffer: () => isArrayBuffer_default,
  isBoolean: () => isBoolean,
  isDataView: () => isDataView_default,
  isDate: () => isDate_default,
  isElement: () => isElement,
  isEmpty: () => isEmpty,
  isEqual: () => isEqual,
  isError: () => isError_default,
  isFinite: () => isFinite2,
  isFunction: () => isFunction_default,
  isMap: () => isMap_default,
  isMatch: () => isMatch,
  isNaN: () => isNaN2,
  isNull: () => isNull,
  isNumber: () => isNumber_default,
  isObject: () => isObject2,
  isRegExp: () => isRegExp_default,
  isSet: () => isSet_default,
  isString: () => isString_default,
  isSymbol: () => isSymbol_default,
  isTypedArray: () => isTypedArray_default,
  isUndefined: () => isUndefined,
  isWeakMap: () => isWeakMap_default,
  isWeakSet: () => isWeakSet_default,
  iteratee: () => iteratee,
  keys: () => keys,
  last: () => last,
  lastIndexOf: () => lastIndexOf_default,
  map: () => map,
  mapObject: () => mapObject,
  matcher: () => matcher,
  matches: () => matcher,
  max: () => max,
  memoize: () => memoize,
  methods: () => functions,
  min: () => min,
  mixin: () => mixin,
  negate: () => negate,
  noop: () => noop,
  now: () => now_default,
  object: () => object,
  omit: () => omit_default,
  once: () => once_default,
  pairs: () => pairs,
  partial: () => partial_default,
  partition: () => partition_default,
  pick: () => pick_default,
  pluck: () => pluck,
  property: () => property,
  propertyOf: () => propertyOf,
  random: () => random,
  range: () => range,
  reduce: () => reduce_default,
  reduceRight: () => reduceRight_default,
  reject: () => reject,
  rest: () => rest,
  restArguments: () => restArguments,
  result: () => result,
  sample: () => sample,
  select: () => filter,
  shuffle: () => shuffle,
  size: () => size,
  some: () => some,
  sortBy: () => sortBy,
  sortedIndex: () => sortedIndex,
  tail: () => rest,
  take: () => first,
  tap: () => tap,
  template: () => template,
  templateSettings: () => templateSettings_default,
  throttle: () => throttle,
  times: () => times,
  toArray: () => toArray,
  toPath: () => toPath,
  transpose: () => unzip,
  unescape: () => unescape_default,
  union: () => union_default,
  uniq: () => uniq,
  unique: () => uniq,
  uniqueId: () => uniqueId,
  unzip: () => unzip,
  values: () => values,
  where: () => where,
  without: () => without_default,
  wrap: () => wrap,
  zip: () => zip_default
});
var init_index_all = __esm({
  "node_modules/underscore/modules/index-all.js"() {
    init_index_default();
    init_modules();
  }
});

// node_modules/bluebird/js/release/es5.js
var require_es5 = __commonJS({
  "node_modules/bluebird/js/release/es5.js"(exports2, module2) {
    var isES5 = function() {
      "use strict";
      return this === void 0;
    }();
    if (isES5) {
      module2.exports = {
        freeze: Object.freeze,
        defineProperty: Object.defineProperty,
        getDescriptor: Object.getOwnPropertyDescriptor,
        keys: Object.keys,
        names: Object.getOwnPropertyNames,
        getPrototypeOf: Object.getPrototypeOf,
        isArray: Array.isArray,
        isES5,
        propertyIsWritable: function(obj2, prop) {
          var descriptor = Object.getOwnPropertyDescriptor(obj2, prop);
          return !!(!descriptor || descriptor.writable || descriptor.set);
        }
      };
    } else {
      has3 = {}.hasOwnProperty;
      str = {}.toString;
      proto = {}.constructor.prototype;
      ObjectKeys = function(o) {
        var ret2 = [];
        for (var key in o) {
          if (has3.call(o, key)) {
            ret2.push(key);
          }
        }
        return ret2;
      };
      ObjectGetDescriptor = function(o, key) {
        return {
          value: o[key]
        };
      };
      ObjectDefineProperty = function(o, key, desc) {
        o[key] = desc.value;
        return o;
      };
      ObjectFreeze = function(obj2) {
        return obj2;
      };
      ObjectGetPrototypeOf = function(obj2) {
        try {
          return Object(obj2).constructor.prototype;
        } catch (e) {
          return proto;
        }
      };
      ArrayIsArray = function(obj2) {
        try {
          return str.call(obj2) === "[object Array]";
        } catch (e) {
          return false;
        }
      };
      module2.exports = {
        isArray: ArrayIsArray,
        keys: ObjectKeys,
        names: ObjectKeys,
        defineProperty: ObjectDefineProperty,
        getDescriptor: ObjectGetDescriptor,
        freeze: ObjectFreeze,
        getPrototypeOf: ObjectGetPrototypeOf,
        isES5,
        propertyIsWritable: function() {
          return true;
        }
      };
    }
    var has3;
    var str;
    var proto;
    var ObjectKeys;
    var ObjectGetDescriptor;
    var ObjectDefineProperty;
    var ObjectFreeze;
    var ObjectGetPrototypeOf;
    var ArrayIsArray;
  }
});

// node_modules/bluebird/js/release/util.js
var require_util = __commonJS({
  "node_modules/bluebird/js/release/util.js"(exports, module) {
    "use strict";
    var es5 = require_es5();
    var canEvaluate = typeof navigator == "undefined";
    var errorObj = {
      e: {}
    };
    var tryCatchTarget;
    var globalObject = typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : exports !== void 0 ? exports : null;
    function tryCatcher() {
      try {
        var target = tryCatchTarget;
        tryCatchTarget = null;
        return target.apply(this, arguments);
      } catch (e) {
        errorObj.e = e;
        return errorObj;
      }
    }
    function tryCatch(fn) {
      tryCatchTarget = fn;
      return tryCatcher;
    }
    var inherits = function(Child, Parent) {
      var hasProp = {}.hasOwnProperty;
      function T() {
        this.constructor = Child;
        this.constructor$ = Parent;
        for (var propertyName in Parent.prototype) {
          if (hasProp.call(Parent.prototype, propertyName) && propertyName.charAt(propertyName.length - 1) !== "$") {
            this[propertyName + "$"] = Parent.prototype[propertyName];
          }
        }
      }
      T.prototype = Parent.prototype;
      Child.prototype = new T();
      return Child.prototype;
    };
    function isPrimitive(val) {
      return val == null || val === true || val === false || typeof val === "string" || typeof val === "number";
    }
    function isObject(value) {
      return typeof value === "function" || typeof value === "object" && value !== null;
    }
    function maybeWrapAsError(maybeError) {
      if (!isPrimitive(maybeError)) return maybeError;
      return new Error(safeToString(maybeError));
    }
    function withAppended(target, appendee) {
      var len = target.length;
      var ret2 = new Array(len + 1);
      var i;
      for (i = 0; i < len; ++i) {
        ret2[i] = target[i];
      }
      ret2[i] = appendee;
      return ret2;
    }
    function getDataPropertyOrDefault(obj2, key, defaultValue) {
      if (es5.isES5) {
        var desc = Object.getOwnPropertyDescriptor(obj2, key);
        if (desc != null) {
          return desc.get == null && desc.set == null ? desc.value : defaultValue;
        }
      } else {
        return {}.hasOwnProperty.call(obj2, key) ? obj2[key] : void 0;
      }
    }
    function notEnumerableProp(obj2, name, value) {
      if (isPrimitive(obj2)) return obj2;
      var descriptor = {
        value,
        configurable: true,
        enumerable: false,
        writable: true
      };
      es5.defineProperty(obj2, name, descriptor);
      return obj2;
    }
    function thrower(r) {
      throw r;
    }
    var inheritedDataKeys = function() {
      var excludedPrototypes = [Array.prototype, Object.prototype, Function.prototype];
      var isExcludedProto = function(val) {
        for (var i = 0; i < excludedPrototypes.length; ++i) {
          if (excludedPrototypes[i] === val) {
            return true;
          }
        }
        return false;
      };
      if (es5.isES5) {
        var getKeys = Object.getOwnPropertyNames;
        return function(obj2) {
          var ret2 = [];
          var visitedKeys = /* @__PURE__ */ Object.create(null);
          while (obj2 != null && !isExcludedProto(obj2)) {
            var keys2;
            try {
              keys2 = getKeys(obj2);
            } catch (e) {
              return ret2;
            }
            for (var i = 0; i < keys2.length; ++i) {
              var key = keys2[i];
              if (visitedKeys[key]) continue;
              visitedKeys[key] = true;
              var desc = Object.getOwnPropertyDescriptor(obj2, key);
              if (desc != null && desc.get == null && desc.set == null) {
                ret2.push(key);
              }
            }
            obj2 = es5.getPrototypeOf(obj2);
          }
          return ret2;
        };
      } else {
        var hasProp = {}.hasOwnProperty;
        return function(obj2) {
          if (isExcludedProto(obj2)) return [];
          var ret2 = [];
          enumeration: for (var key in obj2) {
            if (hasProp.call(obj2, key)) {
              ret2.push(key);
            } else {
              for (var i = 0; i < excludedPrototypes.length; ++i) {
                if (hasProp.call(excludedPrototypes[i], key)) {
                  continue enumeration;
                }
              }
              ret2.push(key);
            }
          }
          return ret2;
        };
      }
    }();
    var thisAssignmentPattern = /this\s*\.\s*\S+\s*=/;
    function isClass(fn) {
      try {
        if (typeof fn === "function") {
          var keys2 = es5.names(fn.prototype);
          var hasMethods = es5.isES5 && keys2.length > 1;
          var hasMethodsOtherThanConstructor = keys2.length > 0 && !(keys2.length === 1 && keys2[0] === "constructor");
          var hasThisAssignmentAndStaticMethods = thisAssignmentPattern.test(fn + "") && es5.names(fn).length > 0;
          if (hasMethods || hasMethodsOtherThanConstructor || hasThisAssignmentAndStaticMethods) {
            return true;
          }
        }
        return false;
      } catch (e) {
        return false;
      }
    }
    function toFastProperties(obj) {
      function FakeConstructor() {
      }
      FakeConstructor.prototype = obj;
      var l = 8;
      while (l--) new FakeConstructor();
      return obj;
      eval(obj);
    }
    var rident = /^[a-z$_][a-z$_0-9]*$/i;
    function isIdentifier(str) {
      return rident.test(str);
    }
    function filledRange(count, prefix, suffix) {
      var ret2 = new Array(count);
      for (var i = 0; i < count; ++i) {
        ret2[i] = prefix + i + suffix;
      }
      return ret2;
    }
    function safeToString(obj2) {
      try {
        return obj2 + "";
      } catch (e) {
        return "[no string representation]";
      }
    }
    function isError(obj2) {
      return obj2 !== null && typeof obj2 === "object" && typeof obj2.message === "string" && typeof obj2.name === "string";
    }
    function markAsOriginatingFromRejection(e) {
      try {
        notEnumerableProp(e, "isOperational", true);
      } catch (ignore) {
      }
    }
    function originatesFromRejection(e) {
      if (e == null) return false;
      return e instanceof Error["__BluebirdErrorTypes__"].OperationalError || e["isOperational"] === true;
    }
    function canAttachTrace(obj2) {
      return isError(obj2) && es5.propertyIsWritable(obj2, "stack");
    }
    var ensureErrorObject = function() {
      if (!("stack" in new Error())) {
        return function(value) {
          if (canAttachTrace(value)) return value;
          try {
            throw new Error(safeToString(value));
          } catch (err) {
            return err;
          }
        };
      } else {
        return function(value) {
          if (canAttachTrace(value)) return value;
          return new Error(safeToString(value));
        };
      }
    }();
    function classString(obj2) {
      return {}.toString.call(obj2);
    }
    function copyDescriptors(from, to, filter2) {
      var keys2 = es5.names(from);
      for (var i = 0; i < keys2.length; ++i) {
        var key = keys2[i];
        if (filter2(key)) {
          try {
            es5.defineProperty(to, key, es5.getDescriptor(from, key));
          } catch (ignore) {
          }
        }
      }
    }
    var asArray = function(v) {
      if (es5.isArray(v)) {
        return v;
      }
      return null;
    };
    if (typeof Symbol !== "undefined" && Symbol.iterator) {
      ArrayFrom = typeof Array.from === "function" ? function(v) {
        return Array.from(v);
      } : function(v) {
        var ret2 = [];
        var it = v[Symbol.iterator]();
        var itResult;
        while (!(itResult = it.next()).done) {
          ret2.push(itResult.value);
        }
        return ret2;
      };
      asArray = function(v) {
        if (es5.isArray(v)) {
          return v;
        } else if (v != null && typeof v[Symbol.iterator] === "function") {
          return ArrayFrom(v);
        }
        return null;
      };
    }
    var ArrayFrom;
    var isNode = typeof process !== "undefined" && classString(process).toLowerCase() === "[object process]";
    var hasEnvVariables = typeof process !== "undefined" && typeof process.env !== "undefined";
    function env(key) {
      return hasEnvVariables ? process.env[key] : void 0;
    }
    function getNativePromise() {
      if (typeof Promise === "function") {
        try {
          var promise = new Promise(function() {
          });
          if ({}.toString.call(promise) === "[object Promise]") {
            return Promise;
          }
        } catch (e) {
        }
      }
    }
    function domainBind(self2, cb2) {
      return self2.bind(cb2);
    }
    var ret = {
      isClass,
      isIdentifier,
      inheritedDataKeys,
      getDataPropertyOrDefault,
      thrower,
      isArray: es5.isArray,
      asArray,
      notEnumerableProp,
      isPrimitive,
      isObject,
      isError,
      canEvaluate,
      errorObj,
      tryCatch,
      inherits,
      withAppended,
      maybeWrapAsError,
      toFastProperties,
      filledRange,
      toString: safeToString,
      canAttachTrace,
      ensureErrorObject,
      originatesFromRejection,
      markAsOriginatingFromRejection,
      classString,
      copyDescriptors,
      hasDevTools: typeof chrome !== "undefined" && chrome && typeof chrome.loadTimes === "function",
      isNode,
      hasEnvVariables,
      env,
      global: globalObject,
      getNativePromise,
      domainBind
    };
    ret.isRecentNode = ret.isNode && function() {
      var version = process.versions.node.split(".").map(Number);
      return version[0] === 0 && version[1] > 10 || version[0] > 0;
    }();
    if (ret.isNode) ret.toFastProperties(process);
    try {
      throw new Error();
    } catch (e) {
      ret.lastLineError = e;
    }
    module.exports = ret;
  }
});

// node_modules/bluebird/js/release/schedule.js
var require_schedule = __commonJS({
  "node_modules/bluebird/js/release/schedule.js"(exports2, module2) {
    "use strict";
    var util = require_util();
    var schedule;
    var noAsyncScheduler = function() {
      throw new Error("No async scheduler available\n\n    See http://goo.gl/MqrFmX\n");
    };
    var NativePromise = util.getNativePromise();
    if (util.isNode && typeof MutationObserver === "undefined") {
      GlobalSetImmediate = global.setImmediate;
      ProcessNextTick = process.nextTick;
      schedule = util.isRecentNode ? function(fn) {
        GlobalSetImmediate.call(global, fn);
      } : function(fn) {
        ProcessNextTick.call(process, fn);
      };
    } else if (typeof NativePromise === "function" && typeof NativePromise.resolve === "function") {
      nativePromise = NativePromise.resolve();
      schedule = function(fn) {
        nativePromise.then(fn);
      };
    } else if (typeof MutationObserver !== "undefined" && !(typeof window !== "undefined" && window.navigator && (window.navigator.standalone || window.cordova))) {
      schedule = function() {
        var div = document.createElement("div");
        var opts = {
          attributes: true
        };
        var toggleScheduled = false;
        var div2 = document.createElement("div");
        var o2 = new MutationObserver(function() {
          div.classList.toggle("foo");
          toggleScheduled = false;
        });
        o2.observe(div2, opts);
        var scheduleToggle = function() {
          if (toggleScheduled) return;
          toggleScheduled = true;
          div2.classList.toggle("foo");
        };
        return function schedule2(fn) {
          var o = new MutationObserver(function() {
            o.disconnect();
            fn();
          });
          o.observe(div, opts);
          scheduleToggle();
        };
      }();
    } else if (typeof setImmediate !== "undefined") {
      schedule = function(fn) {
        setImmediate(fn);
      };
    } else if (typeof setTimeout !== "undefined") {
      schedule = function(fn) {
        setTimeout(fn, 0);
      };
    } else {
      schedule = noAsyncScheduler;
    }
    var GlobalSetImmediate;
    var ProcessNextTick;
    var nativePromise;
    module2.exports = schedule;
  }
});

// node_modules/bluebird/js/release/queue.js
var require_queue = __commonJS({
  "node_modules/bluebird/js/release/queue.js"(exports2, module2) {
    "use strict";
    function arrayMove(src, srcIndex, dst, dstIndex, len) {
      for (var j = 0; j < len; ++j) {
        dst[j + dstIndex] = src[j + srcIndex];
        src[j + srcIndex] = void 0;
      }
    }
    function Queue(capacity) {
      this._capacity = capacity;
      this._length = 0;
      this._front = 0;
    }
    Queue.prototype._willBeOverCapacity = function(size2) {
      return this._capacity < size2;
    };
    Queue.prototype._pushOne = function(arg) {
      var length = this.length();
      this._checkCapacity(length + 1);
      var i = this._front + length & this._capacity - 1;
      this[i] = arg;
      this._length = length + 1;
    };
    Queue.prototype.push = function(fn, receiver, arg) {
      var length = this.length() + 3;
      if (this._willBeOverCapacity(length)) {
        this._pushOne(fn);
        this._pushOne(receiver);
        this._pushOne(arg);
        return;
      }
      var j = this._front + length - 3;
      this._checkCapacity(length);
      var wrapMask = this._capacity - 1;
      this[j + 0 & wrapMask] = fn;
      this[j + 1 & wrapMask] = receiver;
      this[j + 2 & wrapMask] = arg;
      this._length = length;
    };
    Queue.prototype.shift = function() {
      var front = this._front, ret2 = this[front];
      this[front] = void 0;
      this._front = front + 1 & this._capacity - 1;
      this._length--;
      return ret2;
    };
    Queue.prototype.length = function() {
      return this._length;
    };
    Queue.prototype._checkCapacity = function(size2) {
      if (this._capacity < size2) {
        this._resizeTo(this._capacity << 1);
      }
    };
    Queue.prototype._resizeTo = function(capacity) {
      var oldCapacity = this._capacity;
      this._capacity = capacity;
      var front = this._front;
      var length = this._length;
      var moveItemsCount = front + length & oldCapacity - 1;
      arrayMove(this, 0, this, oldCapacity, moveItemsCount);
    };
    module2.exports = Queue;
  }
});

// node_modules/bluebird/js/release/async.js
var require_async = __commonJS({
  "node_modules/bluebird/js/release/async.js"(exports2, module2) {
    "use strict";
    var firstLineError;
    try {
      throw new Error();
    } catch (e) {
      firstLineError = e;
    }
    var schedule = require_schedule();
    var Queue = require_queue();
    var util = require_util();
    function Async() {
      this._customScheduler = false;
      this._isTickUsed = false;
      this._lateQueue = new Queue(16);
      this._normalQueue = new Queue(16);
      this._haveDrainedQueues = false;
      this._trampolineEnabled = true;
      var self2 = this;
      this.drainQueues = function() {
        self2._drainQueues();
      };
      this._schedule = schedule;
    }
    Async.prototype.setScheduler = function(fn) {
      var prev = this._schedule;
      this._schedule = fn;
      this._customScheduler = true;
      return prev;
    };
    Async.prototype.hasCustomScheduler = function() {
      return this._customScheduler;
    };
    Async.prototype.enableTrampoline = function() {
      this._trampolineEnabled = true;
    };
    Async.prototype.disableTrampolineIfNecessary = function() {
      if (util.hasDevTools) {
        this._trampolineEnabled = false;
      }
    };
    Async.prototype.haveItemsQueued = function() {
      return this._isTickUsed || this._haveDrainedQueues;
    };
    Async.prototype.fatalError = function(e, isNode2) {
      if (isNode2) {
        process.stderr.write("Fatal " + (e instanceof Error ? e.stack : e) + "\n");
        process.exit(2);
      } else {
        this.throwLater(e);
      }
    };
    Async.prototype.throwLater = function(fn, arg) {
      if (arguments.length === 1) {
        arg = fn;
        fn = function() {
          throw arg;
        };
      }
      if (typeof setTimeout !== "undefined") {
        setTimeout(function() {
          fn(arg);
        }, 0);
      } else try {
        this._schedule(function() {
          fn(arg);
        });
      } catch (e) {
        throw new Error("No async scheduler available\n\n    See http://goo.gl/MqrFmX\n");
      }
    };
    function AsyncInvokeLater(fn, receiver, arg) {
      this._lateQueue.push(fn, receiver, arg);
      this._queueTick();
    }
    function AsyncInvoke(fn, receiver, arg) {
      this._normalQueue.push(fn, receiver, arg);
      this._queueTick();
    }
    function AsyncSettlePromises(promise) {
      this._normalQueue._pushOne(promise);
      this._queueTick();
    }
    if (!util.hasDevTools) {
      Async.prototype.invokeLater = AsyncInvokeLater;
      Async.prototype.invoke = AsyncInvoke;
      Async.prototype.settlePromises = AsyncSettlePromises;
    } else {
      Async.prototype.invokeLater = function(fn, receiver, arg) {
        if (this._trampolineEnabled) {
          AsyncInvokeLater.call(this, fn, receiver, arg);
        } else {
          this._schedule(function() {
            setTimeout(function() {
              fn.call(receiver, arg);
            }, 100);
          });
        }
      };
      Async.prototype.invoke = function(fn, receiver, arg) {
        if (this._trampolineEnabled) {
          AsyncInvoke.call(this, fn, receiver, arg);
        } else {
          this._schedule(function() {
            fn.call(receiver, arg);
          });
        }
      };
      Async.prototype.settlePromises = function(promise) {
        if (this._trampolineEnabled) {
          AsyncSettlePromises.call(this, promise);
        } else {
          this._schedule(function() {
            promise._settlePromises();
          });
        }
      };
    }
    Async.prototype._drainQueue = function(queue) {
      while (queue.length() > 0) {
        var fn = queue.shift();
        if (typeof fn !== "function") {
          fn._settlePromises();
          continue;
        }
        var receiver = queue.shift();
        var arg = queue.shift();
        fn.call(receiver, arg);
      }
    };
    Async.prototype._drainQueues = function() {
      this._drainQueue(this._normalQueue);
      this._reset();
      this._haveDrainedQueues = true;
      this._drainQueue(this._lateQueue);
    };
    Async.prototype._queueTick = function() {
      if (!this._isTickUsed) {
        this._isTickUsed = true;
        this._schedule(this.drainQueues);
      }
    };
    Async.prototype._reset = function() {
      this._isTickUsed = false;
    };
    module2.exports = Async;
    module2.exports.firstLineError = firstLineError;
  }
});

// node_modules/bluebird/js/release/errors.js
var require_errors = __commonJS({
  "node_modules/bluebird/js/release/errors.js"(exports2, module2) {
    "use strict";
    var es52 = require_es5();
    var Objectfreeze = es52.freeze;
    var util = require_util();
    var inherits2 = util.inherits;
    var notEnumerableProp2 = util.notEnumerableProp;
    function subError(nameProperty, defaultMessage) {
      function SubError(message) {
        if (!(this instanceof SubError)) return new SubError(message);
        notEnumerableProp2(this, "message", typeof message === "string" ? message : defaultMessage);
        notEnumerableProp2(this, "name", nameProperty);
        if (Error.captureStackTrace) {
          Error.captureStackTrace(this, this.constructor);
        } else {
          Error.call(this);
        }
      }
      inherits2(SubError, Error);
      return SubError;
    }
    var _TypeError;
    var _RangeError;
    var Warning = subError("Warning", "warning");
    var CancellationError = subError("CancellationError", "cancellation error");
    var TimeoutError = subError("TimeoutError", "timeout error");
    var AggregateError = subError("AggregateError", "aggregate error");
    try {
      _TypeError = TypeError;
      _RangeError = RangeError;
    } catch (e) {
      _TypeError = subError("TypeError", "type error");
      _RangeError = subError("RangeError", "range error");
    }
    var methods = "join pop push shift unshift slice filter forEach some every map indexOf lastIndexOf reduce reduceRight sort reverse".split(" ");
    for (i = 0; i < methods.length; ++i) {
      if (typeof Array.prototype[methods[i]] === "function") {
        AggregateError.prototype[methods[i]] = Array.prototype[methods[i]];
      }
    }
    var i;
    es52.defineProperty(AggregateError.prototype, "length", {
      value: 0,
      configurable: false,
      writable: true,
      enumerable: true
    });
    AggregateError.prototype["isOperational"] = true;
    var level = 0;
    AggregateError.prototype.toString = function() {
      var indent = Array(level * 4 + 1).join(" ");
      var ret2 = "\n" + indent + "AggregateError of:\n";
      level++;
      indent = Array(level * 4 + 1).join(" ");
      for (var i2 = 0; i2 < this.length; ++i2) {
        var str = this[i2] === this ? "[Circular AggregateError]" : this[i2] + "";
        var lines = str.split("\n");
        for (var j = 0; j < lines.length; ++j) {
          lines[j] = indent + lines[j];
        }
        str = lines.join("\n");
        ret2 += str + "\n";
      }
      level--;
      return ret2;
    };
    function OperationalError(message) {
      if (!(this instanceof OperationalError)) return new OperationalError(message);
      notEnumerableProp2(this, "name", "OperationalError");
      notEnumerableProp2(this, "message", message);
      this.cause = message;
      this["isOperational"] = true;
      if (message instanceof Error) {
        notEnumerableProp2(this, "message", message.message);
        notEnumerableProp2(this, "stack", message.stack);
      } else if (Error.captureStackTrace) {
        Error.captureStackTrace(this, this.constructor);
      }
    }
    inherits2(OperationalError, Error);
    var errorTypes = Error["__BluebirdErrorTypes__"];
    if (!errorTypes) {
      errorTypes = Objectfreeze({
        CancellationError,
        TimeoutError,
        OperationalError,
        RejectionError: OperationalError,
        AggregateError
      });
      es52.defineProperty(Error, "__BluebirdErrorTypes__", {
        value: errorTypes,
        writable: false,
        enumerable: false,
        configurable: false
      });
    }
    module2.exports = {
      Error,
      TypeError: _TypeError,
      RangeError: _RangeError,
      CancellationError: errorTypes.CancellationError,
      OperationalError: errorTypes.OperationalError,
      TimeoutError: errorTypes.TimeoutError,
      AggregateError: errorTypes.AggregateError,
      Warning
    };
  }
});

// node_modules/bluebird/js/release/thenables.js
var require_thenables = __commonJS({
  "node_modules/bluebird/js/release/thenables.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL) {
      var util = require_util();
      var errorObj2 = util.errorObj;
      var isObject3 = util.isObject;
      function tryConvertToPromise(obj2, context) {
        if (isObject3(obj2)) {
          if (obj2 instanceof Promise2) return obj2;
          var then = getThen(obj2);
          if (then === errorObj2) {
            if (context) context._pushContext();
            var ret2 = Promise2.reject(then.e);
            if (context) context._popContext();
            return ret2;
          } else if (typeof then === "function") {
            if (isAnyBluebirdPromise(obj2)) {
              var ret2 = new Promise2(INTERNAL);
              obj2._then(ret2._fulfill, ret2._reject, void 0, ret2, null);
              return ret2;
            }
            return doThenable(obj2, then, context);
          }
        }
        return obj2;
      }
      function doGetThen(obj2) {
        return obj2.then;
      }
      function getThen(obj2) {
        try {
          return doGetThen(obj2);
        } catch (e) {
          errorObj2.e = e;
          return errorObj2;
        }
      }
      var hasProp = {}.hasOwnProperty;
      function isAnyBluebirdPromise(obj2) {
        try {
          return hasProp.call(obj2, "_promise0");
        } catch (e) {
          return false;
        }
      }
      function doThenable(x, then, context) {
        var promise = new Promise2(INTERNAL);
        var ret2 = promise;
        if (context) context._pushContext();
        promise._captureStackTrace();
        if (context) context._popContext();
        var synchronous = true;
        var result2 = util.tryCatch(then).call(x, resolve, reject2);
        synchronous = false;
        if (promise && result2 === errorObj2) {
          promise._rejectCallback(result2.e, true, true);
          promise = null;
        }
        function resolve(value) {
          if (!promise) return;
          promise._resolveCallback(value);
          promise = null;
        }
        function reject2(reason) {
          if (!promise) return;
          promise._rejectCallback(reason, synchronous, true);
          promise = null;
        }
        return ret2;
      }
      return tryConvertToPromise;
    };
  }
});

// node_modules/bluebird/js/release/promise_array.js
var require_promise_array = __commonJS({
  "node_modules/bluebird/js/release/promise_array.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL, tryConvertToPromise, apiRejection, Proxyable) {
      var util = require_util();
      var isArray = util.isArray;
      function toResolutionValue(val) {
        switch (val) {
          case -2:
            return [];
          case -3:
            return {};
        }
      }
      function PromiseArray(values2) {
        var promise = this._promise = new Promise2(INTERNAL);
        if (values2 instanceof Promise2) {
          promise._propagateFrom(values2, 3);
        }
        promise._setOnCancel(this);
        this._values = values2;
        this._length = 0;
        this._totalResolved = 0;
        this._init(void 0, -2);
      }
      util.inherits(PromiseArray, Proxyable);
      PromiseArray.prototype.length = function() {
        return this._length;
      };
      PromiseArray.prototype.promise = function() {
        return this._promise;
      };
      PromiseArray.prototype._init = function init(_3, resolveValueIfEmpty) {
        var values2 = tryConvertToPromise(this._values, this._promise);
        if (values2 instanceof Promise2) {
          values2 = values2._target();
          var bitField = values2._bitField;
          ;
          this._values = values2;
          if ((bitField & 50397184) === 0) {
            this._promise._setAsyncGuaranteed();
            return values2._then(init, this._reject, void 0, this, resolveValueIfEmpty);
          } else if ((bitField & 33554432) !== 0) {
            values2 = values2._value();
          } else if ((bitField & 16777216) !== 0) {
            return this._reject(values2._reason());
          } else {
            return this._cancel();
          }
        }
        values2 = util.asArray(values2);
        if (values2 === null) {
          var err = apiRejection("expecting an array or an iterable object but got " + util.classString(values2)).reason();
          this._promise._rejectCallback(err, false);
          return;
        }
        if (values2.length === 0) {
          if (resolveValueIfEmpty === -5) {
            this._resolveEmptyArray();
          } else {
            this._resolve(toResolutionValue(resolveValueIfEmpty));
          }
          return;
        }
        this._iterate(values2);
      };
      PromiseArray.prototype._iterate = function(values2) {
        var len = this.getActualLength(values2.length);
        this._length = len;
        this._values = this.shouldCopyValues() ? new Array(len) : this._values;
        var result2 = this._promise;
        var isResolved = false;
        var bitField = null;
        for (var i = 0; i < len; ++i) {
          var maybePromise = tryConvertToPromise(values2[i], result2);
          if (maybePromise instanceof Promise2) {
            maybePromise = maybePromise._target();
            bitField = maybePromise._bitField;
          } else {
            bitField = null;
          }
          if (isResolved) {
            if (bitField !== null) {
              maybePromise.suppressUnhandledRejections();
            }
          } else if (bitField !== null) {
            if ((bitField & 50397184) === 0) {
              maybePromise._proxy(this, i);
              this._values[i] = maybePromise;
            } else if ((bitField & 33554432) !== 0) {
              isResolved = this._promiseFulfilled(maybePromise._value(), i);
            } else if ((bitField & 16777216) !== 0) {
              isResolved = this._promiseRejected(maybePromise._reason(), i);
            } else {
              isResolved = this._promiseCancelled(i);
            }
          } else {
            isResolved = this._promiseFulfilled(maybePromise, i);
          }
        }
        if (!isResolved) result2._setAsyncGuaranteed();
      };
      PromiseArray.prototype._isResolved = function() {
        return this._values === null;
      };
      PromiseArray.prototype._resolve = function(value) {
        this._values = null;
        this._promise._fulfill(value);
      };
      PromiseArray.prototype._cancel = function() {
        if (this._isResolved() || !this._promise._isCancellable()) return;
        this._values = null;
        this._promise._cancel();
      };
      PromiseArray.prototype._reject = function(reason) {
        this._values = null;
        this._promise._rejectCallback(reason, false);
      };
      PromiseArray.prototype._promiseFulfilled = function(value, index) {
        this._values[index] = value;
        var totalResolved = ++this._totalResolved;
        if (totalResolved >= this._length) {
          this._resolve(this._values);
          return true;
        }
        return false;
      };
      PromiseArray.prototype._promiseCancelled = function() {
        this._cancel();
        return true;
      };
      PromiseArray.prototype._promiseRejected = function(reason) {
        this._totalResolved++;
        this._reject(reason);
        return true;
      };
      PromiseArray.prototype._resultCancelled = function() {
        if (this._isResolved()) return;
        var values2 = this._values;
        this._cancel();
        if (values2 instanceof Promise2) {
          values2.cancel();
        } else {
          for (var i = 0; i < values2.length; ++i) {
            if (values2[i] instanceof Promise2) {
              values2[i].cancel();
            }
          }
        }
      };
      PromiseArray.prototype.shouldCopyValues = function() {
        return true;
      };
      PromiseArray.prototype.getActualLength = function(len) {
        return len;
      };
      return PromiseArray;
    };
  }
});

// node_modules/bluebird/js/release/context.js
var require_context = __commonJS({
  "node_modules/bluebird/js/release/context.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2) {
      var longStackTraces = false;
      var contextStack = [];
      Promise2.prototype._promiseCreated = function() {
      };
      Promise2.prototype._pushContext = function() {
      };
      Promise2.prototype._popContext = function() {
        return null;
      };
      Promise2._peekContext = Promise2.prototype._peekContext = function() {
      };
      function Context() {
        this._trace = new Context.CapturedTrace(peekContext());
      }
      Context.prototype._pushContext = function() {
        if (this._trace !== void 0) {
          this._trace._promiseCreated = null;
          contextStack.push(this._trace);
        }
      };
      Context.prototype._popContext = function() {
        if (this._trace !== void 0) {
          var trace = contextStack.pop();
          var ret2 = trace._promiseCreated;
          trace._promiseCreated = null;
          return ret2;
        }
        return null;
      };
      function createContext() {
        if (longStackTraces) return new Context();
      }
      function peekContext() {
        var lastIndex = contextStack.length - 1;
        if (lastIndex >= 0) {
          return contextStack[lastIndex];
        }
        return void 0;
      }
      Context.CapturedTrace = null;
      Context.create = createContext;
      Context.deactivateLongStackTraces = function() {
      };
      Context.activateLongStackTraces = function() {
        var Promise_pushContext = Promise2.prototype._pushContext;
        var Promise_popContext = Promise2.prototype._popContext;
        var Promise_PeekContext = Promise2._peekContext;
        var Promise_peekContext = Promise2.prototype._peekContext;
        var Promise_promiseCreated = Promise2.prototype._promiseCreated;
        Context.deactivateLongStackTraces = function() {
          Promise2.prototype._pushContext = Promise_pushContext;
          Promise2.prototype._popContext = Promise_popContext;
          Promise2._peekContext = Promise_PeekContext;
          Promise2.prototype._peekContext = Promise_peekContext;
          Promise2.prototype._promiseCreated = Promise_promiseCreated;
          longStackTraces = false;
        };
        longStackTraces = true;
        Promise2.prototype._pushContext = Context.prototype._pushContext;
        Promise2.prototype._popContext = Context.prototype._popContext;
        Promise2._peekContext = Promise2.prototype._peekContext = peekContext;
        Promise2.prototype._promiseCreated = function() {
          var ctx = this._peekContext();
          if (ctx && ctx._promiseCreated == null) ctx._promiseCreated = this;
        };
      };
      return Context;
    };
  }
});

// node_modules/bluebird/js/release/debuggability.js
var require_debuggability = __commonJS({
  "node_modules/bluebird/js/release/debuggability.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, Context) {
      var getDomain = Promise2._getDomain;
      var async = Promise2._async;
      var Warning = require_errors().Warning;
      var util = require_util();
      var canAttachTrace2 = util.canAttachTrace;
      var unhandledRejectionHandled;
      var possiblyUnhandledRejection;
      var bluebirdFramePattern = /[\\\/]bluebird[\\\/]js[\\\/](release|debug|instrumented)/;
      var nodeFramePattern = /\((?:timers\.js):\d+:\d+\)/;
      var parseLinePattern = /[\/<\(](.+?):(\d+):(\d+)\)?\s*$/;
      var stackFramePattern = null;
      var formatStack = null;
      var indentStackFrames = false;
      var printWarning;
      var debugging = !!(util.env("BLUEBIRD_DEBUG") != 0 && (util.env("BLUEBIRD_DEBUG") || util.env("NODE_ENV") === "development"));
      var warnings = !!(util.env("BLUEBIRD_WARNINGS") != 0 && (debugging || util.env("BLUEBIRD_WARNINGS")));
      var longStackTraces = !!(util.env("BLUEBIRD_LONG_STACK_TRACES") != 0 && (debugging || util.env("BLUEBIRD_LONG_STACK_TRACES")));
      var wForgottenReturn = util.env("BLUEBIRD_W_FORGOTTEN_RETURN") != 0 && (warnings || !!util.env("BLUEBIRD_W_FORGOTTEN_RETURN"));
      Promise2.prototype.suppressUnhandledRejections = function() {
        var target = this._target();
        target._bitField = target._bitField & ~1048576 | 524288;
      };
      Promise2.prototype._ensurePossibleRejectionHandled = function() {
        if ((this._bitField & 524288) !== 0) return;
        this._setRejectionIsUnhandled();
        async.invokeLater(this._notifyUnhandledRejection, this, void 0);
      };
      Promise2.prototype._notifyUnhandledRejectionIsHandled = function() {
        fireRejectionEvent("rejectionHandled", unhandledRejectionHandled, void 0, this);
      };
      Promise2.prototype._setReturnedNonUndefined = function() {
        this._bitField = this._bitField | 268435456;
      };
      Promise2.prototype._returnedNonUndefined = function() {
        return (this._bitField & 268435456) !== 0;
      };
      Promise2.prototype._notifyUnhandledRejection = function() {
        if (this._isRejectionUnhandled()) {
          var reason = this._settledValue();
          this._setUnhandledRejectionIsNotified();
          fireRejectionEvent("unhandledRejection", possiblyUnhandledRejection, reason, this);
        }
      };
      Promise2.prototype._setUnhandledRejectionIsNotified = function() {
        this._bitField = this._bitField | 262144;
      };
      Promise2.prototype._unsetUnhandledRejectionIsNotified = function() {
        this._bitField = this._bitField & ~262144;
      };
      Promise2.prototype._isUnhandledRejectionNotified = function() {
        return (this._bitField & 262144) > 0;
      };
      Promise2.prototype._setRejectionIsUnhandled = function() {
        this._bitField = this._bitField | 1048576;
      };
      Promise2.prototype._unsetRejectionIsUnhandled = function() {
        this._bitField = this._bitField & ~1048576;
        if (this._isUnhandledRejectionNotified()) {
          this._unsetUnhandledRejectionIsNotified();
          this._notifyUnhandledRejectionIsHandled();
        }
      };
      Promise2.prototype._isRejectionUnhandled = function() {
        return (this._bitField & 1048576) > 0;
      };
      Promise2.prototype._warn = function(message, shouldUseOwnTrace, promise) {
        return warn(message, shouldUseOwnTrace, promise || this);
      };
      Promise2.onPossiblyUnhandledRejection = function(fn) {
        var domain = getDomain();
        possiblyUnhandledRejection = typeof fn === "function" ? domain === null ? fn : util.domainBind(domain, fn) : void 0;
      };
      Promise2.onUnhandledRejectionHandled = function(fn) {
        var domain = getDomain();
        unhandledRejectionHandled = typeof fn === "function" ? domain === null ? fn : util.domainBind(domain, fn) : void 0;
      };
      var disableLongStackTraces = function() {
      };
      Promise2.longStackTraces = function() {
        if (async.haveItemsQueued() && !config.longStackTraces) {
          throw new Error("cannot enable long stack traces after promises have been created\n\n    See http://goo.gl/MqrFmX\n");
        }
        if (!config.longStackTraces && longStackTracesIsSupported()) {
          var Promise_captureStackTrace = Promise2.prototype._captureStackTrace;
          var Promise_attachExtraTrace = Promise2.prototype._attachExtraTrace;
          config.longStackTraces = true;
          disableLongStackTraces = function() {
            if (async.haveItemsQueued() && !config.longStackTraces) {
              throw new Error("cannot enable long stack traces after promises have been created\n\n    See http://goo.gl/MqrFmX\n");
            }
            Promise2.prototype._captureStackTrace = Promise_captureStackTrace;
            Promise2.prototype._attachExtraTrace = Promise_attachExtraTrace;
            Context.deactivateLongStackTraces();
            async.enableTrampoline();
            config.longStackTraces = false;
          };
          Promise2.prototype._captureStackTrace = longStackTracesCaptureStackTrace;
          Promise2.prototype._attachExtraTrace = longStackTracesAttachExtraTrace;
          Context.activateLongStackTraces();
          async.disableTrampolineIfNecessary();
        }
      };
      Promise2.hasLongStackTraces = function() {
        return config.longStackTraces && longStackTracesIsSupported();
      };
      var fireDomEvent = function() {
        try {
          if (typeof CustomEvent === "function") {
            var event = new CustomEvent("CustomEvent");
            util.global.dispatchEvent(event);
            return function(name, event2) {
              var domEvent = new CustomEvent(name.toLowerCase(), {
                detail: event2,
                cancelable: true
              });
              return !util.global.dispatchEvent(domEvent);
            };
          } else if (typeof Event === "function") {
            var event = new Event("CustomEvent");
            util.global.dispatchEvent(event);
            return function(name, event2) {
              var domEvent = new Event(name.toLowerCase(), {
                cancelable: true
              });
              domEvent.detail = event2;
              return !util.global.dispatchEvent(domEvent);
            };
          } else {
            var event = document.createEvent("CustomEvent");
            event.initCustomEvent("testingtheevent", false, true, {});
            util.global.dispatchEvent(event);
            return function(name, event2) {
              var domEvent = document.createEvent("CustomEvent");
              domEvent.initCustomEvent(name.toLowerCase(), false, true, event2);
              return !util.global.dispatchEvent(domEvent);
            };
          }
        } catch (e) {
        }
        return function() {
          return false;
        };
      }();
      var fireGlobalEvent = function() {
        if (util.isNode) {
          return function() {
            return process.emit.apply(process, arguments);
          };
        } else {
          if (!util.global) {
            return function() {
              return false;
            };
          }
          return function(name) {
            var methodName = "on" + name.toLowerCase();
            var method = util.global[methodName];
            if (!method) return false;
            method.apply(util.global, [].slice.call(arguments, 1));
            return true;
          };
        }
      }();
      function generatePromiseLifecycleEventObject(name, promise) {
        return {
          promise
        };
      }
      var eventToObjectGenerator = {
        promiseCreated: generatePromiseLifecycleEventObject,
        promiseFulfilled: generatePromiseLifecycleEventObject,
        promiseRejected: generatePromiseLifecycleEventObject,
        promiseResolved: generatePromiseLifecycleEventObject,
        promiseCancelled: generatePromiseLifecycleEventObject,
        promiseChained: function(name, promise, child) {
          return {
            promise,
            child
          };
        },
        warning: function(name, warning) {
          return {
            warning
          };
        },
        unhandledRejection: function(name, reason, promise) {
          return {
            reason,
            promise
          };
        },
        rejectionHandled: generatePromiseLifecycleEventObject
      };
      var activeFireEvent = function(name) {
        var globalEventFired = false;
        try {
          globalEventFired = fireGlobalEvent.apply(null, arguments);
        } catch (e) {
          async.throwLater(e);
          globalEventFired = true;
        }
        var domEventFired = false;
        try {
          domEventFired = fireDomEvent(name, eventToObjectGenerator[name].apply(null, arguments));
        } catch (e) {
          async.throwLater(e);
          domEventFired = true;
        }
        return domEventFired || globalEventFired;
      };
      Promise2.config = function(opts) {
        opts = Object(opts);
        if ("longStackTraces" in opts) {
          if (opts.longStackTraces) {
            Promise2.longStackTraces();
          } else if (!opts.longStackTraces && Promise2.hasLongStackTraces()) {
            disableLongStackTraces();
          }
        }
        if ("warnings" in opts) {
          var warningsOption = opts.warnings;
          config.warnings = !!warningsOption;
          wForgottenReturn = config.warnings;
          if (util.isObject(warningsOption)) {
            if ("wForgottenReturn" in warningsOption) {
              wForgottenReturn = !!warningsOption.wForgottenReturn;
            }
          }
        }
        if ("cancellation" in opts && opts.cancellation && !config.cancellation) {
          if (async.haveItemsQueued()) {
            throw new Error("cannot enable cancellation after promises are in use");
          }
          Promise2.prototype._clearCancellationData = cancellationClearCancellationData;
          Promise2.prototype._propagateFrom = cancellationPropagateFrom;
          Promise2.prototype._onCancel = cancellationOnCancel;
          Promise2.prototype._setOnCancel = cancellationSetOnCancel;
          Promise2.prototype._attachCancellationCallback = cancellationAttachCancellationCallback;
          Promise2.prototype._execute = cancellationExecute;
          propagateFromFunction = cancellationPropagateFrom;
          config.cancellation = true;
        }
        if ("monitoring" in opts) {
          if (opts.monitoring && !config.monitoring) {
            config.monitoring = true;
            Promise2.prototype._fireEvent = activeFireEvent;
          } else if (!opts.monitoring && config.monitoring) {
            config.monitoring = false;
            Promise2.prototype._fireEvent = defaultFireEvent;
          }
        }
        return Promise2;
      };
      function defaultFireEvent() {
        return false;
      }
      Promise2.prototype._fireEvent = defaultFireEvent;
      Promise2.prototype._execute = function(executor, resolve, reject2) {
        try {
          executor(resolve, reject2);
        } catch (e) {
          return e;
        }
      };
      Promise2.prototype._onCancel = function() {
      };
      Promise2.prototype._setOnCancel = function(handler) {
        ;
      };
      Promise2.prototype._attachCancellationCallback = function(onCancel) {
        ;
      };
      Promise2.prototype._captureStackTrace = function() {
      };
      Promise2.prototype._attachExtraTrace = function() {
      };
      Promise2.prototype._clearCancellationData = function() {
      };
      Promise2.prototype._propagateFrom = function(parent, flags) {
        ;
        ;
      };
      function cancellationExecute(executor, resolve, reject2) {
        var promise = this;
        try {
          executor(resolve, reject2, function(onCancel) {
            if (typeof onCancel !== "function") {
              throw new TypeError("onCancel must be a function, got: " + util.toString(onCancel));
            }
            promise._attachCancellationCallback(onCancel);
          });
        } catch (e) {
          return e;
        }
      }
      function cancellationAttachCancellationCallback(onCancel) {
        if (!this._isCancellable()) return this;
        var previousOnCancel = this._onCancel();
        if (previousOnCancel !== void 0) {
          if (util.isArray(previousOnCancel)) {
            previousOnCancel.push(onCancel);
          } else {
            this._setOnCancel([previousOnCancel, onCancel]);
          }
        } else {
          this._setOnCancel(onCancel);
        }
      }
      function cancellationOnCancel() {
        return this._onCancelField;
      }
      function cancellationSetOnCancel(onCancel) {
        this._onCancelField = onCancel;
      }
      function cancellationClearCancellationData() {
        this._cancellationParent = void 0;
        this._onCancelField = void 0;
      }
      function cancellationPropagateFrom(parent, flags) {
        if ((flags & 1) !== 0) {
          this._cancellationParent = parent;
          var branchesRemainingToCancel = parent._branchesRemainingToCancel;
          if (branchesRemainingToCancel === void 0) {
            branchesRemainingToCancel = 0;
          }
          parent._branchesRemainingToCancel = branchesRemainingToCancel + 1;
        }
        if ((flags & 2) !== 0 && parent._isBound()) {
          this._setBoundTo(parent._boundTo);
        }
      }
      function bindingPropagateFrom(parent, flags) {
        if ((flags & 2) !== 0 && parent._isBound()) {
          this._setBoundTo(parent._boundTo);
        }
      }
      var propagateFromFunction = bindingPropagateFrom;
      function boundValueFunction() {
        var ret2 = this._boundTo;
        if (ret2 !== void 0) {
          if (ret2 instanceof Promise2) {
            if (ret2.isFulfilled()) {
              return ret2.value();
            } else {
              return void 0;
            }
          }
        }
        return ret2;
      }
      function longStackTracesCaptureStackTrace() {
        this._trace = new CapturedTrace(this._peekContext());
      }
      function longStackTracesAttachExtraTrace(error, ignoreSelf) {
        if (canAttachTrace2(error)) {
          var trace = this._trace;
          if (trace !== void 0) {
            if (ignoreSelf) trace = trace._parent;
          }
          if (trace !== void 0) {
            trace.attachExtraTrace(error);
          } else if (!error.__stackCleaned__) {
            var parsed = parseStackAndMessage(error);
            util.notEnumerableProp(error, "stack", parsed.message + "\n" + parsed.stack.join("\n"));
            util.notEnumerableProp(error, "__stackCleaned__", true);
          }
        }
      }
      function checkForgottenReturns(returnValue, promiseCreated, name, promise, parent) {
        if (returnValue === void 0 && promiseCreated !== null && wForgottenReturn) {
          if (parent !== void 0 && parent._returnedNonUndefined()) return;
          if ((promise._bitField & 65535) === 0) return;
          if (name) name = name + " ";
          var handlerLine = "";
          var creatorLine = "";
          if (promiseCreated._trace) {
            var traceLines = promiseCreated._trace.stack.split("\n");
            var stack = cleanStack(traceLines);
            for (var i = stack.length - 1; i >= 0; --i) {
              var line = stack[i];
              if (!nodeFramePattern.test(line)) {
                var lineMatches = line.match(parseLinePattern);
                if (lineMatches) {
                  handlerLine = "at " + lineMatches[1] + ":" + lineMatches[2] + ":" + lineMatches[3] + " ";
                }
                break;
              }
            }
            if (stack.length > 0) {
              var firstUserLine = stack[0];
              for (var i = 0; i < traceLines.length; ++i) {
                if (traceLines[i] === firstUserLine) {
                  if (i > 0) {
                    creatorLine = "\n" + traceLines[i - 1];
                  }
                  break;
                }
              }
            }
          }
          var msg = "a promise was created in a " + name + "handler " + handlerLine + "but was not returned from it, see http://goo.gl/rRqMUw" + creatorLine;
          promise._warn(msg, true, promiseCreated);
        }
      }
      function deprecated(name, replacement) {
        var message = name + " is deprecated and will be removed in a future version.";
        if (replacement) message += " Use " + replacement + " instead.";
        return warn(message);
      }
      function warn(message, shouldUseOwnTrace, promise) {
        if (!config.warnings) return;
        var warning = new Warning(message);
        var ctx;
        if (shouldUseOwnTrace) {
          promise._attachExtraTrace(warning);
        } else if (config.longStackTraces && (ctx = Promise2._peekContext())) {
          ctx.attachExtraTrace(warning);
        } else {
          var parsed = parseStackAndMessage(warning);
          warning.stack = parsed.message + "\n" + parsed.stack.join("\n");
        }
        if (!activeFireEvent("warning", warning)) {
          formatAndLogError(warning, "", true);
        }
      }
      function reconstructStack(message, stacks) {
        for (var i = 0; i < stacks.length - 1; ++i) {
          stacks[i].push("From previous event:");
          stacks[i] = stacks[i].join("\n");
        }
        if (i < stacks.length) {
          stacks[i] = stacks[i].join("\n");
        }
        return message + "\n" + stacks.join("\n");
      }
      function removeDuplicateOrEmptyJumps(stacks) {
        for (var i = 0; i < stacks.length; ++i) {
          if (stacks[i].length === 0 || i + 1 < stacks.length && stacks[i][0] === stacks[i + 1][0]) {
            stacks.splice(i, 1);
            i--;
          }
        }
      }
      function removeCommonRoots(stacks) {
        var current = stacks[0];
        for (var i = 1; i < stacks.length; ++i) {
          var prev = stacks[i];
          var currentLastIndex = current.length - 1;
          var currentLastLine = current[currentLastIndex];
          var commonRootMeetPoint = -1;
          for (var j = prev.length - 1; j >= 0; --j) {
            if (prev[j] === currentLastLine) {
              commonRootMeetPoint = j;
              break;
            }
          }
          for (var j = commonRootMeetPoint; j >= 0; --j) {
            var line = prev[j];
            if (current[currentLastIndex] === line) {
              current.pop();
              currentLastIndex--;
            } else {
              break;
            }
          }
          current = prev;
        }
      }
      function cleanStack(stack) {
        var ret2 = [];
        for (var i = 0; i < stack.length; ++i) {
          var line = stack[i];
          var isTraceLine = "    (No stack trace)" === line || stackFramePattern.test(line);
          var isInternalFrame = isTraceLine && shouldIgnore(line);
          if (isTraceLine && !isInternalFrame) {
            if (indentStackFrames && line.charAt(0) !== " ") {
              line = "    " + line;
            }
            ret2.push(line);
          }
        }
        return ret2;
      }
      function stackFramesAsArray(error) {
        var stack = error.stack.replace(/\s+$/g, "").split("\n");
        for (var i = 0; i < stack.length; ++i) {
          var line = stack[i];
          if ("    (No stack trace)" === line || stackFramePattern.test(line)) {
            break;
          }
        }
        if (i > 0 && error.name != "SyntaxError") {
          stack = stack.slice(i);
        }
        return stack;
      }
      function parseStackAndMessage(error) {
        var stack = error.stack;
        var message = error.toString();
        stack = typeof stack === "string" && stack.length > 0 ? stackFramesAsArray(error) : ["    (No stack trace)"];
        return {
          message,
          stack: error.name == "SyntaxError" ? stack : cleanStack(stack)
        };
      }
      function formatAndLogError(error, title, isSoft) {
        if (typeof console !== "undefined") {
          var message;
          if (util.isObject(error)) {
            var stack = error.stack;
            message = title + formatStack(stack, error);
          } else {
            message = title + String(error);
          }
          if (typeof printWarning === "function") {
            printWarning(message, isSoft);
          } else if (typeof console.log === "function" || typeof console.log === "object") {
            console.log(message);
          }
        }
      }
      function fireRejectionEvent(name, localHandler, reason, promise) {
        var localEventFired = false;
        try {
          if (typeof localHandler === "function") {
            localEventFired = true;
            if (name === "rejectionHandled") {
              localHandler(promise);
            } else {
              localHandler(reason, promise);
            }
          }
        } catch (e) {
          async.throwLater(e);
        }
        if (name === "unhandledRejection") {
          if (!activeFireEvent(name, reason, promise) && !localEventFired) {
            formatAndLogError(reason, "Unhandled rejection ");
          }
        } else {
          activeFireEvent(name, promise);
        }
      }
      function formatNonError(obj2) {
        var str;
        if (typeof obj2 === "function") {
          str = "[function " + (obj2.name || "anonymous") + "]";
        } else {
          str = obj2 && typeof obj2.toString === "function" ? obj2.toString() : util.toString(obj2);
          var ruselessToString = /\[object [a-zA-Z0-9$_]+\]/;
          if (ruselessToString.test(str)) {
            try {
              var newStr = JSON.stringify(obj2);
              str = newStr;
            } catch (e) {
            }
          }
          if (str.length === 0) {
            str = "(empty array)";
          }
        }
        return "(<" + snip(str) + ">, no stack trace)";
      }
      function snip(str) {
        var maxChars = 41;
        if (str.length < maxChars) {
          return str;
        }
        return str.substr(0, maxChars - 3) + "...";
      }
      function longStackTracesIsSupported() {
        return typeof captureStackTrace === "function";
      }
      var shouldIgnore = function() {
        return false;
      };
      var parseLineInfoRegex = /[\/<\(]([^:\/]+):(\d+):(?:\d+)\)?\s*$/;
      function parseLineInfo(line) {
        var matches = line.match(parseLineInfoRegex);
        if (matches) {
          return {
            fileName: matches[1],
            line: parseInt(matches[2], 10)
          };
        }
      }
      function setBounds(firstLineError, lastLineError) {
        if (!longStackTracesIsSupported()) return;
        var firstStackLines = firstLineError.stack.split("\n");
        var lastStackLines = lastLineError.stack.split("\n");
        var firstIndex = -1;
        var lastIndex = -1;
        var firstFileName;
        var lastFileName;
        for (var i = 0; i < firstStackLines.length; ++i) {
          var result2 = parseLineInfo(firstStackLines[i]);
          if (result2) {
            firstFileName = result2.fileName;
            firstIndex = result2.line;
            break;
          }
        }
        for (var i = 0; i < lastStackLines.length; ++i) {
          var result2 = parseLineInfo(lastStackLines[i]);
          if (result2) {
            lastFileName = result2.fileName;
            lastIndex = result2.line;
            break;
          }
        }
        if (firstIndex < 0 || lastIndex < 0 || !firstFileName || !lastFileName || firstFileName !== lastFileName || firstIndex >= lastIndex) {
          return;
        }
        shouldIgnore = function(line) {
          if (bluebirdFramePattern.test(line)) return true;
          var info = parseLineInfo(line);
          if (info) {
            if (info.fileName === firstFileName && firstIndex <= info.line && info.line <= lastIndex) {
              return true;
            }
          }
          return false;
        };
      }
      function CapturedTrace(parent) {
        this._parent = parent;
        this._promisesCreated = 0;
        var length = this._length = 1 + (parent === void 0 ? 0 : parent._length);
        captureStackTrace(this, CapturedTrace);
        if (length > 32) this.uncycle();
      }
      util.inherits(CapturedTrace, Error);
      Context.CapturedTrace = CapturedTrace;
      CapturedTrace.prototype.uncycle = function() {
        var length = this._length;
        if (length < 2) return;
        var nodes = [];
        var stackToIndex = {};
        for (var i = 0, node = this; node !== void 0; ++i) {
          nodes.push(node);
          node = node._parent;
        }
        length = this._length = i;
        for (var i = length - 1; i >= 0; --i) {
          var stack = nodes[i].stack;
          if (stackToIndex[stack] === void 0) {
            stackToIndex[stack] = i;
          }
        }
        for (var i = 0; i < length; ++i) {
          var currentStack = nodes[i].stack;
          var index = stackToIndex[currentStack];
          if (index !== void 0 && index !== i) {
            if (index > 0) {
              nodes[index - 1]._parent = void 0;
              nodes[index - 1]._length = 1;
            }
            nodes[i]._parent = void 0;
            nodes[i]._length = 1;
            var cycleEdgeNode = i > 0 ? nodes[i - 1] : this;
            if (index < length - 1) {
              cycleEdgeNode._parent = nodes[index + 1];
              cycleEdgeNode._parent.uncycle();
              cycleEdgeNode._length = cycleEdgeNode._parent._length + 1;
            } else {
              cycleEdgeNode._parent = void 0;
              cycleEdgeNode._length = 1;
            }
            var currentChildLength = cycleEdgeNode._length + 1;
            for (var j = i - 2; j >= 0; --j) {
              nodes[j]._length = currentChildLength;
              currentChildLength++;
            }
            return;
          }
        }
      };
      CapturedTrace.prototype.attachExtraTrace = function(error) {
        if (error.__stackCleaned__) return;
        this.uncycle();
        var parsed = parseStackAndMessage(error);
        var message = parsed.message;
        var stacks = [parsed.stack];
        var trace = this;
        while (trace !== void 0) {
          stacks.push(cleanStack(trace.stack.split("\n")));
          trace = trace._parent;
        }
        removeCommonRoots(stacks);
        removeDuplicateOrEmptyJumps(stacks);
        util.notEnumerableProp(error, "stack", reconstructStack(message, stacks));
        util.notEnumerableProp(error, "__stackCleaned__", true);
      };
      var captureStackTrace = function stackDetection() {
        var v8stackFramePattern = /^\s*at\s*/;
        var v8stackFormatter = function(stack, error) {
          if (typeof stack === "string") return stack;
          if (error.name !== void 0 && error.message !== void 0) {
            return error.toString();
          }
          return formatNonError(error);
        };
        if (typeof Error.stackTraceLimit === "number" && typeof Error.captureStackTrace === "function") {
          Error.stackTraceLimit += 6;
          stackFramePattern = v8stackFramePattern;
          formatStack = v8stackFormatter;
          var captureStackTrace2 = Error.captureStackTrace;
          shouldIgnore = function(line) {
            return bluebirdFramePattern.test(line);
          };
          return function(receiver, ignoreUntil) {
            Error.stackTraceLimit += 6;
            captureStackTrace2(receiver, ignoreUntil);
            Error.stackTraceLimit -= 6;
          };
        }
        var err = new Error();
        if (typeof err.stack === "string" && err.stack.split("\n")[0].indexOf("stackDetection@") >= 0) {
          stackFramePattern = /@/;
          formatStack = v8stackFormatter;
          indentStackFrames = true;
          return function captureStackTrace3(o) {
            o.stack = new Error().stack;
          };
        }
        var hasStackAfterThrow;
        try {
          throw new Error();
        } catch (e) {
          hasStackAfterThrow = "stack" in e;
        }
        if (!("stack" in err) && hasStackAfterThrow && typeof Error.stackTraceLimit === "number") {
          stackFramePattern = v8stackFramePattern;
          formatStack = v8stackFormatter;
          return function captureStackTrace3(o) {
            Error.stackTraceLimit += 6;
            try {
              throw new Error();
            } catch (e) {
              o.stack = e.stack;
            }
            Error.stackTraceLimit -= 6;
          };
        }
        formatStack = function(stack, error) {
          if (typeof stack === "string") return stack;
          if ((typeof error === "object" || typeof error === "function") && error.name !== void 0 && error.message !== void 0) {
            return error.toString();
          }
          return formatNonError(error);
        };
        return null;
      }([]);
      if (typeof console !== "undefined" && typeof console.warn !== "undefined") {
        printWarning = function(message) {
          console.warn(message);
        };
        if (util.isNode && process.stderr.isTTY) {
          printWarning = function(message, isSoft) {
            var color = isSoft ? "\x1B[33m" : "\x1B[31m";
            console.warn(color + message + "\x1B[0m\n");
          };
        } else if (!util.isNode && typeof new Error().stack === "string") {
          printWarning = function(message, isSoft) {
            console.warn("%c" + message, isSoft ? "color: darkorange" : "color: red");
          };
        }
      }
      var config = {
        warnings,
        longStackTraces: false,
        cancellation: false,
        monitoring: false
      };
      if (longStackTraces) Promise2.longStackTraces();
      return {
        longStackTraces: function() {
          return config.longStackTraces;
        },
        warnings: function() {
          return config.warnings;
        },
        cancellation: function() {
          return config.cancellation;
        },
        monitoring: function() {
          return config.monitoring;
        },
        propagateFromFunction: function() {
          return propagateFromFunction;
        },
        boundValueFunction: function() {
          return boundValueFunction;
        },
        checkForgottenReturns,
        setBounds,
        warn,
        deprecated,
        CapturedTrace,
        fireDomEvent,
        fireGlobalEvent
      };
    };
  }
});

// node_modules/bluebird/js/release/finally.js
var require_finally = __commonJS({
  "node_modules/bluebird/js/release/finally.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, tryConvertToPromise) {
      var util = require_util();
      var CancellationError = Promise2.CancellationError;
      var errorObj2 = util.errorObj;
      function PassThroughHandlerContext(promise, type, handler) {
        this.promise = promise;
        this.type = type;
        this.handler = handler;
        this.called = false;
        this.cancelPromise = null;
      }
      PassThroughHandlerContext.prototype.isFinallyHandler = function() {
        return this.type === 0;
      };
      function FinallyHandlerCancelReaction(finallyHandler2) {
        this.finallyHandler = finallyHandler2;
      }
      FinallyHandlerCancelReaction.prototype._resultCancelled = function() {
        checkCancel(this.finallyHandler);
      };
      function checkCancel(ctx, reason) {
        if (ctx.cancelPromise != null) {
          if (arguments.length > 1) {
            ctx.cancelPromise._reject(reason);
          } else {
            ctx.cancelPromise._cancel();
          }
          ctx.cancelPromise = null;
          return true;
        }
        return false;
      }
      function succeed() {
        return finallyHandler.call(this, this.promise._target()._settledValue());
      }
      function fail(reason) {
        if (checkCancel(this, reason)) return;
        errorObj2.e = reason;
        return errorObj2;
      }
      function finallyHandler(reasonOrValue) {
        var promise = this.promise;
        var handler = this.handler;
        if (!this.called) {
          this.called = true;
          var ret2 = this.isFinallyHandler() ? handler.call(promise._boundValue()) : handler.call(promise._boundValue(), reasonOrValue);
          if (ret2 !== void 0) {
            promise._setReturnedNonUndefined();
            var maybePromise = tryConvertToPromise(ret2, promise);
            if (maybePromise instanceof Promise2) {
              if (this.cancelPromise != null) {
                if (maybePromise._isCancelled()) {
                  var reason = new CancellationError("late cancellation observer");
                  promise._attachExtraTrace(reason);
                  errorObj2.e = reason;
                  return errorObj2;
                } else if (maybePromise.isPending()) {
                  maybePromise._attachCancellationCallback(new FinallyHandlerCancelReaction(this));
                }
              }
              return maybePromise._then(succeed, fail, void 0, this, void 0);
            }
          }
        }
        if (promise.isRejected()) {
          checkCancel(this);
          errorObj2.e = reasonOrValue;
          return errorObj2;
        } else {
          checkCancel(this);
          return reasonOrValue;
        }
      }
      Promise2.prototype._passThrough = function(handler, type, success, fail2) {
        if (typeof handler !== "function") return this.then();
        return this._then(success, fail2, void 0, new PassThroughHandlerContext(this, type, handler), void 0);
      };
      Promise2.prototype.lastly = Promise2.prototype["finally"] = function(handler) {
        return this._passThrough(handler, 0, finallyHandler, finallyHandler);
      };
      Promise2.prototype.tap = function(handler) {
        return this._passThrough(handler, 1, finallyHandler);
      };
      return PassThroughHandlerContext;
    };
  }
});

// node_modules/bluebird/js/release/catch_filter.js
var require_catch_filter = __commonJS({
  "node_modules/bluebird/js/release/catch_filter.js"(exports2, module2) {
    "use strict";
    module2.exports = function(NEXT_FILTER) {
      var util = require_util();
      var getKeys = require_es5().keys;
      var tryCatch2 = util.tryCatch;
      var errorObj2 = util.errorObj;
      function catchFilter(instances, cb2, promise) {
        return function(e) {
          var boundTo = promise._boundValue();
          predicateLoop: for (var i = 0; i < instances.length; ++i) {
            var item = instances[i];
            if (item === Error || item != null && item.prototype instanceof Error) {
              if (e instanceof item) {
                return tryCatch2(cb2).call(boundTo, e);
              }
            } else if (typeof item === "function") {
              var matchesPredicate = tryCatch2(item).call(boundTo, e);
              if (matchesPredicate === errorObj2) {
                return matchesPredicate;
              } else if (matchesPredicate) {
                return tryCatch2(cb2).call(boundTo, e);
              }
            } else if (util.isObject(e)) {
              var keys2 = getKeys(item);
              for (var j = 0; j < keys2.length; ++j) {
                var key = keys2[j];
                if (item[key] != e[key]) {
                  continue predicateLoop;
                }
              }
              return tryCatch2(cb2).call(boundTo, e);
            }
          }
          return NEXT_FILTER;
        };
      }
      return catchFilter;
    };
  }
});

// node_modules/bluebird/js/release/nodeback.js
var require_nodeback = __commonJS({
  "node_modules/bluebird/js/release/nodeback.js"(exports2, module2) {
    "use strict";
    var util = require_util();
    var maybeWrapAsError2 = util.maybeWrapAsError;
    var errors = require_errors();
    var OperationalError = errors.OperationalError;
    var es52 = require_es5();
    function isUntypedError(obj2) {
      return obj2 instanceof Error && es52.getPrototypeOf(obj2) === Error.prototype;
    }
    var rErrorKey = /^(?:name|message|stack|cause)$/;
    function wrapAsOperationalError(obj2) {
      var ret2;
      if (isUntypedError(obj2)) {
        ret2 = new OperationalError(obj2);
        ret2.name = obj2.name;
        ret2.message = obj2.message;
        ret2.stack = obj2.stack;
        var keys2 = es52.keys(obj2);
        for (var i = 0; i < keys2.length; ++i) {
          var key = keys2[i];
          if (!rErrorKey.test(key)) {
            ret2[key] = obj2[key];
          }
        }
        return ret2;
      }
      util.markAsOriginatingFromRejection(obj2);
      return obj2;
    }
    function nodebackForPromise(promise, multiArgs) {
      return function(err, value) {
        if (promise === null) return;
        if (err) {
          var wrapped = wrapAsOperationalError(maybeWrapAsError2(err));
          promise._attachExtraTrace(wrapped);
          promise._reject(wrapped);
        } else if (!multiArgs) {
          promise._fulfill(value);
        } else {
          var $_len = arguments.length;
          var args = new Array(Math.max($_len - 1, 0));
          for (var $_i = 1; $_i < $_len; ++$_i) {
            args[$_i - 1] = arguments[$_i];
          }
          ;
          promise._fulfill(args);
        }
        promise = null;
      };
    }
    module2.exports = nodebackForPromise;
  }
});

// node_modules/bluebird/js/release/method.js
var require_method = __commonJS({
  "node_modules/bluebird/js/release/method.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL, tryConvertToPromise, apiRejection, debug) {
      var util = require_util();
      var tryCatch2 = util.tryCatch;
      Promise2.method = function(fn) {
        if (typeof fn !== "function") {
          throw new Promise2.TypeError("expecting a function but got " + util.classString(fn));
        }
        return function() {
          var ret2 = new Promise2(INTERNAL);
          ret2._captureStackTrace();
          ret2._pushContext();
          var value = tryCatch2(fn).apply(this, arguments);
          var promiseCreated = ret2._popContext();
          debug.checkForgottenReturns(value, promiseCreated, "Promise.method", ret2);
          ret2._resolveFromSyncValue(value);
          return ret2;
        };
      };
      Promise2.attempt = Promise2["try"] = function(fn) {
        if (typeof fn !== "function") {
          return apiRejection("expecting a function but got " + util.classString(fn));
        }
        var ret2 = new Promise2(INTERNAL);
        ret2._captureStackTrace();
        ret2._pushContext();
        var value;
        if (arguments.length > 1) {
          debug.deprecated("calling Promise.try with more than 1 argument");
          var arg = arguments[1];
          var ctx = arguments[2];
          value = util.isArray(arg) ? tryCatch2(fn).apply(ctx, arg) : tryCatch2(fn).call(ctx, arg);
        } else {
          value = tryCatch2(fn)();
        }
        var promiseCreated = ret2._popContext();
        debug.checkForgottenReturns(value, promiseCreated, "Promise.try", ret2);
        ret2._resolveFromSyncValue(value);
        return ret2;
      };
      Promise2.prototype._resolveFromSyncValue = function(value) {
        if (value === util.errorObj) {
          this._rejectCallback(value.e, false);
        } else {
          this._resolveCallback(value, true);
        }
      };
    };
  }
});

// node_modules/bluebird/js/release/bind.js
var require_bind = __commonJS({
  "node_modules/bluebird/js/release/bind.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL, tryConvertToPromise, debug) {
      var calledBind = false;
      var rejectThis = function(_3, e) {
        this._reject(e);
      };
      var targetRejected = function(e, context) {
        context.promiseRejectionQueued = true;
        context.bindingPromise._then(rejectThis, rejectThis, null, this, e);
      };
      var bindingResolved = function(thisArg, context) {
        if ((this._bitField & 50397184) === 0) {
          this._resolveCallback(context.target);
        }
      };
      var bindingRejected = function(e, context) {
        if (!context.promiseRejectionQueued) this._reject(e);
      };
      Promise2.prototype.bind = function(thisArg) {
        if (!calledBind) {
          calledBind = true;
          Promise2.prototype._propagateFrom = debug.propagateFromFunction();
          Promise2.prototype._boundValue = debug.boundValueFunction();
        }
        var maybePromise = tryConvertToPromise(thisArg);
        var ret2 = new Promise2(INTERNAL);
        ret2._propagateFrom(this, 1);
        var target = this._target();
        ret2._setBoundTo(maybePromise);
        if (maybePromise instanceof Promise2) {
          var context = {
            promiseRejectionQueued: false,
            promise: ret2,
            target,
            bindingPromise: maybePromise
          };
          target._then(INTERNAL, targetRejected, void 0, ret2, context);
          maybePromise._then(bindingResolved, bindingRejected, void 0, ret2, context);
          ret2._setOnCancel(maybePromise);
        } else {
          ret2._resolveCallback(target);
        }
        return ret2;
      };
      Promise2.prototype._setBoundTo = function(obj2) {
        if (obj2 !== void 0) {
          this._bitField = this._bitField | 2097152;
          this._boundTo = obj2;
        } else {
          this._bitField = this._bitField & ~2097152;
        }
      };
      Promise2.prototype._isBound = function() {
        return (this._bitField & 2097152) === 2097152;
      };
      Promise2.bind = function(thisArg, value) {
        return Promise2.resolve(value).bind(thisArg);
      };
    };
  }
});

// node_modules/bluebird/js/release/cancel.js
var require_cancel = __commonJS({
  "node_modules/bluebird/js/release/cancel.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, PromiseArray, apiRejection, debug) {
      var util = require_util();
      var tryCatch2 = util.tryCatch;
      var errorObj2 = util.errorObj;
      var async = Promise2._async;
      Promise2.prototype["break"] = Promise2.prototype.cancel = function() {
        if (!debug.cancellation()) return this._warn("cancellation is disabled");
        var promise = this;
        var child = promise;
        while (promise._isCancellable()) {
          if (!promise._cancelBy(child)) {
            if (child._isFollowing()) {
              child._followee().cancel();
            } else {
              child._cancelBranched();
            }
            break;
          }
          var parent = promise._cancellationParent;
          if (parent == null || !parent._isCancellable()) {
            if (promise._isFollowing()) {
              promise._followee().cancel();
            } else {
              promise._cancelBranched();
            }
            break;
          } else {
            if (promise._isFollowing()) promise._followee().cancel();
            promise._setWillBeCancelled();
            child = promise;
            promise = parent;
          }
        }
      };
      Promise2.prototype._branchHasCancelled = function() {
        this._branchesRemainingToCancel--;
      };
      Promise2.prototype._enoughBranchesHaveCancelled = function() {
        return this._branchesRemainingToCancel === void 0 || this._branchesRemainingToCancel <= 0;
      };
      Promise2.prototype._cancelBy = function(canceller) {
        if (canceller === this) {
          this._branchesRemainingToCancel = 0;
          this._invokeOnCancel();
          return true;
        } else {
          this._branchHasCancelled();
          if (this._enoughBranchesHaveCancelled()) {
            this._invokeOnCancel();
            return true;
          }
        }
        return false;
      };
      Promise2.prototype._cancelBranched = function() {
        if (this._enoughBranchesHaveCancelled()) {
          this._cancel();
        }
      };
      Promise2.prototype._cancel = function() {
        if (!this._isCancellable()) return;
        this._setCancelled();
        async.invoke(this._cancelPromises, this, void 0);
      };
      Promise2.prototype._cancelPromises = function() {
        if (this._length() > 0) this._settlePromises();
      };
      Promise2.prototype._unsetOnCancel = function() {
        this._onCancelField = void 0;
      };
      Promise2.prototype._isCancellable = function() {
        return this.isPending() && !this._isCancelled();
      };
      Promise2.prototype.isCancellable = function() {
        return this.isPending() && !this.isCancelled();
      };
      Promise2.prototype._doInvokeOnCancel = function(onCancelCallback, internalOnly) {
        if (util.isArray(onCancelCallback)) {
          for (var i = 0; i < onCancelCallback.length; ++i) {
            this._doInvokeOnCancel(onCancelCallback[i], internalOnly);
          }
        } else if (onCancelCallback !== void 0) {
          if (typeof onCancelCallback === "function") {
            if (!internalOnly) {
              var e = tryCatch2(onCancelCallback).call(this._boundValue());
              if (e === errorObj2) {
                this._attachExtraTrace(e.e);
                async.throwLater(e.e);
              }
            }
          } else {
            onCancelCallback._resultCancelled(this);
          }
        }
      };
      Promise2.prototype._invokeOnCancel = function() {
        var onCancelCallback = this._onCancel();
        this._unsetOnCancel();
        async.invoke(this._doInvokeOnCancel, this, onCancelCallback);
      };
      Promise2.prototype._invokeInternalOnCancel = function() {
        if (this._isCancellable()) {
          this._doInvokeOnCancel(this._onCancel(), true);
          this._unsetOnCancel();
        }
      };
      Promise2.prototype._resultCancelled = function() {
        this.cancel();
      };
    };
  }
});

// node_modules/bluebird/js/release/direct_resolve.js
var require_direct_resolve = __commonJS({
  "node_modules/bluebird/js/release/direct_resolve.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2) {
      function returner() {
        return this.value;
      }
      function thrower2() {
        throw this.reason;
      }
      Promise2.prototype["return"] = Promise2.prototype.thenReturn = function(value) {
        if (value instanceof Promise2) value.suppressUnhandledRejections();
        return this._then(returner, void 0, void 0, {
          value
        }, void 0);
      };
      Promise2.prototype["throw"] = Promise2.prototype.thenThrow = function(reason) {
        return this._then(thrower2, void 0, void 0, {
          reason
        }, void 0);
      };
      Promise2.prototype.catchThrow = function(reason) {
        if (arguments.length <= 1) {
          return this._then(void 0, thrower2, void 0, {
            reason
          }, void 0);
        } else {
          var _reason = arguments[1];
          var handler = function() {
            throw _reason;
          };
          return this.caught(reason, handler);
        }
      };
      Promise2.prototype.catchReturn = function(value) {
        if (arguments.length <= 1) {
          if (value instanceof Promise2) value.suppressUnhandledRejections();
          return this._then(void 0, returner, void 0, {
            value
          }, void 0);
        } else {
          var _value = arguments[1];
          if (_value instanceof Promise2) _value.suppressUnhandledRejections();
          var handler = function() {
            return _value;
          };
          return this.caught(value, handler);
        }
      };
    };
  }
});

// node_modules/bluebird/js/release/synchronous_inspection.js
var require_synchronous_inspection = __commonJS({
  "node_modules/bluebird/js/release/synchronous_inspection.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2) {
      function PromiseInspection(promise) {
        if (promise !== void 0) {
          promise = promise._target();
          this._bitField = promise._bitField;
          this._settledValueField = promise._isFateSealed() ? promise._settledValue() : void 0;
        } else {
          this._bitField = 0;
          this._settledValueField = void 0;
        }
      }
      PromiseInspection.prototype._settledValue = function() {
        return this._settledValueField;
      };
      var value = PromiseInspection.prototype.value = function() {
        if (!this.isFulfilled()) {
          throw new TypeError("cannot get fulfillment value of a non-fulfilled promise\n\n    See http://goo.gl/MqrFmX\n");
        }
        return this._settledValue();
      };
      var reason = PromiseInspection.prototype.error = PromiseInspection.prototype.reason = function() {
        if (!this.isRejected()) {
          throw new TypeError("cannot get rejection reason of a non-rejected promise\n\n    See http://goo.gl/MqrFmX\n");
        }
        return this._settledValue();
      };
      var isFulfilled = PromiseInspection.prototype.isFulfilled = function() {
        return (this._bitField & 33554432) !== 0;
      };
      var isRejected = PromiseInspection.prototype.isRejected = function() {
        return (this._bitField & 16777216) !== 0;
      };
      var isPending = PromiseInspection.prototype.isPending = function() {
        return (this._bitField & 50397184) === 0;
      };
      var isResolved = PromiseInspection.prototype.isResolved = function() {
        return (this._bitField & 50331648) !== 0;
      };
      PromiseInspection.prototype.isCancelled = function() {
        return (this._bitField & 8454144) !== 0;
      };
      Promise2.prototype.__isCancelled = function() {
        return (this._bitField & 65536) === 65536;
      };
      Promise2.prototype._isCancelled = function() {
        return this._target().__isCancelled();
      };
      Promise2.prototype.isCancelled = function() {
        return (this._target()._bitField & 8454144) !== 0;
      };
      Promise2.prototype.isPending = function() {
        return isPending.call(this._target());
      };
      Promise2.prototype.isRejected = function() {
        return isRejected.call(this._target());
      };
      Promise2.prototype.isFulfilled = function() {
        return isFulfilled.call(this._target());
      };
      Promise2.prototype.isResolved = function() {
        return isResolved.call(this._target());
      };
      Promise2.prototype.value = function() {
        return value.call(this._target());
      };
      Promise2.prototype.reason = function() {
        var target = this._target();
        target._unsetRejectionIsUnhandled();
        return reason.call(target);
      };
      Promise2.prototype._value = function() {
        return this._settledValue();
      };
      Promise2.prototype._reason = function() {
        this._unsetRejectionIsUnhandled();
        return this._settledValue();
      };
      Promise2.PromiseInspection = PromiseInspection;
    };
  }
});

// node_modules/bluebird/js/release/join.js
var require_join = __commonJS({
  "node_modules/bluebird/js/release/join.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, PromiseArray, tryConvertToPromise, INTERNAL, async, getDomain) {
      var util = require_util();
      var canEvaluate2 = util.canEvaluate;
      var tryCatch2 = util.tryCatch;
      var errorObj2 = util.errorObj;
      var reject2;
      if (true) {
        if (canEvaluate2) {
          var thenCallback = function(i2) {
            return new Function("value", "holder", "                             \n            'use strict';                                                    \n            holder.pIndex = value;                                           \n            holder.checkFulfillment(this);                                   \n            ".replace(/Index/g, i2));
          };
          var promiseSetter = function(i2) {
            return new Function("promise", "holder", "                           \n            'use strict';                                                    \n            holder.pIndex = promise;                                         \n            ".replace(/Index/g, i2));
          };
          var generateHolderClass = function(total) {
            var props = new Array(total);
            for (var i2 = 0; i2 < props.length; ++i2) {
              props[i2] = "this.p" + (i2 + 1);
            }
            var assignment = props.join(" = ") + " = null;";
            var cancellationCode = "var promise;\n" + props.map(function(prop) {
              return "                                                         \n                promise = " + prop + ";                                      \n                if (promise instanceof Promise) {                            \n                    promise.cancel();                                        \n                }                                                            \n            ";
            }).join("\n");
            var passedArguments = props.join(", ");
            var name = "Holder$" + total;
            var code = "return function(tryCatch, errorObj, Promise, async) {    \n            'use strict';                                                    \n            function [TheName](fn) {                                         \n                [TheProperties]                                              \n                this.fn = fn;                                                \n                this.asyncNeeded = true;                                     \n                this.now = 0;                                                \n            }                                                                \n                                                                             \n            [TheName].prototype._callFunction = function(promise) {          \n                promise._pushContext();                                      \n                var ret = tryCatch(this.fn)([ThePassedArguments]);           \n                promise._popContext();                                       \n                if (ret === errorObj) {                                      \n                    promise._rejectCallback(ret.e, false);                   \n                } else {                                                     \n                    promise._resolveCallback(ret);                           \n                }                                                            \n            };                                                               \n                                                                             \n            [TheName].prototype.checkFulfillment = function(promise) {       \n                var now = ++this.now;                                        \n                if (now === [TheTotal]) {                                    \n                    if (this.asyncNeeded) {                                  \n                        async.invoke(this._callFunction, this, promise);     \n                    } else {                                                 \n                        this._callFunction(promise);                         \n                    }                                                        \n                                                                             \n                }                                                            \n            };                                                               \n                                                                             \n            [TheName].prototype._resultCancelled = function() {              \n                [CancellationCode]                                           \n            };                                                               \n                                                                             \n            return [TheName];                                                \n        }(tryCatch, errorObj, Promise, async);                               \n        ";
            code = code.replace(/\[TheName\]/g, name).replace(/\[TheTotal\]/g, total).replace(/\[ThePassedArguments\]/g, passedArguments).replace(/\[TheProperties\]/g, assignment).replace(/\[CancellationCode\]/g, cancellationCode);
            return new Function("tryCatch", "errorObj", "Promise", "async", code)(tryCatch2, errorObj2, Promise2, async);
          };
          var holderClasses = [];
          var thenCallbacks = [];
          var promiseSetters = [];
          for (var i = 0; i < 8; ++i) {
            holderClasses.push(generateHolderClass(i + 1));
            thenCallbacks.push(thenCallback(i + 1));
            promiseSetters.push(promiseSetter(i + 1));
          }
          reject2 = function(reason) {
            this._reject(reason);
          };
        }
      }
      Promise2.join = function() {
        var last2 = arguments.length - 1;
        var fn;
        if (last2 > 0 && typeof arguments[last2] === "function") {
          fn = arguments[last2];
          if (true) {
            if (last2 <= 8 && canEvaluate2) {
              var ret2 = new Promise2(INTERNAL);
              ret2._captureStackTrace();
              var HolderClass = holderClasses[last2 - 1];
              var holder = new HolderClass(fn);
              var callbacks = thenCallbacks;
              for (var i2 = 0; i2 < last2; ++i2) {
                var maybePromise = tryConvertToPromise(arguments[i2], ret2);
                if (maybePromise instanceof Promise2) {
                  maybePromise = maybePromise._target();
                  var bitField = maybePromise._bitField;
                  ;
                  if ((bitField & 50397184) === 0) {
                    maybePromise._then(callbacks[i2], reject2, void 0, ret2, holder);
                    promiseSetters[i2](maybePromise, holder);
                    holder.asyncNeeded = false;
                  } else if ((bitField & 33554432) !== 0) {
                    callbacks[i2].call(ret2, maybePromise._value(), holder);
                  } else if ((bitField & 16777216) !== 0) {
                    ret2._reject(maybePromise._reason());
                  } else {
                    ret2._cancel();
                  }
                } else {
                  callbacks[i2].call(ret2, maybePromise, holder);
                }
              }
              if (!ret2._isFateSealed()) {
                if (holder.asyncNeeded) {
                  var domain = getDomain();
                  if (domain !== null) {
                    holder.fn = util.domainBind(domain, holder.fn);
                  }
                }
                ret2._setAsyncGuaranteed();
                ret2._setOnCancel(holder);
              }
              return ret2;
            }
          }
        }
        var $_len = arguments.length;
        var args = new Array($_len);
        for (var $_i = 0; $_i < $_len; ++$_i) {
          args[$_i] = arguments[$_i];
        }
        ;
        if (fn) args.pop();
        var ret2 = new PromiseArray(args).promise();
        return fn !== void 0 ? ret2.spread(fn) : ret2;
      };
    };
  }
});

// node_modules/bluebird/js/release/map.js
var require_map = __commonJS({
  "node_modules/bluebird/js/release/map.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, PromiseArray, apiRejection, tryConvertToPromise, INTERNAL, debug) {
      var getDomain = Promise2._getDomain;
      var util = require_util();
      var tryCatch2 = util.tryCatch;
      var errorObj2 = util.errorObj;
      var async = Promise2._async;
      function MappingPromiseArray(promises, fn, limit, _filter) {
        this.constructor$(promises);
        this._promise._captureStackTrace();
        var domain = getDomain();
        this._callback = domain === null ? fn : util.domainBind(domain, fn);
        this._preservedValues = _filter === INTERNAL ? new Array(this.length()) : null;
        this._limit = limit;
        this._inFlight = 0;
        this._queue = [];
        async.invoke(this._asyncInit, this, void 0);
      }
      util.inherits(MappingPromiseArray, PromiseArray);
      MappingPromiseArray.prototype._asyncInit = function() {
        this._init$(void 0, -2);
      };
      MappingPromiseArray.prototype._init = function() {
      };
      MappingPromiseArray.prototype._promiseFulfilled = function(value, index) {
        var values2 = this._values;
        var length = this.length();
        var preservedValues = this._preservedValues;
        var limit = this._limit;
        if (index < 0) {
          index = index * -1 - 1;
          values2[index] = value;
          if (limit >= 1) {
            this._inFlight--;
            this._drainQueue();
            if (this._isResolved()) return true;
          }
        } else {
          if (limit >= 1 && this._inFlight >= limit) {
            values2[index] = value;
            this._queue.push(index);
            return false;
          }
          if (preservedValues !== null) preservedValues[index] = value;
          var promise = this._promise;
          var callback = this._callback;
          var receiver = promise._boundValue();
          promise._pushContext();
          var ret2 = tryCatch2(callback).call(receiver, value, index, length);
          var promiseCreated = promise._popContext();
          debug.checkForgottenReturns(ret2, promiseCreated, preservedValues !== null ? "Promise.filter" : "Promise.map", promise);
          if (ret2 === errorObj2) {
            this._reject(ret2.e);
            return true;
          }
          var maybePromise = tryConvertToPromise(ret2, this._promise);
          if (maybePromise instanceof Promise2) {
            maybePromise = maybePromise._target();
            var bitField = maybePromise._bitField;
            ;
            if ((bitField & 50397184) === 0) {
              if (limit >= 1) this._inFlight++;
              values2[index] = maybePromise;
              maybePromise._proxy(this, (index + 1) * -1);
              return false;
            } else if ((bitField & 33554432) !== 0) {
              ret2 = maybePromise._value();
            } else if ((bitField & 16777216) !== 0) {
              this._reject(maybePromise._reason());
              return true;
            } else {
              this._cancel();
              return true;
            }
          }
          values2[index] = ret2;
        }
        var totalResolved = ++this._totalResolved;
        if (totalResolved >= length) {
          if (preservedValues !== null) {
            this._filter(values2, preservedValues);
          } else {
            this._resolve(values2);
          }
          return true;
        }
        return false;
      };
      MappingPromiseArray.prototype._drainQueue = function() {
        var queue = this._queue;
        var limit = this._limit;
        var values2 = this._values;
        while (queue.length > 0 && this._inFlight < limit) {
          if (this._isResolved()) return;
          var index = queue.pop();
          this._promiseFulfilled(values2[index], index);
        }
      };
      MappingPromiseArray.prototype._filter = function(booleans, values2) {
        var len = values2.length;
        var ret2 = new Array(len);
        var j = 0;
        for (var i = 0; i < len; ++i) {
          if (booleans[i]) ret2[j++] = values2[i];
        }
        ret2.length = j;
        this._resolve(ret2);
      };
      MappingPromiseArray.prototype.preservedValues = function() {
        return this._preservedValues;
      };
      function map2(promises, fn, options, _filter) {
        if (typeof fn !== "function") {
          return apiRejection("expecting a function but got " + util.classString(fn));
        }
        var limit = 0;
        if (options !== void 0) {
          if (typeof options === "object" && options !== null) {
            if (typeof options.concurrency !== "number") {
              return Promise2.reject(new TypeError("'concurrency' must be a number but it is " + util.classString(options.concurrency)));
            }
            limit = options.concurrency;
          } else {
            return Promise2.reject(new TypeError("options argument must be an object but it is " + util.classString(options)));
          }
        }
        limit = typeof limit === "number" && isFinite(limit) && limit >= 1 ? limit : 0;
        return new MappingPromiseArray(promises, fn, limit, _filter).promise();
      }
      Promise2.prototype.map = function(fn, options) {
        return map2(this, fn, options, null);
      };
      Promise2.map = function(promises, fn, options, _filter) {
        return map2(promises, fn, options, _filter);
      };
    };
  }
});

// node_modules/bluebird/js/release/call_get.js
var require_call_get = __commonJS({
  "node_modules/bluebird/js/release/call_get.js"(exports2, module2) {
    "use strict";
    var cr = Object.create;
    if (cr) {
      callerCache = cr(null);
      getterCache = cr(null);
      callerCache[" size"] = getterCache[" size"] = 0;
    }
    var callerCache;
    var getterCache;
    module2.exports = function(Promise2) {
      var util = require_util();
      var canEvaluate2 = util.canEvaluate;
      var isIdentifier2 = util.isIdentifier;
      var getMethodCaller;
      var getGetter;
      if (true) {
        var makeMethodCaller = function(methodName) {
          return new Function("ensureMethod", "                                    \n        return function(obj) {                                               \n            'use strict'                                                     \n            var len = this.length;                                           \n            ensureMethod(obj, 'methodName');                                 \n            switch(len) {                                                    \n                case 1: return obj.methodName(this[0]);                      \n                case 2: return obj.methodName(this[0], this[1]);             \n                case 3: return obj.methodName(this[0], this[1], this[2]);    \n                case 0: return obj.methodName();                             \n                default:                                                     \n                    return obj.methodName.apply(obj, this);                  \n            }                                                                \n        };                                                                   \n        ".replace(/methodName/g, methodName))(ensureMethod);
        };
        var makeGetter = function(propertyName) {
          return new Function("obj", "                                             \n        'use strict';                                                        \n        return obj.propertyName;                                             \n        ".replace("propertyName", propertyName));
        };
        var getCompiled = function(name, compiler, cache) {
          var ret2 = cache[name];
          if (typeof ret2 !== "function") {
            if (!isIdentifier2(name)) {
              return null;
            }
            ret2 = compiler(name);
            cache[name] = ret2;
            cache[" size"]++;
            if (cache[" size"] > 512) {
              var keys2 = Object.keys(cache);
              for (var i = 0; i < 256; ++i) delete cache[keys2[i]];
              cache[" size"] = keys2.length - 256;
            }
          }
          return ret2;
        };
        getMethodCaller = function(name) {
          return getCompiled(name, makeMethodCaller, callerCache);
        };
        getGetter = function(name) {
          return getCompiled(name, makeGetter, getterCache);
        };
      }
      function ensureMethod(obj2, methodName) {
        var fn;
        if (obj2 != null) fn = obj2[methodName];
        if (typeof fn !== "function") {
          var message = "Object " + util.classString(obj2) + " has no method '" + util.toString(methodName) + "'";
          throw new Promise2.TypeError(message);
        }
        return fn;
      }
      function caller(obj2) {
        var methodName = this.pop();
        var fn = ensureMethod(obj2, methodName);
        return fn.apply(obj2, this);
      }
      Promise2.prototype.call = function(methodName) {
        var $_len = arguments.length;
        var args = new Array(Math.max($_len - 1, 0));
        for (var $_i = 1; $_i < $_len; ++$_i) {
          args[$_i - 1] = arguments[$_i];
        }
        ;
        if (true) {
          if (canEvaluate2) {
            var maybeCaller = getMethodCaller(methodName);
            if (maybeCaller !== null) {
              return this._then(maybeCaller, void 0, void 0, args, void 0);
            }
          }
        }
        args.push(methodName);
        return this._then(caller, void 0, void 0, args, void 0);
      };
      function namedGetter(obj2) {
        return obj2[this];
      }
      function indexedGetter(obj2) {
        var index = +this;
        if (index < 0) index = Math.max(0, index + obj2.length);
        return obj2[index];
      }
      Promise2.prototype.get = function(propertyName) {
        var isIndex = typeof propertyName === "number";
        var getter;
        if (!isIndex) {
          if (canEvaluate2) {
            var maybeGetter = getGetter(propertyName);
            getter = maybeGetter !== null ? maybeGetter : namedGetter;
          } else {
            getter = namedGetter;
          }
        } else {
          getter = indexedGetter;
        }
        return this._then(getter, void 0, void 0, propertyName, void 0);
      };
    };
  }
});

// node_modules/bluebird/js/release/using.js
var require_using = __commonJS({
  "node_modules/bluebird/js/release/using.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, apiRejection, tryConvertToPromise, createContext, INTERNAL, debug) {
      var util = require_util();
      var TypeError2 = require_errors().TypeError;
      var inherits2 = require_util().inherits;
      var errorObj2 = util.errorObj;
      var tryCatch2 = util.tryCatch;
      var NULL = {};
      function thrower2(e) {
        setTimeout(function() {
          throw e;
        }, 0);
      }
      function castPreservingDisposable(thenable) {
        var maybePromise = tryConvertToPromise(thenable);
        if (maybePromise !== thenable && typeof thenable._isDisposable === "function" && typeof thenable._getDisposer === "function" && thenable._isDisposable()) {
          maybePromise._setDisposable(thenable._getDisposer());
        }
        return maybePromise;
      }
      function dispose(resources, inspection) {
        var i = 0;
        var len = resources.length;
        var ret2 = new Promise2(INTERNAL);
        function iterator() {
          if (i >= len) return ret2._fulfill();
          var maybePromise = castPreservingDisposable(resources[i++]);
          if (maybePromise instanceof Promise2 && maybePromise._isDisposable()) {
            try {
              maybePromise = tryConvertToPromise(maybePromise._getDisposer().tryDispose(inspection), resources.promise);
            } catch (e) {
              return thrower2(e);
            }
            if (maybePromise instanceof Promise2) {
              return maybePromise._then(iterator, thrower2, null, null, null);
            }
          }
          iterator();
        }
        iterator();
        return ret2;
      }
      function Disposer(data, promise, context) {
        this._data = data;
        this._promise = promise;
        this._context = context;
      }
      Disposer.prototype.data = function() {
        return this._data;
      };
      Disposer.prototype.promise = function() {
        return this._promise;
      };
      Disposer.prototype.resource = function() {
        if (this.promise().isFulfilled()) {
          return this.promise().value();
        }
        return NULL;
      };
      Disposer.prototype.tryDispose = function(inspection) {
        var resource = this.resource();
        var context = this._context;
        if (context !== void 0) context._pushContext();
        var ret2 = resource !== NULL ? this.doDispose(resource, inspection) : null;
        if (context !== void 0) context._popContext();
        this._promise._unsetDisposable();
        this._data = null;
        return ret2;
      };
      Disposer.isDisposer = function(d) {
        return d != null && typeof d.resource === "function" && typeof d.tryDispose === "function";
      };
      function FunctionDisposer(fn, promise, context) {
        this.constructor$(fn, promise, context);
      }
      inherits2(FunctionDisposer, Disposer);
      FunctionDisposer.prototype.doDispose = function(resource, inspection) {
        var fn = this.data();
        return fn.call(resource, resource, inspection);
      };
      function maybeUnwrapDisposer(value) {
        if (Disposer.isDisposer(value)) {
          this.resources[this.index]._setDisposable(value);
          return value.promise();
        }
        return value;
      }
      function ResourceList(length) {
        this.length = length;
        this.promise = null;
        this[length - 1] = null;
      }
      ResourceList.prototype._resultCancelled = function() {
        var len = this.length;
        for (var i = 0; i < len; ++i) {
          var item = this[i];
          if (item instanceof Promise2) {
            item.cancel();
          }
        }
      };
      Promise2.using = function() {
        var len = arguments.length;
        if (len < 2) return apiRejection("you must pass at least 2 arguments to Promise.using");
        var fn = arguments[len - 1];
        if (typeof fn !== "function") {
          return apiRejection("expecting a function but got " + util.classString(fn));
        }
        var input;
        var spreadArgs = true;
        if (len === 2 && Array.isArray(arguments[0])) {
          input = arguments[0];
          len = input.length;
          spreadArgs = false;
        } else {
          input = arguments;
          len--;
        }
        var resources = new ResourceList(len);
        for (var i = 0; i < len; ++i) {
          var resource = input[i];
          if (Disposer.isDisposer(resource)) {
            var disposer = resource;
            resource = resource.promise();
            resource._setDisposable(disposer);
          } else {
            var maybePromise = tryConvertToPromise(resource);
            if (maybePromise instanceof Promise2) {
              resource = maybePromise._then(maybeUnwrapDisposer, null, null, {
                resources,
                index: i
              }, void 0);
            }
          }
          resources[i] = resource;
        }
        var reflectedResources = new Array(resources.length);
        for (var i = 0; i < reflectedResources.length; ++i) {
          reflectedResources[i] = Promise2.resolve(resources[i]).reflect();
        }
        var resultPromise = Promise2.all(reflectedResources).then(function(inspections) {
          for (var i2 = 0; i2 < inspections.length; ++i2) {
            var inspection = inspections[i2];
            if (inspection.isRejected()) {
              errorObj2.e = inspection.error();
              return errorObj2;
            } else if (!inspection.isFulfilled()) {
              resultPromise.cancel();
              return;
            }
            inspections[i2] = inspection.value();
          }
          promise._pushContext();
          fn = tryCatch2(fn);
          var ret2 = spreadArgs ? fn.apply(void 0, inspections) : fn(inspections);
          var promiseCreated = promise._popContext();
          debug.checkForgottenReturns(ret2, promiseCreated, "Promise.using", promise);
          return ret2;
        });
        var promise = resultPromise.lastly(function() {
          var inspection = new Promise2.PromiseInspection(resultPromise);
          return dispose(resources, inspection);
        });
        resources.promise = promise;
        promise._setOnCancel(resources);
        return promise;
      };
      Promise2.prototype._setDisposable = function(disposer) {
        this._bitField = this._bitField | 131072;
        this._disposer = disposer;
      };
      Promise2.prototype._isDisposable = function() {
        return (this._bitField & 131072) > 0;
      };
      Promise2.prototype._getDisposer = function() {
        return this._disposer;
      };
      Promise2.prototype._unsetDisposable = function() {
        this._bitField = this._bitField & ~131072;
        this._disposer = void 0;
      };
      Promise2.prototype.disposer = function(fn) {
        if (typeof fn === "function") {
          return new FunctionDisposer(fn, this, createContext());
        }
        throw new TypeError2();
      };
    };
  }
});

// node_modules/bluebird/js/release/timers.js
var require_timers = __commonJS({
  "node_modules/bluebird/js/release/timers.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL, debug) {
      var util = require_util();
      var TimeoutError = Promise2.TimeoutError;
      function HandleWrapper(handle) {
        this.handle = handle;
      }
      HandleWrapper.prototype._resultCancelled = function() {
        clearTimeout(this.handle);
      };
      var afterValue = function(value) {
        return delay(+this).thenReturn(value);
      };
      var delay = Promise2.delay = function(ms, value) {
        var ret2;
        var handle;
        if (value !== void 0) {
          ret2 = Promise2.resolve(value)._then(afterValue, null, null, ms, void 0);
          if (debug.cancellation() && value instanceof Promise2) {
            ret2._setOnCancel(value);
          }
        } else {
          ret2 = new Promise2(INTERNAL);
          handle = setTimeout(function() {
            ret2._fulfill();
          }, +ms);
          if (debug.cancellation()) {
            ret2._setOnCancel(new HandleWrapper(handle));
          }
          ret2._captureStackTrace();
        }
        ret2._setAsyncGuaranteed();
        return ret2;
      };
      Promise2.prototype.delay = function(ms) {
        return delay(ms, this);
      };
      var afterTimeout = function(promise, message, parent) {
        var err;
        if (typeof message !== "string") {
          if (message instanceof Error) {
            err = message;
          } else {
            err = new TimeoutError("operation timed out");
          }
        } else {
          err = new TimeoutError(message);
        }
        util.markAsOriginatingFromRejection(err);
        promise._attachExtraTrace(err);
        promise._reject(err);
        if (parent != null) {
          parent.cancel();
        }
      };
      function successClear(value) {
        clearTimeout(this.handle);
        return value;
      }
      function failureClear(reason) {
        clearTimeout(this.handle);
        throw reason;
      }
      Promise2.prototype.timeout = function(ms, message) {
        ms = +ms;
        var ret2, parent;
        var handleWrapper = new HandleWrapper(setTimeout(function timeoutTimeout() {
          if (ret2.isPending()) {
            afterTimeout(ret2, message, parent);
          }
        }, ms));
        if (debug.cancellation()) {
          parent = this.then();
          ret2 = parent._then(successClear, failureClear, void 0, handleWrapper, void 0);
          ret2._setOnCancel(handleWrapper);
        } else {
          ret2 = this._then(successClear, failureClear, void 0, handleWrapper, void 0);
        }
        return ret2;
      };
    };
  }
});

// node_modules/bluebird/js/release/generators.js
var require_generators = __commonJS({
  "node_modules/bluebird/js/release/generators.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, apiRejection, INTERNAL, tryConvertToPromise, Proxyable, debug) {
      var errors = require_errors();
      var TypeError2 = errors.TypeError;
      var util = require_util();
      var errorObj2 = util.errorObj;
      var tryCatch2 = util.tryCatch;
      var yieldHandlers = [];
      function promiseFromYieldHandler(value, yieldHandlers2, traceParent) {
        for (var i = 0; i < yieldHandlers2.length; ++i) {
          traceParent._pushContext();
          var result2 = tryCatch2(yieldHandlers2[i])(value);
          traceParent._popContext();
          if (result2 === errorObj2) {
            traceParent._pushContext();
            var ret2 = Promise2.reject(errorObj2.e);
            traceParent._popContext();
            return ret2;
          }
          var maybePromise = tryConvertToPromise(result2, traceParent);
          if (maybePromise instanceof Promise2) return maybePromise;
        }
        return null;
      }
      function PromiseSpawn(generatorFunction, receiver, yieldHandler, stack) {
        if (debug.cancellation()) {
          var internal = new Promise2(INTERNAL);
          var _finallyPromise = this._finallyPromise = new Promise2(INTERNAL);
          this._promise = internal.lastly(function() {
            return _finallyPromise;
          });
          internal._captureStackTrace();
          internal._setOnCancel(this);
        } else {
          var promise = this._promise = new Promise2(INTERNAL);
          promise._captureStackTrace();
        }
        this._stack = stack;
        this._generatorFunction = generatorFunction;
        this._receiver = receiver;
        this._generator = void 0;
        this._yieldHandlers = typeof yieldHandler === "function" ? [yieldHandler].concat(yieldHandlers) : yieldHandlers;
        this._yieldedPromise = null;
        this._cancellationPhase = false;
      }
      util.inherits(PromiseSpawn, Proxyable);
      PromiseSpawn.prototype._isResolved = function() {
        return this._promise === null;
      };
      PromiseSpawn.prototype._cleanup = function() {
        this._promise = this._generator = null;
        if (debug.cancellation() && this._finallyPromise !== null) {
          this._finallyPromise._fulfill();
          this._finallyPromise = null;
        }
      };
      PromiseSpawn.prototype._promiseCancelled = function() {
        if (this._isResolved()) return;
        var implementsReturn = typeof this._generator["return"] !== "undefined";
        var result2;
        if (!implementsReturn) {
          var reason = new Promise2.CancellationError("generator .return() sentinel");
          Promise2.coroutine.returnSentinel = reason;
          this._promise._attachExtraTrace(reason);
          this._promise._pushContext();
          result2 = tryCatch2(this._generator["throw"]).call(this._generator, reason);
          this._promise._popContext();
        } else {
          this._promise._pushContext();
          result2 = tryCatch2(this._generator["return"]).call(this._generator, void 0);
          this._promise._popContext();
        }
        this._cancellationPhase = true;
        this._yieldedPromise = null;
        this._continue(result2);
      };
      PromiseSpawn.prototype._promiseFulfilled = function(value) {
        this._yieldedPromise = null;
        this._promise._pushContext();
        var result2 = tryCatch2(this._generator.next).call(this._generator, value);
        this._promise._popContext();
        this._continue(result2);
      };
      PromiseSpawn.prototype._promiseRejected = function(reason) {
        this._yieldedPromise = null;
        this._promise._attachExtraTrace(reason);
        this._promise._pushContext();
        var result2 = tryCatch2(this._generator["throw"]).call(this._generator, reason);
        this._promise._popContext();
        this._continue(result2);
      };
      PromiseSpawn.prototype._resultCancelled = function() {
        if (this._yieldedPromise instanceof Promise2) {
          var promise = this._yieldedPromise;
          this._yieldedPromise = null;
          promise.cancel();
        }
      };
      PromiseSpawn.prototype.promise = function() {
        return this._promise;
      };
      PromiseSpawn.prototype._run = function() {
        this._generator = this._generatorFunction.call(this._receiver);
        this._receiver = this._generatorFunction = void 0;
        this._promiseFulfilled(void 0);
      };
      PromiseSpawn.prototype._continue = function(result2) {
        var promise = this._promise;
        if (result2 === errorObj2) {
          this._cleanup();
          if (this._cancellationPhase) {
            return promise.cancel();
          } else {
            return promise._rejectCallback(result2.e, false);
          }
        }
        var value = result2.value;
        if (result2.done === true) {
          this._cleanup();
          if (this._cancellationPhase) {
            return promise.cancel();
          } else {
            return promise._resolveCallback(value);
          }
        } else {
          var maybePromise = tryConvertToPromise(value, this._promise);
          if (!(maybePromise instanceof Promise2)) {
            maybePromise = promiseFromYieldHandler(maybePromise, this._yieldHandlers, this._promise);
            if (maybePromise === null) {
              this._promiseRejected(new TypeError2("A value %s was yielded that could not be treated as a promise\n\n    See http://goo.gl/MqrFmX\n\n".replace("%s", value) + "From coroutine:\n" + this._stack.split("\n").slice(1, -7).join("\n")));
              return;
            }
          }
          maybePromise = maybePromise._target();
          var bitField = maybePromise._bitField;
          ;
          if ((bitField & 50397184) === 0) {
            this._yieldedPromise = maybePromise;
            maybePromise._proxy(this, null);
          } else if ((bitField & 33554432) !== 0) {
            Promise2._async.invoke(this._promiseFulfilled, this, maybePromise._value());
          } else if ((bitField & 16777216) !== 0) {
            Promise2._async.invoke(this._promiseRejected, this, maybePromise._reason());
          } else {
            this._promiseCancelled();
          }
        }
      };
      Promise2.coroutine = function(generatorFunction, options) {
        if (typeof generatorFunction !== "function") {
          throw new TypeError2("generatorFunction must be a function\n\n    See http://goo.gl/MqrFmX\n");
        }
        var yieldHandler = Object(options).yieldHandler;
        var PromiseSpawn$ = PromiseSpawn;
        var stack = new Error().stack;
        return function() {
          var generator = generatorFunction.apply(this, arguments);
          var spawn = new PromiseSpawn$(void 0, void 0, yieldHandler, stack);
          var ret2 = spawn.promise();
          spawn._generator = generator;
          spawn._promiseFulfilled(void 0);
          return ret2;
        };
      };
      Promise2.coroutine.addYieldHandler = function(fn) {
        if (typeof fn !== "function") {
          throw new TypeError2("expecting a function but got " + util.classString(fn));
        }
        yieldHandlers.push(fn);
      };
      Promise2.spawn = function(generatorFunction) {
        debug.deprecated("Promise.spawn()", "Promise.coroutine()");
        if (typeof generatorFunction !== "function") {
          return apiRejection("generatorFunction must be a function\n\n    See http://goo.gl/MqrFmX\n");
        }
        var spawn = new PromiseSpawn(generatorFunction, this);
        var ret2 = spawn.promise();
        spawn._run(Promise2.spawn);
        return ret2;
      };
    };
  }
});

// node_modules/bluebird/js/release/nodeify.js
var require_nodeify = __commonJS({
  "node_modules/bluebird/js/release/nodeify.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2) {
      var util = require_util();
      var async = Promise2._async;
      var tryCatch2 = util.tryCatch;
      var errorObj2 = util.errorObj;
      function spreadAdapter(val, nodeback) {
        var promise = this;
        if (!util.isArray(val)) return successAdapter.call(promise, val, nodeback);
        var ret2 = tryCatch2(nodeback).apply(promise._boundValue(), [null].concat(val));
        if (ret2 === errorObj2) {
          async.throwLater(ret2.e);
        }
      }
      function successAdapter(val, nodeback) {
        var promise = this;
        var receiver = promise._boundValue();
        var ret2 = val === void 0 ? tryCatch2(nodeback).call(receiver, null) : tryCatch2(nodeback).call(receiver, null, val);
        if (ret2 === errorObj2) {
          async.throwLater(ret2.e);
        }
      }
      function errorAdapter(reason, nodeback) {
        var promise = this;
        if (!reason) {
          var newReason = new Error(reason + "");
          newReason.cause = reason;
          reason = newReason;
        }
        var ret2 = tryCatch2(nodeback).call(promise._boundValue(), reason);
        if (ret2 === errorObj2) {
          async.throwLater(ret2.e);
        }
      }
      Promise2.prototype.asCallback = Promise2.prototype.nodeify = function(nodeback, options) {
        if (typeof nodeback == "function") {
          var adapter = successAdapter;
          if (options !== void 0 && Object(options).spread) {
            adapter = spreadAdapter;
          }
          this._then(adapter, errorAdapter, void 0, this, nodeback);
        }
        return this;
      };
    };
  }
});

// node_modules/bluebird/js/release/promisify.js
var require_promisify = __commonJS({
  "node_modules/bluebird/js/release/promisify.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL) {
      var THIS = {};
      var util = require_util();
      var nodebackForPromise = require_nodeback();
      var withAppended2 = util.withAppended;
      var maybeWrapAsError2 = util.maybeWrapAsError;
      var canEvaluate2 = util.canEvaluate;
      var TypeError2 = require_errors().TypeError;
      var defaultSuffix = "Async";
      var defaultPromisified = {
        __isPromisified__: true
      };
      var noCopyProps = ["arity", "length", "name", "arguments", "caller", "callee", "prototype", "__isPromisified__"];
      var noCopyPropsPattern = new RegExp("^(?:" + noCopyProps.join("|") + ")$");
      var defaultFilter = function(name) {
        return util.isIdentifier(name) && name.charAt(0) !== "_" && name !== "constructor";
      };
      function propsFilter(key) {
        return !noCopyPropsPattern.test(key);
      }
      function isPromisified(fn) {
        try {
          return fn.__isPromisified__ === true;
        } catch (e) {
          return false;
        }
      }
      function hasPromisified(obj2, key, suffix) {
        var val = util.getDataPropertyOrDefault(obj2, key + suffix, defaultPromisified);
        return val ? isPromisified(val) : false;
      }
      function checkValid(ret2, suffix, suffixRegexp) {
        for (var i = 0; i < ret2.length; i += 2) {
          var key = ret2[i];
          if (suffixRegexp.test(key)) {
            var keyWithoutAsyncSuffix = key.replace(suffixRegexp, "");
            for (var j = 0; j < ret2.length; j += 2) {
              if (ret2[j] === keyWithoutAsyncSuffix) {
                throw new TypeError2("Cannot promisify an API that has normal methods with '%s'-suffix\n\n    See http://goo.gl/MqrFmX\n".replace("%s", suffix));
              }
            }
          }
        }
      }
      function promisifiableMethods(obj2, suffix, suffixRegexp, filter2) {
        var keys2 = util.inheritedDataKeys(obj2);
        var ret2 = [];
        for (var i = 0; i < keys2.length; ++i) {
          var key = keys2[i];
          var value = obj2[key];
          var passesDefaultFilter = filter2 === defaultFilter ? true : defaultFilter(key, value, obj2);
          if (typeof value === "function" && !isPromisified(value) && !hasPromisified(obj2, key, suffix) && filter2(key, value, obj2, passesDefaultFilter)) {
            ret2.push(key, value);
          }
        }
        checkValid(ret2, suffix, suffixRegexp);
        return ret2;
      }
      var escapeIdentRegex = function(str) {
        return str.replace(/([$])/, "\\$");
      };
      var makeNodePromisifiedEval;
      if (true) {
        var switchCaseArgumentOrder = function(likelyArgumentCount) {
          var ret2 = [likelyArgumentCount];
          var min2 = Math.max(0, likelyArgumentCount - 1 - 3);
          for (var i = likelyArgumentCount - 1; i >= min2; --i) {
            ret2.push(i);
          }
          for (var i = likelyArgumentCount + 1; i <= 3; ++i) {
            ret2.push(i);
          }
          return ret2;
        };
        var argumentSequence = function(argumentCount) {
          return util.filledRange(argumentCount, "_arg", "");
        };
        var parameterDeclaration = function(parameterCount2) {
          return util.filledRange(Math.max(parameterCount2, 3), "_arg", "");
        };
        var parameterCount = function(fn) {
          if (typeof fn.length === "number") {
            return Math.max(Math.min(fn.length, 1023 + 1), 0);
          }
          return 0;
        };
        makeNodePromisifiedEval = function(callback, receiver, originalName, fn, _3, multiArgs) {
          var newParameterCount = Math.max(0, parameterCount(fn) - 1);
          var argumentOrder = switchCaseArgumentOrder(newParameterCount);
          var shouldProxyThis = typeof callback === "string" || receiver === THIS;
          function generateCallForArgumentCount(count) {
            var args = argumentSequence(count).join(", ");
            var comma = count > 0 ? ", " : "";
            var ret2;
            if (shouldProxyThis) {
              ret2 = "ret = callback.call(this, {{args}}, nodeback); break;\n";
            } else {
              ret2 = receiver === void 0 ? "ret = callback({{args}}, nodeback); break;\n" : "ret = callback.call(receiver, {{args}}, nodeback); break;\n";
            }
            return ret2.replace("{{args}}", args).replace(", ", comma);
          }
          function generateArgumentSwitchCase() {
            var ret2 = "";
            for (var i = 0; i < argumentOrder.length; ++i) {
              ret2 += "case " + argumentOrder[i] + ":" + generateCallForArgumentCount(argumentOrder[i]);
            }
            ret2 += "                                                             \n        default:                                                             \n            var args = new Array(len + 1);                                   \n            var i = 0;                                                       \n            for (var i = 0; i < len; ++i) {                                  \n               args[i] = arguments[i];                                       \n            }                                                                \n            args[i] = nodeback;                                              \n            [CodeForCall]                                                    \n            break;                                                           \n        ".replace("[CodeForCall]", shouldProxyThis ? "ret = callback.apply(this, args);\n" : "ret = callback.apply(receiver, args);\n");
            return ret2;
          }
          var getFunctionCode = typeof callback === "string" ? "this != null ? this['" + callback + "'] : fn" : "fn";
          var body = "'use strict';                                                \n        var ret = function (Parameters) {                                    \n            'use strict';                                                    \n            var len = arguments.length;                                      \n            var promise = new Promise(INTERNAL);                             \n            promise._captureStackTrace();                                    \n            var nodeback = nodebackForPromise(promise, " + multiArgs + ");   \n            var ret;                                                         \n            var callback = tryCatch([GetFunctionCode]);                      \n            switch(len) {                                                    \n                [CodeForSwitchCase]                                          \n            }                                                                \n            if (ret === errorObj) {                                          \n                promise._rejectCallback(maybeWrapAsError(ret.e), true, true);\n            }                                                                \n            if (!promise._isFateSealed()) promise._setAsyncGuaranteed();     \n            return promise;                                                  \n        };                                                                   \n        notEnumerableProp(ret, '__isPromisified__', true);                   \n        return ret;                                                          \n    ".replace("[CodeForSwitchCase]", generateArgumentSwitchCase()).replace("[GetFunctionCode]", getFunctionCode);
          body = body.replace("Parameters", parameterDeclaration(newParameterCount));
          return new Function("Promise", "fn", "receiver", "withAppended", "maybeWrapAsError", "nodebackForPromise", "tryCatch", "errorObj", "notEnumerableProp", "INTERNAL", body)(Promise2, fn, receiver, withAppended2, maybeWrapAsError2, nodebackForPromise, util.tryCatch, util.errorObj, util.notEnumerableProp, INTERNAL);
        };
      }
      function makeNodePromisifiedClosure(callback, receiver, _3, fn, __, multiArgs) {
        var defaultThis = /* @__PURE__ */ function() {
          return this;
        }();
        var method = callback;
        if (typeof method === "string") {
          callback = fn;
        }
        function promisified() {
          var _receiver = receiver;
          if (receiver === THIS) _receiver = this;
          var promise = new Promise2(INTERNAL);
          promise._captureStackTrace();
          var cb2 = typeof method === "string" && this !== defaultThis ? this[method] : callback;
          var fn2 = nodebackForPromise(promise, multiArgs);
          try {
            cb2.apply(_receiver, withAppended2(arguments, fn2));
          } catch (e) {
            promise._rejectCallback(maybeWrapAsError2(e), true, true);
          }
          if (!promise._isFateSealed()) promise._setAsyncGuaranteed();
          return promise;
        }
        util.notEnumerableProp(promisified, "__isPromisified__", true);
        return promisified;
      }
      var makeNodePromisified = canEvaluate2 ? makeNodePromisifiedEval : makeNodePromisifiedClosure;
      function promisifyAll(obj2, suffix, filter2, promisifier, multiArgs) {
        var suffixRegexp = new RegExp(escapeIdentRegex(suffix) + "$");
        var methods = promisifiableMethods(obj2, suffix, suffixRegexp, filter2);
        for (var i = 0, len = methods.length; i < len; i += 2) {
          var key = methods[i];
          var fn = methods[i + 1];
          var promisifiedKey = key + suffix;
          if (promisifier === makeNodePromisified) {
            obj2[promisifiedKey] = makeNodePromisified(key, THIS, key, fn, suffix, multiArgs);
          } else {
            var promisified = promisifier(fn, function() {
              return makeNodePromisified(key, THIS, key, fn, suffix, multiArgs);
            });
            util.notEnumerableProp(promisified, "__isPromisified__", true);
            obj2[promisifiedKey] = promisified;
          }
        }
        util.toFastProperties(obj2);
        return obj2;
      }
      function promisify(callback, receiver, multiArgs) {
        return makeNodePromisified(callback, receiver, void 0, callback, null, multiArgs);
      }
      Promise2.promisify = function(fn, options) {
        if (typeof fn !== "function") {
          throw new TypeError2("expecting a function but got " + util.classString(fn));
        }
        if (isPromisified(fn)) {
          return fn;
        }
        options = Object(options);
        var receiver = options.context === void 0 ? THIS : options.context;
        var multiArgs = !!options.multiArgs;
        var ret2 = promisify(fn, receiver, multiArgs);
        util.copyDescriptors(fn, ret2, propsFilter);
        return ret2;
      };
      Promise2.promisifyAll = function(target, options) {
        if (typeof target !== "function" && typeof target !== "object") {
          throw new TypeError2("the target of promisifyAll must be an object or a function\n\n    See http://goo.gl/MqrFmX\n");
        }
        options = Object(options);
        var multiArgs = !!options.multiArgs;
        var suffix = options.suffix;
        if (typeof suffix !== "string") suffix = defaultSuffix;
        var filter2 = options.filter;
        if (typeof filter2 !== "function") filter2 = defaultFilter;
        var promisifier = options.promisifier;
        if (typeof promisifier !== "function") promisifier = makeNodePromisified;
        if (!util.isIdentifier(suffix)) {
          throw new RangeError("suffix must be a valid identifier\n\n    See http://goo.gl/MqrFmX\n");
        }
        var keys2 = util.inheritedDataKeys(target);
        for (var i = 0; i < keys2.length; ++i) {
          var value = target[keys2[i]];
          if (keys2[i] !== "constructor" && util.isClass(value)) {
            promisifyAll(value.prototype, suffix, filter2, promisifier, multiArgs);
            promisifyAll(value, suffix, filter2, promisifier, multiArgs);
          }
        }
        return promisifyAll(target, suffix, filter2, promisifier, multiArgs);
      };
    };
  }
});

// node_modules/bluebird/js/release/props.js
var require_props = __commonJS({
  "node_modules/bluebird/js/release/props.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, PromiseArray, tryConvertToPromise, apiRejection) {
      var util = require_util();
      var isObject3 = util.isObject;
      var es52 = require_es5();
      var Es6Map;
      if (typeof Map === "function") Es6Map = Map;
      var mapToEntries = /* @__PURE__ */ function() {
        var index = 0;
        var size2 = 0;
        function extractEntry(value, key) {
          this[index] = value;
          this[index + size2] = key;
          index++;
        }
        return function mapToEntries2(map2) {
          size2 = map2.size;
          index = 0;
          var ret2 = new Array(map2.size * 2);
          map2.forEach(extractEntry, ret2);
          return ret2;
        };
      }();
      var entriesToMap = function(entries) {
        var ret2 = new Es6Map();
        var length = entries.length / 2 | 0;
        for (var i = 0; i < length; ++i) {
          var key = entries[length + i];
          var value = entries[i];
          ret2.set(key, value);
        }
        return ret2;
      };
      function PropertiesPromiseArray(obj2) {
        var isMap = false;
        var entries;
        if (Es6Map !== void 0 && obj2 instanceof Es6Map) {
          entries = mapToEntries(obj2);
          isMap = true;
        } else {
          var keys2 = es52.keys(obj2);
          var len = keys2.length;
          entries = new Array(len * 2);
          for (var i = 0; i < len; ++i) {
            var key = keys2[i];
            entries[i] = obj2[key];
            entries[i + len] = key;
          }
        }
        this.constructor$(entries);
        this._isMap = isMap;
        this._init$(void 0, -3);
      }
      util.inherits(PropertiesPromiseArray, PromiseArray);
      PropertiesPromiseArray.prototype._init = function() {
      };
      PropertiesPromiseArray.prototype._promiseFulfilled = function(value, index) {
        this._values[index] = value;
        var totalResolved = ++this._totalResolved;
        if (totalResolved >= this._length) {
          var val;
          if (this._isMap) {
            val = entriesToMap(this._values);
          } else {
            val = {};
            var keyOffset = this.length();
            for (var i = 0, len = this.length(); i < len; ++i) {
              val[this._values[i + keyOffset]] = this._values[i];
            }
          }
          this._resolve(val);
          return true;
        }
        return false;
      };
      PropertiesPromiseArray.prototype.shouldCopyValues = function() {
        return false;
      };
      PropertiesPromiseArray.prototype.getActualLength = function(len) {
        return len >> 1;
      };
      function props(promises) {
        var ret2;
        var castValue = tryConvertToPromise(promises);
        if (!isObject3(castValue)) {
          return apiRejection("cannot await properties of a non-object\n\n    See http://goo.gl/MqrFmX\n");
        } else if (castValue instanceof Promise2) {
          ret2 = castValue._then(Promise2.props, void 0, void 0, void 0, void 0);
        } else {
          ret2 = new PropertiesPromiseArray(castValue).promise();
        }
        if (castValue instanceof Promise2) {
          ret2._propagateFrom(castValue, 2);
        }
        return ret2;
      }
      Promise2.prototype.props = function() {
        return props(this);
      };
      Promise2.props = function(promises) {
        return props(promises);
      };
    };
  }
});

// node_modules/bluebird/js/release/race.js
var require_race = __commonJS({
  "node_modules/bluebird/js/release/race.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL, tryConvertToPromise, apiRejection) {
      var util = require_util();
      var raceLater = function(promise) {
        return promise.then(function(array) {
          return race(array, promise);
        });
      };
      function race(promises, parent) {
        var maybePromise = tryConvertToPromise(promises);
        if (maybePromise instanceof Promise2) {
          return raceLater(maybePromise);
        } else {
          promises = util.asArray(promises);
          if (promises === null) return apiRejection("expecting an array or an iterable object but got " + util.classString(promises));
        }
        var ret2 = new Promise2(INTERNAL);
        if (parent !== void 0) {
          ret2._propagateFrom(parent, 3);
        }
        var fulfill = ret2._fulfill;
        var reject2 = ret2._reject;
        for (var i = 0, len = promises.length; i < len; ++i) {
          var val = promises[i];
          if (val === void 0 && !(i in promises)) {
            continue;
          }
          Promise2.cast(val)._then(fulfill, reject2, void 0, ret2, null);
        }
        return ret2;
      }
      Promise2.race = function(promises) {
        return race(promises, void 0);
      };
      Promise2.prototype.race = function() {
        return race(this, void 0);
      };
    };
  }
});

// node_modules/bluebird/js/release/reduce.js
var require_reduce = __commonJS({
  "node_modules/bluebird/js/release/reduce.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, PromiseArray, apiRejection, tryConvertToPromise, INTERNAL, debug) {
      var getDomain = Promise2._getDomain;
      var util = require_util();
      var tryCatch2 = util.tryCatch;
      function ReductionPromiseArray(promises, fn, initialValue, _each) {
        this.constructor$(promises);
        var domain = getDomain();
        this._fn = domain === null ? fn : util.domainBind(domain, fn);
        if (initialValue !== void 0) {
          initialValue = Promise2.resolve(initialValue);
          initialValue._attachCancellationCallback(this);
        }
        this._initialValue = initialValue;
        this._currentCancellable = null;
        if (_each === INTERNAL) {
          this._eachValues = Array(this._length);
        } else if (_each === 0) {
          this._eachValues = null;
        } else {
          this._eachValues = void 0;
        }
        this._promise._captureStackTrace();
        this._init$(void 0, -5);
      }
      util.inherits(ReductionPromiseArray, PromiseArray);
      ReductionPromiseArray.prototype._gotAccum = function(accum) {
        if (this._eachValues !== void 0 && this._eachValues !== null && accum !== INTERNAL) {
          this._eachValues.push(accum);
        }
      };
      ReductionPromiseArray.prototype._eachComplete = function(value) {
        if (this._eachValues !== null) {
          this._eachValues.push(value);
        }
        return this._eachValues;
      };
      ReductionPromiseArray.prototype._init = function() {
      };
      ReductionPromiseArray.prototype._resolveEmptyArray = function() {
        this._resolve(this._eachValues !== void 0 ? this._eachValues : this._initialValue);
      };
      ReductionPromiseArray.prototype.shouldCopyValues = function() {
        return false;
      };
      ReductionPromiseArray.prototype._resolve = function(value) {
        this._promise._resolveCallback(value);
        this._values = null;
      };
      ReductionPromiseArray.prototype._resultCancelled = function(sender) {
        if (sender === this._initialValue) return this._cancel();
        if (this._isResolved()) return;
        this._resultCancelled$();
        if (this._currentCancellable instanceof Promise2) {
          this._currentCancellable.cancel();
        }
        if (this._initialValue instanceof Promise2) {
          this._initialValue.cancel();
        }
      };
      ReductionPromiseArray.prototype._iterate = function(values2) {
        this._values = values2;
        var value;
        var i;
        var length = values2.length;
        if (this._initialValue !== void 0) {
          value = this._initialValue;
          i = 0;
        } else {
          value = Promise2.resolve(values2[0]);
          i = 1;
        }
        this._currentCancellable = value;
        if (!value.isRejected()) {
          for (; i < length; ++i) {
            var ctx = {
              accum: null,
              value: values2[i],
              index: i,
              length,
              array: this
            };
            value = value._then(gotAccum, void 0, void 0, ctx, void 0);
          }
        }
        if (this._eachValues !== void 0) {
          value = value._then(this._eachComplete, void 0, void 0, this, void 0);
        }
        value._then(completed, completed, void 0, value, this);
      };
      Promise2.prototype.reduce = function(fn, initialValue) {
        return reduce(this, fn, initialValue, null);
      };
      Promise2.reduce = function(promises, fn, initialValue, _each) {
        return reduce(promises, fn, initialValue, _each);
      };
      function completed(valueOrReason, array) {
        if (this.isFulfilled()) {
          array._resolve(valueOrReason);
        } else {
          array._reject(valueOrReason);
        }
      }
      function reduce(promises, fn, initialValue, _each) {
        if (typeof fn !== "function") {
          return apiRejection("expecting a function but got " + util.classString(fn));
        }
        var array = new ReductionPromiseArray(promises, fn, initialValue, _each);
        return array.promise();
      }
      function gotAccum(accum) {
        this.accum = accum;
        this.array._gotAccum(accum);
        var value = tryConvertToPromise(this.value, this.array._promise);
        if (value instanceof Promise2) {
          this.array._currentCancellable = value;
          return value._then(gotValue, void 0, void 0, this, void 0);
        } else {
          return gotValue.call(this, value);
        }
      }
      function gotValue(value) {
        var array = this.array;
        var promise = array._promise;
        var fn = tryCatch2(array._fn);
        promise._pushContext();
        var ret2;
        if (array._eachValues !== void 0) {
          ret2 = fn.call(promise._boundValue(), value, this.index, this.length);
        } else {
          ret2 = fn.call(promise._boundValue(), this.accum, value, this.index, this.length);
        }
        if (ret2 instanceof Promise2) {
          array._currentCancellable = ret2;
        }
        var promiseCreated = promise._popContext();
        debug.checkForgottenReturns(ret2, promiseCreated, array._eachValues !== void 0 ? "Promise.each" : "Promise.reduce", promise);
        return ret2;
      }
    };
  }
});

// node_modules/bluebird/js/release/settle.js
var require_settle = __commonJS({
  "node_modules/bluebird/js/release/settle.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, PromiseArray, debug) {
      var PromiseInspection = Promise2.PromiseInspection;
      var util = require_util();
      function SettledPromiseArray(values2) {
        this.constructor$(values2);
      }
      util.inherits(SettledPromiseArray, PromiseArray);
      SettledPromiseArray.prototype._promiseResolved = function(index, inspection) {
        this._values[index] = inspection;
        var totalResolved = ++this._totalResolved;
        if (totalResolved >= this._length) {
          this._resolve(this._values);
          return true;
        }
        return false;
      };
      SettledPromiseArray.prototype._promiseFulfilled = function(value, index) {
        var ret2 = new PromiseInspection();
        ret2._bitField = 33554432;
        ret2._settledValueField = value;
        return this._promiseResolved(index, ret2);
      };
      SettledPromiseArray.prototype._promiseRejected = function(reason, index) {
        var ret2 = new PromiseInspection();
        ret2._bitField = 16777216;
        ret2._settledValueField = reason;
        return this._promiseResolved(index, ret2);
      };
      Promise2.settle = function(promises) {
        debug.deprecated(".settle()", ".reflect()");
        return new SettledPromiseArray(promises).promise();
      };
      Promise2.prototype.settle = function() {
        return Promise2.settle(this);
      };
    };
  }
});

// node_modules/bluebird/js/release/some.js
var require_some = __commonJS({
  "node_modules/bluebird/js/release/some.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, PromiseArray, apiRejection) {
      var util = require_util();
      var RangeError2 = require_errors().RangeError;
      var AggregateError = require_errors().AggregateError;
      var isArray = util.isArray;
      var CANCELLATION = {};
      function SomePromiseArray(values2) {
        this.constructor$(values2);
        this._howMany = 0;
        this._unwrap = false;
        this._initialized = false;
      }
      util.inherits(SomePromiseArray, PromiseArray);
      SomePromiseArray.prototype._init = function() {
        if (!this._initialized) {
          return;
        }
        if (this._howMany === 0) {
          this._resolve([]);
          return;
        }
        this._init$(void 0, -5);
        var isArrayResolved = isArray(this._values);
        if (!this._isResolved() && isArrayResolved && this._howMany > this._canPossiblyFulfill()) {
          this._reject(this._getRangeError(this.length()));
        }
      };
      SomePromiseArray.prototype.init = function() {
        this._initialized = true;
        this._init();
      };
      SomePromiseArray.prototype.setUnwrap = function() {
        this._unwrap = true;
      };
      SomePromiseArray.prototype.howMany = function() {
        return this._howMany;
      };
      SomePromiseArray.prototype.setHowMany = function(count) {
        this._howMany = count;
      };
      SomePromiseArray.prototype._promiseFulfilled = function(value) {
        this._addFulfilled(value);
        if (this._fulfilled() === this.howMany()) {
          this._values.length = this.howMany();
          if (this.howMany() === 1 && this._unwrap) {
            this._resolve(this._values[0]);
          } else {
            this._resolve(this._values);
          }
          return true;
        }
        return false;
      };
      SomePromiseArray.prototype._promiseRejected = function(reason) {
        this._addRejected(reason);
        return this._checkOutcome();
      };
      SomePromiseArray.prototype._promiseCancelled = function() {
        if (this._values instanceof Promise2 || this._values == null) {
          return this._cancel();
        }
        this._addRejected(CANCELLATION);
        return this._checkOutcome();
      };
      SomePromiseArray.prototype._checkOutcome = function() {
        if (this.howMany() > this._canPossiblyFulfill()) {
          var e = new AggregateError();
          for (var i = this.length(); i < this._values.length; ++i) {
            if (this._values[i] !== CANCELLATION) {
              e.push(this._values[i]);
            }
          }
          if (e.length > 0) {
            this._reject(e);
          } else {
            this._cancel();
          }
          return true;
        }
        return false;
      };
      SomePromiseArray.prototype._fulfilled = function() {
        return this._totalResolved;
      };
      SomePromiseArray.prototype._rejected = function() {
        return this._values.length - this.length();
      };
      SomePromiseArray.prototype._addRejected = function(reason) {
        this._values.push(reason);
      };
      SomePromiseArray.prototype._addFulfilled = function(value) {
        this._values[this._totalResolved++] = value;
      };
      SomePromiseArray.prototype._canPossiblyFulfill = function() {
        return this.length() - this._rejected();
      };
      SomePromiseArray.prototype._getRangeError = function(count) {
        var message = "Input array must contain at least " + this._howMany + " items but contains only " + count + " items";
        return new RangeError2(message);
      };
      SomePromiseArray.prototype._resolveEmptyArray = function() {
        this._reject(this._getRangeError(0));
      };
      function some2(promises, howMany) {
        if ((howMany | 0) !== howMany || howMany < 0) {
          return apiRejection("expecting a positive integer\n\n    See http://goo.gl/MqrFmX\n");
        }
        var ret2 = new SomePromiseArray(promises);
        var promise = ret2.promise();
        ret2.setHowMany(howMany);
        ret2.init();
        return promise;
      }
      Promise2.some = function(promises, howMany) {
        return some2(promises, howMany);
      };
      Promise2.prototype.some = function(howMany) {
        return some2(this, howMany);
      };
      Promise2._SomePromiseArray = SomePromiseArray;
    };
  }
});

// node_modules/bluebird/js/release/filter.js
var require_filter = __commonJS({
  "node_modules/bluebird/js/release/filter.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL) {
      var PromiseMap = Promise2.map;
      Promise2.prototype.filter = function(fn, options) {
        return PromiseMap(this, fn, options, INTERNAL);
      };
      Promise2.filter = function(promises, fn, options) {
        return PromiseMap(promises, fn, options, INTERNAL);
      };
    };
  }
});

// node_modules/bluebird/js/release/each.js
var require_each = __commonJS({
  "node_modules/bluebird/js/release/each.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2, INTERNAL) {
      var PromiseReduce = Promise2.reduce;
      var PromiseAll = Promise2.all;
      function promiseAllThis() {
        return PromiseAll(this);
      }
      function PromiseMapSeries(promises, fn) {
        return PromiseReduce(promises, fn, INTERNAL, INTERNAL);
      }
      Promise2.prototype.each = function(fn) {
        return PromiseReduce(this, fn, INTERNAL, 0)._then(promiseAllThis, void 0, void 0, this, void 0);
      };
      Promise2.prototype.mapSeries = function(fn) {
        return PromiseReduce(this, fn, INTERNAL, INTERNAL);
      };
      Promise2.each = function(promises, fn) {
        return PromiseReduce(promises, fn, INTERNAL, 0)._then(promiseAllThis, void 0, void 0, promises, void 0);
      };
      Promise2.mapSeries = PromiseMapSeries;
    };
  }
});

// node_modules/bluebird/js/release/any.js
var require_any = __commonJS({
  "node_modules/bluebird/js/release/any.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Promise2) {
      var SomePromiseArray = Promise2._SomePromiseArray;
      function any(promises) {
        var ret2 = new SomePromiseArray(promises);
        var promise = ret2.promise();
        ret2.setHowMany(1);
        ret2.setUnwrap();
        ret2.init();
        return promise;
      }
      Promise2.any = function(promises) {
        return any(promises);
      };
      Promise2.prototype.any = function() {
        return any(this);
      };
    };
  }
});

// node_modules/bluebird/js/release/promise.js
var require_promise = __commonJS({
  "node_modules/bluebird/js/release/promise.js"(exports2, module2) {
    "use strict";
    module2.exports = function() {
      var makeSelfResolutionError = function() {
        return new TypeError2("circular promise resolution chain\n\n    See http://goo.gl/MqrFmX\n");
      };
      var reflectHandler = function() {
        return new Promise2.PromiseInspection(this._target());
      };
      var apiRejection = function(msg) {
        return Promise2.reject(new TypeError2(msg));
      };
      function Proxyable() {
      }
      var UNDEFINED_BINDING = {};
      var util = require_util();
      var getDomain;
      if (util.isNode) {
        getDomain = function() {
          var ret2 = process.domain;
          if (ret2 === void 0) ret2 = null;
          return ret2;
        };
      } else {
        getDomain = function() {
          return null;
        };
      }
      util.notEnumerableProp(Promise2, "_getDomain", getDomain);
      var es52 = require_es5();
      var Async = require_async();
      var async = new Async();
      es52.defineProperty(Promise2, "_async", {
        value: async
      });
      var errors = require_errors();
      var TypeError2 = Promise2.TypeError = errors.TypeError;
      Promise2.RangeError = errors.RangeError;
      var CancellationError = Promise2.CancellationError = errors.CancellationError;
      Promise2.TimeoutError = errors.TimeoutError;
      Promise2.OperationalError = errors.OperationalError;
      Promise2.RejectionError = errors.OperationalError;
      Promise2.AggregateError = errors.AggregateError;
      var INTERNAL = function() {
      };
      var APPLY = {};
      var NEXT_FILTER = {};
      var tryConvertToPromise = require_thenables()(Promise2, INTERNAL);
      var PromiseArray = require_promise_array()(Promise2, INTERNAL, tryConvertToPromise, apiRejection, Proxyable);
      var Context = require_context()(Promise2);
      var createContext = Context.create;
      var debug = require_debuggability()(Promise2, Context);
      var CapturedTrace = debug.CapturedTrace;
      var PassThroughHandlerContext = require_finally()(Promise2, tryConvertToPromise);
      var catchFilter = require_catch_filter()(NEXT_FILTER);
      var nodebackForPromise = require_nodeback();
      var errorObj2 = util.errorObj;
      var tryCatch2 = util.tryCatch;
      function check(self2, executor) {
        if (typeof executor !== "function") {
          throw new TypeError2("expecting a function but got " + util.classString(executor));
        }
        if (self2.constructor !== Promise2) {
          throw new TypeError2("the promise constructor cannot be invoked directly\n\n    See http://goo.gl/MqrFmX\n");
        }
      }
      function Promise2(executor) {
        this._bitField = 0;
        this._fulfillmentHandler0 = void 0;
        this._rejectionHandler0 = void 0;
        this._promise0 = void 0;
        this._receiver0 = void 0;
        if (executor !== INTERNAL) {
          check(this, executor);
          this._resolveFromExecutor(executor);
        }
        this._promiseCreated();
        this._fireEvent("promiseCreated", this);
      }
      Promise2.prototype.toString = function() {
        return "[object Promise]";
      };
      Promise2.prototype.caught = Promise2.prototype["catch"] = function(fn) {
        var len = arguments.length;
        if (len > 1) {
          var catchInstances = new Array(len - 1), j = 0, i;
          for (i = 0; i < len - 1; ++i) {
            var item = arguments[i];
            if (util.isObject(item)) {
              catchInstances[j++] = item;
            } else {
              return apiRejection("expecting an object but got A catch statement predicate " + util.classString(item));
            }
          }
          catchInstances.length = j;
          fn = arguments[i];
          return this.then(void 0, catchFilter(catchInstances, fn, this));
        }
        return this.then(void 0, fn);
      };
      Promise2.prototype.reflect = function() {
        return this._then(reflectHandler, reflectHandler, void 0, this, void 0);
      };
      Promise2.prototype.then = function(didFulfill, didReject) {
        if (debug.warnings() && arguments.length > 0 && typeof didFulfill !== "function" && typeof didReject !== "function") {
          var msg = ".then() only accepts functions but was passed: " + util.classString(didFulfill);
          if (arguments.length > 1) {
            msg += ", " + util.classString(didReject);
          }
          this._warn(msg);
        }
        return this._then(didFulfill, didReject, void 0, void 0, void 0);
      };
      Promise2.prototype.done = function(didFulfill, didReject) {
        var promise = this._then(didFulfill, didReject, void 0, void 0, void 0);
        promise._setIsFinal();
      };
      Promise2.prototype.spread = function(fn) {
        if (typeof fn !== "function") {
          return apiRejection("expecting a function but got " + util.classString(fn));
        }
        return this.all()._then(fn, void 0, void 0, APPLY, void 0);
      };
      Promise2.prototype.toJSON = function() {
        var ret2 = {
          isFulfilled: false,
          isRejected: false,
          fulfillmentValue: void 0,
          rejectionReason: void 0
        };
        if (this.isFulfilled()) {
          ret2.fulfillmentValue = this.value();
          ret2.isFulfilled = true;
        } else if (this.isRejected()) {
          ret2.rejectionReason = this.reason();
          ret2.isRejected = true;
        }
        return ret2;
      };
      Promise2.prototype.all = function() {
        if (arguments.length > 0) {
          this._warn(".all() was passed arguments but it does not take any");
        }
        return new PromiseArray(this).promise();
      };
      Promise2.prototype.error = function(fn) {
        return this.caught(util.originatesFromRejection, fn);
      };
      Promise2.getNewLibraryCopy = module2.exports;
      Promise2.is = function(val) {
        return val instanceof Promise2;
      };
      Promise2.fromNode = Promise2.fromCallback = function(fn) {
        var ret2 = new Promise2(INTERNAL);
        ret2._captureStackTrace();
        var multiArgs = arguments.length > 1 ? !!Object(arguments[1]).multiArgs : false;
        var result2 = tryCatch2(fn)(nodebackForPromise(ret2, multiArgs));
        if (result2 === errorObj2) {
          ret2._rejectCallback(result2.e, true);
        }
        if (!ret2._isFateSealed()) ret2._setAsyncGuaranteed();
        return ret2;
      };
      Promise2.all = function(promises) {
        return new PromiseArray(promises).promise();
      };
      Promise2.cast = function(obj2) {
        var ret2 = tryConvertToPromise(obj2);
        if (!(ret2 instanceof Promise2)) {
          ret2 = new Promise2(INTERNAL);
          ret2._captureStackTrace();
          ret2._setFulfilled();
          ret2._rejectionHandler0 = obj2;
        }
        return ret2;
      };
      Promise2.resolve = Promise2.fulfilled = Promise2.cast;
      Promise2.reject = Promise2.rejected = function(reason) {
        var ret2 = new Promise2(INTERNAL);
        ret2._captureStackTrace();
        ret2._rejectCallback(reason, true);
        return ret2;
      };
      Promise2.setScheduler = function(fn) {
        if (typeof fn !== "function") {
          throw new TypeError2("expecting a function but got " + util.classString(fn));
        }
        return async.setScheduler(fn);
      };
      Promise2.prototype._then = function(didFulfill, didReject, _3, receiver, internalData) {
        var haveInternalData = internalData !== void 0;
        var promise = haveInternalData ? internalData : new Promise2(INTERNAL);
        var target = this._target();
        var bitField = target._bitField;
        if (!haveInternalData) {
          promise._propagateFrom(this, 3);
          promise._captureStackTrace();
          if (receiver === void 0 && (this._bitField & 2097152) !== 0) {
            if (!((bitField & 50397184) === 0)) {
              receiver = this._boundValue();
            } else {
              receiver = target === this ? void 0 : this._boundTo;
            }
          }
          this._fireEvent("promiseChained", this, promise);
        }
        var domain = getDomain();
        if (!((bitField & 50397184) === 0)) {
          var handler, value, settler = target._settlePromiseCtx;
          if ((bitField & 33554432) !== 0) {
            value = target._rejectionHandler0;
            handler = didFulfill;
          } else if ((bitField & 16777216) !== 0) {
            value = target._fulfillmentHandler0;
            handler = didReject;
            target._unsetRejectionIsUnhandled();
          } else {
            settler = target._settlePromiseLateCancellationObserver;
            value = new CancellationError("late cancellation observer");
            target._attachExtraTrace(value);
            handler = didReject;
          }
          async.invoke(settler, target, {
            handler: domain === null ? handler : typeof handler === "function" && util.domainBind(domain, handler),
            promise,
            receiver,
            value
          });
        } else {
          target._addCallbacks(didFulfill, didReject, promise, receiver, domain);
        }
        return promise;
      };
      Promise2.prototype._length = function() {
        return this._bitField & 65535;
      };
      Promise2.prototype._isFateSealed = function() {
        return (this._bitField & 117506048) !== 0;
      };
      Promise2.prototype._isFollowing = function() {
        return (this._bitField & 67108864) === 67108864;
      };
      Promise2.prototype._setLength = function(len) {
        this._bitField = this._bitField & -65536 | len & 65535;
      };
      Promise2.prototype._setFulfilled = function() {
        this._bitField = this._bitField | 33554432;
        this._fireEvent("promiseFulfilled", this);
      };
      Promise2.prototype._setRejected = function() {
        this._bitField = this._bitField | 16777216;
        this._fireEvent("promiseRejected", this);
      };
      Promise2.prototype._setFollowing = function() {
        this._bitField = this._bitField | 67108864;
        this._fireEvent("promiseResolved", this);
      };
      Promise2.prototype._setIsFinal = function() {
        this._bitField = this._bitField | 4194304;
      };
      Promise2.prototype._isFinal = function() {
        return (this._bitField & 4194304) > 0;
      };
      Promise2.prototype._unsetCancelled = function() {
        this._bitField = this._bitField & ~65536;
      };
      Promise2.prototype._setCancelled = function() {
        this._bitField = this._bitField | 65536;
        this._fireEvent("promiseCancelled", this);
      };
      Promise2.prototype._setWillBeCancelled = function() {
        this._bitField = this._bitField | 8388608;
      };
      Promise2.prototype._setAsyncGuaranteed = function() {
        if (async.hasCustomScheduler()) return;
        this._bitField = this._bitField | 134217728;
      };
      Promise2.prototype._receiverAt = function(index) {
        var ret2 = index === 0 ? this._receiver0 : this[index * 4 - 4 + 3];
        if (ret2 === UNDEFINED_BINDING) {
          return void 0;
        } else if (ret2 === void 0 && this._isBound()) {
          return this._boundValue();
        }
        return ret2;
      };
      Promise2.prototype._promiseAt = function(index) {
        return this[index * 4 - 4 + 2];
      };
      Promise2.prototype._fulfillmentHandlerAt = function(index) {
        return this[index * 4 - 4 + 0];
      };
      Promise2.prototype._rejectionHandlerAt = function(index) {
        return this[index * 4 - 4 + 1];
      };
      Promise2.prototype._boundValue = function() {
      };
      Promise2.prototype._migrateCallback0 = function(follower) {
        var bitField = follower._bitField;
        var fulfill = follower._fulfillmentHandler0;
        var reject2 = follower._rejectionHandler0;
        var promise = follower._promise0;
        var receiver = follower._receiverAt(0);
        if (receiver === void 0) receiver = UNDEFINED_BINDING;
        this._addCallbacks(fulfill, reject2, promise, receiver, null);
      };
      Promise2.prototype._migrateCallbackAt = function(follower, index) {
        var fulfill = follower._fulfillmentHandlerAt(index);
        var reject2 = follower._rejectionHandlerAt(index);
        var promise = follower._promiseAt(index);
        var receiver = follower._receiverAt(index);
        if (receiver === void 0) receiver = UNDEFINED_BINDING;
        this._addCallbacks(fulfill, reject2, promise, receiver, null);
      };
      Promise2.prototype._addCallbacks = function(fulfill, reject2, promise, receiver, domain) {
        var index = this._length();
        if (index >= 65535 - 4) {
          index = 0;
          this._setLength(0);
        }
        if (index === 0) {
          this._promise0 = promise;
          this._receiver0 = receiver;
          if (typeof fulfill === "function") {
            this._fulfillmentHandler0 = domain === null ? fulfill : util.domainBind(domain, fulfill);
          }
          if (typeof reject2 === "function") {
            this._rejectionHandler0 = domain === null ? reject2 : util.domainBind(domain, reject2);
          }
        } else {
          var base = index * 4 - 4;
          this[base + 2] = promise;
          this[base + 3] = receiver;
          if (typeof fulfill === "function") {
            this[base + 0] = domain === null ? fulfill : util.domainBind(domain, fulfill);
          }
          if (typeof reject2 === "function") {
            this[base + 1] = domain === null ? reject2 : util.domainBind(domain, reject2);
          }
        }
        this._setLength(index + 1);
        return index;
      };
      Promise2.prototype._proxy = function(proxyable, arg) {
        this._addCallbacks(void 0, void 0, arg, proxyable, null);
      };
      Promise2.prototype._resolveCallback = function(value, shouldBind) {
        if ((this._bitField & 117506048) !== 0) return;
        if (value === this) return this._rejectCallback(makeSelfResolutionError(), false);
        var maybePromise = tryConvertToPromise(value, this);
        if (!(maybePromise instanceof Promise2)) return this._fulfill(value);
        if (shouldBind) this._propagateFrom(maybePromise, 2);
        var promise = maybePromise._target();
        if (promise === this) {
          this._reject(makeSelfResolutionError());
          return;
        }
        var bitField = promise._bitField;
        if ((bitField & 50397184) === 0) {
          var len = this._length();
          if (len > 0) promise._migrateCallback0(this);
          for (var i = 1; i < len; ++i) {
            promise._migrateCallbackAt(this, i);
          }
          this._setFollowing();
          this._setLength(0);
          this._setFollowee(promise);
        } else if ((bitField & 33554432) !== 0) {
          this._fulfill(promise._value());
        } else if ((bitField & 16777216) !== 0) {
          this._reject(promise._reason());
        } else {
          var reason = new CancellationError("late cancellation observer");
          promise._attachExtraTrace(reason);
          this._reject(reason);
        }
      };
      Promise2.prototype._rejectCallback = function(reason, synchronous, ignoreNonErrorWarnings) {
        var trace = util.ensureErrorObject(reason);
        var hasStack = trace === reason;
        if (!hasStack && !ignoreNonErrorWarnings && debug.warnings()) {
          var message = "a promise was rejected with a non-error: " + util.classString(reason);
          this._warn(message, true);
        }
        this._attachExtraTrace(trace, synchronous ? hasStack : false);
        this._reject(reason);
      };
      Promise2.prototype._resolveFromExecutor = function(executor) {
        var promise = this;
        this._captureStackTrace();
        this._pushContext();
        var synchronous = true;
        var r = this._execute(executor, function(value) {
          promise._resolveCallback(value);
        }, function(reason) {
          promise._rejectCallback(reason, synchronous);
        });
        synchronous = false;
        this._popContext();
        if (r !== void 0) {
          promise._rejectCallback(r, true);
        }
      };
      Promise2.prototype._settlePromiseFromHandler = function(handler, receiver, value, promise) {
        var bitField = promise._bitField;
        if ((bitField & 65536) !== 0) return;
        promise._pushContext();
        var x;
        if (receiver === APPLY) {
          if (!value || typeof value.length !== "number") {
            x = errorObj2;
            x.e = new TypeError2("cannot .spread() a non-array: " + util.classString(value));
          } else {
            x = tryCatch2(handler).apply(this._boundValue(), value);
          }
        } else {
          x = tryCatch2(handler).call(receiver, value);
        }
        var promiseCreated = promise._popContext();
        bitField = promise._bitField;
        if ((bitField & 65536) !== 0) return;
        if (x === NEXT_FILTER) {
          promise._reject(value);
        } else if (x === errorObj2) {
          promise._rejectCallback(x.e, false);
        } else {
          debug.checkForgottenReturns(x, promiseCreated, "", promise, this);
          promise._resolveCallback(x);
        }
      };
      Promise2.prototype._target = function() {
        var ret2 = this;
        while (ret2._isFollowing()) ret2 = ret2._followee();
        return ret2;
      };
      Promise2.prototype._followee = function() {
        return this._rejectionHandler0;
      };
      Promise2.prototype._setFollowee = function(promise) {
        this._rejectionHandler0 = promise;
      };
      Promise2.prototype._settlePromise = function(promise, handler, receiver, value) {
        var isPromise = promise instanceof Promise2;
        var bitField = this._bitField;
        var asyncGuaranteed = (bitField & 134217728) !== 0;
        if ((bitField & 65536) !== 0) {
          if (isPromise) promise._invokeInternalOnCancel();
          if (receiver instanceof PassThroughHandlerContext && receiver.isFinallyHandler()) {
            receiver.cancelPromise = promise;
            if (tryCatch2(handler).call(receiver, value) === errorObj2) {
              promise._reject(errorObj2.e);
            }
          } else if (handler === reflectHandler) {
            promise._fulfill(reflectHandler.call(receiver));
          } else if (receiver instanceof Proxyable) {
            receiver._promiseCancelled(promise);
          } else if (isPromise || promise instanceof PromiseArray) {
            promise._cancel();
          } else {
            receiver.cancel();
          }
        } else if (typeof handler === "function") {
          if (!isPromise) {
            handler.call(receiver, value, promise);
          } else {
            if (asyncGuaranteed) promise._setAsyncGuaranteed();
            this._settlePromiseFromHandler(handler, receiver, value, promise);
          }
        } else if (receiver instanceof Proxyable) {
          if (!receiver._isResolved()) {
            if ((bitField & 33554432) !== 0) {
              receiver._promiseFulfilled(value, promise);
            } else {
              receiver._promiseRejected(value, promise);
            }
          }
        } else if (isPromise) {
          if (asyncGuaranteed) promise._setAsyncGuaranteed();
          if ((bitField & 33554432) !== 0) {
            promise._fulfill(value);
          } else {
            promise._reject(value);
          }
        }
      };
      Promise2.prototype._settlePromiseLateCancellationObserver = function(ctx) {
        var handler = ctx.handler;
        var promise = ctx.promise;
        var receiver = ctx.receiver;
        var value = ctx.value;
        if (typeof handler === "function") {
          if (!(promise instanceof Promise2)) {
            handler.call(receiver, value, promise);
          } else {
            this._settlePromiseFromHandler(handler, receiver, value, promise);
          }
        } else if (promise instanceof Promise2) {
          promise._reject(value);
        }
      };
      Promise2.prototype._settlePromiseCtx = function(ctx) {
        this._settlePromise(ctx.promise, ctx.handler, ctx.receiver, ctx.value);
      };
      Promise2.prototype._settlePromise0 = function(handler, value, bitField) {
        var promise = this._promise0;
        var receiver = this._receiverAt(0);
        this._promise0 = void 0;
        this._receiver0 = void 0;
        this._settlePromise(promise, handler, receiver, value);
      };
      Promise2.prototype._clearCallbackDataAtIndex = function(index) {
        var base = index * 4 - 4;
        this[base + 2] = this[base + 3] = this[base + 0] = this[base + 1] = void 0;
      };
      Promise2.prototype._fulfill = function(value) {
        var bitField = this._bitField;
        if ((bitField & 117506048) >>> 16) return;
        if (value === this) {
          var err = makeSelfResolutionError();
          this._attachExtraTrace(err);
          return this._reject(err);
        }
        this._setFulfilled();
        this._rejectionHandler0 = value;
        if ((bitField & 65535) > 0) {
          if ((bitField & 134217728) !== 0) {
            this._settlePromises();
          } else {
            async.settlePromises(this);
          }
        }
      };
      Promise2.prototype._reject = function(reason) {
        var bitField = this._bitField;
        if ((bitField & 117506048) >>> 16) return;
        this._setRejected();
        this._fulfillmentHandler0 = reason;
        if (this._isFinal()) {
          return async.fatalError(reason, util.isNode);
        }
        if ((bitField & 65535) > 0) {
          async.settlePromises(this);
        } else {
          this._ensurePossibleRejectionHandled();
        }
      };
      Promise2.prototype._fulfillPromises = function(len, value) {
        for (var i = 1; i < len; i++) {
          var handler = this._fulfillmentHandlerAt(i);
          var promise = this._promiseAt(i);
          var receiver = this._receiverAt(i);
          this._clearCallbackDataAtIndex(i);
          this._settlePromise(promise, handler, receiver, value);
        }
      };
      Promise2.prototype._rejectPromises = function(len, reason) {
        for (var i = 1; i < len; i++) {
          var handler = this._rejectionHandlerAt(i);
          var promise = this._promiseAt(i);
          var receiver = this._receiverAt(i);
          this._clearCallbackDataAtIndex(i);
          this._settlePromise(promise, handler, receiver, reason);
        }
      };
      Promise2.prototype._settlePromises = function() {
        var bitField = this._bitField;
        var len = bitField & 65535;
        if (len > 0) {
          if ((bitField & 16842752) !== 0) {
            var reason = this._fulfillmentHandler0;
            this._settlePromise0(this._rejectionHandler0, reason, bitField);
            this._rejectPromises(len, reason);
          } else {
            var value = this._rejectionHandler0;
            this._settlePromise0(this._fulfillmentHandler0, value, bitField);
            this._fulfillPromises(len, value);
          }
          this._setLength(0);
        }
        this._clearCancellationData();
      };
      Promise2.prototype._settledValue = function() {
        var bitField = this._bitField;
        if ((bitField & 33554432) !== 0) {
          return this._rejectionHandler0;
        } else if ((bitField & 16777216) !== 0) {
          return this._fulfillmentHandler0;
        }
      };
      function deferResolve(v) {
        this.promise._resolveCallback(v);
      }
      function deferReject(v) {
        this.promise._rejectCallback(v, false);
      }
      Promise2.defer = Promise2.pending = function() {
        debug.deprecated("Promise.defer", "new Promise");
        var promise = new Promise2(INTERNAL);
        return {
          promise,
          resolve: deferResolve,
          reject: deferReject
        };
      };
      util.notEnumerableProp(Promise2, "_makeSelfResolutionError", makeSelfResolutionError);
      require_method()(Promise2, INTERNAL, tryConvertToPromise, apiRejection, debug);
      require_bind()(Promise2, INTERNAL, tryConvertToPromise, debug);
      require_cancel()(Promise2, PromiseArray, apiRejection, debug);
      require_direct_resolve()(Promise2);
      require_synchronous_inspection()(Promise2);
      require_join()(Promise2, PromiseArray, tryConvertToPromise, INTERNAL, async, getDomain);
      Promise2.Promise = Promise2;
      Promise2.version = "3.4.7";
      require_map()(Promise2, PromiseArray, apiRejection, tryConvertToPromise, INTERNAL, debug);
      require_call_get()(Promise2);
      require_using()(Promise2, apiRejection, tryConvertToPromise, createContext, INTERNAL, debug);
      require_timers()(Promise2, INTERNAL, debug);
      require_generators()(Promise2, apiRejection, INTERNAL, tryConvertToPromise, Proxyable, debug);
      require_nodeify()(Promise2);
      require_promisify()(Promise2, INTERNAL);
      require_props()(Promise2, PromiseArray, tryConvertToPromise, apiRejection);
      require_race()(Promise2, INTERNAL, tryConvertToPromise, apiRejection);
      require_reduce()(Promise2, PromiseArray, apiRejection, tryConvertToPromise, INTERNAL, debug);
      require_settle()(Promise2, PromiseArray, debug);
      require_some()(Promise2, PromiseArray, apiRejection);
      require_filter()(Promise2, INTERNAL);
      require_each()(Promise2, INTERNAL);
      require_any()(Promise2);
      util.toFastProperties(Promise2);
      util.toFastProperties(Promise2.prototype);
      function fillTypes(value) {
        var p = new Promise2(INTERNAL);
        p._fulfillmentHandler0 = value;
        p._rejectionHandler0 = value;
        p._promise0 = value;
        p._receiver0 = value;
      }
      fillTypes({
        a: 1
      });
      fillTypes({
        b: 2
      });
      fillTypes({
        c: 3
      });
      fillTypes(1);
      fillTypes(function() {
      });
      fillTypes(void 0);
      fillTypes(false);
      fillTypes(new Promise2(INTERNAL));
      debug.setBounds(Async.firstLineError, util.lastLineError);
      return Promise2;
    };
  }
});

// node_modules/mammoth/lib/promises.js
var require_promises = __commonJS({
  "node_modules/mammoth/lib/promises.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var bluebird = require_promise()();
    exports2.defer = defer;
    exports2.when = bluebird.resolve;
    exports2.resolve = bluebird.resolve;
    exports2.all = bluebird.all;
    exports2.props = bluebird.props;
    exports2.reject = bluebird.reject;
    exports2.promisify = bluebird.promisify;
    exports2.mapSeries = bluebird.mapSeries;
    exports2.attempt = bluebird.attempt;
    exports2.nfcall = function(func) {
      var args = Array.prototype.slice.call(arguments, 1);
      var promisedFunc = bluebird.promisify(func);
      return promisedFunc.apply(null, args);
    };
    bluebird.prototype.fail = bluebird.prototype.caught;
    bluebird.prototype.also = function(func) {
      return this.then(function(value) {
        var returnValue = _3.extend({}, value, func(value));
        return bluebird.props(returnValue);
      });
    };
    function defer() {
      var resolve;
      var reject2;
      var promise = new bluebird.Promise(function(resolveArg, rejectArg) {
        resolve = resolveArg;
        reject2 = rejectArg;
      });
      return {
        resolve,
        reject: reject2,
        promise
      };
    }
  }
});

// node_modules/mammoth/lib/documents.js
var require_documents = __commonJS({
  "node_modules/mammoth/lib/documents.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var types = exports2.types = {
      document: "document",
      paragraph: "paragraph",
      run: "run",
      text: "text",
      tab: "tab",
      checkbox: "checkbox",
      hyperlink: "hyperlink",
      noteReference: "noteReference",
      image: "image",
      note: "note",
      commentReference: "commentReference",
      comment: "comment",
      table: "table",
      tableRow: "tableRow",
      tableCell: "tableCell",
      "break": "break",
      bookmarkStart: "bookmarkStart"
    };
    function Document(children, options) {
      options = options || {};
      return {
        type: types.document,
        children,
        notes: options.notes || new Notes({}),
        comments: options.comments || []
      };
    }
    function Paragraph(children, properties) {
      properties = properties || {};
      var indent = properties.indent || {};
      return {
        type: types.paragraph,
        children,
        styleId: properties.styleId || null,
        styleName: properties.styleName || null,
        numbering: properties.numbering || null,
        alignment: properties.alignment || null,
        indent: {
          start: indent.start || null,
          end: indent.end || null,
          firstLine: indent.firstLine || null,
          hanging: indent.hanging || null
        }
      };
    }
    function Run(children, properties) {
      properties = properties || {};
      return {
        type: types.run,
        children,
        styleId: properties.styleId || null,
        styleName: properties.styleName || null,
        isBold: !!properties.isBold,
        isUnderline: !!properties.isUnderline,
        isItalic: !!properties.isItalic,
        isStrikethrough: !!properties.isStrikethrough,
        isAllCaps: !!properties.isAllCaps,
        isSmallCaps: !!properties.isSmallCaps,
        verticalAlignment: properties.verticalAlignment || verticalAlignment.baseline,
        font: properties.font || null,
        fontSize: properties.fontSize || null,
        highlight: properties.highlight || null
      };
    }
    var verticalAlignment = {
      baseline: "baseline",
      superscript: "superscript",
      subscript: "subscript"
    };
    function Text(value) {
      return {
        type: types.text,
        value
      };
    }
    function Tab() {
      return {
        type: types.tab
      };
    }
    function Checkbox(options) {
      return {
        type: types.checkbox,
        checked: options.checked
      };
    }
    function Hyperlink(children, options) {
      return {
        type: types.hyperlink,
        children,
        href: options.href,
        anchor: options.anchor,
        targetFrame: options.targetFrame
      };
    }
    function NoteReference(options) {
      return {
        type: types.noteReference,
        noteType: options.noteType,
        noteId: options.noteId
      };
    }
    function Notes(notes) {
      this._notes = _3.indexBy(notes, function(note) {
        return noteKey(note.noteType, note.noteId);
      });
    }
    Notes.prototype.resolve = function(reference) {
      return this.findNoteByKey(noteKey(reference.noteType, reference.noteId));
    };
    Notes.prototype.findNoteByKey = function(key) {
      return this._notes[key] || null;
    };
    function Note(options) {
      return {
        type: types.note,
        noteType: options.noteType,
        noteId: options.noteId,
        body: options.body
      };
    }
    function commentReference(options) {
      return {
        type: types.commentReference,
        commentId: options.commentId
      };
    }
    function comment(options) {
      return {
        type: types.comment,
        commentId: options.commentId,
        body: options.body,
        authorName: options.authorName,
        authorInitials: options.authorInitials
      };
    }
    function noteKey(noteType, id) {
      return noteType + "-" + id;
    }
    function Image(options) {
      return {
        type: types.image,
        // `read` is retained for backwards compatibility, but other read
        // methods should be preferred.
        read: function(encoding) {
          if (encoding) {
            return options.readImage(encoding);
          } else {
            return options.readImage().then(function(arrayBuffer) {
              return Buffer.from(arrayBuffer);
            });
          }
        },
        readAsArrayBuffer: function() {
          return options.readImage();
        },
        readAsBase64String: function() {
          return options.readImage("base64");
        },
        readAsBuffer: function() {
          return options.readImage().then(function(arrayBuffer) {
            return Buffer.from(arrayBuffer);
          });
        },
        altText: options.altText,
        contentType: options.contentType
      };
    }
    function Table(children, properties) {
      properties = properties || {};
      return {
        type: types.table,
        children,
        styleId: properties.styleId || null,
        styleName: properties.styleName || null
      };
    }
    function TableRow(children, options) {
      options = options || {};
      return {
        type: types.tableRow,
        children,
        isHeader: options.isHeader || false
      };
    }
    function TableCell(children, options) {
      options = options || {};
      return {
        type: types.tableCell,
        children,
        colSpan: options.colSpan == null ? 1 : options.colSpan,
        rowSpan: options.rowSpan == null ? 1 : options.rowSpan
      };
    }
    function Break(breakType) {
      return {
        type: types["break"],
        breakType
      };
    }
    function BookmarkStart(options) {
      return {
        type: types.bookmarkStart,
        name: options.name
      };
    }
    exports2.document = exports2.Document = Document;
    exports2.paragraph = exports2.Paragraph = Paragraph;
    exports2.run = exports2.Run = Run;
    exports2.text = exports2.Text = Text;
    exports2.tab = exports2.Tab = Tab;
    exports2.checkbox = exports2.Checkbox = Checkbox;
    exports2.Hyperlink = Hyperlink;
    exports2.noteReference = exports2.NoteReference = NoteReference;
    exports2.Notes = Notes;
    exports2.Note = Note;
    exports2.commentReference = commentReference;
    exports2.comment = comment;
    exports2.Image = Image;
    exports2.Table = Table;
    exports2.TableRow = TableRow;
    exports2.TableCell = TableCell;
    exports2.lineBreak = Break("line");
    exports2.pageBreak = Break("page");
    exports2.columnBreak = Break("column");
    exports2.BookmarkStart = BookmarkStart;
    exports2.verticalAlignment = verticalAlignment;
  }
});

// node_modules/mammoth/lib/results.js
var require_results = __commonJS({
  "node_modules/mammoth/lib/results.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    exports2.Result = Result;
    exports2.success = success;
    exports2.warning = warning;
    exports2.error = error;
    function Result(value, messages) {
      this.value = value;
      this.messages = messages || [];
    }
    Result.prototype.map = function(func) {
      return new Result(func(this.value), this.messages);
    };
    Result.prototype.flatMap = function(func) {
      var funcResult = func(this.value);
      return new Result(funcResult.value, combineMessages([this, funcResult]));
    };
    Result.prototype.flatMapThen = function(func) {
      var that = this;
      return func(this.value).then(function(otherResult) {
        return new Result(otherResult.value, combineMessages([that, otherResult]));
      });
    };
    Result.combine = function(results) {
      var values2 = _3.flatten(_3.pluck(results, "value"));
      var messages = combineMessages(results);
      return new Result(values2, messages);
    };
    function success(value) {
      return new Result(value, []);
    }
    function warning(message) {
      return {
        type: "warning",
        message
      };
    }
    function error(exception) {
      return {
        type: "error",
        message: exception.message,
        error: exception
      };
    }
    function combineMessages(results) {
      var messages = [];
      _3.flatten(_3.pluck(results, "messages"), true).forEach(function(message) {
        if (!containsMessage(messages, message)) {
          messages.push(message);
        }
      });
      return messages;
    }
    function containsMessage(messages, message) {
      return _3.find(messages, isSameMessage.bind(null, message)) !== void 0;
    }
    function isSameMessage(first2, second) {
      return first2.type === second.type && first2.message === second.message;
    }
  }
});

// node_modules/base64-js/index.js
var require_base64_js = __commonJS({
  "node_modules/base64-js/index.js"(exports2) {
    "use strict";
    exports2.byteLength = byteLength;
    exports2.toByteArray = toByteArray;
    exports2.fromByteArray = fromByteArray;
    var lookup = [];
    var revLookup = [];
    var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
    var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (i = 0, len = code.length; i < len; ++i) {
      lookup[i] = code[i];
      revLookup[code.charCodeAt(i)] = i;
    }
    var i;
    var len;
    revLookup["-".charCodeAt(0)] = 62;
    revLookup["_".charCodeAt(0)] = 63;
    function getLens(b64) {
      var len2 = b64.length;
      if (len2 % 4 > 0) {
        throw new Error("Invalid string. Length must be a multiple of 4");
      }
      var validLen = b64.indexOf("=");
      if (validLen === -1) validLen = len2;
      var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
      return [validLen, placeHoldersLen];
    }
    function byteLength(b64) {
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function _byteLength(b64, validLen, placeHoldersLen) {
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function toByteArray(b64) {
      var tmp;
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
      var curByte = 0;
      var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
      var i2;
      for (i2 = 0; i2 < len2; i2 += 4) {
        tmp = revLookup[b64.charCodeAt(i2)] << 18 | revLookup[b64.charCodeAt(i2 + 1)] << 12 | revLookup[b64.charCodeAt(i2 + 2)] << 6 | revLookup[b64.charCodeAt(i2 + 3)];
        arr[curByte++] = tmp >> 16 & 255;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 2) {
        tmp = revLookup[b64.charCodeAt(i2)] << 2 | revLookup[b64.charCodeAt(i2 + 1)] >> 4;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 1) {
        tmp = revLookup[b64.charCodeAt(i2)] << 10 | revLookup[b64.charCodeAt(i2 + 1)] << 4 | revLookup[b64.charCodeAt(i2 + 2)] >> 2;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      return arr;
    }
    function tripletToBase64(num) {
      return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
    }
    function encodeChunk(uint8, start, end) {
      var tmp;
      var output = [];
      for (var i2 = start; i2 < end; i2 += 3) {
        tmp = (uint8[i2] << 16 & 16711680) + (uint8[i2 + 1] << 8 & 65280) + (uint8[i2 + 2] & 255);
        output.push(tripletToBase64(tmp));
      }
      return output.join("");
    }
    function fromByteArray(uint8) {
      var tmp;
      var len2 = uint8.length;
      var extraBytes = len2 % 3;
      var parts = [];
      var maxChunkLength = 16383;
      for (var i2 = 0, len22 = len2 - extraBytes; i2 < len22; i2 += maxChunkLength) {
        parts.push(encodeChunk(uint8, i2, i2 + maxChunkLength > len22 ? len22 : i2 + maxChunkLength));
      }
      if (extraBytes === 1) {
        tmp = uint8[len2 - 1];
        parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "==");
      } else if (extraBytes === 2) {
        tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
        parts.push(lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "=");
      }
      return parts.join("");
    }
  }
});

// node_modules/jszip/dist/jszip.min.js
var require_jszip_min = __commonJS({
  "node_modules/jszip/dist/jszip.min.js"(exports2, module2) {
    !function(e) {
      if ("object" == typeof exports2 && "undefined" != typeof module2) module2.exports = e();
      else if ("function" == typeof define && define.amd) define([], e);
      else {
        ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).JSZip = e();
      }
    }(function() {
      return function s(a, o, h) {
        function u(r, e2) {
          if (!o[r]) {
            if (!a[r]) {
              var t = "function" == typeof __require && __require;
              if (!e2 && t) return t(r, true);
              if (l2) return l2(r, true);
              var n = new Error("Cannot find module '" + r + "'");
              throw n.code = "MODULE_NOT_FOUND", n;
            }
            var i = o[r] = {
              exports: {}
            };
            a[r][0].call(i.exports, function(e3) {
              var t2 = a[r][1][e3];
              return u(t2 || e3);
            }, i, i.exports, s, a, o, h);
          }
          return o[r].exports;
        }
        for (var l2 = "function" == typeof __require && __require, e = 0; e < h.length; e++) u(h[e]);
        return u;
      }({
        1: [function(e, t, r) {
          "use strict";
          var d = e("./utils"), c = e("./support"), p = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
          r.encode = function(e2) {
            for (var t2, r2, n, i, s, a, o, h = [], u = 0, l2 = e2.length, f = l2, c2 = "string" !== d.getTypeOf(e2); u < e2.length; ) f = l2 - u, n = c2 ? (t2 = e2[u++], r2 = u < l2 ? e2[u++] : 0, u < l2 ? e2[u++] : 0) : (t2 = e2.charCodeAt(u++), r2 = u < l2 ? e2.charCodeAt(u++) : 0, u < l2 ? e2.charCodeAt(u++) : 0), i = t2 >> 2, s = (3 & t2) << 4 | r2 >> 4, a = 1 < f ? (15 & r2) << 2 | n >> 6 : 64, o = 2 < f ? 63 & n : 64, h.push(p.charAt(i) + p.charAt(s) + p.charAt(a) + p.charAt(o));
            return h.join("");
          }, r.decode = function(e2) {
            var t2, r2, n, i, s, a, o = 0, h = 0, u = "data:";
            if (e2.substr(0, u.length) === u) throw new Error("Invalid base64 input, it looks like a data url.");
            var l2, f = 3 * (e2 = e2.replace(/[^A-Za-z0-9+/=]/g, "")).length / 4;
            if (e2.charAt(e2.length - 1) === p.charAt(64) && f--, e2.charAt(e2.length - 2) === p.charAt(64) && f--, f % 1 != 0) throw new Error("Invalid base64 input, bad content length.");
            for (l2 = c.uint8array ? new Uint8Array(0 | f) : new Array(0 | f); o < e2.length; ) t2 = p.indexOf(e2.charAt(o++)) << 2 | (i = p.indexOf(e2.charAt(o++))) >> 4, r2 = (15 & i) << 4 | (s = p.indexOf(e2.charAt(o++))) >> 2, n = (3 & s) << 6 | (a = p.indexOf(e2.charAt(o++))), l2[h++] = t2, 64 !== s && (l2[h++] = r2), 64 !== a && (l2[h++] = n);
            return l2;
          };
        }, {
          "./support": 30,
          "./utils": 32
        }],
        2: [function(e, t, r) {
          "use strict";
          var n = e("./external"), i = e("./stream/DataWorker"), s = e("./stream/Crc32Probe"), a = e("./stream/DataLengthProbe");
          function o(e2, t2, r2, n2, i2) {
            this.compressedSize = e2, this.uncompressedSize = t2, this.crc32 = r2, this.compression = n2, this.compressedContent = i2;
          }
          o.prototype = {
            getContentWorker: function() {
              var e2 = new i(n.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")), t2 = this;
              return e2.on("end", function() {
                if (this.streamInfo.data_length !== t2.uncompressedSize) throw new Error("Bug : uncompressed data size mismatch");
              }), e2;
            },
            getCompressedWorker: function() {
              return new i(n.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize", this.compressedSize).withStreamInfo("uncompressedSize", this.uncompressedSize).withStreamInfo("crc32", this.crc32).withStreamInfo("compression", this.compression);
            }
          }, o.createWorkerFrom = function(e2, t2, r2) {
            return e2.pipe(new s()).pipe(new a("uncompressedSize")).pipe(t2.compressWorker(r2)).pipe(new a("compressedSize")).withStreamInfo("compression", t2);
          }, t.exports = o;
        }, {
          "./external": 6,
          "./stream/Crc32Probe": 25,
          "./stream/DataLengthProbe": 26,
          "./stream/DataWorker": 27
        }],
        3: [function(e, t, r) {
          "use strict";
          var n = e("./stream/GenericWorker");
          r.STORE = {
            magic: "\0\0",
            compressWorker: function() {
              return new n("STORE compression");
            },
            uncompressWorker: function() {
              return new n("STORE decompression");
            }
          }, r.DEFLATE = e("./flate");
        }, {
          "./flate": 7,
          "./stream/GenericWorker": 28
        }],
        4: [function(e, t, r) {
          "use strict";
          var n = e("./utils");
          var o = function() {
            for (var e2, t2 = [], r2 = 0; r2 < 256; r2++) {
              e2 = r2;
              for (var n2 = 0; n2 < 8; n2++) e2 = 1 & e2 ? 3988292384 ^ e2 >>> 1 : e2 >>> 1;
              t2[r2] = e2;
            }
            return t2;
          }();
          t.exports = function(e2, t2) {
            return void 0 !== e2 && e2.length ? "string" !== n.getTypeOf(e2) ? function(e3, t3, r2, n2) {
              var i = o, s = n2 + r2;
              e3 ^= -1;
              for (var a = n2; a < s; a++) e3 = e3 >>> 8 ^ i[255 & (e3 ^ t3[a])];
              return -1 ^ e3;
            }(0 | t2, e2, e2.length, 0) : function(e3, t3, r2, n2) {
              var i = o, s = n2 + r2;
              e3 ^= -1;
              for (var a = n2; a < s; a++) e3 = e3 >>> 8 ^ i[255 & (e3 ^ t3.charCodeAt(a))];
              return -1 ^ e3;
            }(0 | t2, e2, e2.length, 0) : 0;
          };
        }, {
          "./utils": 32
        }],
        5: [function(e, t, r) {
          "use strict";
          r.base64 = false, r.binary = false, r.dir = false, r.createFolders = true, r.date = null, r.compression = null, r.compressionOptions = null, r.comment = null, r.unixPermissions = null, r.dosPermissions = null;
        }, {}],
        6: [function(e, t, r) {
          "use strict";
          var n = null;
          n = "undefined" != typeof Promise ? Promise : e("lie"), t.exports = {
            Promise: n
          };
        }, {
          lie: 37
        }],
        7: [function(e, t, r) {
          "use strict";
          var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Uint32Array, i = e("pako"), s = e("./utils"), a = e("./stream/GenericWorker"), o = n ? "uint8array" : "array";
          function h(e2, t2) {
            a.call(this, "FlateWorker/" + e2), this._pako = null, this._pakoAction = e2, this._pakoOptions = t2, this.meta = {};
          }
          r.magic = "\b\0", s.inherits(h, a), h.prototype.processChunk = function(e2) {
            this.meta = e2.meta, null === this._pako && this._createPako(), this._pako.push(s.transformTo(o, e2.data), false);
          }, h.prototype.flush = function() {
            a.prototype.flush.call(this), null === this._pako && this._createPako(), this._pako.push([], true);
          }, h.prototype.cleanUp = function() {
            a.prototype.cleanUp.call(this), this._pako = null;
          }, h.prototype._createPako = function() {
            this._pako = new i[this._pakoAction]({
              raw: true,
              level: this._pakoOptions.level || -1
            });
            var t2 = this;
            this._pako.onData = function(e2) {
              t2.push({
                data: e2,
                meta: t2.meta
              });
            };
          }, r.compressWorker = function(e2) {
            return new h("Deflate", e2);
          }, r.uncompressWorker = function() {
            return new h("Inflate", {});
          };
        }, {
          "./stream/GenericWorker": 28,
          "./utils": 32,
          pako: 38
        }],
        8: [function(e, t, r) {
          "use strict";
          function A(e2, t2) {
            var r2, n2 = "";
            for (r2 = 0; r2 < t2; r2++) n2 += String.fromCharCode(255 & e2), e2 >>>= 8;
            return n2;
          }
          function n(e2, t2, r2, n2, i2, s2) {
            var a, o, h = e2.file, u = e2.compression, l2 = s2 !== O.utf8encode, f = I.transformTo("string", s2(h.name)), c = I.transformTo("string", O.utf8encode(h.name)), d = h.comment, p = I.transformTo("string", s2(d)), m = I.transformTo("string", O.utf8encode(d)), _3 = c.length !== h.name.length, g = m.length !== d.length, b = "", v = "", y = "", w = h.dir, k = h.date, x = {
              crc32: 0,
              compressedSize: 0,
              uncompressedSize: 0
            };
            t2 && !r2 || (x.crc32 = e2.crc32, x.compressedSize = e2.compressedSize, x.uncompressedSize = e2.uncompressedSize);
            var S = 0;
            t2 && (S |= 8), l2 || !_3 && !g || (S |= 2048);
            var z = 0, C = 0;
            w && (z |= 16), "UNIX" === i2 ? (C = 798, z |= function(e3, t3) {
              var r3 = e3;
              return e3 || (r3 = t3 ? 16893 : 33204), (65535 & r3) << 16;
            }(h.unixPermissions, w)) : (C = 20, z |= function(e3) {
              return 63 & (e3 || 0);
            }(h.dosPermissions)), a = k.getUTCHours(), a <<= 6, a |= k.getUTCMinutes(), a <<= 5, a |= k.getUTCSeconds() / 2, o = k.getUTCFullYear() - 1980, o <<= 4, o |= k.getUTCMonth() + 1, o <<= 5, o |= k.getUTCDate(), _3 && (v = A(1, 1) + A(B(f), 4) + c, b += "up" + A(v.length, 2) + v), g && (y = A(1, 1) + A(B(p), 4) + m, b += "uc" + A(y.length, 2) + y);
            var E = "";
            return E += "\n\0", E += A(S, 2), E += u.magic, E += A(a, 2), E += A(o, 2), E += A(x.crc32, 4), E += A(x.compressedSize, 4), E += A(x.uncompressedSize, 4), E += A(f.length, 2), E += A(b.length, 2), {
              fileRecord: R.LOCAL_FILE_HEADER + E + f + b,
              dirRecord: R.CENTRAL_FILE_HEADER + A(C, 2) + E + A(p.length, 2) + "\0\0\0\0" + A(z, 4) + A(n2, 4) + f + b + p
            };
          }
          var I = e("../utils"), i = e("../stream/GenericWorker"), O = e("../utf8"), B = e("../crc32"), R = e("../signature");
          function s(e2, t2, r2, n2) {
            i.call(this, "ZipFileWorker"), this.bytesWritten = 0, this.zipComment = t2, this.zipPlatform = r2, this.encodeFileName = n2, this.streamFiles = e2, this.accumulate = false, this.contentBuffer = [], this.dirRecords = [], this.currentSourceOffset = 0, this.entriesCount = 0, this.currentFile = null, this._sources = [];
          }
          I.inherits(s, i), s.prototype.push = function(e2) {
            var t2 = e2.meta.percent || 0, r2 = this.entriesCount, n2 = this._sources.length;
            this.accumulate ? this.contentBuffer.push(e2) : (this.bytesWritten += e2.data.length, i.prototype.push.call(this, {
              data: e2.data,
              meta: {
                currentFile: this.currentFile,
                percent: r2 ? (t2 + 100 * (r2 - n2 - 1)) / r2 : 100
              }
            }));
          }, s.prototype.openedSource = function(e2) {
            this.currentSourceOffset = this.bytesWritten, this.currentFile = e2.file.name;
            var t2 = this.streamFiles && !e2.file.dir;
            if (t2) {
              var r2 = n(e2, t2, false, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
              this.push({
                data: r2.fileRecord,
                meta: {
                  percent: 0
                }
              });
            } else this.accumulate = true;
          }, s.prototype.closedSource = function(e2) {
            this.accumulate = false;
            var t2 = this.streamFiles && !e2.file.dir, r2 = n(e2, t2, true, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
            if (this.dirRecords.push(r2.dirRecord), t2) this.push({
              data: function(e3) {
                return R.DATA_DESCRIPTOR + A(e3.crc32, 4) + A(e3.compressedSize, 4) + A(e3.uncompressedSize, 4);
              }(e2),
              meta: {
                percent: 100
              }
            });
            else for (this.push({
              data: r2.fileRecord,
              meta: {
                percent: 0
              }
            }); this.contentBuffer.length; ) this.push(this.contentBuffer.shift());
            this.currentFile = null;
          }, s.prototype.flush = function() {
            for (var e2 = this.bytesWritten, t2 = 0; t2 < this.dirRecords.length; t2++) this.push({
              data: this.dirRecords[t2],
              meta: {
                percent: 100
              }
            });
            var r2 = this.bytesWritten - e2, n2 = function(e3, t3, r3, n3, i2) {
              var s2 = I.transformTo("string", i2(n3));
              return R.CENTRAL_DIRECTORY_END + "\0\0\0\0" + A(e3, 2) + A(e3, 2) + A(t3, 4) + A(r3, 4) + A(s2.length, 2) + s2;
            }(this.dirRecords.length, r2, e2, this.zipComment, this.encodeFileName);
            this.push({
              data: n2,
              meta: {
                percent: 100
              }
            });
          }, s.prototype.prepareNextSource = function() {
            this.previous = this._sources.shift(), this.openedSource(this.previous.streamInfo), this.isPaused ? this.previous.pause() : this.previous.resume();
          }, s.prototype.registerPrevious = function(e2) {
            this._sources.push(e2);
            var t2 = this;
            return e2.on("data", function(e3) {
              t2.processChunk(e3);
            }), e2.on("end", function() {
              t2.closedSource(t2.previous.streamInfo), t2._sources.length ? t2.prepareNextSource() : t2.end();
            }), e2.on("error", function(e3) {
              t2.error(e3);
            }), this;
          }, s.prototype.resume = function() {
            return !!i.prototype.resume.call(this) && (!this.previous && this._sources.length ? (this.prepareNextSource(), true) : this.previous || this._sources.length || this.generatedError ? void 0 : (this.end(), true));
          }, s.prototype.error = function(e2) {
            var t2 = this._sources;
            if (!i.prototype.error.call(this, e2)) return false;
            for (var r2 = 0; r2 < t2.length; r2++) try {
              t2[r2].error(e2);
            } catch (e3) {
            }
            return true;
          }, s.prototype.lock = function() {
            i.prototype.lock.call(this);
            for (var e2 = this._sources, t2 = 0; t2 < e2.length; t2++) e2[t2].lock();
          }, t.exports = s;
        }, {
          "../crc32": 4,
          "../signature": 23,
          "../stream/GenericWorker": 28,
          "../utf8": 31,
          "../utils": 32
        }],
        9: [function(e, t, r) {
          "use strict";
          var u = e("../compressions"), n = e("./ZipFileWorker");
          r.generateWorker = function(e2, a, t2) {
            var o = new n(a.streamFiles, t2, a.platform, a.encodeFileName), h = 0;
            try {
              e2.forEach(function(e3, t3) {
                h++;
                var r2 = function(e4, t4) {
                  var r3 = e4 || t4, n3 = u[r3];
                  if (!n3) throw new Error(r3 + " is not a valid compression method !");
                  return n3;
                }(t3.options.compression, a.compression), n2 = t3.options.compressionOptions || a.compressionOptions || {}, i = t3.dir, s = t3.date;
                t3._compressWorker(r2, n2).withStreamInfo("file", {
                  name: e3,
                  dir: i,
                  date: s,
                  comment: t3.comment || "",
                  unixPermissions: t3.unixPermissions,
                  dosPermissions: t3.dosPermissions
                }).pipe(o);
              }), o.entriesCount = h;
            } catch (e3) {
              o.error(e3);
            }
            return o;
          };
        }, {
          "../compressions": 3,
          "./ZipFileWorker": 8
        }],
        10: [function(e, t, r) {
          "use strict";
          function n() {
            if (!(this instanceof n)) return new n();
            if (arguments.length) throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");
            this.files = /* @__PURE__ */ Object.create(null), this.comment = null, this.root = "", this.clone = function() {
              var e2 = new n();
              for (var t2 in this) "function" != typeof this[t2] && (e2[t2] = this[t2]);
              return e2;
            };
          }
          (n.prototype = e("./object")).loadAsync = e("./load"), n.support = e("./support"), n.defaults = e("./defaults"), n.version = "3.10.1", n.loadAsync = function(e2, t2) {
            return new n().loadAsync(e2, t2);
          }, n.external = e("./external"), t.exports = n;
        }, {
          "./defaults": 5,
          "./external": 6,
          "./load": 11,
          "./object": 15,
          "./support": 30
        }],
        11: [function(e, t, r) {
          "use strict";
          var u = e("./utils"), i = e("./external"), n = e("./utf8"), s = e("./zipEntries"), a = e("./stream/Crc32Probe"), l2 = e("./nodejsUtils");
          function f(n2) {
            return new i.Promise(function(e2, t2) {
              var r2 = n2.decompressed.getContentWorker().pipe(new a());
              r2.on("error", function(e3) {
                t2(e3);
              }).on("end", function() {
                r2.streamInfo.crc32 !== n2.decompressed.crc32 ? t2(new Error("Corrupted zip : CRC32 mismatch")) : e2();
              }).resume();
            });
          }
          t.exports = function(e2, o) {
            var h = this;
            return o = u.extend(o || {}, {
              base64: false,
              checkCRC32: false,
              optimizedBinaryString: false,
              createFolders: false,
              decodeFileName: n.utf8decode
            }), l2.isNode && l2.isStream(e2) ? i.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")) : u.prepareContent("the loaded zip file", e2, true, o.optimizedBinaryString, o.base64).then(function(e3) {
              var t2 = new s(o);
              return t2.load(e3), t2;
            }).then(function(e3) {
              var t2 = [i.Promise.resolve(e3)], r2 = e3.files;
              if (o.checkCRC32) for (var n2 = 0; n2 < r2.length; n2++) t2.push(f(r2[n2]));
              return i.Promise.all(t2);
            }).then(function(e3) {
              for (var t2 = e3.shift(), r2 = t2.files, n2 = 0; n2 < r2.length; n2++) {
                var i2 = r2[n2], s2 = i2.fileNameStr, a2 = u.resolve(i2.fileNameStr);
                h.file(a2, i2.decompressed, {
                  binary: true,
                  optimizedBinaryString: true,
                  date: i2.date,
                  dir: i2.dir,
                  comment: i2.fileCommentStr.length ? i2.fileCommentStr : null,
                  unixPermissions: i2.unixPermissions,
                  dosPermissions: i2.dosPermissions,
                  createFolders: o.createFolders
                }), i2.dir || (h.file(a2).unsafeOriginalName = s2);
              }
              return t2.zipComment.length && (h.comment = t2.zipComment), h;
            });
          };
        }, {
          "./external": 6,
          "./nodejsUtils": 14,
          "./stream/Crc32Probe": 25,
          "./utf8": 31,
          "./utils": 32,
          "./zipEntries": 33
        }],
        12: [function(e, t, r) {
          "use strict";
          var n = e("../utils"), i = e("../stream/GenericWorker");
          function s(e2, t2) {
            i.call(this, "Nodejs stream input adapter for " + e2), this._upstreamEnded = false, this._bindStream(t2);
          }
          n.inherits(s, i), s.prototype._bindStream = function(e2) {
            var t2 = this;
            (this._stream = e2).pause(), e2.on("data", function(e3) {
              t2.push({
                data: e3,
                meta: {
                  percent: 0
                }
              });
            }).on("error", function(e3) {
              t2.isPaused ? this.generatedError = e3 : t2.error(e3);
            }).on("end", function() {
              t2.isPaused ? t2._upstreamEnded = true : t2.end();
            });
          }, s.prototype.pause = function() {
            return !!i.prototype.pause.call(this) && (this._stream.pause(), true);
          }, s.prototype.resume = function() {
            return !!i.prototype.resume.call(this) && (this._upstreamEnded ? this.end() : this._stream.resume(), true);
          }, t.exports = s;
        }, {
          "../stream/GenericWorker": 28,
          "../utils": 32
        }],
        13: [function(e, t, r) {
          "use strict";
          var i = e("readable-stream").Readable;
          function n(e2, t2, r2) {
            i.call(this, t2), this._helper = e2;
            var n2 = this;
            e2.on("data", function(e3, t3) {
              n2.push(e3) || n2._helper.pause(), r2 && r2(t3);
            }).on("error", function(e3) {
              n2.emit("error", e3);
            }).on("end", function() {
              n2.push(null);
            });
          }
          e("../utils").inherits(n, i), n.prototype._read = function() {
            this._helper.resume();
          }, t.exports = n;
        }, {
          "../utils": 32,
          "readable-stream": 16
        }],
        14: [function(e, t, r) {
          "use strict";
          t.exports = {
            isNode: "undefined" != typeof Buffer,
            newBufferFrom: function(e2, t2) {
              if (Buffer.from && Buffer.from !== Uint8Array.from) return Buffer.from(e2, t2);
              if ("number" == typeof e2) throw new Error('The "data" argument must not be a number');
              return new Buffer(e2, t2);
            },
            allocBuffer: function(e2) {
              if (Buffer.alloc) return Buffer.alloc(e2);
              var t2 = new Buffer(e2);
              return t2.fill(0), t2;
            },
            isBuffer: function(e2) {
              return Buffer.isBuffer(e2);
            },
            isStream: function(e2) {
              return e2 && "function" == typeof e2.on && "function" == typeof e2.pause && "function" == typeof e2.resume;
            }
          };
        }, {}],
        15: [function(e, t, r) {
          "use strict";
          function s(e2, t2, r2) {
            var n2, i2 = u.getTypeOf(t2), s2 = u.extend(r2 || {}, f);
            s2.date = s2.date || /* @__PURE__ */ new Date(), null !== s2.compression && (s2.compression = s2.compression.toUpperCase()), "string" == typeof s2.unixPermissions && (s2.unixPermissions = parseInt(s2.unixPermissions, 8)), s2.unixPermissions && 16384 & s2.unixPermissions && (s2.dir = true), s2.dosPermissions && 16 & s2.dosPermissions && (s2.dir = true), s2.dir && (e2 = g(e2)), s2.createFolders && (n2 = _3(e2)) && b.call(this, n2, true);
            var a2 = "string" === i2 && false === s2.binary && false === s2.base64;
            r2 && void 0 !== r2.binary || (s2.binary = !a2), (t2 instanceof c && 0 === t2.uncompressedSize || s2.dir || !t2 || 0 === t2.length) && (s2.base64 = false, s2.binary = true, t2 = "", s2.compression = "STORE", i2 = "string");
            var o2 = null;
            o2 = t2 instanceof c || t2 instanceof l2 ? t2 : p.isNode && p.isStream(t2) ? new m(e2, t2) : u.prepareContent(e2, t2, s2.binary, s2.optimizedBinaryString, s2.base64);
            var h2 = new d(e2, o2, s2);
            this.files[e2] = h2;
          }
          var i = e("./utf8"), u = e("./utils"), l2 = e("./stream/GenericWorker"), a = e("./stream/StreamHelper"), f = e("./defaults"), c = e("./compressedObject"), d = e("./zipObject"), o = e("./generate"), p = e("./nodejsUtils"), m = e("./nodejs/NodejsStreamInputAdapter"), _3 = function(e2) {
            "/" === e2.slice(-1) && (e2 = e2.substring(0, e2.length - 1));
            var t2 = e2.lastIndexOf("/");
            return 0 < t2 ? e2.substring(0, t2) : "";
          }, g = function(e2) {
            return "/" !== e2.slice(-1) && (e2 += "/"), e2;
          }, b = function(e2, t2) {
            return t2 = void 0 !== t2 ? t2 : f.createFolders, e2 = g(e2), this.files[e2] || s.call(this, e2, null, {
              dir: true,
              createFolders: t2
            }), this.files[e2];
          };
          function h(e2) {
            return "[object RegExp]" === Object.prototype.toString.call(e2);
          }
          var n = {
            load: function() {
              throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
            },
            forEach: function(e2) {
              var t2, r2, n2;
              for (t2 in this.files) n2 = this.files[t2], (r2 = t2.slice(this.root.length, t2.length)) && t2.slice(0, this.root.length) === this.root && e2(r2, n2);
            },
            filter: function(r2) {
              var n2 = [];
              return this.forEach(function(e2, t2) {
                r2(e2, t2) && n2.push(t2);
              }), n2;
            },
            file: function(e2, t2, r2) {
              if (1 !== arguments.length) return e2 = this.root + e2, s.call(this, e2, t2, r2), this;
              if (h(e2)) {
                var n2 = e2;
                return this.filter(function(e3, t3) {
                  return !t3.dir && n2.test(e3);
                });
              }
              var i2 = this.files[this.root + e2];
              return i2 && !i2.dir ? i2 : null;
            },
            folder: function(r2) {
              if (!r2) return this;
              if (h(r2)) return this.filter(function(e3, t3) {
                return t3.dir && r2.test(e3);
              });
              var e2 = this.root + r2, t2 = b.call(this, e2), n2 = this.clone();
              return n2.root = t2.name, n2;
            },
            remove: function(r2) {
              r2 = this.root + r2;
              var e2 = this.files[r2];
              if (e2 || ("/" !== r2.slice(-1) && (r2 += "/"), e2 = this.files[r2]), e2 && !e2.dir) delete this.files[r2];
              else for (var t2 = this.filter(function(e3, t3) {
                return t3.name.slice(0, r2.length) === r2;
              }), n2 = 0; n2 < t2.length; n2++) delete this.files[t2[n2].name];
              return this;
            },
            generate: function() {
              throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
            },
            generateInternalStream: function(e2) {
              var t2, r2 = {};
              try {
                if ((r2 = u.extend(e2 || {}, {
                  streamFiles: false,
                  compression: "STORE",
                  compressionOptions: null,
                  type: "",
                  platform: "DOS",
                  comment: null,
                  mimeType: "application/zip",
                  encodeFileName: i.utf8encode
                })).type = r2.type.toLowerCase(), r2.compression = r2.compression.toUpperCase(), "binarystring" === r2.type && (r2.type = "string"), !r2.type) throw new Error("No output type specified.");
                u.checkSupport(r2.type), "darwin" !== r2.platform && "freebsd" !== r2.platform && "linux" !== r2.platform && "sunos" !== r2.platform || (r2.platform = "UNIX"), "win32" === r2.platform && (r2.platform = "DOS");
                var n2 = r2.comment || this.comment || "";
                t2 = o.generateWorker(this, r2, n2);
              } catch (e3) {
                (t2 = new l2("error")).error(e3);
              }
              return new a(t2, r2.type || "string", r2.mimeType);
            },
            generateAsync: function(e2, t2) {
              return this.generateInternalStream(e2).accumulate(t2);
            },
            generateNodeStream: function(e2, t2) {
              return (e2 = e2 || {}).type || (e2.type = "nodebuffer"), this.generateInternalStream(e2).toNodejsStream(t2);
            }
          };
          t.exports = n;
        }, {
          "./compressedObject": 2,
          "./defaults": 5,
          "./generate": 9,
          "./nodejs/NodejsStreamInputAdapter": 12,
          "./nodejsUtils": 14,
          "./stream/GenericWorker": 28,
          "./stream/StreamHelper": 29,
          "./utf8": 31,
          "./utils": 32,
          "./zipObject": 35
        }],
        16: [function(e, t, r) {
          "use strict";
          t.exports = e("stream");
        }, {
          stream: void 0
        }],
        17: [function(e, t, r) {
          "use strict";
          var n = e("./DataReader");
          function i(e2) {
            n.call(this, e2);
            for (var t2 = 0; t2 < this.data.length; t2++) e2[t2] = 255 & e2[t2];
          }
          e("../utils").inherits(i, n), i.prototype.byteAt = function(e2) {
            return this.data[this.zero + e2];
          }, i.prototype.lastIndexOfSignature = function(e2) {
            for (var t2 = e2.charCodeAt(0), r2 = e2.charCodeAt(1), n2 = e2.charCodeAt(2), i2 = e2.charCodeAt(3), s = this.length - 4; 0 <= s; --s) if (this.data[s] === t2 && this.data[s + 1] === r2 && this.data[s + 2] === n2 && this.data[s + 3] === i2) return s - this.zero;
            return -1;
          }, i.prototype.readAndCheckSignature = function(e2) {
            var t2 = e2.charCodeAt(0), r2 = e2.charCodeAt(1), n2 = e2.charCodeAt(2), i2 = e2.charCodeAt(3), s = this.readData(4);
            return t2 === s[0] && r2 === s[1] && n2 === s[2] && i2 === s[3];
          }, i.prototype.readData = function(e2) {
            if (this.checkOffset(e2), 0 === e2) return [];
            var t2 = this.data.slice(this.zero + this.index, this.zero + this.index + e2);
            return this.index += e2, t2;
          }, t.exports = i;
        }, {
          "../utils": 32,
          "./DataReader": 18
        }],
        18: [function(e, t, r) {
          "use strict";
          var n = e("../utils");
          function i(e2) {
            this.data = e2, this.length = e2.length, this.index = 0, this.zero = 0;
          }
          i.prototype = {
            checkOffset: function(e2) {
              this.checkIndex(this.index + e2);
            },
            checkIndex: function(e2) {
              if (this.length < this.zero + e2 || e2 < 0) throw new Error("End of data reached (data length = " + this.length + ", asked index = " + e2 + "). Corrupted zip ?");
            },
            setIndex: function(e2) {
              this.checkIndex(e2), this.index = e2;
            },
            skip: function(e2) {
              this.setIndex(this.index + e2);
            },
            byteAt: function() {
            },
            readInt: function(e2) {
              var t2, r2 = 0;
              for (this.checkOffset(e2), t2 = this.index + e2 - 1; t2 >= this.index; t2--) r2 = (r2 << 8) + this.byteAt(t2);
              return this.index += e2, r2;
            },
            readString: function(e2) {
              return n.transformTo("string", this.readData(e2));
            },
            readData: function() {
            },
            lastIndexOfSignature: function() {
            },
            readAndCheckSignature: function() {
            },
            readDate: function() {
              var e2 = this.readInt(4);
              return new Date(Date.UTC(1980 + (e2 >> 25 & 127), (e2 >> 21 & 15) - 1, e2 >> 16 & 31, e2 >> 11 & 31, e2 >> 5 & 63, (31 & e2) << 1));
            }
          }, t.exports = i;
        }, {
          "../utils": 32
        }],
        19: [function(e, t, r) {
          "use strict";
          var n = e("./Uint8ArrayReader");
          function i(e2) {
            n.call(this, e2);
          }
          e("../utils").inherits(i, n), i.prototype.readData = function(e2) {
            this.checkOffset(e2);
            var t2 = this.data.slice(this.zero + this.index, this.zero + this.index + e2);
            return this.index += e2, t2;
          }, t.exports = i;
        }, {
          "../utils": 32,
          "./Uint8ArrayReader": 21
        }],
        20: [function(e, t, r) {
          "use strict";
          var n = e("./DataReader");
          function i(e2) {
            n.call(this, e2);
          }
          e("../utils").inherits(i, n), i.prototype.byteAt = function(e2) {
            return this.data.charCodeAt(this.zero + e2);
          }, i.prototype.lastIndexOfSignature = function(e2) {
            return this.data.lastIndexOf(e2) - this.zero;
          }, i.prototype.readAndCheckSignature = function(e2) {
            return e2 === this.readData(4);
          }, i.prototype.readData = function(e2) {
            this.checkOffset(e2);
            var t2 = this.data.slice(this.zero + this.index, this.zero + this.index + e2);
            return this.index += e2, t2;
          }, t.exports = i;
        }, {
          "../utils": 32,
          "./DataReader": 18
        }],
        21: [function(e, t, r) {
          "use strict";
          var n = e("./ArrayReader");
          function i(e2) {
            n.call(this, e2);
          }
          e("../utils").inherits(i, n), i.prototype.readData = function(e2) {
            if (this.checkOffset(e2), 0 === e2) return new Uint8Array(0);
            var t2 = this.data.subarray(this.zero + this.index, this.zero + this.index + e2);
            return this.index += e2, t2;
          }, t.exports = i;
        }, {
          "../utils": 32,
          "./ArrayReader": 17
        }],
        22: [function(e, t, r) {
          "use strict";
          var n = e("../utils"), i = e("../support"), s = e("./ArrayReader"), a = e("./StringReader"), o = e("./NodeBufferReader"), h = e("./Uint8ArrayReader");
          t.exports = function(e2) {
            var t2 = n.getTypeOf(e2);
            return n.checkSupport(t2), "string" !== t2 || i.uint8array ? "nodebuffer" === t2 ? new o(e2) : i.uint8array ? new h(n.transformTo("uint8array", e2)) : new s(n.transformTo("array", e2)) : new a(e2);
          };
        }, {
          "../support": 30,
          "../utils": 32,
          "./ArrayReader": 17,
          "./NodeBufferReader": 19,
          "./StringReader": 20,
          "./Uint8ArrayReader": 21
        }],
        23: [function(e, t, r) {
          "use strict";
          r.LOCAL_FILE_HEADER = "PK", r.CENTRAL_FILE_HEADER = "PK", r.CENTRAL_DIRECTORY_END = "PK", r.ZIP64_CENTRAL_DIRECTORY_LOCATOR = "PK\x07", r.ZIP64_CENTRAL_DIRECTORY_END = "PK", r.DATA_DESCRIPTOR = "PK\x07\b";
        }, {}],
        24: [function(e, t, r) {
          "use strict";
          var n = e("./GenericWorker"), i = e("../utils");
          function s(e2) {
            n.call(this, "ConvertWorker to " + e2), this.destType = e2;
          }
          i.inherits(s, n), s.prototype.processChunk = function(e2) {
            this.push({
              data: i.transformTo(this.destType, e2.data),
              meta: e2.meta
            });
          }, t.exports = s;
        }, {
          "../utils": 32,
          "./GenericWorker": 28
        }],
        25: [function(e, t, r) {
          "use strict";
          var n = e("./GenericWorker"), i = e("../crc32");
          function s() {
            n.call(this, "Crc32Probe"), this.withStreamInfo("crc32", 0);
          }
          e("../utils").inherits(s, n), s.prototype.processChunk = function(e2) {
            this.streamInfo.crc32 = i(e2.data, this.streamInfo.crc32 || 0), this.push(e2);
          }, t.exports = s;
        }, {
          "../crc32": 4,
          "../utils": 32,
          "./GenericWorker": 28
        }],
        26: [function(e, t, r) {
          "use strict";
          var n = e("../utils"), i = e("./GenericWorker");
          function s(e2) {
            i.call(this, "DataLengthProbe for " + e2), this.propName = e2, this.withStreamInfo(e2, 0);
          }
          n.inherits(s, i), s.prototype.processChunk = function(e2) {
            if (e2) {
              var t2 = this.streamInfo[this.propName] || 0;
              this.streamInfo[this.propName] = t2 + e2.data.length;
            }
            i.prototype.processChunk.call(this, e2);
          }, t.exports = s;
        }, {
          "../utils": 32,
          "./GenericWorker": 28
        }],
        27: [function(e, t, r) {
          "use strict";
          var n = e("../utils"), i = e("./GenericWorker");
          function s(e2) {
            i.call(this, "DataWorker");
            var t2 = this;
            this.dataIsReady = false, this.index = 0, this.max = 0, this.data = null, this.type = "", this._tickScheduled = false, e2.then(function(e3) {
              t2.dataIsReady = true, t2.data = e3, t2.max = e3 && e3.length || 0, t2.type = n.getTypeOf(e3), t2.isPaused || t2._tickAndRepeat();
            }, function(e3) {
              t2.error(e3);
            });
          }
          n.inherits(s, i), s.prototype.cleanUp = function() {
            i.prototype.cleanUp.call(this), this.data = null;
          }, s.prototype.resume = function() {
            return !!i.prototype.resume.call(this) && (!this._tickScheduled && this.dataIsReady && (this._tickScheduled = true, n.delay(this._tickAndRepeat, [], this)), true);
          }, s.prototype._tickAndRepeat = function() {
            this._tickScheduled = false, this.isPaused || this.isFinished || (this._tick(), this.isFinished || (n.delay(this._tickAndRepeat, [], this), this._tickScheduled = true));
          }, s.prototype._tick = function() {
            if (this.isPaused || this.isFinished) return false;
            var e2 = null, t2 = Math.min(this.max, this.index + 16384);
            if (this.index >= this.max) return this.end();
            switch (this.type) {
              case "string":
                e2 = this.data.substring(this.index, t2);
                break;
              case "uint8array":
                e2 = this.data.subarray(this.index, t2);
                break;
              case "array":
              case "nodebuffer":
                e2 = this.data.slice(this.index, t2);
            }
            return this.index = t2, this.push({
              data: e2,
              meta: {
                percent: this.max ? this.index / this.max * 100 : 0
              }
            });
          }, t.exports = s;
        }, {
          "../utils": 32,
          "./GenericWorker": 28
        }],
        28: [function(e, t, r) {
          "use strict";
          function n(e2) {
            this.name = e2 || "default", this.streamInfo = {}, this.generatedError = null, this.extraStreamInfo = {}, this.isPaused = true, this.isFinished = false, this.isLocked = false, this._listeners = {
              data: [],
              end: [],
              error: []
            }, this.previous = null;
          }
          n.prototype = {
            push: function(e2) {
              this.emit("data", e2);
            },
            end: function() {
              if (this.isFinished) return false;
              this.flush();
              try {
                this.emit("end"), this.cleanUp(), this.isFinished = true;
              } catch (e2) {
                this.emit("error", e2);
              }
              return true;
            },
            error: function(e2) {
              return !this.isFinished && (this.isPaused ? this.generatedError = e2 : (this.isFinished = true, this.emit("error", e2), this.previous && this.previous.error(e2), this.cleanUp()), true);
            },
            on: function(e2, t2) {
              return this._listeners[e2].push(t2), this;
            },
            cleanUp: function() {
              this.streamInfo = this.generatedError = this.extraStreamInfo = null, this._listeners = [];
            },
            emit: function(e2, t2) {
              if (this._listeners[e2]) for (var r2 = 0; r2 < this._listeners[e2].length; r2++) this._listeners[e2][r2].call(this, t2);
            },
            pipe: function(e2) {
              return e2.registerPrevious(this);
            },
            registerPrevious: function(e2) {
              if (this.isLocked) throw new Error("The stream '" + this + "' has already been used.");
              this.streamInfo = e2.streamInfo, this.mergeStreamInfo(), this.previous = e2;
              var t2 = this;
              return e2.on("data", function(e3) {
                t2.processChunk(e3);
              }), e2.on("end", function() {
                t2.end();
              }), e2.on("error", function(e3) {
                t2.error(e3);
              }), this;
            },
            pause: function() {
              return !this.isPaused && !this.isFinished && (this.isPaused = true, this.previous && this.previous.pause(), true);
            },
            resume: function() {
              if (!this.isPaused || this.isFinished) return false;
              var e2 = this.isPaused = false;
              return this.generatedError && (this.error(this.generatedError), e2 = true), this.previous && this.previous.resume(), !e2;
            },
            flush: function() {
            },
            processChunk: function(e2) {
              this.push(e2);
            },
            withStreamInfo: function(e2, t2) {
              return this.extraStreamInfo[e2] = t2, this.mergeStreamInfo(), this;
            },
            mergeStreamInfo: function() {
              for (var e2 in this.extraStreamInfo) Object.prototype.hasOwnProperty.call(this.extraStreamInfo, e2) && (this.streamInfo[e2] = this.extraStreamInfo[e2]);
            },
            lock: function() {
              if (this.isLocked) throw new Error("The stream '" + this + "' has already been used.");
              this.isLocked = true, this.previous && this.previous.lock();
            },
            toString: function() {
              var e2 = "Worker " + this.name;
              return this.previous ? this.previous + " -> " + e2 : e2;
            }
          }, t.exports = n;
        }, {}],
        29: [function(e, t, r) {
          "use strict";
          var h = e("../utils"), i = e("./ConvertWorker"), s = e("./GenericWorker"), u = e("../base64"), n = e("../support"), a = e("../external"), o = null;
          if (n.nodestream) try {
            o = e("../nodejs/NodejsStreamOutputAdapter");
          } catch (e2) {
          }
          function l2(e2, o2) {
            return new a.Promise(function(t2, r2) {
              var n2 = [], i2 = e2._internalType, s2 = e2._outputType, a2 = e2._mimeType;
              e2.on("data", function(e3, t3) {
                n2.push(e3), o2 && o2(t3);
              }).on("error", function(e3) {
                n2 = [], r2(e3);
              }).on("end", function() {
                try {
                  var e3 = function(e4, t3, r3) {
                    switch (e4) {
                      case "blob":
                        return h.newBlob(h.transformTo("arraybuffer", t3), r3);
                      case "base64":
                        return u.encode(t3);
                      default:
                        return h.transformTo(e4, t3);
                    }
                  }(s2, function(e4, t3) {
                    var r3, n3 = 0, i3 = null, s3 = 0;
                    for (r3 = 0; r3 < t3.length; r3++) s3 += t3[r3].length;
                    switch (e4) {
                      case "string":
                        return t3.join("");
                      case "array":
                        return Array.prototype.concat.apply([], t3);
                      case "uint8array":
                        for (i3 = new Uint8Array(s3), r3 = 0; r3 < t3.length; r3++) i3.set(t3[r3], n3), n3 += t3[r3].length;
                        return i3;
                      case "nodebuffer":
                        return Buffer.concat(t3);
                      default:
                        throw new Error("concat : unsupported type '" + e4 + "'");
                    }
                  }(i2, n2), a2);
                  t2(e3);
                } catch (e4) {
                  r2(e4);
                }
                n2 = [];
              }).resume();
            });
          }
          function f(e2, t2, r2) {
            var n2 = t2;
            switch (t2) {
              case "blob":
              case "arraybuffer":
                n2 = "uint8array";
                break;
              case "base64":
                n2 = "string";
            }
            try {
              this._internalType = n2, this._outputType = t2, this._mimeType = r2, h.checkSupport(n2), this._worker = e2.pipe(new i(n2)), e2.lock();
            } catch (e3) {
              this._worker = new s("error"), this._worker.error(e3);
            }
          }
          f.prototype = {
            accumulate: function(e2) {
              return l2(this, e2);
            },
            on: function(e2, t2) {
              var r2 = this;
              return "data" === e2 ? this._worker.on(e2, function(e3) {
                t2.call(r2, e3.data, e3.meta);
              }) : this._worker.on(e2, function() {
                h.delay(t2, arguments, r2);
              }), this;
            },
            resume: function() {
              return h.delay(this._worker.resume, [], this._worker), this;
            },
            pause: function() {
              return this._worker.pause(), this;
            },
            toNodejsStream: function(e2) {
              if (h.checkSupport("nodestream"), "nodebuffer" !== this._outputType) throw new Error(this._outputType + " is not supported by this method");
              return new o(this, {
                objectMode: "nodebuffer" !== this._outputType
              }, e2);
            }
          }, t.exports = f;
        }, {
          "../base64": 1,
          "../external": 6,
          "../nodejs/NodejsStreamOutputAdapter": 13,
          "../support": 30,
          "../utils": 32,
          "./ConvertWorker": 24,
          "./GenericWorker": 28
        }],
        30: [function(e, t, r) {
          "use strict";
          if (r.base64 = true, r.array = true, r.string = true, r.arraybuffer = "undefined" != typeof ArrayBuffer && "undefined" != typeof Uint8Array, r.nodebuffer = "undefined" != typeof Buffer, r.uint8array = "undefined" != typeof Uint8Array, "undefined" == typeof ArrayBuffer) r.blob = false;
          else {
            var n = new ArrayBuffer(0);
            try {
              r.blob = 0 === new Blob([n], {
                type: "application/zip"
              }).size;
            } catch (e2) {
              try {
                var i = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
                i.append(n), r.blob = 0 === i.getBlob("application/zip").size;
              } catch (e3) {
                r.blob = false;
              }
            }
          }
          try {
            r.nodestream = !!e("readable-stream").Readable;
          } catch (e2) {
            r.nodestream = false;
          }
        }, {
          "readable-stream": 16
        }],
        31: [function(e, t, s) {
          "use strict";
          for (var o = e("./utils"), h = e("./support"), r = e("./nodejsUtils"), n = e("./stream/GenericWorker"), u = new Array(256), i = 0; i < 256; i++) u[i] = 252 <= i ? 6 : 248 <= i ? 5 : 240 <= i ? 4 : 224 <= i ? 3 : 192 <= i ? 2 : 1;
          u[254] = u[254] = 1;
          function a() {
            n.call(this, "utf-8 decode"), this.leftOver = null;
          }
          function l2() {
            n.call(this, "utf-8 encode");
          }
          s.utf8encode = function(e2) {
            return h.nodebuffer ? r.newBufferFrom(e2, "utf-8") : function(e3) {
              var t2, r2, n2, i2, s2, a2 = e3.length, o2 = 0;
              for (i2 = 0; i2 < a2; i2++) 55296 == (64512 & (r2 = e3.charCodeAt(i2))) && i2 + 1 < a2 && 56320 == (64512 & (n2 = e3.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), o2 += r2 < 128 ? 1 : r2 < 2048 ? 2 : r2 < 65536 ? 3 : 4;
              for (t2 = h.uint8array ? new Uint8Array(o2) : new Array(o2), i2 = s2 = 0; s2 < o2; i2++) 55296 == (64512 & (r2 = e3.charCodeAt(i2))) && i2 + 1 < a2 && 56320 == (64512 & (n2 = e3.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), r2 < 128 ? t2[s2++] = r2 : (r2 < 2048 ? t2[s2++] = 192 | r2 >>> 6 : (r2 < 65536 ? t2[s2++] = 224 | r2 >>> 12 : (t2[s2++] = 240 | r2 >>> 18, t2[s2++] = 128 | r2 >>> 12 & 63), t2[s2++] = 128 | r2 >>> 6 & 63), t2[s2++] = 128 | 63 & r2);
              return t2;
            }(e2);
          }, s.utf8decode = function(e2) {
            return h.nodebuffer ? o.transformTo("nodebuffer", e2).toString("utf-8") : function(e3) {
              var t2, r2, n2, i2, s2 = e3.length, a2 = new Array(2 * s2);
              for (t2 = r2 = 0; t2 < s2; ) if ((n2 = e3[t2++]) < 128) a2[r2++] = n2;
              else if (4 < (i2 = u[n2])) a2[r2++] = 65533, t2 += i2 - 1;
              else {
                for (n2 &= 2 === i2 ? 31 : 3 === i2 ? 15 : 7; 1 < i2 && t2 < s2; ) n2 = n2 << 6 | 63 & e3[t2++], i2--;
                1 < i2 ? a2[r2++] = 65533 : n2 < 65536 ? a2[r2++] = n2 : (n2 -= 65536, a2[r2++] = 55296 | n2 >> 10 & 1023, a2[r2++] = 56320 | 1023 & n2);
              }
              return a2.length !== r2 && (a2.subarray ? a2 = a2.subarray(0, r2) : a2.length = r2), o.applyFromCharCode(a2);
            }(e2 = o.transformTo(h.uint8array ? "uint8array" : "array", e2));
          }, o.inherits(a, n), a.prototype.processChunk = function(e2) {
            var t2 = o.transformTo(h.uint8array ? "uint8array" : "array", e2.data);
            if (this.leftOver && this.leftOver.length) {
              if (h.uint8array) {
                var r2 = t2;
                (t2 = new Uint8Array(r2.length + this.leftOver.length)).set(this.leftOver, 0), t2.set(r2, this.leftOver.length);
              } else t2 = this.leftOver.concat(t2);
              this.leftOver = null;
            }
            var n2 = function(e3, t3) {
              var r3;
              for ((t3 = t3 || e3.length) > e3.length && (t3 = e3.length), r3 = t3 - 1; 0 <= r3 && 128 == (192 & e3[r3]); ) r3--;
              return r3 < 0 ? t3 : 0 === r3 ? t3 : r3 + u[e3[r3]] > t3 ? r3 : t3;
            }(t2), i2 = t2;
            n2 !== t2.length && (h.uint8array ? (i2 = t2.subarray(0, n2), this.leftOver = t2.subarray(n2, t2.length)) : (i2 = t2.slice(0, n2), this.leftOver = t2.slice(n2, t2.length))), this.push({
              data: s.utf8decode(i2),
              meta: e2.meta
            });
          }, a.prototype.flush = function() {
            this.leftOver && this.leftOver.length && (this.push({
              data: s.utf8decode(this.leftOver),
              meta: {}
            }), this.leftOver = null);
          }, s.Utf8DecodeWorker = a, o.inherits(l2, n), l2.prototype.processChunk = function(e2) {
            this.push({
              data: s.utf8encode(e2.data),
              meta: e2.meta
            });
          }, s.Utf8EncodeWorker = l2;
        }, {
          "./nodejsUtils": 14,
          "./stream/GenericWorker": 28,
          "./support": 30,
          "./utils": 32
        }],
        32: [function(e, t, a) {
          "use strict";
          var o = e("./support"), h = e("./base64"), r = e("./nodejsUtils"), u = e("./external");
          function n(e2) {
            return e2;
          }
          function l2(e2, t2) {
            for (var r2 = 0; r2 < e2.length; ++r2) t2[r2] = 255 & e2.charCodeAt(r2);
            return t2;
          }
          e("setimmediate"), a.newBlob = function(t2, r2) {
            a.checkSupport("blob");
            try {
              return new Blob([t2], {
                type: r2
              });
            } catch (e2) {
              try {
                var n2 = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
                return n2.append(t2), n2.getBlob(r2);
              } catch (e3) {
                throw new Error("Bug : can't construct the Blob.");
              }
            }
          };
          var i = {
            stringifyByChunk: function(e2, t2, r2) {
              var n2 = [], i2 = 0, s2 = e2.length;
              if (s2 <= r2) return String.fromCharCode.apply(null, e2);
              for (; i2 < s2; ) "array" === t2 || "nodebuffer" === t2 ? n2.push(String.fromCharCode.apply(null, e2.slice(i2, Math.min(i2 + r2, s2)))) : n2.push(String.fromCharCode.apply(null, e2.subarray(i2, Math.min(i2 + r2, s2)))), i2 += r2;
              return n2.join("");
            },
            stringifyByChar: function(e2) {
              for (var t2 = "", r2 = 0; r2 < e2.length; r2++) t2 += String.fromCharCode(e2[r2]);
              return t2;
            },
            applyCanBeUsed: {
              uint8array: function() {
                try {
                  return o.uint8array && 1 === String.fromCharCode.apply(null, new Uint8Array(1)).length;
                } catch (e2) {
                  return false;
                }
              }(),
              nodebuffer: function() {
                try {
                  return o.nodebuffer && 1 === String.fromCharCode.apply(null, r.allocBuffer(1)).length;
                } catch (e2) {
                  return false;
                }
              }()
            }
          };
          function s(e2) {
            var t2 = 65536, r2 = a.getTypeOf(e2), n2 = true;
            if ("uint8array" === r2 ? n2 = i.applyCanBeUsed.uint8array : "nodebuffer" === r2 && (n2 = i.applyCanBeUsed.nodebuffer), n2) for (; 1 < t2; ) try {
              return i.stringifyByChunk(e2, r2, t2);
            } catch (e3) {
              t2 = Math.floor(t2 / 2);
            }
            return i.stringifyByChar(e2);
          }
          function f(e2, t2) {
            for (var r2 = 0; r2 < e2.length; r2++) t2[r2] = e2[r2];
            return t2;
          }
          a.applyFromCharCode = s;
          var c = {};
          c.string = {
            string: n,
            array: function(e2) {
              return l2(e2, new Array(e2.length));
            },
            arraybuffer: function(e2) {
              return c.string.uint8array(e2).buffer;
            },
            uint8array: function(e2) {
              return l2(e2, new Uint8Array(e2.length));
            },
            nodebuffer: function(e2) {
              return l2(e2, r.allocBuffer(e2.length));
            }
          }, c.array = {
            string: s,
            array: n,
            arraybuffer: function(e2) {
              return new Uint8Array(e2).buffer;
            },
            uint8array: function(e2) {
              return new Uint8Array(e2);
            },
            nodebuffer: function(e2) {
              return r.newBufferFrom(e2);
            }
          }, c.arraybuffer = {
            string: function(e2) {
              return s(new Uint8Array(e2));
            },
            array: function(e2) {
              return f(new Uint8Array(e2), new Array(e2.byteLength));
            },
            arraybuffer: n,
            uint8array: function(e2) {
              return new Uint8Array(e2);
            },
            nodebuffer: function(e2) {
              return r.newBufferFrom(new Uint8Array(e2));
            }
          }, c.uint8array = {
            string: s,
            array: function(e2) {
              return f(e2, new Array(e2.length));
            },
            arraybuffer: function(e2) {
              return e2.buffer;
            },
            uint8array: n,
            nodebuffer: function(e2) {
              return r.newBufferFrom(e2);
            }
          }, c.nodebuffer = {
            string: s,
            array: function(e2) {
              return f(e2, new Array(e2.length));
            },
            arraybuffer: function(e2) {
              return c.nodebuffer.uint8array(e2).buffer;
            },
            uint8array: function(e2) {
              return f(e2, new Uint8Array(e2.length));
            },
            nodebuffer: n
          }, a.transformTo = function(e2, t2) {
            if (t2 = t2 || "", !e2) return t2;
            a.checkSupport(e2);
            var r2 = a.getTypeOf(t2);
            return c[r2][e2](t2);
          }, a.resolve = function(e2) {
            for (var t2 = e2.split("/"), r2 = [], n2 = 0; n2 < t2.length; n2++) {
              var i2 = t2[n2];
              "." === i2 || "" === i2 && 0 !== n2 && n2 !== t2.length - 1 || (".." === i2 ? r2.pop() : r2.push(i2));
            }
            return r2.join("/");
          }, a.getTypeOf = function(e2) {
            return "string" == typeof e2 ? "string" : "[object Array]" === Object.prototype.toString.call(e2) ? "array" : o.nodebuffer && r.isBuffer(e2) ? "nodebuffer" : o.uint8array && e2 instanceof Uint8Array ? "uint8array" : o.arraybuffer && e2 instanceof ArrayBuffer ? "arraybuffer" : void 0;
          }, a.checkSupport = function(e2) {
            if (!o[e2.toLowerCase()]) throw new Error(e2 + " is not supported by this platform");
          }, a.MAX_VALUE_16BITS = 65535, a.MAX_VALUE_32BITS = -1, a.pretty = function(e2) {
            var t2, r2, n2 = "";
            for (r2 = 0; r2 < (e2 || "").length; r2++) n2 += "\\x" + ((t2 = e2.charCodeAt(r2)) < 16 ? "0" : "") + t2.toString(16).toUpperCase();
            return n2;
          }, a.delay = function(e2, t2, r2) {
            setImmediate(function() {
              e2.apply(r2 || null, t2 || []);
            });
          }, a.inherits = function(e2, t2) {
            function r2() {
            }
            r2.prototype = t2.prototype, e2.prototype = new r2();
          }, a.extend = function() {
            var e2, t2, r2 = {};
            for (e2 = 0; e2 < arguments.length; e2++) for (t2 in arguments[e2]) Object.prototype.hasOwnProperty.call(arguments[e2], t2) && void 0 === r2[t2] && (r2[t2] = arguments[e2][t2]);
            return r2;
          }, a.prepareContent = function(r2, e2, n2, i2, s2) {
            return u.Promise.resolve(e2).then(function(n3) {
              return o.blob && (n3 instanceof Blob || -1 !== ["[object File]", "[object Blob]"].indexOf(Object.prototype.toString.call(n3))) && "undefined" != typeof FileReader ? new u.Promise(function(t2, r3) {
                var e3 = new FileReader();
                e3.onload = function(e4) {
                  t2(e4.target.result);
                }, e3.onerror = function(e4) {
                  r3(e4.target.error);
                }, e3.readAsArrayBuffer(n3);
              }) : n3;
            }).then(function(e3) {
              var t2 = a.getTypeOf(e3);
              return t2 ? ("arraybuffer" === t2 ? e3 = a.transformTo("uint8array", e3) : "string" === t2 && (s2 ? e3 = h.decode(e3) : n2 && true !== i2 && (e3 = function(e4) {
                return l2(e4, o.uint8array ? new Uint8Array(e4.length) : new Array(e4.length));
              }(e3))), e3) : u.Promise.reject(new Error("Can't read the data of '" + r2 + "'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"));
            });
          };
        }, {
          "./base64": 1,
          "./external": 6,
          "./nodejsUtils": 14,
          "./support": 30,
          setimmediate: 54
        }],
        33: [function(e, t, r) {
          "use strict";
          var n = e("./reader/readerFor"), i = e("./utils"), s = e("./signature"), a = e("./zipEntry"), o = e("./support");
          function h(e2) {
            this.files = [], this.loadOptions = e2;
          }
          h.prototype = {
            checkSignature: function(e2) {
              if (!this.reader.readAndCheckSignature(e2)) {
                this.reader.index -= 4;
                var t2 = this.reader.readString(4);
                throw new Error("Corrupted zip or bug: unexpected signature (" + i.pretty(t2) + ", expected " + i.pretty(e2) + ")");
              }
            },
            isSignature: function(e2, t2) {
              var r2 = this.reader.index;
              this.reader.setIndex(e2);
              var n2 = this.reader.readString(4) === t2;
              return this.reader.setIndex(r2), n2;
            },
            readBlockEndOfCentral: function() {
              this.diskNumber = this.reader.readInt(2), this.diskWithCentralDirStart = this.reader.readInt(2), this.centralDirRecordsOnThisDisk = this.reader.readInt(2), this.centralDirRecords = this.reader.readInt(2), this.centralDirSize = this.reader.readInt(4), this.centralDirOffset = this.reader.readInt(4), this.zipCommentLength = this.reader.readInt(2);
              var e2 = this.reader.readData(this.zipCommentLength), t2 = o.uint8array ? "uint8array" : "array", r2 = i.transformTo(t2, e2);
              this.zipComment = this.loadOptions.decodeFileName(r2);
            },
            readBlockZip64EndOfCentral: function() {
              this.zip64EndOfCentralSize = this.reader.readInt(8), this.reader.skip(4), this.diskNumber = this.reader.readInt(4), this.diskWithCentralDirStart = this.reader.readInt(4), this.centralDirRecordsOnThisDisk = this.reader.readInt(8), this.centralDirRecords = this.reader.readInt(8), this.centralDirSize = this.reader.readInt(8), this.centralDirOffset = this.reader.readInt(8), this.zip64ExtensibleData = {};
              for (var e2, t2, r2, n2 = this.zip64EndOfCentralSize - 44; 0 < n2; ) e2 = this.reader.readInt(2), t2 = this.reader.readInt(4), r2 = this.reader.readData(t2), this.zip64ExtensibleData[e2] = {
                id: e2,
                length: t2,
                value: r2
              };
            },
            readBlockZip64EndOfCentralLocator: function() {
              if (this.diskWithZip64CentralDirStart = this.reader.readInt(4), this.relativeOffsetEndOfZip64CentralDir = this.reader.readInt(8), this.disksCount = this.reader.readInt(4), 1 < this.disksCount) throw new Error("Multi-volumes zip are not supported");
            },
            readLocalFiles: function() {
              var e2, t2;
              for (e2 = 0; e2 < this.files.length; e2++) t2 = this.files[e2], this.reader.setIndex(t2.localHeaderOffset), this.checkSignature(s.LOCAL_FILE_HEADER), t2.readLocalPart(this.reader), t2.handleUTF8(), t2.processAttributes();
            },
            readCentralDir: function() {
              var e2;
              for (this.reader.setIndex(this.centralDirOffset); this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER); ) (e2 = new a({
                zip64: this.zip64
              }, this.loadOptions)).readCentralPart(this.reader), this.files.push(e2);
              if (this.centralDirRecords !== this.files.length && 0 !== this.centralDirRecords && 0 === this.files.length) throw new Error("Corrupted zip or bug: expected " + this.centralDirRecords + " records in central dir, got " + this.files.length);
            },
            readEndOfCentral: function() {
              var e2 = this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);
              if (e2 < 0) throw !this.isSignature(0, s.LOCAL_FILE_HEADER) ? new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html") : new Error("Corrupted zip: can't find end of central directory");
              this.reader.setIndex(e2);
              var t2 = e2;
              if (this.checkSignature(s.CENTRAL_DIRECTORY_END), this.readBlockEndOfCentral(), this.diskNumber === i.MAX_VALUE_16BITS || this.diskWithCentralDirStart === i.MAX_VALUE_16BITS || this.centralDirRecordsOnThisDisk === i.MAX_VALUE_16BITS || this.centralDirRecords === i.MAX_VALUE_16BITS || this.centralDirSize === i.MAX_VALUE_32BITS || this.centralDirOffset === i.MAX_VALUE_32BITS) {
                if (this.zip64 = true, (e2 = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR)) < 0) throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");
                if (this.reader.setIndex(e2), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR), this.readBlockZip64EndOfCentralLocator(), !this.isSignature(this.relativeOffsetEndOfZip64CentralDir, s.ZIP64_CENTRAL_DIRECTORY_END) && (this.relativeOffsetEndOfZip64CentralDir = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.relativeOffsetEndOfZip64CentralDir < 0)) throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");
                this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.readBlockZip64EndOfCentral();
              }
              var r2 = this.centralDirOffset + this.centralDirSize;
              this.zip64 && (r2 += 20, r2 += 12 + this.zip64EndOfCentralSize);
              var n2 = t2 - r2;
              if (0 < n2) this.isSignature(t2, s.CENTRAL_FILE_HEADER) || (this.reader.zero = n2);
              else if (n2 < 0) throw new Error("Corrupted zip: missing " + Math.abs(n2) + " bytes.");
            },
            prepareReader: function(e2) {
              this.reader = n(e2);
            },
            load: function(e2) {
              this.prepareReader(e2), this.readEndOfCentral(), this.readCentralDir(), this.readLocalFiles();
            }
          }, t.exports = h;
        }, {
          "./reader/readerFor": 22,
          "./signature": 23,
          "./support": 30,
          "./utils": 32,
          "./zipEntry": 34
        }],
        34: [function(e, t, r) {
          "use strict";
          var n = e("./reader/readerFor"), s = e("./utils"), i = e("./compressedObject"), a = e("./crc32"), o = e("./utf8"), h = e("./compressions"), u = e("./support");
          function l2(e2, t2) {
            this.options = e2, this.loadOptions = t2;
          }
          l2.prototype = {
            isEncrypted: function() {
              return 1 == (1 & this.bitFlag);
            },
            useUTF8: function() {
              return 2048 == (2048 & this.bitFlag);
            },
            readLocalPart: function(e2) {
              var t2, r2;
              if (e2.skip(22), this.fileNameLength = e2.readInt(2), r2 = e2.readInt(2), this.fileName = e2.readData(this.fileNameLength), e2.skip(r2), -1 === this.compressedSize || -1 === this.uncompressedSize) throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");
              if (null === (t2 = function(e3) {
                for (var t3 in h) if (Object.prototype.hasOwnProperty.call(h, t3) && h[t3].magic === e3) return h[t3];
                return null;
              }(this.compressionMethod))) throw new Error("Corrupted zip : compression " + s.pretty(this.compressionMethod) + " unknown (inner file : " + s.transformTo("string", this.fileName) + ")");
              this.decompressed = new i(this.compressedSize, this.uncompressedSize, this.crc32, t2, e2.readData(this.compressedSize));
            },
            readCentralPart: function(e2) {
              this.versionMadeBy = e2.readInt(2), e2.skip(2), this.bitFlag = e2.readInt(2), this.compressionMethod = e2.readString(2), this.date = e2.readDate(), this.crc32 = e2.readInt(4), this.compressedSize = e2.readInt(4), this.uncompressedSize = e2.readInt(4);
              var t2 = e2.readInt(2);
              if (this.extraFieldsLength = e2.readInt(2), this.fileCommentLength = e2.readInt(2), this.diskNumberStart = e2.readInt(2), this.internalFileAttributes = e2.readInt(2), this.externalFileAttributes = e2.readInt(4), this.localHeaderOffset = e2.readInt(4), this.isEncrypted()) throw new Error("Encrypted zip are not supported");
              e2.skip(t2), this.readExtraFields(e2), this.parseZIP64ExtraField(e2), this.fileComment = e2.readData(this.fileCommentLength);
            },
            processAttributes: function() {
              this.unixPermissions = null, this.dosPermissions = null;
              var e2 = this.versionMadeBy >> 8;
              this.dir = !!(16 & this.externalFileAttributes), 0 == e2 && (this.dosPermissions = 63 & this.externalFileAttributes), 3 == e2 && (this.unixPermissions = this.externalFileAttributes >> 16 & 65535), this.dir || "/" !== this.fileNameStr.slice(-1) || (this.dir = true);
            },
            parseZIP64ExtraField: function() {
              if (this.extraFields[1]) {
                var e2 = n(this.extraFields[1].value);
                this.uncompressedSize === s.MAX_VALUE_32BITS && (this.uncompressedSize = e2.readInt(8)), this.compressedSize === s.MAX_VALUE_32BITS && (this.compressedSize = e2.readInt(8)), this.localHeaderOffset === s.MAX_VALUE_32BITS && (this.localHeaderOffset = e2.readInt(8)), this.diskNumberStart === s.MAX_VALUE_32BITS && (this.diskNumberStart = e2.readInt(4));
              }
            },
            readExtraFields: function(e2) {
              var t2, r2, n2, i2 = e2.index + this.extraFieldsLength;
              for (this.extraFields || (this.extraFields = {}); e2.index + 4 < i2; ) t2 = e2.readInt(2), r2 = e2.readInt(2), n2 = e2.readData(r2), this.extraFields[t2] = {
                id: t2,
                length: r2,
                value: n2
              };
              e2.setIndex(i2);
            },
            handleUTF8: function() {
              var e2 = u.uint8array ? "uint8array" : "array";
              if (this.useUTF8()) this.fileNameStr = o.utf8decode(this.fileName), this.fileCommentStr = o.utf8decode(this.fileComment);
              else {
                var t2 = this.findExtraFieldUnicodePath();
                if (null !== t2) this.fileNameStr = t2;
                else {
                  var r2 = s.transformTo(e2, this.fileName);
                  this.fileNameStr = this.loadOptions.decodeFileName(r2);
                }
                var n2 = this.findExtraFieldUnicodeComment();
                if (null !== n2) this.fileCommentStr = n2;
                else {
                  var i2 = s.transformTo(e2, this.fileComment);
                  this.fileCommentStr = this.loadOptions.decodeFileName(i2);
                }
              }
            },
            findExtraFieldUnicodePath: function() {
              var e2 = this.extraFields[28789];
              if (e2) {
                var t2 = n(e2.value);
                return 1 !== t2.readInt(1) ? null : a(this.fileName) !== t2.readInt(4) ? null : o.utf8decode(t2.readData(e2.length - 5));
              }
              return null;
            },
            findExtraFieldUnicodeComment: function() {
              var e2 = this.extraFields[25461];
              if (e2) {
                var t2 = n(e2.value);
                return 1 !== t2.readInt(1) ? null : a(this.fileComment) !== t2.readInt(4) ? null : o.utf8decode(t2.readData(e2.length - 5));
              }
              return null;
            }
          }, t.exports = l2;
        }, {
          "./compressedObject": 2,
          "./compressions": 3,
          "./crc32": 4,
          "./reader/readerFor": 22,
          "./support": 30,
          "./utf8": 31,
          "./utils": 32
        }],
        35: [function(e, t, r) {
          "use strict";
          function n(e2, t2, r2) {
            this.name = e2, this.dir = r2.dir, this.date = r2.date, this.comment = r2.comment, this.unixPermissions = r2.unixPermissions, this.dosPermissions = r2.dosPermissions, this._data = t2, this._dataBinary = r2.binary, this.options = {
              compression: r2.compression,
              compressionOptions: r2.compressionOptions
            };
          }
          var s = e("./stream/StreamHelper"), i = e("./stream/DataWorker"), a = e("./utf8"), o = e("./compressedObject"), h = e("./stream/GenericWorker");
          n.prototype = {
            internalStream: function(e2) {
              var t2 = null, r2 = "string";
              try {
                if (!e2) throw new Error("No output type specified.");
                var n2 = "string" === (r2 = e2.toLowerCase()) || "text" === r2;
                "binarystring" !== r2 && "text" !== r2 || (r2 = "string"), t2 = this._decompressWorker();
                var i2 = !this._dataBinary;
                i2 && !n2 && (t2 = t2.pipe(new a.Utf8EncodeWorker())), !i2 && n2 && (t2 = t2.pipe(new a.Utf8DecodeWorker()));
              } catch (e3) {
                (t2 = new h("error")).error(e3);
              }
              return new s(t2, r2, "");
            },
            async: function(e2, t2) {
              return this.internalStream(e2).accumulate(t2);
            },
            nodeStream: function(e2, t2) {
              return this.internalStream(e2 || "nodebuffer").toNodejsStream(t2);
            },
            _compressWorker: function(e2, t2) {
              if (this._data instanceof o && this._data.compression.magic === e2.magic) return this._data.getCompressedWorker();
              var r2 = this._decompressWorker();
              return this._dataBinary || (r2 = r2.pipe(new a.Utf8EncodeWorker())), o.createWorkerFrom(r2, e2, t2);
            },
            _decompressWorker: function() {
              return this._data instanceof o ? this._data.getContentWorker() : this._data instanceof h ? this._data : new i(this._data);
            }
          };
          for (var u = ["asText", "asBinary", "asNodeBuffer", "asUint8Array", "asArrayBuffer"], l2 = function() {
            throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
          }, f = 0; f < u.length; f++) n.prototype[u[f]] = l2;
          t.exports = n;
        }, {
          "./compressedObject": 2,
          "./stream/DataWorker": 27,
          "./stream/GenericWorker": 28,
          "./stream/StreamHelper": 29,
          "./utf8": 31
        }],
        36: [function(e, l2, t) {
          (function(t2) {
            "use strict";
            var r, n, e2 = t2.MutationObserver || t2.WebKitMutationObserver;
            if (e2) {
              var i = 0, s = new e2(u), a = t2.document.createTextNode("");
              s.observe(a, {
                characterData: true
              }), r = function() {
                a.data = i = ++i % 2;
              };
            } else if (t2.setImmediate || void 0 === t2.MessageChannel) r = "document" in t2 && "onreadystatechange" in t2.document.createElement("script") ? function() {
              var e3 = t2.document.createElement("script");
              e3.onreadystatechange = function() {
                u(), e3.onreadystatechange = null, e3.parentNode.removeChild(e3), e3 = null;
              }, t2.document.documentElement.appendChild(e3);
            } : function() {
              setTimeout(u, 0);
            };
            else {
              var o = new t2.MessageChannel();
              o.port1.onmessage = u, r = function() {
                o.port2.postMessage(0);
              };
            }
            var h = [];
            function u() {
              var e3, t3;
              n = true;
              for (var r2 = h.length; r2; ) {
                for (t3 = h, h = [], e3 = -1; ++e3 < r2; ) t3[e3]();
                r2 = h.length;
              }
              n = false;
            }
            l2.exports = function(e3) {
              1 !== h.push(e3) || n || r();
            };
          }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
        }, {}],
        37: [function(e, t, r) {
          "use strict";
          var i = e("immediate");
          function u() {
          }
          var l2 = {}, s = ["REJECTED"], a = ["FULFILLED"], n = ["PENDING"];
          function o(e2) {
            if ("function" != typeof e2) throw new TypeError("resolver must be a function");
            this.state = n, this.queue = [], this.outcome = void 0, e2 !== u && d(this, e2);
          }
          function h(e2, t2, r2) {
            this.promise = e2, "function" == typeof t2 && (this.onFulfilled = t2, this.callFulfilled = this.otherCallFulfilled), "function" == typeof r2 && (this.onRejected = r2, this.callRejected = this.otherCallRejected);
          }
          function f(t2, r2, n2) {
            i(function() {
              var e2;
              try {
                e2 = r2(n2);
              } catch (e3) {
                return l2.reject(t2, e3);
              }
              e2 === t2 ? l2.reject(t2, new TypeError("Cannot resolve promise with itself")) : l2.resolve(t2, e2);
            });
          }
          function c(e2) {
            var t2 = e2 && e2.then;
            if (e2 && ("object" == typeof e2 || "function" == typeof e2) && "function" == typeof t2) return function() {
              t2.apply(e2, arguments);
            };
          }
          function d(t2, e2) {
            var r2 = false;
            function n2(e3) {
              r2 || (r2 = true, l2.reject(t2, e3));
            }
            function i2(e3) {
              r2 || (r2 = true, l2.resolve(t2, e3));
            }
            var s2 = p(function() {
              e2(i2, n2);
            });
            "error" === s2.status && n2(s2.value);
          }
          function p(e2, t2) {
            var r2 = {};
            try {
              r2.value = e2(t2), r2.status = "success";
            } catch (e3) {
              r2.status = "error", r2.value = e3;
            }
            return r2;
          }
          (t.exports = o).prototype.finally = function(t2) {
            if ("function" != typeof t2) return this;
            var r2 = this.constructor;
            return this.then(function(e2) {
              return r2.resolve(t2()).then(function() {
                return e2;
              });
            }, function(e2) {
              return r2.resolve(t2()).then(function() {
                throw e2;
              });
            });
          }, o.prototype.catch = function(e2) {
            return this.then(null, e2);
          }, o.prototype.then = function(e2, t2) {
            if ("function" != typeof e2 && this.state === a || "function" != typeof t2 && this.state === s) return this;
            var r2 = new this.constructor(u);
            this.state !== n ? f(r2, this.state === a ? e2 : t2, this.outcome) : this.queue.push(new h(r2, e2, t2));
            return r2;
          }, h.prototype.callFulfilled = function(e2) {
            l2.resolve(this.promise, e2);
          }, h.prototype.otherCallFulfilled = function(e2) {
            f(this.promise, this.onFulfilled, e2);
          }, h.prototype.callRejected = function(e2) {
            l2.reject(this.promise, e2);
          }, h.prototype.otherCallRejected = function(e2) {
            f(this.promise, this.onRejected, e2);
          }, l2.resolve = function(e2, t2) {
            var r2 = p(c, t2);
            if ("error" === r2.status) return l2.reject(e2, r2.value);
            var n2 = r2.value;
            if (n2) d(e2, n2);
            else {
              e2.state = a, e2.outcome = t2;
              for (var i2 = -1, s2 = e2.queue.length; ++i2 < s2; ) e2.queue[i2].callFulfilled(t2);
            }
            return e2;
          }, l2.reject = function(e2, t2) {
            e2.state = s, e2.outcome = t2;
            for (var r2 = -1, n2 = e2.queue.length; ++r2 < n2; ) e2.queue[r2].callRejected(t2);
            return e2;
          }, o.resolve = function(e2) {
            if (e2 instanceof this) return e2;
            return l2.resolve(new this(u), e2);
          }, o.reject = function(e2) {
            var t2 = new this(u);
            return l2.reject(t2, e2);
          }, o.all = function(e2) {
            var r2 = this;
            if ("[object Array]" !== Object.prototype.toString.call(e2)) return this.reject(new TypeError("must be an array"));
            var n2 = e2.length, i2 = false;
            if (!n2) return this.resolve([]);
            var s2 = new Array(n2), a2 = 0, t2 = -1, o2 = new this(u);
            for (; ++t2 < n2; ) h2(e2[t2], t2);
            return o2;
            function h2(e3, t3) {
              r2.resolve(e3).then(function(e4) {
                s2[t3] = e4, ++a2 !== n2 || i2 || (i2 = true, l2.resolve(o2, s2));
              }, function(e4) {
                i2 || (i2 = true, l2.reject(o2, e4));
              });
            }
          }, o.race = function(e2) {
            var t2 = this;
            if ("[object Array]" !== Object.prototype.toString.call(e2)) return this.reject(new TypeError("must be an array"));
            var r2 = e2.length, n2 = false;
            if (!r2) return this.resolve([]);
            var i2 = -1, s2 = new this(u);
            for (; ++i2 < r2; ) a2 = e2[i2], t2.resolve(a2).then(function(e3) {
              n2 || (n2 = true, l2.resolve(s2, e3));
            }, function(e3) {
              n2 || (n2 = true, l2.reject(s2, e3));
            });
            var a2;
            return s2;
          };
        }, {
          immediate: 36
        }],
        38: [function(e, t, r) {
          "use strict";
          var n = {};
          (0, e("./lib/utils/common").assign)(n, e("./lib/deflate"), e("./lib/inflate"), e("./lib/zlib/constants")), t.exports = n;
        }, {
          "./lib/deflate": 39,
          "./lib/inflate": 40,
          "./lib/utils/common": 41,
          "./lib/zlib/constants": 44
        }],
        39: [function(e, t, r) {
          "use strict";
          var a = e("./zlib/deflate"), o = e("./utils/common"), h = e("./utils/strings"), i = e("./zlib/messages"), s = e("./zlib/zstream"), u = Object.prototype.toString, l2 = 0, f = -1, c = 0, d = 8;
          function p(e2) {
            if (!(this instanceof p)) return new p(e2);
            this.options = o.assign({
              level: f,
              method: d,
              chunkSize: 16384,
              windowBits: 15,
              memLevel: 8,
              strategy: c,
              to: ""
            }, e2 || {});
            var t2 = this.options;
            t2.raw && 0 < t2.windowBits ? t2.windowBits = -t2.windowBits : t2.gzip && 0 < t2.windowBits && t2.windowBits < 16 && (t2.windowBits += 16), this.err = 0, this.msg = "", this.ended = false, this.chunks = [], this.strm = new s(), this.strm.avail_out = 0;
            var r2 = a.deflateInit2(this.strm, t2.level, t2.method, t2.windowBits, t2.memLevel, t2.strategy);
            if (r2 !== l2) throw new Error(i[r2]);
            if (t2.header && a.deflateSetHeader(this.strm, t2.header), t2.dictionary) {
              var n2;
              if (n2 = "string" == typeof t2.dictionary ? h.string2buf(t2.dictionary) : "[object ArrayBuffer]" === u.call(t2.dictionary) ? new Uint8Array(t2.dictionary) : t2.dictionary, (r2 = a.deflateSetDictionary(this.strm, n2)) !== l2) throw new Error(i[r2]);
              this._dict_set = true;
            }
          }
          function n(e2, t2) {
            var r2 = new p(t2);
            if (r2.push(e2, true), r2.err) throw r2.msg || i[r2.err];
            return r2.result;
          }
          p.prototype.push = function(e2, t2) {
            var r2, n2, i2 = this.strm, s2 = this.options.chunkSize;
            if (this.ended) return false;
            n2 = t2 === ~~t2 ? t2 : true === t2 ? 4 : 0, "string" == typeof e2 ? i2.input = h.string2buf(e2) : "[object ArrayBuffer]" === u.call(e2) ? i2.input = new Uint8Array(e2) : i2.input = e2, i2.next_in = 0, i2.avail_in = i2.input.length;
            do {
              if (0 === i2.avail_out && (i2.output = new o.Buf8(s2), i2.next_out = 0, i2.avail_out = s2), 1 !== (r2 = a.deflate(i2, n2)) && r2 !== l2) return this.onEnd(r2), !(this.ended = true);
              0 !== i2.avail_out && (0 !== i2.avail_in || 4 !== n2 && 2 !== n2) || ("string" === this.options.to ? this.onData(h.buf2binstring(o.shrinkBuf(i2.output, i2.next_out))) : this.onData(o.shrinkBuf(i2.output, i2.next_out)));
            } while ((0 < i2.avail_in || 0 === i2.avail_out) && 1 !== r2);
            return 4 === n2 ? (r2 = a.deflateEnd(this.strm), this.onEnd(r2), this.ended = true, r2 === l2) : 2 !== n2 || (this.onEnd(l2), !(i2.avail_out = 0));
          }, p.prototype.onData = function(e2) {
            this.chunks.push(e2);
          }, p.prototype.onEnd = function(e2) {
            e2 === l2 && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = o.flattenChunks(this.chunks)), this.chunks = [], this.err = e2, this.msg = this.strm.msg;
          }, r.Deflate = p, r.deflate = n, r.deflateRaw = function(e2, t2) {
            return (t2 = t2 || {}).raw = true, n(e2, t2);
          }, r.gzip = function(e2, t2) {
            return (t2 = t2 || {}).gzip = true, n(e2, t2);
          };
        }, {
          "./utils/common": 41,
          "./utils/strings": 42,
          "./zlib/deflate": 46,
          "./zlib/messages": 51,
          "./zlib/zstream": 53
        }],
        40: [function(e, t, r) {
          "use strict";
          var c = e("./zlib/inflate"), d = e("./utils/common"), p = e("./utils/strings"), m = e("./zlib/constants"), n = e("./zlib/messages"), i = e("./zlib/zstream"), s = e("./zlib/gzheader"), _3 = Object.prototype.toString;
          function a(e2) {
            if (!(this instanceof a)) return new a(e2);
            this.options = d.assign({
              chunkSize: 16384,
              windowBits: 0,
              to: ""
            }, e2 || {});
            var t2 = this.options;
            t2.raw && 0 <= t2.windowBits && t2.windowBits < 16 && (t2.windowBits = -t2.windowBits, 0 === t2.windowBits && (t2.windowBits = -15)), !(0 <= t2.windowBits && t2.windowBits < 16) || e2 && e2.windowBits || (t2.windowBits += 32), 15 < t2.windowBits && t2.windowBits < 48 && 0 == (15 & t2.windowBits) && (t2.windowBits |= 15), this.err = 0, this.msg = "", this.ended = false, this.chunks = [], this.strm = new i(), this.strm.avail_out = 0;
            var r2 = c.inflateInit2(this.strm, t2.windowBits);
            if (r2 !== m.Z_OK) throw new Error(n[r2]);
            this.header = new s(), c.inflateGetHeader(this.strm, this.header);
          }
          function o(e2, t2) {
            var r2 = new a(t2);
            if (r2.push(e2, true), r2.err) throw r2.msg || n[r2.err];
            return r2.result;
          }
          a.prototype.push = function(e2, t2) {
            var r2, n2, i2, s2, a2, o2, h = this.strm, u = this.options.chunkSize, l2 = this.options.dictionary, f = false;
            if (this.ended) return false;
            n2 = t2 === ~~t2 ? t2 : true === t2 ? m.Z_FINISH : m.Z_NO_FLUSH, "string" == typeof e2 ? h.input = p.binstring2buf(e2) : "[object ArrayBuffer]" === _3.call(e2) ? h.input = new Uint8Array(e2) : h.input = e2, h.next_in = 0, h.avail_in = h.input.length;
            do {
              if (0 === h.avail_out && (h.output = new d.Buf8(u), h.next_out = 0, h.avail_out = u), (r2 = c.inflate(h, m.Z_NO_FLUSH)) === m.Z_NEED_DICT && l2 && (o2 = "string" == typeof l2 ? p.string2buf(l2) : "[object ArrayBuffer]" === _3.call(l2) ? new Uint8Array(l2) : l2, r2 = c.inflateSetDictionary(this.strm, o2)), r2 === m.Z_BUF_ERROR && true === f && (r2 = m.Z_OK, f = false), r2 !== m.Z_STREAM_END && r2 !== m.Z_OK) return this.onEnd(r2), !(this.ended = true);
              h.next_out && (0 !== h.avail_out && r2 !== m.Z_STREAM_END && (0 !== h.avail_in || n2 !== m.Z_FINISH && n2 !== m.Z_SYNC_FLUSH) || ("string" === this.options.to ? (i2 = p.utf8border(h.output, h.next_out), s2 = h.next_out - i2, a2 = p.buf2string(h.output, i2), h.next_out = s2, h.avail_out = u - s2, s2 && d.arraySet(h.output, h.output, i2, s2, 0), this.onData(a2)) : this.onData(d.shrinkBuf(h.output, h.next_out)))), 0 === h.avail_in && 0 === h.avail_out && (f = true);
            } while ((0 < h.avail_in || 0 === h.avail_out) && r2 !== m.Z_STREAM_END);
            return r2 === m.Z_STREAM_END && (n2 = m.Z_FINISH), n2 === m.Z_FINISH ? (r2 = c.inflateEnd(this.strm), this.onEnd(r2), this.ended = true, r2 === m.Z_OK) : n2 !== m.Z_SYNC_FLUSH || (this.onEnd(m.Z_OK), !(h.avail_out = 0));
          }, a.prototype.onData = function(e2) {
            this.chunks.push(e2);
          }, a.prototype.onEnd = function(e2) {
            e2 === m.Z_OK && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = d.flattenChunks(this.chunks)), this.chunks = [], this.err = e2, this.msg = this.strm.msg;
          }, r.Inflate = a, r.inflate = o, r.inflateRaw = function(e2, t2) {
            return (t2 = t2 || {}).raw = true, o(e2, t2);
          }, r.ungzip = o;
        }, {
          "./utils/common": 41,
          "./utils/strings": 42,
          "./zlib/constants": 44,
          "./zlib/gzheader": 47,
          "./zlib/inflate": 49,
          "./zlib/messages": 51,
          "./zlib/zstream": 53
        }],
        41: [function(e, t, r) {
          "use strict";
          var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Int32Array;
          r.assign = function(e2) {
            for (var t2 = Array.prototype.slice.call(arguments, 1); t2.length; ) {
              var r2 = t2.shift();
              if (r2) {
                if ("object" != typeof r2) throw new TypeError(r2 + "must be non-object");
                for (var n2 in r2) r2.hasOwnProperty(n2) && (e2[n2] = r2[n2]);
              }
            }
            return e2;
          }, r.shrinkBuf = function(e2, t2) {
            return e2.length === t2 ? e2 : e2.subarray ? e2.subarray(0, t2) : (e2.length = t2, e2);
          };
          var i = {
            arraySet: function(e2, t2, r2, n2, i2) {
              if (t2.subarray && e2.subarray) e2.set(t2.subarray(r2, r2 + n2), i2);
              else for (var s2 = 0; s2 < n2; s2++) e2[i2 + s2] = t2[r2 + s2];
            },
            flattenChunks: function(e2) {
              var t2, r2, n2, i2, s2, a;
              for (t2 = n2 = 0, r2 = e2.length; t2 < r2; t2++) n2 += e2[t2].length;
              for (a = new Uint8Array(n2), t2 = i2 = 0, r2 = e2.length; t2 < r2; t2++) s2 = e2[t2], a.set(s2, i2), i2 += s2.length;
              return a;
            }
          }, s = {
            arraySet: function(e2, t2, r2, n2, i2) {
              for (var s2 = 0; s2 < n2; s2++) e2[i2 + s2] = t2[r2 + s2];
            },
            flattenChunks: function(e2) {
              return [].concat.apply([], e2);
            }
          };
          r.setTyped = function(e2) {
            e2 ? (r.Buf8 = Uint8Array, r.Buf16 = Uint16Array, r.Buf32 = Int32Array, r.assign(r, i)) : (r.Buf8 = Array, r.Buf16 = Array, r.Buf32 = Array, r.assign(r, s));
          }, r.setTyped(n);
        }, {}],
        42: [function(e, t, r) {
          "use strict";
          var h = e("./common"), i = true, s = true;
          try {
            String.fromCharCode.apply(null, [0]);
          } catch (e2) {
            i = false;
          }
          try {
            String.fromCharCode.apply(null, new Uint8Array(1));
          } catch (e2) {
            s = false;
          }
          for (var u = new h.Buf8(256), n = 0; n < 256; n++) u[n] = 252 <= n ? 6 : 248 <= n ? 5 : 240 <= n ? 4 : 224 <= n ? 3 : 192 <= n ? 2 : 1;
          function l2(e2, t2) {
            if (t2 < 65537 && (e2.subarray && s || !e2.subarray && i)) return String.fromCharCode.apply(null, h.shrinkBuf(e2, t2));
            for (var r2 = "", n2 = 0; n2 < t2; n2++) r2 += String.fromCharCode(e2[n2]);
            return r2;
          }
          u[254] = u[254] = 1, r.string2buf = function(e2) {
            var t2, r2, n2, i2, s2, a = e2.length, o = 0;
            for (i2 = 0; i2 < a; i2++) 55296 == (64512 & (r2 = e2.charCodeAt(i2))) && i2 + 1 < a && 56320 == (64512 & (n2 = e2.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), o += r2 < 128 ? 1 : r2 < 2048 ? 2 : r2 < 65536 ? 3 : 4;
            for (t2 = new h.Buf8(o), i2 = s2 = 0; s2 < o; i2++) 55296 == (64512 & (r2 = e2.charCodeAt(i2))) && i2 + 1 < a && 56320 == (64512 & (n2 = e2.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), r2 < 128 ? t2[s2++] = r2 : (r2 < 2048 ? t2[s2++] = 192 | r2 >>> 6 : (r2 < 65536 ? t2[s2++] = 224 | r2 >>> 12 : (t2[s2++] = 240 | r2 >>> 18, t2[s2++] = 128 | r2 >>> 12 & 63), t2[s2++] = 128 | r2 >>> 6 & 63), t2[s2++] = 128 | 63 & r2);
            return t2;
          }, r.buf2binstring = function(e2) {
            return l2(e2, e2.length);
          }, r.binstring2buf = function(e2) {
            for (var t2 = new h.Buf8(e2.length), r2 = 0, n2 = t2.length; r2 < n2; r2++) t2[r2] = e2.charCodeAt(r2);
            return t2;
          }, r.buf2string = function(e2, t2) {
            var r2, n2, i2, s2, a = t2 || e2.length, o = new Array(2 * a);
            for (r2 = n2 = 0; r2 < a; ) if ((i2 = e2[r2++]) < 128) o[n2++] = i2;
            else if (4 < (s2 = u[i2])) o[n2++] = 65533, r2 += s2 - 1;
            else {
              for (i2 &= 2 === s2 ? 31 : 3 === s2 ? 15 : 7; 1 < s2 && r2 < a; ) i2 = i2 << 6 | 63 & e2[r2++], s2--;
              1 < s2 ? o[n2++] = 65533 : i2 < 65536 ? o[n2++] = i2 : (i2 -= 65536, o[n2++] = 55296 | i2 >> 10 & 1023, o[n2++] = 56320 | 1023 & i2);
            }
            return l2(o, n2);
          }, r.utf8border = function(e2, t2) {
            var r2;
            for ((t2 = t2 || e2.length) > e2.length && (t2 = e2.length), r2 = t2 - 1; 0 <= r2 && 128 == (192 & e2[r2]); ) r2--;
            return r2 < 0 ? t2 : 0 === r2 ? t2 : r2 + u[e2[r2]] > t2 ? r2 : t2;
          };
        }, {
          "./common": 41
        }],
        43: [function(e, t, r) {
          "use strict";
          t.exports = function(e2, t2, r2, n) {
            for (var i = 65535 & e2 | 0, s = e2 >>> 16 & 65535 | 0, a = 0; 0 !== r2; ) {
              for (r2 -= a = 2e3 < r2 ? 2e3 : r2; s = s + (i = i + t2[n++] | 0) | 0, --a; ) ;
              i %= 65521, s %= 65521;
            }
            return i | s << 16 | 0;
          };
        }, {}],
        44: [function(e, t, r) {
          "use strict";
          t.exports = {
            Z_NO_FLUSH: 0,
            Z_PARTIAL_FLUSH: 1,
            Z_SYNC_FLUSH: 2,
            Z_FULL_FLUSH: 3,
            Z_FINISH: 4,
            Z_BLOCK: 5,
            Z_TREES: 6,
            Z_OK: 0,
            Z_STREAM_END: 1,
            Z_NEED_DICT: 2,
            Z_ERRNO: -1,
            Z_STREAM_ERROR: -2,
            Z_DATA_ERROR: -3,
            Z_BUF_ERROR: -5,
            Z_NO_COMPRESSION: 0,
            Z_BEST_SPEED: 1,
            Z_BEST_COMPRESSION: 9,
            Z_DEFAULT_COMPRESSION: -1,
            Z_FILTERED: 1,
            Z_HUFFMAN_ONLY: 2,
            Z_RLE: 3,
            Z_FIXED: 4,
            Z_DEFAULT_STRATEGY: 0,
            Z_BINARY: 0,
            Z_TEXT: 1,
            Z_UNKNOWN: 2,
            Z_DEFLATED: 8
          };
        }, {}],
        45: [function(e, t, r) {
          "use strict";
          var o = function() {
            for (var e2, t2 = [], r2 = 0; r2 < 256; r2++) {
              e2 = r2;
              for (var n = 0; n < 8; n++) e2 = 1 & e2 ? 3988292384 ^ e2 >>> 1 : e2 >>> 1;
              t2[r2] = e2;
            }
            return t2;
          }();
          t.exports = function(e2, t2, r2, n) {
            var i = o, s = n + r2;
            e2 ^= -1;
            for (var a = n; a < s; a++) e2 = e2 >>> 8 ^ i[255 & (e2 ^ t2[a])];
            return -1 ^ e2;
          };
        }, {}],
        46: [function(e, t, r) {
          "use strict";
          var h, c = e("../utils/common"), u = e("./trees"), d = e("./adler32"), p = e("./crc32"), n = e("./messages"), l2 = 0, f = 4, m = 0, _3 = -2, g = -1, b = 4, i = 2, v = 8, y = 9, s = 286, a = 30, o = 19, w = 2 * s + 1, k = 15, x = 3, S = 258, z = S + x + 1, C = 42, E = 113, A = 1, I = 2, O = 3, B = 4;
          function R(e2, t2) {
            return e2.msg = n[t2], t2;
          }
          function T(e2) {
            return (e2 << 1) - (4 < e2 ? 9 : 0);
          }
          function D(e2) {
            for (var t2 = e2.length; 0 <= --t2; ) e2[t2] = 0;
          }
          function F(e2) {
            var t2 = e2.state, r2 = t2.pending;
            r2 > e2.avail_out && (r2 = e2.avail_out), 0 !== r2 && (c.arraySet(e2.output, t2.pending_buf, t2.pending_out, r2, e2.next_out), e2.next_out += r2, t2.pending_out += r2, e2.total_out += r2, e2.avail_out -= r2, t2.pending -= r2, 0 === t2.pending && (t2.pending_out = 0));
          }
          function N(e2, t2) {
            u._tr_flush_block(e2, 0 <= e2.block_start ? e2.block_start : -1, e2.strstart - e2.block_start, t2), e2.block_start = e2.strstart, F(e2.strm);
          }
          function U(e2, t2) {
            e2.pending_buf[e2.pending++] = t2;
          }
          function P(e2, t2) {
            e2.pending_buf[e2.pending++] = t2 >>> 8 & 255, e2.pending_buf[e2.pending++] = 255 & t2;
          }
          function L(e2, t2) {
            var r2, n2, i2 = e2.max_chain_length, s2 = e2.strstart, a2 = e2.prev_length, o2 = e2.nice_match, h2 = e2.strstart > e2.w_size - z ? e2.strstart - (e2.w_size - z) : 0, u2 = e2.window, l3 = e2.w_mask, f2 = e2.prev, c2 = e2.strstart + S, d2 = u2[s2 + a2 - 1], p2 = u2[s2 + a2];
            e2.prev_length >= e2.good_match && (i2 >>= 2), o2 > e2.lookahead && (o2 = e2.lookahead);
            do {
              if (u2[(r2 = t2) + a2] === p2 && u2[r2 + a2 - 1] === d2 && u2[r2] === u2[s2] && u2[++r2] === u2[s2 + 1]) {
                s2 += 2, r2++;
                do {
                } while (u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && s2 < c2);
                if (n2 = S - (c2 - s2), s2 = c2 - S, a2 < n2) {
                  if (e2.match_start = t2, o2 <= (a2 = n2)) break;
                  d2 = u2[s2 + a2 - 1], p2 = u2[s2 + a2];
                }
              }
            } while ((t2 = f2[t2 & l3]) > h2 && 0 != --i2);
            return a2 <= e2.lookahead ? a2 : e2.lookahead;
          }
          function j(e2) {
            var t2, r2, n2, i2, s2, a2, o2, h2, u2, l3, f2 = e2.w_size;
            do {
              if (i2 = e2.window_size - e2.lookahead - e2.strstart, e2.strstart >= f2 + (f2 - z)) {
                for (c.arraySet(e2.window, e2.window, f2, f2, 0), e2.match_start -= f2, e2.strstart -= f2, e2.block_start -= f2, t2 = r2 = e2.hash_size; n2 = e2.head[--t2], e2.head[t2] = f2 <= n2 ? n2 - f2 : 0, --r2; ) ;
                for (t2 = r2 = f2; n2 = e2.prev[--t2], e2.prev[t2] = f2 <= n2 ? n2 - f2 : 0, --r2; ) ;
                i2 += f2;
              }
              if (0 === e2.strm.avail_in) break;
              if (a2 = e2.strm, o2 = e2.window, h2 = e2.strstart + e2.lookahead, u2 = i2, l3 = void 0, l3 = a2.avail_in, u2 < l3 && (l3 = u2), r2 = 0 === l3 ? 0 : (a2.avail_in -= l3, c.arraySet(o2, a2.input, a2.next_in, l3, h2), 1 === a2.state.wrap ? a2.adler = d(a2.adler, o2, l3, h2) : 2 === a2.state.wrap && (a2.adler = p(a2.adler, o2, l3, h2)), a2.next_in += l3, a2.total_in += l3, l3), e2.lookahead += r2, e2.lookahead + e2.insert >= x) for (s2 = e2.strstart - e2.insert, e2.ins_h = e2.window[s2], e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[s2 + 1]) & e2.hash_mask; e2.insert && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[s2 + x - 1]) & e2.hash_mask, e2.prev[s2 & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = s2, s2++, e2.insert--, !(e2.lookahead + e2.insert < x)); ) ;
            } while (e2.lookahead < z && 0 !== e2.strm.avail_in);
          }
          function Z(e2, t2) {
            for (var r2, n2; ; ) {
              if (e2.lookahead < z) {
                if (j(e2), e2.lookahead < z && t2 === l2) return A;
                if (0 === e2.lookahead) break;
              }
              if (r2 = 0, e2.lookahead >= x && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart), 0 !== r2 && e2.strstart - r2 <= e2.w_size - z && (e2.match_length = L(e2, r2)), e2.match_length >= x) {
                if (n2 = u._tr_tally(e2, e2.strstart - e2.match_start, e2.match_length - x), e2.lookahead -= e2.match_length, e2.match_length <= e2.max_lazy_match && e2.lookahead >= x) {
                  for (e2.match_length--; e2.strstart++, e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart, 0 != --e2.match_length; ) ;
                  e2.strstart++;
                } else e2.strstart += e2.match_length, e2.match_length = 0, e2.ins_h = e2.window[e2.strstart], e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + 1]) & e2.hash_mask;
              } else n2 = u._tr_tally(e2, 0, e2.window[e2.strstart]), e2.lookahead--, e2.strstart++;
              if (n2 && (N(e2, false), 0 === e2.strm.avail_out)) return A;
            }
            return e2.insert = e2.strstart < x - 1 ? e2.strstart : x - 1, t2 === f ? (N(e2, true), 0 === e2.strm.avail_out ? O : B) : e2.last_lit && (N(e2, false), 0 === e2.strm.avail_out) ? A : I;
          }
          function W(e2, t2) {
            for (var r2, n2, i2; ; ) {
              if (e2.lookahead < z) {
                if (j(e2), e2.lookahead < z && t2 === l2) return A;
                if (0 === e2.lookahead) break;
              }
              if (r2 = 0, e2.lookahead >= x && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart), e2.prev_length = e2.match_length, e2.prev_match = e2.match_start, e2.match_length = x - 1, 0 !== r2 && e2.prev_length < e2.max_lazy_match && e2.strstart - r2 <= e2.w_size - z && (e2.match_length = L(e2, r2), e2.match_length <= 5 && (1 === e2.strategy || e2.match_length === x && 4096 < e2.strstart - e2.match_start) && (e2.match_length = x - 1)), e2.prev_length >= x && e2.match_length <= e2.prev_length) {
                for (i2 = e2.strstart + e2.lookahead - x, n2 = u._tr_tally(e2, e2.strstart - 1 - e2.prev_match, e2.prev_length - x), e2.lookahead -= e2.prev_length - 1, e2.prev_length -= 2; ++e2.strstart <= i2 && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart), 0 != --e2.prev_length; ) ;
                if (e2.match_available = 0, e2.match_length = x - 1, e2.strstart++, n2 && (N(e2, false), 0 === e2.strm.avail_out)) return A;
              } else if (e2.match_available) {
                if ((n2 = u._tr_tally(e2, 0, e2.window[e2.strstart - 1])) && N(e2, false), e2.strstart++, e2.lookahead--, 0 === e2.strm.avail_out) return A;
              } else e2.match_available = 1, e2.strstart++, e2.lookahead--;
            }
            return e2.match_available && (n2 = u._tr_tally(e2, 0, e2.window[e2.strstart - 1]), e2.match_available = 0), e2.insert = e2.strstart < x - 1 ? e2.strstart : x - 1, t2 === f ? (N(e2, true), 0 === e2.strm.avail_out ? O : B) : e2.last_lit && (N(e2, false), 0 === e2.strm.avail_out) ? A : I;
          }
          function M(e2, t2, r2, n2, i2) {
            this.good_length = e2, this.max_lazy = t2, this.nice_length = r2, this.max_chain = n2, this.func = i2;
          }
          function H() {
            this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = v, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new c.Buf16(2 * w), this.dyn_dtree = new c.Buf16(2 * (2 * a + 1)), this.bl_tree = new c.Buf16(2 * (2 * o + 1)), D(this.dyn_ltree), D(this.dyn_dtree), D(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new c.Buf16(k + 1), this.heap = new c.Buf16(2 * s + 1), D(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new c.Buf16(2 * s + 1), D(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
          }
          function G(e2) {
            var t2;
            return e2 && e2.state ? (e2.total_in = e2.total_out = 0, e2.data_type = i, (t2 = e2.state).pending = 0, t2.pending_out = 0, t2.wrap < 0 && (t2.wrap = -t2.wrap), t2.status = t2.wrap ? C : E, e2.adler = 2 === t2.wrap ? 0 : 1, t2.last_flush = l2, u._tr_init(t2), m) : R(e2, _3);
          }
          function K(e2) {
            var t2 = G(e2);
            return t2 === m && function(e3) {
              e3.window_size = 2 * e3.w_size, D(e3.head), e3.max_lazy_match = h[e3.level].max_lazy, e3.good_match = h[e3.level].good_length, e3.nice_match = h[e3.level].nice_length, e3.max_chain_length = h[e3.level].max_chain, e3.strstart = 0, e3.block_start = 0, e3.lookahead = 0, e3.insert = 0, e3.match_length = e3.prev_length = x - 1, e3.match_available = 0, e3.ins_h = 0;
            }(e2.state), t2;
          }
          function Y(e2, t2, r2, n2, i2, s2) {
            if (!e2) return _3;
            var a2 = 1;
            if (t2 === g && (t2 = 6), n2 < 0 ? (a2 = 0, n2 = -n2) : 15 < n2 && (a2 = 2, n2 -= 16), i2 < 1 || y < i2 || r2 !== v || n2 < 8 || 15 < n2 || t2 < 0 || 9 < t2 || s2 < 0 || b < s2) return R(e2, _3);
            8 === n2 && (n2 = 9);
            var o2 = new H();
            return (e2.state = o2).strm = e2, o2.wrap = a2, o2.gzhead = null, o2.w_bits = n2, o2.w_size = 1 << o2.w_bits, o2.w_mask = o2.w_size - 1, o2.hash_bits = i2 + 7, o2.hash_size = 1 << o2.hash_bits, o2.hash_mask = o2.hash_size - 1, o2.hash_shift = ~~((o2.hash_bits + x - 1) / x), o2.window = new c.Buf8(2 * o2.w_size), o2.head = new c.Buf16(o2.hash_size), o2.prev = new c.Buf16(o2.w_size), o2.lit_bufsize = 1 << i2 + 6, o2.pending_buf_size = 4 * o2.lit_bufsize, o2.pending_buf = new c.Buf8(o2.pending_buf_size), o2.d_buf = 1 * o2.lit_bufsize, o2.l_buf = 3 * o2.lit_bufsize, o2.level = t2, o2.strategy = s2, o2.method = r2, K(e2);
          }
          h = [new M(0, 0, 0, 0, function(e2, t2) {
            var r2 = 65535;
            for (r2 > e2.pending_buf_size - 5 && (r2 = e2.pending_buf_size - 5); ; ) {
              if (e2.lookahead <= 1) {
                if (j(e2), 0 === e2.lookahead && t2 === l2) return A;
                if (0 === e2.lookahead) break;
              }
              e2.strstart += e2.lookahead, e2.lookahead = 0;
              var n2 = e2.block_start + r2;
              if ((0 === e2.strstart || e2.strstart >= n2) && (e2.lookahead = e2.strstart - n2, e2.strstart = n2, N(e2, false), 0 === e2.strm.avail_out)) return A;
              if (e2.strstart - e2.block_start >= e2.w_size - z && (N(e2, false), 0 === e2.strm.avail_out)) return A;
            }
            return e2.insert = 0, t2 === f ? (N(e2, true), 0 === e2.strm.avail_out ? O : B) : (e2.strstart > e2.block_start && (N(e2, false), e2.strm.avail_out), A);
          }), new M(4, 4, 8, 4, Z), new M(4, 5, 16, 8, Z), new M(4, 6, 32, 32, Z), new M(4, 4, 16, 16, W), new M(8, 16, 32, 32, W), new M(8, 16, 128, 128, W), new M(8, 32, 128, 256, W), new M(32, 128, 258, 1024, W), new M(32, 258, 258, 4096, W)], r.deflateInit = function(e2, t2) {
            return Y(e2, t2, v, 15, 8, 0);
          }, r.deflateInit2 = Y, r.deflateReset = K, r.deflateResetKeep = G, r.deflateSetHeader = function(e2, t2) {
            return e2 && e2.state ? 2 !== e2.state.wrap ? _3 : (e2.state.gzhead = t2, m) : _3;
          }, r.deflate = function(e2, t2) {
            var r2, n2, i2, s2;
            if (!e2 || !e2.state || 5 < t2 || t2 < 0) return e2 ? R(e2, _3) : _3;
            if (n2 = e2.state, !e2.output || !e2.input && 0 !== e2.avail_in || 666 === n2.status && t2 !== f) return R(e2, 0 === e2.avail_out ? -5 : _3);
            if (n2.strm = e2, r2 = n2.last_flush, n2.last_flush = t2, n2.status === C) if (2 === n2.wrap) e2.adler = 0, U(n2, 31), U(n2, 139), U(n2, 8), n2.gzhead ? (U(n2, (n2.gzhead.text ? 1 : 0) + (n2.gzhead.hcrc ? 2 : 0) + (n2.gzhead.extra ? 4 : 0) + (n2.gzhead.name ? 8 : 0) + (n2.gzhead.comment ? 16 : 0)), U(n2, 255 & n2.gzhead.time), U(n2, n2.gzhead.time >> 8 & 255), U(n2, n2.gzhead.time >> 16 & 255), U(n2, n2.gzhead.time >> 24 & 255), U(n2, 9 === n2.level ? 2 : 2 <= n2.strategy || n2.level < 2 ? 4 : 0), U(n2, 255 & n2.gzhead.os), n2.gzhead.extra && n2.gzhead.extra.length && (U(n2, 255 & n2.gzhead.extra.length), U(n2, n2.gzhead.extra.length >> 8 & 255)), n2.gzhead.hcrc && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending, 0)), n2.gzindex = 0, n2.status = 69) : (U(n2, 0), U(n2, 0), U(n2, 0), U(n2, 0), U(n2, 0), U(n2, 9 === n2.level ? 2 : 2 <= n2.strategy || n2.level < 2 ? 4 : 0), U(n2, 3), n2.status = E);
            else {
              var a2 = v + (n2.w_bits - 8 << 4) << 8;
              a2 |= (2 <= n2.strategy || n2.level < 2 ? 0 : n2.level < 6 ? 1 : 6 === n2.level ? 2 : 3) << 6, 0 !== n2.strstart && (a2 |= 32), a2 += 31 - a2 % 31, n2.status = E, P(n2, a2), 0 !== n2.strstart && (P(n2, e2.adler >>> 16), P(n2, 65535 & e2.adler)), e2.adler = 1;
            }
            if (69 === n2.status) if (n2.gzhead.extra) {
              for (i2 = n2.pending; n2.gzindex < (65535 & n2.gzhead.extra.length) && (n2.pending !== n2.pending_buf_size || (n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), F(e2), i2 = n2.pending, n2.pending !== n2.pending_buf_size)); ) U(n2, 255 & n2.gzhead.extra[n2.gzindex]), n2.gzindex++;
              n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), n2.gzindex === n2.gzhead.extra.length && (n2.gzindex = 0, n2.status = 73);
            } else n2.status = 73;
            if (73 === n2.status) if (n2.gzhead.name) {
              i2 = n2.pending;
              do {
                if (n2.pending === n2.pending_buf_size && (n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), F(e2), i2 = n2.pending, n2.pending === n2.pending_buf_size)) {
                  s2 = 1;
                  break;
                }
                s2 = n2.gzindex < n2.gzhead.name.length ? 255 & n2.gzhead.name.charCodeAt(n2.gzindex++) : 0, U(n2, s2);
              } while (0 !== s2);
              n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), 0 === s2 && (n2.gzindex = 0, n2.status = 91);
            } else n2.status = 91;
            if (91 === n2.status) if (n2.gzhead.comment) {
              i2 = n2.pending;
              do {
                if (n2.pending === n2.pending_buf_size && (n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), F(e2), i2 = n2.pending, n2.pending === n2.pending_buf_size)) {
                  s2 = 1;
                  break;
                }
                s2 = n2.gzindex < n2.gzhead.comment.length ? 255 & n2.gzhead.comment.charCodeAt(n2.gzindex++) : 0, U(n2, s2);
              } while (0 !== s2);
              n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), 0 === s2 && (n2.status = 103);
            } else n2.status = 103;
            if (103 === n2.status && (n2.gzhead.hcrc ? (n2.pending + 2 > n2.pending_buf_size && F(e2), n2.pending + 2 <= n2.pending_buf_size && (U(n2, 255 & e2.adler), U(n2, e2.adler >> 8 & 255), e2.adler = 0, n2.status = E)) : n2.status = E), 0 !== n2.pending) {
              if (F(e2), 0 === e2.avail_out) return n2.last_flush = -1, m;
            } else if (0 === e2.avail_in && T(t2) <= T(r2) && t2 !== f) return R(e2, -5);
            if (666 === n2.status && 0 !== e2.avail_in) return R(e2, -5);
            if (0 !== e2.avail_in || 0 !== n2.lookahead || t2 !== l2 && 666 !== n2.status) {
              var o2 = 2 === n2.strategy ? function(e3, t3) {
                for (var r3; ; ) {
                  if (0 === e3.lookahead && (j(e3), 0 === e3.lookahead)) {
                    if (t3 === l2) return A;
                    break;
                  }
                  if (e3.match_length = 0, r3 = u._tr_tally(e3, 0, e3.window[e3.strstart]), e3.lookahead--, e3.strstart++, r3 && (N(e3, false), 0 === e3.strm.avail_out)) return A;
                }
                return e3.insert = 0, t3 === f ? (N(e3, true), 0 === e3.strm.avail_out ? O : B) : e3.last_lit && (N(e3, false), 0 === e3.strm.avail_out) ? A : I;
              }(n2, t2) : 3 === n2.strategy ? function(e3, t3) {
                for (var r3, n3, i3, s3, a3 = e3.window; ; ) {
                  if (e3.lookahead <= S) {
                    if (j(e3), e3.lookahead <= S && t3 === l2) return A;
                    if (0 === e3.lookahead) break;
                  }
                  if (e3.match_length = 0, e3.lookahead >= x && 0 < e3.strstart && (n3 = a3[i3 = e3.strstart - 1]) === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3]) {
                    s3 = e3.strstart + S;
                    do {
                    } while (n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && i3 < s3);
                    e3.match_length = S - (s3 - i3), e3.match_length > e3.lookahead && (e3.match_length = e3.lookahead);
                  }
                  if (e3.match_length >= x ? (r3 = u._tr_tally(e3, 1, e3.match_length - x), e3.lookahead -= e3.match_length, e3.strstart += e3.match_length, e3.match_length = 0) : (r3 = u._tr_tally(e3, 0, e3.window[e3.strstart]), e3.lookahead--, e3.strstart++), r3 && (N(e3, false), 0 === e3.strm.avail_out)) return A;
                }
                return e3.insert = 0, t3 === f ? (N(e3, true), 0 === e3.strm.avail_out ? O : B) : e3.last_lit && (N(e3, false), 0 === e3.strm.avail_out) ? A : I;
              }(n2, t2) : h[n2.level].func(n2, t2);
              if (o2 !== O && o2 !== B || (n2.status = 666), o2 === A || o2 === O) return 0 === e2.avail_out && (n2.last_flush = -1), m;
              if (o2 === I && (1 === t2 ? u._tr_align(n2) : 5 !== t2 && (u._tr_stored_block(n2, 0, 0, false), 3 === t2 && (D(n2.head), 0 === n2.lookahead && (n2.strstart = 0, n2.block_start = 0, n2.insert = 0))), F(e2), 0 === e2.avail_out)) return n2.last_flush = -1, m;
            }
            return t2 !== f ? m : n2.wrap <= 0 ? 1 : (2 === n2.wrap ? (U(n2, 255 & e2.adler), U(n2, e2.adler >> 8 & 255), U(n2, e2.adler >> 16 & 255), U(n2, e2.adler >> 24 & 255), U(n2, 255 & e2.total_in), U(n2, e2.total_in >> 8 & 255), U(n2, e2.total_in >> 16 & 255), U(n2, e2.total_in >> 24 & 255)) : (P(n2, e2.adler >>> 16), P(n2, 65535 & e2.adler)), F(e2), 0 < n2.wrap && (n2.wrap = -n2.wrap), 0 !== n2.pending ? m : 1);
          }, r.deflateEnd = function(e2) {
            var t2;
            return e2 && e2.state ? (t2 = e2.state.status) !== C && 69 !== t2 && 73 !== t2 && 91 !== t2 && 103 !== t2 && t2 !== E && 666 !== t2 ? R(e2, _3) : (e2.state = null, t2 === E ? R(e2, -3) : m) : _3;
          }, r.deflateSetDictionary = function(e2, t2) {
            var r2, n2, i2, s2, a2, o2, h2, u2, l3 = t2.length;
            if (!e2 || !e2.state) return _3;
            if (2 === (s2 = (r2 = e2.state).wrap) || 1 === s2 && r2.status !== C || r2.lookahead) return _3;
            for (1 === s2 && (e2.adler = d(e2.adler, t2, l3, 0)), r2.wrap = 0, l3 >= r2.w_size && (0 === s2 && (D(r2.head), r2.strstart = 0, r2.block_start = 0, r2.insert = 0), u2 = new c.Buf8(r2.w_size), c.arraySet(u2, t2, l3 - r2.w_size, r2.w_size, 0), t2 = u2, l3 = r2.w_size), a2 = e2.avail_in, o2 = e2.next_in, h2 = e2.input, e2.avail_in = l3, e2.next_in = 0, e2.input = t2, j(r2); r2.lookahead >= x; ) {
              for (n2 = r2.strstart, i2 = r2.lookahead - (x - 1); r2.ins_h = (r2.ins_h << r2.hash_shift ^ r2.window[n2 + x - 1]) & r2.hash_mask, r2.prev[n2 & r2.w_mask] = r2.head[r2.ins_h], r2.head[r2.ins_h] = n2, n2++, --i2; ) ;
              r2.strstart = n2, r2.lookahead = x - 1, j(r2);
            }
            return r2.strstart += r2.lookahead, r2.block_start = r2.strstart, r2.insert = r2.lookahead, r2.lookahead = 0, r2.match_length = r2.prev_length = x - 1, r2.match_available = 0, e2.next_in = o2, e2.input = h2, e2.avail_in = a2, r2.wrap = s2, m;
          }, r.deflateInfo = "pako deflate (from Nodeca project)";
        }, {
          "../utils/common": 41,
          "./adler32": 43,
          "./crc32": 45,
          "./messages": 51,
          "./trees": 52
        }],
        47: [function(e, t, r) {
          "use strict";
          t.exports = function() {
            this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = false;
          };
        }, {}],
        48: [function(e, t, r) {
          "use strict";
          t.exports = function(e2, t2) {
            var r2, n, i, s, a, o, h, u, l2, f, c, d, p, m, _3, g, b, v, y, w, k, x, S, z, C;
            r2 = e2.state, n = e2.next_in, z = e2.input, i = n + (e2.avail_in - 5), s = e2.next_out, C = e2.output, a = s - (t2 - e2.avail_out), o = s + (e2.avail_out - 257), h = r2.dmax, u = r2.wsize, l2 = r2.whave, f = r2.wnext, c = r2.window, d = r2.hold, p = r2.bits, m = r2.lencode, _3 = r2.distcode, g = (1 << r2.lenbits) - 1, b = (1 << r2.distbits) - 1;
            e: do {
              p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = m[d & g];
              t: for (; ; ) {
                if (d >>>= y = v >>> 24, p -= y, 0 === (y = v >>> 16 & 255)) C[s++] = 65535 & v;
                else {
                  if (!(16 & y)) {
                    if (0 == (64 & y)) {
                      v = m[(65535 & v) + (d & (1 << y) - 1)];
                      continue t;
                    }
                    if (32 & y) {
                      r2.mode = 12;
                      break e;
                    }
                    e2.msg = "invalid literal/length code", r2.mode = 30;
                    break e;
                  }
                  w = 65535 & v, (y &= 15) && (p < y && (d += z[n++] << p, p += 8), w += d & (1 << y) - 1, d >>>= y, p -= y), p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = _3[d & b];
                  r: for (; ; ) {
                    if (d >>>= y = v >>> 24, p -= y, !(16 & (y = v >>> 16 & 255))) {
                      if (0 == (64 & y)) {
                        v = _3[(65535 & v) + (d & (1 << y) - 1)];
                        continue r;
                      }
                      e2.msg = "invalid distance code", r2.mode = 30;
                      break e;
                    }
                    if (k = 65535 & v, p < (y &= 15) && (d += z[n++] << p, (p += 8) < y && (d += z[n++] << p, p += 8)), h < (k += d & (1 << y) - 1)) {
                      e2.msg = "invalid distance too far back", r2.mode = 30;
                      break e;
                    }
                    if (d >>>= y, p -= y, (y = s - a) < k) {
                      if (l2 < (y = k - y) && r2.sane) {
                        e2.msg = "invalid distance too far back", r2.mode = 30;
                        break e;
                      }
                      if (S = c, (x = 0) === f) {
                        if (x += u - y, y < w) {
                          for (w -= y; C[s++] = c[x++], --y; ) ;
                          x = s - k, S = C;
                        }
                      } else if (f < y) {
                        if (x += u + f - y, (y -= f) < w) {
                          for (w -= y; C[s++] = c[x++], --y; ) ;
                          if (x = 0, f < w) {
                            for (w -= y = f; C[s++] = c[x++], --y; ) ;
                            x = s - k, S = C;
                          }
                        }
                      } else if (x += f - y, y < w) {
                        for (w -= y; C[s++] = c[x++], --y; ) ;
                        x = s - k, S = C;
                      }
                      for (; 2 < w; ) C[s++] = S[x++], C[s++] = S[x++], C[s++] = S[x++], w -= 3;
                      w && (C[s++] = S[x++], 1 < w && (C[s++] = S[x++]));
                    } else {
                      for (x = s - k; C[s++] = C[x++], C[s++] = C[x++], C[s++] = C[x++], 2 < (w -= 3); ) ;
                      w && (C[s++] = C[x++], 1 < w && (C[s++] = C[x++]));
                    }
                    break;
                  }
                }
                break;
              }
            } while (n < i && s < o);
            n -= w = p >> 3, d &= (1 << (p -= w << 3)) - 1, e2.next_in = n, e2.next_out = s, e2.avail_in = n < i ? i - n + 5 : 5 - (n - i), e2.avail_out = s < o ? o - s + 257 : 257 - (s - o), r2.hold = d, r2.bits = p;
          };
        }, {}],
        49: [function(e, t, r) {
          "use strict";
          var I = e("../utils/common"), O = e("./adler32"), B = e("./crc32"), R = e("./inffast"), T = e("./inftrees"), D = 1, F = 2, N = 0, U = -2, P = 1, n = 852, i = 592;
          function L(e2) {
            return (e2 >>> 24 & 255) + (e2 >>> 8 & 65280) + ((65280 & e2) << 8) + ((255 & e2) << 24);
          }
          function s() {
            this.mode = 0, this.last = false, this.wrap = 0, this.havedict = false, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new I.Buf16(320), this.work = new I.Buf16(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
          }
          function a(e2) {
            var t2;
            return e2 && e2.state ? (t2 = e2.state, e2.total_in = e2.total_out = t2.total = 0, e2.msg = "", t2.wrap && (e2.adler = 1 & t2.wrap), t2.mode = P, t2.last = 0, t2.havedict = 0, t2.dmax = 32768, t2.head = null, t2.hold = 0, t2.bits = 0, t2.lencode = t2.lendyn = new I.Buf32(n), t2.distcode = t2.distdyn = new I.Buf32(i), t2.sane = 1, t2.back = -1, N) : U;
          }
          function o(e2) {
            var t2;
            return e2 && e2.state ? ((t2 = e2.state).wsize = 0, t2.whave = 0, t2.wnext = 0, a(e2)) : U;
          }
          function h(e2, t2) {
            var r2, n2;
            return e2 && e2.state ? (n2 = e2.state, t2 < 0 ? (r2 = 0, t2 = -t2) : (r2 = 1 + (t2 >> 4), t2 < 48 && (t2 &= 15)), t2 && (t2 < 8 || 15 < t2) ? U : (null !== n2.window && n2.wbits !== t2 && (n2.window = null), n2.wrap = r2, n2.wbits = t2, o(e2))) : U;
          }
          function u(e2, t2) {
            var r2, n2;
            return e2 ? (n2 = new s(), (e2.state = n2).window = null, (r2 = h(e2, t2)) !== N && (e2.state = null), r2) : U;
          }
          var l2, f, c = true;
          function j(e2) {
            if (c) {
              var t2;
              for (l2 = new I.Buf32(512), f = new I.Buf32(32), t2 = 0; t2 < 144; ) e2.lens[t2++] = 8;
              for (; t2 < 256; ) e2.lens[t2++] = 9;
              for (; t2 < 280; ) e2.lens[t2++] = 7;
              for (; t2 < 288; ) e2.lens[t2++] = 8;
              for (T(D, e2.lens, 0, 288, l2, 0, e2.work, {
                bits: 9
              }), t2 = 0; t2 < 32; ) e2.lens[t2++] = 5;
              T(F, e2.lens, 0, 32, f, 0, e2.work, {
                bits: 5
              }), c = false;
            }
            e2.lencode = l2, e2.lenbits = 9, e2.distcode = f, e2.distbits = 5;
          }
          function Z(e2, t2, r2, n2) {
            var i2, s2 = e2.state;
            return null === s2.window && (s2.wsize = 1 << s2.wbits, s2.wnext = 0, s2.whave = 0, s2.window = new I.Buf8(s2.wsize)), n2 >= s2.wsize ? (I.arraySet(s2.window, t2, r2 - s2.wsize, s2.wsize, 0), s2.wnext = 0, s2.whave = s2.wsize) : (n2 < (i2 = s2.wsize - s2.wnext) && (i2 = n2), I.arraySet(s2.window, t2, r2 - n2, i2, s2.wnext), (n2 -= i2) ? (I.arraySet(s2.window, t2, r2 - n2, n2, 0), s2.wnext = n2, s2.whave = s2.wsize) : (s2.wnext += i2, s2.wnext === s2.wsize && (s2.wnext = 0), s2.whave < s2.wsize && (s2.whave += i2))), 0;
          }
          r.inflateReset = o, r.inflateReset2 = h, r.inflateResetKeep = a, r.inflateInit = function(e2) {
            return u(e2, 15);
          }, r.inflateInit2 = u, r.inflate = function(e2, t2) {
            var r2, n2, i2, s2, a2, o2, h2, u2, l3, f2, c2, d, p, m, _3, g, b, v, y, w, k, x, S, z, C = 0, E = new I.Buf8(4), A = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
            if (!e2 || !e2.state || !e2.output || !e2.input && 0 !== e2.avail_in) return U;
            12 === (r2 = e2.state).mode && (r2.mode = 13), a2 = e2.next_out, i2 = e2.output, h2 = e2.avail_out, s2 = e2.next_in, n2 = e2.input, o2 = e2.avail_in, u2 = r2.hold, l3 = r2.bits, f2 = o2, c2 = h2, x = N;
            e: for (; ; ) switch (r2.mode) {
              case P:
                if (0 === r2.wrap) {
                  r2.mode = 13;
                  break;
                }
                for (; l3 < 16; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                if (2 & r2.wrap && 35615 === u2) {
                  E[r2.check = 0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0), l3 = u2 = 0, r2.mode = 2;
                  break;
                }
                if (r2.flags = 0, r2.head && (r2.head.done = false), !(1 & r2.wrap) || (((255 & u2) << 8) + (u2 >> 8)) % 31) {
                  e2.msg = "incorrect header check", r2.mode = 30;
                  break;
                }
                if (8 != (15 & u2)) {
                  e2.msg = "unknown compression method", r2.mode = 30;
                  break;
                }
                if (l3 -= 4, k = 8 + (15 & (u2 >>>= 4)), 0 === r2.wbits) r2.wbits = k;
                else if (k > r2.wbits) {
                  e2.msg = "invalid window size", r2.mode = 30;
                  break;
                }
                r2.dmax = 1 << k, e2.adler = r2.check = 1, r2.mode = 512 & u2 ? 10 : 12, l3 = u2 = 0;
                break;
              case 2:
                for (; l3 < 16; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                if (r2.flags = u2, 8 != (255 & r2.flags)) {
                  e2.msg = "unknown compression method", r2.mode = 30;
                  break;
                }
                if (57344 & r2.flags) {
                  e2.msg = "unknown header flags set", r2.mode = 30;
                  break;
                }
                r2.head && (r2.head.text = u2 >> 8 & 1), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0)), l3 = u2 = 0, r2.mode = 3;
              case 3:
                for (; l3 < 32; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                r2.head && (r2.head.time = u2), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, E[2] = u2 >>> 16 & 255, E[3] = u2 >>> 24 & 255, r2.check = B(r2.check, E, 4, 0)), l3 = u2 = 0, r2.mode = 4;
              case 4:
                for (; l3 < 16; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                r2.head && (r2.head.xflags = 255 & u2, r2.head.os = u2 >> 8), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0)), l3 = u2 = 0, r2.mode = 5;
              case 5:
                if (1024 & r2.flags) {
                  for (; l3 < 16; ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  r2.length = u2, r2.head && (r2.head.extra_len = u2), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0)), l3 = u2 = 0;
                } else r2.head && (r2.head.extra = null);
                r2.mode = 6;
              case 6:
                if (1024 & r2.flags && (o2 < (d = r2.length) && (d = o2), d && (r2.head && (k = r2.head.extra_len - r2.length, r2.head.extra || (r2.head.extra = new Array(r2.head.extra_len)), I.arraySet(r2.head.extra, n2, s2, d, k)), 512 & r2.flags && (r2.check = B(r2.check, n2, d, s2)), o2 -= d, s2 += d, r2.length -= d), r2.length)) break e;
                r2.length = 0, r2.mode = 7;
              case 7:
                if (2048 & r2.flags) {
                  if (0 === o2) break e;
                  for (d = 0; k = n2[s2 + d++], r2.head && k && r2.length < 65536 && (r2.head.name += String.fromCharCode(k)), k && d < o2; ) ;
                  if (512 & r2.flags && (r2.check = B(r2.check, n2, d, s2)), o2 -= d, s2 += d, k) break e;
                } else r2.head && (r2.head.name = null);
                r2.length = 0, r2.mode = 8;
              case 8:
                if (4096 & r2.flags) {
                  if (0 === o2) break e;
                  for (d = 0; k = n2[s2 + d++], r2.head && k && r2.length < 65536 && (r2.head.comment += String.fromCharCode(k)), k && d < o2; ) ;
                  if (512 & r2.flags && (r2.check = B(r2.check, n2, d, s2)), o2 -= d, s2 += d, k) break e;
                } else r2.head && (r2.head.comment = null);
                r2.mode = 9;
              case 9:
                if (512 & r2.flags) {
                  for (; l3 < 16; ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  if (u2 !== (65535 & r2.check)) {
                    e2.msg = "header crc mismatch", r2.mode = 30;
                    break;
                  }
                  l3 = u2 = 0;
                }
                r2.head && (r2.head.hcrc = r2.flags >> 9 & 1, r2.head.done = true), e2.adler = r2.check = 0, r2.mode = 12;
                break;
              case 10:
                for (; l3 < 32; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                e2.adler = r2.check = L(u2), l3 = u2 = 0, r2.mode = 11;
              case 11:
                if (0 === r2.havedict) return e2.next_out = a2, e2.avail_out = h2, e2.next_in = s2, e2.avail_in = o2, r2.hold = u2, r2.bits = l3, 2;
                e2.adler = r2.check = 1, r2.mode = 12;
              case 12:
                if (5 === t2 || 6 === t2) break e;
              case 13:
                if (r2.last) {
                  u2 >>>= 7 & l3, l3 -= 7 & l3, r2.mode = 27;
                  break;
                }
                for (; l3 < 3; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                switch (r2.last = 1 & u2, l3 -= 1, 3 & (u2 >>>= 1)) {
                  case 0:
                    r2.mode = 14;
                    break;
                  case 1:
                    if (j(r2), r2.mode = 20, 6 !== t2) break;
                    u2 >>>= 2, l3 -= 2;
                    break e;
                  case 2:
                    r2.mode = 17;
                    break;
                  case 3:
                    e2.msg = "invalid block type", r2.mode = 30;
                }
                u2 >>>= 2, l3 -= 2;
                break;
              case 14:
                for (u2 >>>= 7 & l3, l3 -= 7 & l3; l3 < 32; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                if ((65535 & u2) != (u2 >>> 16 ^ 65535)) {
                  e2.msg = "invalid stored block lengths", r2.mode = 30;
                  break;
                }
                if (r2.length = 65535 & u2, l3 = u2 = 0, r2.mode = 15, 6 === t2) break e;
              case 15:
                r2.mode = 16;
              case 16:
                if (d = r2.length) {
                  if (o2 < d && (d = o2), h2 < d && (d = h2), 0 === d) break e;
                  I.arraySet(i2, n2, s2, d, a2), o2 -= d, s2 += d, h2 -= d, a2 += d, r2.length -= d;
                  break;
                }
                r2.mode = 12;
                break;
              case 17:
                for (; l3 < 14; ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                if (r2.nlen = 257 + (31 & u2), u2 >>>= 5, l3 -= 5, r2.ndist = 1 + (31 & u2), u2 >>>= 5, l3 -= 5, r2.ncode = 4 + (15 & u2), u2 >>>= 4, l3 -= 4, 286 < r2.nlen || 30 < r2.ndist) {
                  e2.msg = "too many length or distance symbols", r2.mode = 30;
                  break;
                }
                r2.have = 0, r2.mode = 18;
              case 18:
                for (; r2.have < r2.ncode; ) {
                  for (; l3 < 3; ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  r2.lens[A[r2.have++]] = 7 & u2, u2 >>>= 3, l3 -= 3;
                }
                for (; r2.have < 19; ) r2.lens[A[r2.have++]] = 0;
                if (r2.lencode = r2.lendyn, r2.lenbits = 7, S = {
                  bits: r2.lenbits
                }, x = T(0, r2.lens, 0, 19, r2.lencode, 0, r2.work, S), r2.lenbits = S.bits, x) {
                  e2.msg = "invalid code lengths set", r2.mode = 30;
                  break;
                }
                r2.have = 0, r2.mode = 19;
              case 19:
                for (; r2.have < r2.nlen + r2.ndist; ) {
                  for (; g = (C = r2.lencode[u2 & (1 << r2.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_3 = C >>> 24) <= l3); ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  if (b < 16) u2 >>>= _3, l3 -= _3, r2.lens[r2.have++] = b;
                  else {
                    if (16 === b) {
                      for (z = _3 + 2; l3 < z; ) {
                        if (0 === o2) break e;
                        o2--, u2 += n2[s2++] << l3, l3 += 8;
                      }
                      if (u2 >>>= _3, l3 -= _3, 0 === r2.have) {
                        e2.msg = "invalid bit length repeat", r2.mode = 30;
                        break;
                      }
                      k = r2.lens[r2.have - 1], d = 3 + (3 & u2), u2 >>>= 2, l3 -= 2;
                    } else if (17 === b) {
                      for (z = _3 + 3; l3 < z; ) {
                        if (0 === o2) break e;
                        o2--, u2 += n2[s2++] << l3, l3 += 8;
                      }
                      l3 -= _3, k = 0, d = 3 + (7 & (u2 >>>= _3)), u2 >>>= 3, l3 -= 3;
                    } else {
                      for (z = _3 + 7; l3 < z; ) {
                        if (0 === o2) break e;
                        o2--, u2 += n2[s2++] << l3, l3 += 8;
                      }
                      l3 -= _3, k = 0, d = 11 + (127 & (u2 >>>= _3)), u2 >>>= 7, l3 -= 7;
                    }
                    if (r2.have + d > r2.nlen + r2.ndist) {
                      e2.msg = "invalid bit length repeat", r2.mode = 30;
                      break;
                    }
                    for (; d--; ) r2.lens[r2.have++] = k;
                  }
                }
                if (30 === r2.mode) break;
                if (0 === r2.lens[256]) {
                  e2.msg = "invalid code -- missing end-of-block", r2.mode = 30;
                  break;
                }
                if (r2.lenbits = 9, S = {
                  bits: r2.lenbits
                }, x = T(D, r2.lens, 0, r2.nlen, r2.lencode, 0, r2.work, S), r2.lenbits = S.bits, x) {
                  e2.msg = "invalid literal/lengths set", r2.mode = 30;
                  break;
                }
                if (r2.distbits = 6, r2.distcode = r2.distdyn, S = {
                  bits: r2.distbits
                }, x = T(F, r2.lens, r2.nlen, r2.ndist, r2.distcode, 0, r2.work, S), r2.distbits = S.bits, x) {
                  e2.msg = "invalid distances set", r2.mode = 30;
                  break;
                }
                if (r2.mode = 20, 6 === t2) break e;
              case 20:
                r2.mode = 21;
              case 21:
                if (6 <= o2 && 258 <= h2) {
                  e2.next_out = a2, e2.avail_out = h2, e2.next_in = s2, e2.avail_in = o2, r2.hold = u2, r2.bits = l3, R(e2, c2), a2 = e2.next_out, i2 = e2.output, h2 = e2.avail_out, s2 = e2.next_in, n2 = e2.input, o2 = e2.avail_in, u2 = r2.hold, l3 = r2.bits, 12 === r2.mode && (r2.back = -1);
                  break;
                }
                for (r2.back = 0; g = (C = r2.lencode[u2 & (1 << r2.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_3 = C >>> 24) <= l3); ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                if (g && 0 == (240 & g)) {
                  for (v = _3, y = g, w = b; g = (C = r2.lencode[w + ((u2 & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_3 = C >>> 24) <= l3); ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  u2 >>>= v, l3 -= v, r2.back += v;
                }
                if (u2 >>>= _3, l3 -= _3, r2.back += _3, r2.length = b, 0 === g) {
                  r2.mode = 26;
                  break;
                }
                if (32 & g) {
                  r2.back = -1, r2.mode = 12;
                  break;
                }
                if (64 & g) {
                  e2.msg = "invalid literal/length code", r2.mode = 30;
                  break;
                }
                r2.extra = 15 & g, r2.mode = 22;
              case 22:
                if (r2.extra) {
                  for (z = r2.extra; l3 < z; ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  r2.length += u2 & (1 << r2.extra) - 1, u2 >>>= r2.extra, l3 -= r2.extra, r2.back += r2.extra;
                }
                r2.was = r2.length, r2.mode = 23;
              case 23:
                for (; g = (C = r2.distcode[u2 & (1 << r2.distbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_3 = C >>> 24) <= l3); ) {
                  if (0 === o2) break e;
                  o2--, u2 += n2[s2++] << l3, l3 += 8;
                }
                if (0 == (240 & g)) {
                  for (v = _3, y = g, w = b; g = (C = r2.distcode[w + ((u2 & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_3 = C >>> 24) <= l3); ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  u2 >>>= v, l3 -= v, r2.back += v;
                }
                if (u2 >>>= _3, l3 -= _3, r2.back += _3, 64 & g) {
                  e2.msg = "invalid distance code", r2.mode = 30;
                  break;
                }
                r2.offset = b, r2.extra = 15 & g, r2.mode = 24;
              case 24:
                if (r2.extra) {
                  for (z = r2.extra; l3 < z; ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  r2.offset += u2 & (1 << r2.extra) - 1, u2 >>>= r2.extra, l3 -= r2.extra, r2.back += r2.extra;
                }
                if (r2.offset > r2.dmax) {
                  e2.msg = "invalid distance too far back", r2.mode = 30;
                  break;
                }
                r2.mode = 25;
              case 25:
                if (0 === h2) break e;
                if (d = c2 - h2, r2.offset > d) {
                  if ((d = r2.offset - d) > r2.whave && r2.sane) {
                    e2.msg = "invalid distance too far back", r2.mode = 30;
                    break;
                  }
                  p = d > r2.wnext ? (d -= r2.wnext, r2.wsize - d) : r2.wnext - d, d > r2.length && (d = r2.length), m = r2.window;
                } else m = i2, p = a2 - r2.offset, d = r2.length;
                for (h2 < d && (d = h2), h2 -= d, r2.length -= d; i2[a2++] = m[p++], --d; ) ;
                0 === r2.length && (r2.mode = 21);
                break;
              case 26:
                if (0 === h2) break e;
                i2[a2++] = r2.length, h2--, r2.mode = 21;
                break;
              case 27:
                if (r2.wrap) {
                  for (; l3 < 32; ) {
                    if (0 === o2) break e;
                    o2--, u2 |= n2[s2++] << l3, l3 += 8;
                  }
                  if (c2 -= h2, e2.total_out += c2, r2.total += c2, c2 && (e2.adler = r2.check = r2.flags ? B(r2.check, i2, c2, a2 - c2) : O(r2.check, i2, c2, a2 - c2)), c2 = h2, (r2.flags ? u2 : L(u2)) !== r2.check) {
                    e2.msg = "incorrect data check", r2.mode = 30;
                    break;
                  }
                  l3 = u2 = 0;
                }
                r2.mode = 28;
              case 28:
                if (r2.wrap && r2.flags) {
                  for (; l3 < 32; ) {
                    if (0 === o2) break e;
                    o2--, u2 += n2[s2++] << l3, l3 += 8;
                  }
                  if (u2 !== (4294967295 & r2.total)) {
                    e2.msg = "incorrect length check", r2.mode = 30;
                    break;
                  }
                  l3 = u2 = 0;
                }
                r2.mode = 29;
              case 29:
                x = 1;
                break e;
              case 30:
                x = -3;
                break e;
              case 31:
                return -4;
              case 32:
              default:
                return U;
            }
            return e2.next_out = a2, e2.avail_out = h2, e2.next_in = s2, e2.avail_in = o2, r2.hold = u2, r2.bits = l3, (r2.wsize || c2 !== e2.avail_out && r2.mode < 30 && (r2.mode < 27 || 4 !== t2)) && Z(e2, e2.output, e2.next_out, c2 - e2.avail_out) ? (r2.mode = 31, -4) : (f2 -= e2.avail_in, c2 -= e2.avail_out, e2.total_in += f2, e2.total_out += c2, r2.total += c2, r2.wrap && c2 && (e2.adler = r2.check = r2.flags ? B(r2.check, i2, c2, e2.next_out - c2) : O(r2.check, i2, c2, e2.next_out - c2)), e2.data_type = r2.bits + (r2.last ? 64 : 0) + (12 === r2.mode ? 128 : 0) + (20 === r2.mode || 15 === r2.mode ? 256 : 0), (0 == f2 && 0 === c2 || 4 === t2) && x === N && (x = -5), x);
          }, r.inflateEnd = function(e2) {
            if (!e2 || !e2.state) return U;
            var t2 = e2.state;
            return t2.window && (t2.window = null), e2.state = null, N;
          }, r.inflateGetHeader = function(e2, t2) {
            var r2;
            return e2 && e2.state ? 0 == (2 & (r2 = e2.state).wrap) ? U : ((r2.head = t2).done = false, N) : U;
          }, r.inflateSetDictionary = function(e2, t2) {
            var r2, n2 = t2.length;
            return e2 && e2.state ? 0 !== (r2 = e2.state).wrap && 11 !== r2.mode ? U : 11 === r2.mode && O(1, t2, n2, 0) !== r2.check ? -3 : Z(e2, t2, n2, n2) ? (r2.mode = 31, -4) : (r2.havedict = 1, N) : U;
          }, r.inflateInfo = "pako inflate (from Nodeca project)";
        }, {
          "../utils/common": 41,
          "./adler32": 43,
          "./crc32": 45,
          "./inffast": 48,
          "./inftrees": 50
        }],
        50: [function(e, t, r) {
          "use strict";
          var D = e("../utils/common"), F = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0], N = [16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78], U = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 0, 0], P = [16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 64, 64];
          t.exports = function(e2, t2, r2, n, i, s, a, o) {
            var h, u, l2, f, c, d, p, m, _3, g = o.bits, b = 0, v = 0, y = 0, w = 0, k = 0, x = 0, S = 0, z = 0, C = 0, E = 0, A = null, I = 0, O = new D.Buf16(16), B = new D.Buf16(16), R = null, T = 0;
            for (b = 0; b <= 15; b++) O[b] = 0;
            for (v = 0; v < n; v++) O[t2[r2 + v]]++;
            for (k = g, w = 15; 1 <= w && 0 === O[w]; w--) ;
            if (w < k && (k = w), 0 === w) return i[s++] = 20971520, i[s++] = 20971520, o.bits = 1, 0;
            for (y = 1; y < w && 0 === O[y]; y++) ;
            for (k < y && (k = y), b = z = 1; b <= 15; b++) if (z <<= 1, (z -= O[b]) < 0) return -1;
            if (0 < z && (0 === e2 || 1 !== w)) return -1;
            for (B[1] = 0, b = 1; b < 15; b++) B[b + 1] = B[b] + O[b];
            for (v = 0; v < n; v++) 0 !== t2[r2 + v] && (a[B[t2[r2 + v]]++] = v);
            if (d = 0 === e2 ? (A = R = a, 19) : 1 === e2 ? (A = F, I -= 257, R = N, T -= 257, 256) : (A = U, R = P, -1), b = y, c = s, S = v = E = 0, l2 = -1, f = (C = 1 << (x = k)) - 1, 1 === e2 && 852 < C || 2 === e2 && 592 < C) return 1;
            for (; ; ) {
              for (p = b - S, _3 = a[v] < d ? (m = 0, a[v]) : a[v] > d ? (m = R[T + a[v]], A[I + a[v]]) : (m = 96, 0), h = 1 << b - S, y = u = 1 << x; i[c + (E >> S) + (u -= h)] = p << 24 | m << 16 | _3 | 0, 0 !== u; ) ;
              for (h = 1 << b - 1; E & h; ) h >>= 1;
              if (0 !== h ? (E &= h - 1, E += h) : E = 0, v++, 0 == --O[b]) {
                if (b === w) break;
                b = t2[r2 + a[v]];
              }
              if (k < b && (E & f) !== l2) {
                for (0 === S && (S = k), c += y, z = 1 << (x = b - S); x + S < w && !((z -= O[x + S]) <= 0); ) x++, z <<= 1;
                if (C += 1 << x, 1 === e2 && 852 < C || 2 === e2 && 592 < C) return 1;
                i[l2 = E & f] = k << 24 | x << 16 | c - s | 0;
              }
            }
            return 0 !== E && (i[c + E] = b - S << 24 | 64 << 16 | 0), o.bits = k, 0;
          };
        }, {
          "../utils/common": 41
        }],
        51: [function(e, t, r) {
          "use strict";
          t.exports = {
            2: "need dictionary",
            1: "stream end",
            0: "",
            "-1": "file error",
            "-2": "stream error",
            "-3": "data error",
            "-4": "insufficient memory",
            "-5": "buffer error",
            "-6": "incompatible version"
          };
        }, {}],
        52: [function(e, t, r) {
          "use strict";
          var i = e("../utils/common"), o = 0, h = 1;
          function n(e2) {
            for (var t2 = e2.length; 0 <= --t2; ) e2[t2] = 0;
          }
          var s = 0, a = 29, u = 256, l2 = u + 1 + a, f = 30, c = 19, _3 = 2 * l2 + 1, g = 15, d = 16, p = 7, m = 256, b = 16, v = 17, y = 18, w = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], k = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], x = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7], S = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], z = new Array(2 * (l2 + 2));
          n(z);
          var C = new Array(2 * f);
          n(C);
          var E = new Array(512);
          n(E);
          var A = new Array(256);
          n(A);
          var I = new Array(a);
          n(I);
          var O, B, R, T = new Array(f);
          function D(e2, t2, r2, n2, i2) {
            this.static_tree = e2, this.extra_bits = t2, this.extra_base = r2, this.elems = n2, this.max_length = i2, this.has_stree = e2 && e2.length;
          }
          function F(e2, t2) {
            this.dyn_tree = e2, this.max_code = 0, this.stat_desc = t2;
          }
          function N(e2) {
            return e2 < 256 ? E[e2] : E[256 + (e2 >>> 7)];
          }
          function U(e2, t2) {
            e2.pending_buf[e2.pending++] = 255 & t2, e2.pending_buf[e2.pending++] = t2 >>> 8 & 255;
          }
          function P(e2, t2, r2) {
            e2.bi_valid > d - r2 ? (e2.bi_buf |= t2 << e2.bi_valid & 65535, U(e2, e2.bi_buf), e2.bi_buf = t2 >> d - e2.bi_valid, e2.bi_valid += r2 - d) : (e2.bi_buf |= t2 << e2.bi_valid & 65535, e2.bi_valid += r2);
          }
          function L(e2, t2, r2) {
            P(e2, r2[2 * t2], r2[2 * t2 + 1]);
          }
          function j(e2, t2) {
            for (var r2 = 0; r2 |= 1 & e2, e2 >>>= 1, r2 <<= 1, 0 < --t2; ) ;
            return r2 >>> 1;
          }
          function Z(e2, t2, r2) {
            var n2, i2, s2 = new Array(g + 1), a2 = 0;
            for (n2 = 1; n2 <= g; n2++) s2[n2] = a2 = a2 + r2[n2 - 1] << 1;
            for (i2 = 0; i2 <= t2; i2++) {
              var o2 = e2[2 * i2 + 1];
              0 !== o2 && (e2[2 * i2] = j(s2[o2]++, o2));
            }
          }
          function W(e2) {
            var t2;
            for (t2 = 0; t2 < l2; t2++) e2.dyn_ltree[2 * t2] = 0;
            for (t2 = 0; t2 < f; t2++) e2.dyn_dtree[2 * t2] = 0;
            for (t2 = 0; t2 < c; t2++) e2.bl_tree[2 * t2] = 0;
            e2.dyn_ltree[2 * m] = 1, e2.opt_len = e2.static_len = 0, e2.last_lit = e2.matches = 0;
          }
          function M(e2) {
            8 < e2.bi_valid ? U(e2, e2.bi_buf) : 0 < e2.bi_valid && (e2.pending_buf[e2.pending++] = e2.bi_buf), e2.bi_buf = 0, e2.bi_valid = 0;
          }
          function H(e2, t2, r2, n2) {
            var i2 = 2 * t2, s2 = 2 * r2;
            return e2[i2] < e2[s2] || e2[i2] === e2[s2] && n2[t2] <= n2[r2];
          }
          function G(e2, t2, r2) {
            for (var n2 = e2.heap[r2], i2 = r2 << 1; i2 <= e2.heap_len && (i2 < e2.heap_len && H(t2, e2.heap[i2 + 1], e2.heap[i2], e2.depth) && i2++, !H(t2, n2, e2.heap[i2], e2.depth)); ) e2.heap[r2] = e2.heap[i2], r2 = i2, i2 <<= 1;
            e2.heap[r2] = n2;
          }
          function K(e2, t2, r2) {
            var n2, i2, s2, a2, o2 = 0;
            if (0 !== e2.last_lit) for (; n2 = e2.pending_buf[e2.d_buf + 2 * o2] << 8 | e2.pending_buf[e2.d_buf + 2 * o2 + 1], i2 = e2.pending_buf[e2.l_buf + o2], o2++, 0 === n2 ? L(e2, i2, t2) : (L(e2, (s2 = A[i2]) + u + 1, t2), 0 !== (a2 = w[s2]) && P(e2, i2 -= I[s2], a2), L(e2, s2 = N(--n2), r2), 0 !== (a2 = k[s2]) && P(e2, n2 -= T[s2], a2)), o2 < e2.last_lit; ) ;
            L(e2, m, t2);
          }
          function Y(e2, t2) {
            var r2, n2, i2, s2 = t2.dyn_tree, a2 = t2.stat_desc.static_tree, o2 = t2.stat_desc.has_stree, h2 = t2.stat_desc.elems, u2 = -1;
            for (e2.heap_len = 0, e2.heap_max = _3, r2 = 0; r2 < h2; r2++) 0 !== s2[2 * r2] ? (e2.heap[++e2.heap_len] = u2 = r2, e2.depth[r2] = 0) : s2[2 * r2 + 1] = 0;
            for (; e2.heap_len < 2; ) s2[2 * (i2 = e2.heap[++e2.heap_len] = u2 < 2 ? ++u2 : 0)] = 1, e2.depth[i2] = 0, e2.opt_len--, o2 && (e2.static_len -= a2[2 * i2 + 1]);
            for (t2.max_code = u2, r2 = e2.heap_len >> 1; 1 <= r2; r2--) G(e2, s2, r2);
            for (i2 = h2; r2 = e2.heap[1], e2.heap[1] = e2.heap[e2.heap_len--], G(e2, s2, 1), n2 = e2.heap[1], e2.heap[--e2.heap_max] = r2, e2.heap[--e2.heap_max] = n2, s2[2 * i2] = s2[2 * r2] + s2[2 * n2], e2.depth[i2] = (e2.depth[r2] >= e2.depth[n2] ? e2.depth[r2] : e2.depth[n2]) + 1, s2[2 * r2 + 1] = s2[2 * n2 + 1] = i2, e2.heap[1] = i2++, G(e2, s2, 1), 2 <= e2.heap_len; ) ;
            e2.heap[--e2.heap_max] = e2.heap[1], function(e3, t3) {
              var r3, n3, i3, s3, a3, o3, h3 = t3.dyn_tree, u3 = t3.max_code, l3 = t3.stat_desc.static_tree, f2 = t3.stat_desc.has_stree, c2 = t3.stat_desc.extra_bits, d2 = t3.stat_desc.extra_base, p2 = t3.stat_desc.max_length, m2 = 0;
              for (s3 = 0; s3 <= g; s3++) e3.bl_count[s3] = 0;
              for (h3[2 * e3.heap[e3.heap_max] + 1] = 0, r3 = e3.heap_max + 1; r3 < _3; r3++) p2 < (s3 = h3[2 * h3[2 * (n3 = e3.heap[r3]) + 1] + 1] + 1) && (s3 = p2, m2++), h3[2 * n3 + 1] = s3, u3 < n3 || (e3.bl_count[s3]++, a3 = 0, d2 <= n3 && (a3 = c2[n3 - d2]), o3 = h3[2 * n3], e3.opt_len += o3 * (s3 + a3), f2 && (e3.static_len += o3 * (l3[2 * n3 + 1] + a3)));
              if (0 !== m2) {
                do {
                  for (s3 = p2 - 1; 0 === e3.bl_count[s3]; ) s3--;
                  e3.bl_count[s3]--, e3.bl_count[s3 + 1] += 2, e3.bl_count[p2]--, m2 -= 2;
                } while (0 < m2);
                for (s3 = p2; 0 !== s3; s3--) for (n3 = e3.bl_count[s3]; 0 !== n3; ) u3 < (i3 = e3.heap[--r3]) || (h3[2 * i3 + 1] !== s3 && (e3.opt_len += (s3 - h3[2 * i3 + 1]) * h3[2 * i3], h3[2 * i3 + 1] = s3), n3--);
              }
            }(e2, t2), Z(s2, u2, e2.bl_count);
          }
          function X(e2, t2, r2) {
            var n2, i2, s2 = -1, a2 = t2[1], o2 = 0, h2 = 7, u2 = 4;
            for (0 === a2 && (h2 = 138, u2 = 3), t2[2 * (r2 + 1) + 1] = 65535, n2 = 0; n2 <= r2; n2++) i2 = a2, a2 = t2[2 * (n2 + 1) + 1], ++o2 < h2 && i2 === a2 || (o2 < u2 ? e2.bl_tree[2 * i2] += o2 : 0 !== i2 ? (i2 !== s2 && e2.bl_tree[2 * i2]++, e2.bl_tree[2 * b]++) : o2 <= 10 ? e2.bl_tree[2 * v]++ : e2.bl_tree[2 * y]++, s2 = i2, u2 = (o2 = 0) === a2 ? (h2 = 138, 3) : i2 === a2 ? (h2 = 6, 3) : (h2 = 7, 4));
          }
          function V(e2, t2, r2) {
            var n2, i2, s2 = -1, a2 = t2[1], o2 = 0, h2 = 7, u2 = 4;
            for (0 === a2 && (h2 = 138, u2 = 3), n2 = 0; n2 <= r2; n2++) if (i2 = a2, a2 = t2[2 * (n2 + 1) + 1], !(++o2 < h2 && i2 === a2)) {
              if (o2 < u2) for (; L(e2, i2, e2.bl_tree), 0 != --o2; ) ;
              else 0 !== i2 ? (i2 !== s2 && (L(e2, i2, e2.bl_tree), o2--), L(e2, b, e2.bl_tree), P(e2, o2 - 3, 2)) : o2 <= 10 ? (L(e2, v, e2.bl_tree), P(e2, o2 - 3, 3)) : (L(e2, y, e2.bl_tree), P(e2, o2 - 11, 7));
              s2 = i2, u2 = (o2 = 0) === a2 ? (h2 = 138, 3) : i2 === a2 ? (h2 = 6, 3) : (h2 = 7, 4);
            }
          }
          n(T);
          var q = false;
          function J(e2, t2, r2, n2) {
            P(e2, (s << 1) + (n2 ? 1 : 0), 3), function(e3, t3, r3, n3) {
              M(e3), n3 && (U(e3, r3), U(e3, ~r3)), i.arraySet(e3.pending_buf, e3.window, t3, r3, e3.pending), e3.pending += r3;
            }(e2, t2, r2, true);
          }
          r._tr_init = function(e2) {
            q || (function() {
              var e3, t2, r2, n2, i2, s2 = new Array(g + 1);
              for (n2 = r2 = 0; n2 < a - 1; n2++) for (I[n2] = r2, e3 = 0; e3 < 1 << w[n2]; e3++) A[r2++] = n2;
              for (A[r2 - 1] = n2, n2 = i2 = 0; n2 < 16; n2++) for (T[n2] = i2, e3 = 0; e3 < 1 << k[n2]; e3++) E[i2++] = n2;
              for (i2 >>= 7; n2 < f; n2++) for (T[n2] = i2 << 7, e3 = 0; e3 < 1 << k[n2] - 7; e3++) E[256 + i2++] = n2;
              for (t2 = 0; t2 <= g; t2++) s2[t2] = 0;
              for (e3 = 0; e3 <= 143; ) z[2 * e3 + 1] = 8, e3++, s2[8]++;
              for (; e3 <= 255; ) z[2 * e3 + 1] = 9, e3++, s2[9]++;
              for (; e3 <= 279; ) z[2 * e3 + 1] = 7, e3++, s2[7]++;
              for (; e3 <= 287; ) z[2 * e3 + 1] = 8, e3++, s2[8]++;
              for (Z(z, l2 + 1, s2), e3 = 0; e3 < f; e3++) C[2 * e3 + 1] = 5, C[2 * e3] = j(e3, 5);
              O = new D(z, w, u + 1, l2, g), B = new D(C, k, 0, f, g), R = new D(new Array(0), x, 0, c, p);
            }(), q = true), e2.l_desc = new F(e2.dyn_ltree, O), e2.d_desc = new F(e2.dyn_dtree, B), e2.bl_desc = new F(e2.bl_tree, R), e2.bi_buf = 0, e2.bi_valid = 0, W(e2);
          }, r._tr_stored_block = J, r._tr_flush_block = function(e2, t2, r2, n2) {
            var i2, s2, a2 = 0;
            0 < e2.level ? (2 === e2.strm.data_type && (e2.strm.data_type = function(e3) {
              var t3, r3 = 4093624447;
              for (t3 = 0; t3 <= 31; t3++, r3 >>>= 1) if (1 & r3 && 0 !== e3.dyn_ltree[2 * t3]) return o;
              if (0 !== e3.dyn_ltree[18] || 0 !== e3.dyn_ltree[20] || 0 !== e3.dyn_ltree[26]) return h;
              for (t3 = 32; t3 < u; t3++) if (0 !== e3.dyn_ltree[2 * t3]) return h;
              return o;
            }(e2)), Y(e2, e2.l_desc), Y(e2, e2.d_desc), a2 = function(e3) {
              var t3;
              for (X(e3, e3.dyn_ltree, e3.l_desc.max_code), X(e3, e3.dyn_dtree, e3.d_desc.max_code), Y(e3, e3.bl_desc), t3 = c - 1; 3 <= t3 && 0 === e3.bl_tree[2 * S[t3] + 1]; t3--) ;
              return e3.opt_len += 3 * (t3 + 1) + 5 + 5 + 4, t3;
            }(e2), i2 = e2.opt_len + 3 + 7 >>> 3, (s2 = e2.static_len + 3 + 7 >>> 3) <= i2 && (i2 = s2)) : i2 = s2 = r2 + 5, r2 + 4 <= i2 && -1 !== t2 ? J(e2, t2, r2, n2) : 4 === e2.strategy || s2 === i2 ? (P(e2, 2 + (n2 ? 1 : 0), 3), K(e2, z, C)) : (P(e2, 4 + (n2 ? 1 : 0), 3), function(e3, t3, r3, n3) {
              var i3;
              for (P(e3, t3 - 257, 5), P(e3, r3 - 1, 5), P(e3, n3 - 4, 4), i3 = 0; i3 < n3; i3++) P(e3, e3.bl_tree[2 * S[i3] + 1], 3);
              V(e3, e3.dyn_ltree, t3 - 1), V(e3, e3.dyn_dtree, r3 - 1);
            }(e2, e2.l_desc.max_code + 1, e2.d_desc.max_code + 1, a2 + 1), K(e2, e2.dyn_ltree, e2.dyn_dtree)), W(e2), n2 && M(e2);
          }, r._tr_tally = function(e2, t2, r2) {
            return e2.pending_buf[e2.d_buf + 2 * e2.last_lit] = t2 >>> 8 & 255, e2.pending_buf[e2.d_buf + 2 * e2.last_lit + 1] = 255 & t2, e2.pending_buf[e2.l_buf + e2.last_lit] = 255 & r2, e2.last_lit++, 0 === t2 ? e2.dyn_ltree[2 * r2]++ : (e2.matches++, t2--, e2.dyn_ltree[2 * (A[r2] + u + 1)]++, e2.dyn_dtree[2 * N(t2)]++), e2.last_lit === e2.lit_bufsize - 1;
          }, r._tr_align = function(e2) {
            P(e2, 2, 3), L(e2, m, z), function(e3) {
              16 === e3.bi_valid ? (U(e3, e3.bi_buf), e3.bi_buf = 0, e3.bi_valid = 0) : 8 <= e3.bi_valid && (e3.pending_buf[e3.pending++] = 255 & e3.bi_buf, e3.bi_buf >>= 8, e3.bi_valid -= 8);
            }(e2);
          };
        }, {
          "../utils/common": 41
        }],
        53: [function(e, t, r) {
          "use strict";
          t.exports = function() {
            this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
          };
        }, {}],
        54: [function(e, t, r) {
          (function(e2) {
            !function(r2, n) {
              "use strict";
              if (!r2.setImmediate) {
                var i, s, t2, a, o = 1, h = {}, u = false, l2 = r2.document, e3 = Object.getPrototypeOf && Object.getPrototypeOf(r2);
                e3 = e3 && e3.setTimeout ? e3 : r2, i = "[object process]" === {}.toString.call(r2.process) ? function(e4) {
                  process.nextTick(function() {
                    c(e4);
                  });
                } : function() {
                  if (r2.postMessage && !r2.importScripts) {
                    var e4 = true, t3 = r2.onmessage;
                    return r2.onmessage = function() {
                      e4 = false;
                    }, r2.postMessage("", "*"), r2.onmessage = t3, e4;
                  }
                }() ? (a = "setImmediate$" + Math.random() + "$", r2.addEventListener ? r2.addEventListener("message", d, false) : r2.attachEvent("onmessage", d), function(e4) {
                  r2.postMessage(a + e4, "*");
                }) : r2.MessageChannel ? ((t2 = new MessageChannel()).port1.onmessage = function(e4) {
                  c(e4.data);
                }, function(e4) {
                  t2.port2.postMessage(e4);
                }) : l2 && "onreadystatechange" in l2.createElement("script") ? (s = l2.documentElement, function(e4) {
                  var t3 = l2.createElement("script");
                  t3.onreadystatechange = function() {
                    c(e4), t3.onreadystatechange = null, s.removeChild(t3), t3 = null;
                  }, s.appendChild(t3);
                }) : function(e4) {
                  setTimeout(c, 0, e4);
                }, e3.setImmediate = function(e4) {
                  "function" != typeof e4 && (e4 = new Function("" + e4));
                  for (var t3 = new Array(arguments.length - 1), r3 = 0; r3 < t3.length; r3++) t3[r3] = arguments[r3 + 1];
                  var n2 = {
                    callback: e4,
                    args: t3
                  };
                  return h[o] = n2, i(o), o++;
                }, e3.clearImmediate = f;
              }
              function f(e4) {
                delete h[e4];
              }
              function c(e4) {
                if (u) setTimeout(c, 0, e4);
                else {
                  var t3 = h[e4];
                  if (t3) {
                    u = true;
                    try {
                      !function(e5) {
                        var t4 = e5.callback, r3 = e5.args;
                        switch (r3.length) {
                          case 0:
                            t4();
                            break;
                          case 1:
                            t4(r3[0]);
                            break;
                          case 2:
                            t4(r3[0], r3[1]);
                            break;
                          case 3:
                            t4(r3[0], r3[1], r3[2]);
                            break;
                          default:
                            t4.apply(n, r3);
                        }
                      }(t3);
                    } finally {
                      f(e4), u = false;
                    }
                  }
                }
              }
              function d(e4) {
                e4.source === r2 && "string" == typeof e4.data && 0 === e4.data.indexOf(a) && c(+e4.data.slice(a.length));
              }
            }("undefined" == typeof self ? void 0 === e2 ? this : e2 : self);
          }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
        }, {}]
      }, {}, [10])(10);
    });
  }
});

// node_modules/mammoth/lib/zipfile.js
var require_zipfile = __commonJS({
  "node_modules/mammoth/lib/zipfile.js"(exports2) {
    var base64js = require_base64_js();
    var JSZip = require_jszip_min();
    exports2.openArrayBuffer = openArrayBuffer;
    exports2.splitPath = splitPath;
    exports2.joinPath = joinPath;
    function openArrayBuffer(arrayBuffer) {
      return JSZip.loadAsync(arrayBuffer).then(function(zipFile) {
        function exists(name) {
          return zipFile.file(name) !== null;
        }
        function read(name, encoding) {
          return zipFile.file(name).async("uint8array").then(function(array) {
            if (encoding === "base64") {
              return base64js.fromByteArray(array);
            } else if (encoding) {
              var decoder = new TextDecoder(encoding);
              return decoder.decode(array);
            } else {
              return array;
            }
          });
        }
        function write(name, contents) {
          zipFile.file(name, contents);
        }
        function toArrayBuffer() {
          return zipFile.generateAsync({
            type: "arraybuffer"
          });
        }
        return {
          exists,
          read,
          write,
          toArrayBuffer
        };
      });
    }
    function splitPath(path) {
      var lastIndex = path.lastIndexOf("/");
      if (lastIndex === -1) {
        return {
          dirname: "",
          basename: path
        };
      } else {
        return {
          dirname: path.substring(0, lastIndex),
          basename: path.substring(lastIndex + 1)
        };
      }
    }
    function joinPath() {
      var nonEmptyPaths = Array.prototype.filter.call(arguments, function(path) {
        return path;
      });
      var relevantPaths = [];
      nonEmptyPaths.forEach(function(path) {
        if (/^\//.test(path)) {
          relevantPaths = [path];
        } else {
          relevantPaths.push(path);
        }
      });
      return relevantPaths.join("/");
    }
  }
});

// node_modules/mammoth/lib/xml/nodes.js
var require_nodes = __commonJS({
  "node_modules/mammoth/lib/xml/nodes.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    exports2.Element = Element;
    exports2.element = function(name, attributes, children) {
      return new Element(name, attributes, children);
    };
    exports2.text = function(value) {
      return {
        type: "text",
        value
      };
    };
    var emptyElement = exports2.emptyElement = {
      first: function() {
        return null;
      },
      firstOrEmpty: function() {
        return emptyElement;
      },
      attributes: {},
      children: []
    };
    function Element(name, attributes, children) {
      this.type = "element";
      this.name = name;
      this.attributes = attributes || {};
      this.children = children || [];
    }
    Element.prototype.first = function(name) {
      return _3.find(this.children, function(child) {
        return child.name === name;
      });
    };
    Element.prototype.firstOrEmpty = function(name) {
      return this.first(name) || emptyElement;
    };
    Element.prototype.getElementsByTagName = function(name) {
      var elements = _3.filter(this.children, function(child) {
        return child.name === name;
      });
      return toElementList(elements);
    };
    Element.prototype.text = function() {
      if (this.children.length === 0) {
        return "";
      } else if (this.children.length !== 1 || this.children[0].type !== "text") {
        throw new Error("Not implemented");
      }
      return this.children[0].value;
    };
    var elementListPrototype = {
      getElementsByTagName: function(name) {
        return toElementList(_3.flatten(this.map(function(element) {
          return element.getElementsByTagName(name);
        }, true)));
      }
    };
    function toElementList(array) {
      return _3.extend(array, elementListPrototype);
    }
  }
});

// node_modules/@xmldom/xmldom/lib/conventions.js
var require_conventions = __commonJS({
  "node_modules/@xmldom/xmldom/lib/conventions.js"(exports2) {
    "use strict";
    function find2(list, predicate, ac) {
      if (ac === void 0) {
        ac = Array.prototype;
      }
      if (list && typeof ac.find === "function") {
        return ac.find.call(list, predicate);
      }
      for (var i = 0; i < list.length; i++) {
        if (Object.prototype.hasOwnProperty.call(list, i)) {
          var item = list[i];
          if (predicate.call(void 0, item, i, list)) {
            return item;
          }
        }
      }
    }
    function freeze(object2, oc) {
      if (oc === void 0) {
        oc = Object;
      }
      return oc && typeof oc.freeze === "function" ? oc.freeze(object2) : object2;
    }
    function assign(target, source) {
      if (target === null || typeof target !== "object") {
        throw new TypeError("target is not an object");
      }
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
      return target;
    }
    var MIME_TYPE = freeze({
      /**
       * `text/html`, the only mime type that triggers treating an XML document as HTML.
       *
       * @see DOMParser.SupportedType.isHTML
       * @see https://www.iana.org/assignments/media-types/text/html IANA MimeType registration
       * @see https://en.wikipedia.org/wiki/HTML Wikipedia
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMParser/parseFromString MDN
       * @see https://html.spec.whatwg.org/multipage/dynamic-markup-insertion.html#dom-domparser-parsefromstring WHATWG HTML Spec
       */
      HTML: "text/html",
      /**
       * Helper method to check a mime type if it indicates an HTML document
       *
       * @param {string} [value]
       * @returns {boolean}
       *
       * @see https://www.iana.org/assignments/media-types/text/html IANA MimeType registration
       * @see https://en.wikipedia.org/wiki/HTML Wikipedia
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMParser/parseFromString MDN
       * @see https://html.spec.whatwg.org/multipage/dynamic-markup-insertion.html#dom-domparser-parsefromstring 	 */
      isHTML: function(value) {
        return value === MIME_TYPE.HTML;
      },
      /**
       * `application/xml`, the standard mime type for XML documents.
       *
       * @see https://www.iana.org/assignments/media-types/application/xml IANA MimeType registration
       * @see https://tools.ietf.org/html/rfc7303#section-9.1 RFC 7303
       * @see https://en.wikipedia.org/wiki/XML_and_MIME Wikipedia
       */
      XML_APPLICATION: "application/xml",
      /**
       * `text/html`, an alias for `application/xml`.
       *
       * @see https://tools.ietf.org/html/rfc7303#section-9.2 RFC 7303
       * @see https://www.iana.org/assignments/media-types/text/xml IANA MimeType registration
       * @see https://en.wikipedia.org/wiki/XML_and_MIME Wikipedia
       */
      XML_TEXT: "text/xml",
      /**
       * `application/xhtml+xml`, indicates an XML document that has the default HTML namespace,
       * but is parsed as an XML document.
       *
       * @see https://www.iana.org/assignments/media-types/application/xhtml+xml IANA MimeType registration
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-createdocument WHATWG DOM Spec
       * @see https://en.wikipedia.org/wiki/XHTML Wikipedia
       */
      XML_XHTML_APPLICATION: "application/xhtml+xml",
      /**
       * `image/svg+xml`,
       *
       * @see https://www.iana.org/assignments/media-types/image/svg+xml IANA MimeType registration
       * @see https://www.w3.org/TR/SVG11/ W3C SVG 1.1
       * @see https://en.wikipedia.org/wiki/Scalable_Vector_Graphics Wikipedia
       */
      XML_SVG_IMAGE: "image/svg+xml"
    });
    var NAMESPACE = freeze({
      /**
       * The XHTML namespace.
       *
       * @see http://www.w3.org/1999/xhtml
       */
      HTML: "http://www.w3.org/1999/xhtml",
      /**
       * Checks if `uri` equals `NAMESPACE.HTML`.
       *
       * @param {string} [uri]
       *
       * @see NAMESPACE.HTML
       */
      isHTML: function(uri) {
        return uri === NAMESPACE.HTML;
      },
      /**
       * The SVG namespace.
       *
       * @see http://www.w3.org/2000/svg
       */
      SVG: "http://www.w3.org/2000/svg",
      /**
       * The `xml:` namespace.
       *
       * @see http://www.w3.org/XML/1998/namespace
       */
      XML: "http://www.w3.org/XML/1998/namespace",
      /**
       * The `xmlns:` namespace
       *
       * @see https://www.w3.org/2000/xmlns/
       */
      XMLNS: "http://www.w3.org/2000/xmlns/"
    });
    exports2.assign = assign;
    exports2.find = find2;
    exports2.freeze = freeze;
    exports2.MIME_TYPE = MIME_TYPE;
    exports2.NAMESPACE = NAMESPACE;
  }
});

// node_modules/@xmldom/xmldom/lib/dom.js
var require_dom = __commonJS({
  "node_modules/@xmldom/xmldom/lib/dom.js"(exports2) {
    var conventions = require_conventions();
    var find2 = conventions.find;
    var NAMESPACE = conventions.NAMESPACE;
    function notEmptyString(input) {
      return input !== "";
    }
    function splitOnASCIIWhitespace(input) {
      return input ? input.split(/[\t\n\f\r ]+/).filter(notEmptyString) : [];
    }
    function orderedSetReducer(current, element) {
      if (!current.hasOwnProperty(element)) {
        current[element] = true;
      }
      return current;
    }
    function toOrderedSet(input) {
      if (!input) return [];
      var list = splitOnASCIIWhitespace(input);
      return Object.keys(list.reduce(orderedSetReducer, {}));
    }
    function arrayIncludes(list) {
      return function(element) {
        return list && list.indexOf(element) !== -1;
      };
    }
    function copy(src, dest) {
      for (var p in src) {
        if (Object.prototype.hasOwnProperty.call(src, p)) {
          dest[p] = src[p];
        }
      }
    }
    function _extends(Class, Super) {
      var pt = Class.prototype;
      if (!(pt instanceof Super)) {
        let t2 = function() {
        };
        var t = t2;
        ;
        t2.prototype = Super.prototype;
        t2 = new t2();
        copy(pt, t2);
        Class.prototype = pt = t2;
      }
      if (pt.constructor != Class) {
        if (typeof Class != "function") {
          console.error("unknown Class:" + Class);
        }
        pt.constructor = Class;
      }
    }
    var NodeType = {};
    var ELEMENT_NODE = NodeType.ELEMENT_NODE = 1;
    var ATTRIBUTE_NODE = NodeType.ATTRIBUTE_NODE = 2;
    var TEXT_NODE = NodeType.TEXT_NODE = 3;
    var CDATA_SECTION_NODE = NodeType.CDATA_SECTION_NODE = 4;
    var ENTITY_REFERENCE_NODE = NodeType.ENTITY_REFERENCE_NODE = 5;
    var ENTITY_NODE = NodeType.ENTITY_NODE = 6;
    var PROCESSING_INSTRUCTION_NODE = NodeType.PROCESSING_INSTRUCTION_NODE = 7;
    var COMMENT_NODE = NodeType.COMMENT_NODE = 8;
    var DOCUMENT_NODE = NodeType.DOCUMENT_NODE = 9;
    var DOCUMENT_TYPE_NODE = NodeType.DOCUMENT_TYPE_NODE = 10;
    var DOCUMENT_FRAGMENT_NODE = NodeType.DOCUMENT_FRAGMENT_NODE = 11;
    var NOTATION_NODE = NodeType.NOTATION_NODE = 12;
    var ExceptionCode = {};
    var ExceptionMessage = {};
    var INDEX_SIZE_ERR = ExceptionCode.INDEX_SIZE_ERR = (ExceptionMessage[1] = "Index size error", 1);
    var DOMSTRING_SIZE_ERR = ExceptionCode.DOMSTRING_SIZE_ERR = (ExceptionMessage[2] = "DOMString size error", 2);
    var HIERARCHY_REQUEST_ERR = ExceptionCode.HIERARCHY_REQUEST_ERR = (ExceptionMessage[3] = "Hierarchy request error", 3);
    var WRONG_DOCUMENT_ERR = ExceptionCode.WRONG_DOCUMENT_ERR = (ExceptionMessage[4] = "Wrong document", 4);
    var INVALID_CHARACTER_ERR = ExceptionCode.INVALID_CHARACTER_ERR = (ExceptionMessage[5] = "Invalid character", 5);
    var NO_DATA_ALLOWED_ERR = ExceptionCode.NO_DATA_ALLOWED_ERR = (ExceptionMessage[6] = "No data allowed", 6);
    var NO_MODIFICATION_ALLOWED_ERR = ExceptionCode.NO_MODIFICATION_ALLOWED_ERR = (ExceptionMessage[7] = "No modification allowed", 7);
    var NOT_FOUND_ERR = ExceptionCode.NOT_FOUND_ERR = (ExceptionMessage[8] = "Not found", 8);
    var NOT_SUPPORTED_ERR = ExceptionCode.NOT_SUPPORTED_ERR = (ExceptionMessage[9] = "Not supported", 9);
    var INUSE_ATTRIBUTE_ERR = ExceptionCode.INUSE_ATTRIBUTE_ERR = (ExceptionMessage[10] = "Attribute in use", 10);
    var INVALID_STATE_ERR = ExceptionCode.INVALID_STATE_ERR = (ExceptionMessage[11] = "Invalid state", 11);
    var SYNTAX_ERR = ExceptionCode.SYNTAX_ERR = (ExceptionMessage[12] = "Syntax error", 12);
    var INVALID_MODIFICATION_ERR = ExceptionCode.INVALID_MODIFICATION_ERR = (ExceptionMessage[13] = "Invalid modification", 13);
    var NAMESPACE_ERR = ExceptionCode.NAMESPACE_ERR = (ExceptionMessage[14] = "Invalid namespace", 14);
    var INVALID_ACCESS_ERR = ExceptionCode.INVALID_ACCESS_ERR = (ExceptionMessage[15] = "Invalid access", 15);
    function DOMException(code, message) {
      if (message instanceof Error) {
        var error = message;
      } else {
        error = this;
        Error.call(this, ExceptionMessage[code]);
        this.message = ExceptionMessage[code];
        if (Error.captureStackTrace) Error.captureStackTrace(this, DOMException);
      }
      error.code = code;
      if (message) this.message = this.message + ": " + message;
      return error;
    }
    DOMException.prototype = Error.prototype;
    copy(ExceptionCode, DOMException);
    function NodeList() {
    }
    NodeList.prototype = {
      /**
       * The number of nodes in the list. The range of valid child node indices is 0 to length-1 inclusive.
       * @standard level1
       */
      length: 0,
      /**
       * Returns the indexth item in the collection. If index is greater than or equal to the number of nodes in the list, this returns null.
       * @standard level1
       * @param index  unsigned long
       *   Index into the collection.
       * @return Node
       * 	The node at the indexth position in the NodeList, or null if that is not a valid index.
       */
      item: function(index) {
        return index >= 0 && index < this.length ? this[index] : null;
      },
      toString: function(isHTML, nodeFilter) {
        for (var buf = [], i = 0; i < this.length; i++) {
          serializeToString(this[i], buf, isHTML, nodeFilter);
        }
        return buf.join("");
      },
      /**
       * @private
       * @param {function (Node):boolean} predicate
       * @returns {Node[]}
       */
      filter: function(predicate) {
        return Array.prototype.filter.call(this, predicate);
      },
      /**
       * @private
       * @param {Node} item
       * @returns {number}
       */
      indexOf: function(item) {
        return Array.prototype.indexOf.call(this, item);
      }
    };
    function LiveNodeList(node, refresh) {
      this._node = node;
      this._refresh = refresh;
      _updateLiveList(this);
    }
    function _updateLiveList(list) {
      var inc = list._node._inc || list._node.ownerDocument._inc;
      if (list._inc !== inc) {
        var ls = list._refresh(list._node);
        __set__(list, "length", ls.length);
        if (!list.$$length || ls.length < list.$$length) {
          for (var i = ls.length; i in list; i++) {
            if (Object.prototype.hasOwnProperty.call(list, i)) {
              delete list[i];
            }
          }
        }
        copy(ls, list);
        list._inc = inc;
      }
    }
    LiveNodeList.prototype.item = function(i) {
      _updateLiveList(this);
      return this[i] || null;
    };
    _extends(LiveNodeList, NodeList);
    function NamedNodeMap() {
    }
    function _findNodeIndex(list, node) {
      var i = list.length;
      while (i--) {
        if (list[i] === node) {
          return i;
        }
      }
    }
    function _addNamedNode(el, list, newAttr, oldAttr) {
      if (oldAttr) {
        list[_findNodeIndex(list, oldAttr)] = newAttr;
      } else {
        list[list.length++] = newAttr;
      }
      if (el) {
        newAttr.ownerElement = el;
        var doc = el.ownerDocument;
        if (doc) {
          oldAttr && _onRemoveAttribute(doc, el, oldAttr);
          _onAddAttribute(doc, el, newAttr);
        }
      }
    }
    function _removeNamedNode(el, list, attr) {
      var i = _findNodeIndex(list, attr);
      if (i >= 0) {
        var lastIndex = list.length - 1;
        while (i < lastIndex) {
          list[i] = list[++i];
        }
        list.length = lastIndex;
        if (el) {
          var doc = el.ownerDocument;
          if (doc) {
            _onRemoveAttribute(doc, el, attr);
            attr.ownerElement = null;
          }
        }
      } else {
        throw new DOMException(NOT_FOUND_ERR, new Error(el.tagName + "@" + attr));
      }
    }
    NamedNodeMap.prototype = {
      length: 0,
      item: NodeList.prototype.item,
      getNamedItem: function(key) {
        var i = this.length;
        while (i--) {
          var attr = this[i];
          if (attr.nodeName == key) {
            return attr;
          }
        }
      },
      setNamedItem: function(attr) {
        var el = attr.ownerElement;
        if (el && el != this._ownerElement) {
          throw new DOMException(INUSE_ATTRIBUTE_ERR);
        }
        var oldAttr = this.getNamedItem(attr.nodeName);
        _addNamedNode(this._ownerElement, this, attr, oldAttr);
        return oldAttr;
      },
      /* returns Node */
      setNamedItemNS: function(attr) {
        var el = attr.ownerElement, oldAttr;
        if (el && el != this._ownerElement) {
          throw new DOMException(INUSE_ATTRIBUTE_ERR);
        }
        oldAttr = this.getNamedItemNS(attr.namespaceURI, attr.localName);
        _addNamedNode(this._ownerElement, this, attr, oldAttr);
        return oldAttr;
      },
      /* returns Node */
      removeNamedItem: function(key) {
        var attr = this.getNamedItem(key);
        _removeNamedNode(this._ownerElement, this, attr);
        return attr;
      },
      // raises: NOT_FOUND_ERR,NO_MODIFICATION_ALLOWED_ERR
      //for level2
      removeNamedItemNS: function(namespaceURI, localName) {
        var attr = this.getNamedItemNS(namespaceURI, localName);
        _removeNamedNode(this._ownerElement, this, attr);
        return attr;
      },
      getNamedItemNS: function(namespaceURI, localName) {
        var i = this.length;
        while (i--) {
          var node = this[i];
          if (node.localName == localName && node.namespaceURI == namespaceURI) {
            return node;
          }
        }
        return null;
      }
    };
    function DOMImplementation() {
    }
    DOMImplementation.prototype = {
      /**
       * The DOMImplementation.hasFeature() method returns a Boolean flag indicating if a given feature is supported.
       * The different implementations fairly diverged in what kind of features were reported.
       * The latest version of the spec settled to force this method to always return true, where the functionality was accurate and in use.
       *
       * @deprecated It is deprecated and modern browsers return true in all cases.
       *
       * @param {string} feature
       * @param {string} [version]
       * @returns {boolean} always true
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMImplementation/hasFeature MDN
       * @see https://www.w3.org/TR/REC-DOM-Level-1/level-one-core.html#ID-5CED94D7 DOM Level 1 Core
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-hasfeature DOM Living Standard
       */
      hasFeature: function(feature, version) {
        return true;
      },
      /**
       * Creates an XML Document object of the specified type with its document element.
       *
       * __It behaves slightly different from the description in the living standard__:
       * - There is no interface/class `XMLDocument`, it returns a `Document` instance.
       * - `contentType`, `encoding`, `mode`, `origin`, `url` fields are currently not declared.
       * - this implementation is not validating names or qualified names
       *   (when parsing XML strings, the SAX parser takes care of that)
       *
       * @param {string|null} namespaceURI
       * @param {string} qualifiedName
       * @param {DocumentType=null} doctype
       * @returns {Document}
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMImplementation/createDocument MDN
       * @see https://www.w3.org/TR/DOM-Level-2-Core/core.html#Level-2-Core-DOM-createDocument DOM Level 2 Core (initial)
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-createdocument  DOM Level 2 Core
       *
       * @see https://dom.spec.whatwg.org/#validate-and-extract DOM: Validate and extract
       * @see https://www.w3.org/TR/xml/#NT-NameStartChar XML Spec: Names
       * @see https://www.w3.org/TR/xml-names/#ns-qualnames XML Namespaces: Qualified names
       */
      createDocument: function(namespaceURI, qualifiedName, doctype) {
        var doc = new Document();
        doc.implementation = this;
        doc.childNodes = new NodeList();
        doc.doctype = doctype || null;
        if (doctype) {
          doc.appendChild(doctype);
        }
        if (qualifiedName) {
          var root2 = doc.createElementNS(namespaceURI, qualifiedName);
          doc.appendChild(root2);
        }
        return doc;
      },
      /**
       * Returns a doctype, with the given `qualifiedName`, `publicId`, and `systemId`.
       *
       * __This behavior is slightly different from the in the specs__:
       * - this implementation is not validating names or qualified names
       *   (when parsing XML strings, the SAX parser takes care of that)
       *
       * @param {string} qualifiedName
       * @param {string} [publicId]
       * @param {string} [systemId]
       * @returns {DocumentType} which can either be used with `DOMImplementation.createDocument` upon document creation
       * 				  or can be put into the document via methods like `Node.insertBefore()` or `Node.replaceChild()`
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMImplementation/createDocumentType MDN
       * @see https://www.w3.org/TR/DOM-Level-2-Core/core.html#Level-2-Core-DOM-createDocType DOM Level 2 Core
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-createdocumenttype DOM Living Standard
       *
       * @see https://dom.spec.whatwg.org/#validate-and-extract DOM: Validate and extract
       * @see https://www.w3.org/TR/xml/#NT-NameStartChar XML Spec: Names
       * @see https://www.w3.org/TR/xml-names/#ns-qualnames XML Namespaces: Qualified names
       */
      createDocumentType: function(qualifiedName, publicId, systemId) {
        var node = new DocumentType();
        node.name = qualifiedName;
        node.nodeName = qualifiedName;
        node.publicId = publicId || "";
        node.systemId = systemId || "";
        return node;
      }
    };
    function Node() {
    }
    Node.prototype = {
      firstChild: null,
      lastChild: null,
      previousSibling: null,
      nextSibling: null,
      attributes: null,
      parentNode: null,
      childNodes: null,
      ownerDocument: null,
      nodeValue: null,
      namespaceURI: null,
      prefix: null,
      localName: null,
      // Modified in DOM Level 2:
      insertBefore: function(newChild, refChild) {
        return _insertBefore(this, newChild, refChild);
      },
      replaceChild: function(newChild, oldChild) {
        _insertBefore(this, newChild, oldChild, assertPreReplacementValidityInDocument);
        if (oldChild) {
          this.removeChild(oldChild);
        }
      },
      removeChild: function(oldChild) {
        return _removeChild(this, oldChild);
      },
      appendChild: function(newChild) {
        return this.insertBefore(newChild, null);
      },
      hasChildNodes: function() {
        return this.firstChild != null;
      },
      cloneNode: function(deep) {
        return cloneNode(this.ownerDocument || this, this, deep);
      },
      // Modified in DOM Level 2:
      normalize: function() {
        var child = this.firstChild;
        while (child) {
          var next = child.nextSibling;
          if (next && next.nodeType == TEXT_NODE && child.nodeType == TEXT_NODE) {
            this.removeChild(next);
            child.appendData(next.data);
          } else {
            child.normalize();
            child = next;
          }
        }
      },
      // Introduced in DOM Level 2:
      isSupported: function(feature, version) {
        return this.ownerDocument.implementation.hasFeature(feature, version);
      },
      // Introduced in DOM Level 2:
      hasAttributes: function() {
        return this.attributes.length > 0;
      },
      /**
       * Look up the prefix associated to the given namespace URI, starting from this node.
       * **The default namespace declarations are ignored by this method.**
       * See Namespace Prefix Lookup for details on the algorithm used by this method.
       *
       * _Note: The implementation seems to be incomplete when compared to the algorithm described in the specs._
       *
       * @param {string | null} namespaceURI
       * @returns {string | null}
       * @see https://www.w3.org/TR/DOM-Level-3-Core/core.html#Node3-lookupNamespacePrefix
       * @see https://www.w3.org/TR/DOM-Level-3-Core/namespaces-algorithms.html#lookupNamespacePrefixAlgo
       * @see https://dom.spec.whatwg.org/#dom-node-lookupprefix
       * @see https://github.com/xmldom/xmldom/issues/322
       */
      lookupPrefix: function(namespaceURI) {
        var el = this;
        while (el) {
          var map2 = el._nsMap;
          if (map2) {
            for (var n in map2) {
              if (Object.prototype.hasOwnProperty.call(map2, n) && map2[n] === namespaceURI) {
                return n;
              }
            }
          }
          el = el.nodeType == ATTRIBUTE_NODE ? el.ownerDocument : el.parentNode;
        }
        return null;
      },
      // Introduced in DOM Level 3:
      lookupNamespaceURI: function(prefix) {
        var el = this;
        while (el) {
          var map2 = el._nsMap;
          if (map2) {
            if (Object.prototype.hasOwnProperty.call(map2, prefix)) {
              return map2[prefix];
            }
          }
          el = el.nodeType == ATTRIBUTE_NODE ? el.ownerDocument : el.parentNode;
        }
        return null;
      },
      // Introduced in DOM Level 3:
      isDefaultNamespace: function(namespaceURI) {
        var prefix = this.lookupPrefix(namespaceURI);
        return prefix == null;
      }
    };
    function _xmlEncoder(c) {
      return c == "<" && "&lt;" || c == ">" && "&gt;" || c == "&" && "&amp;" || c == '"' && "&quot;" || "&#" + c.charCodeAt() + ";";
    }
    copy(NodeType, Node);
    copy(NodeType, Node.prototype);
    function _visitNode(node, callback) {
      if (callback(node)) {
        return true;
      }
      if (node = node.firstChild) {
        do {
          if (_visitNode(node, callback)) {
            return true;
          }
        } while (node = node.nextSibling);
      }
    }
    function Document() {
      this.ownerDocument = this;
    }
    function _onAddAttribute(doc, el, newAttr) {
      doc && doc._inc++;
      var ns = newAttr.namespaceURI;
      if (ns === NAMESPACE.XMLNS) {
        el._nsMap[newAttr.prefix ? newAttr.localName : ""] = newAttr.value;
      }
    }
    function _onRemoveAttribute(doc, el, newAttr, remove) {
      doc && doc._inc++;
      var ns = newAttr.namespaceURI;
      if (ns === NAMESPACE.XMLNS) {
        delete el._nsMap[newAttr.prefix ? newAttr.localName : ""];
      }
    }
    function _onUpdateChild(doc, el, newChild) {
      if (doc && doc._inc) {
        doc._inc++;
        var cs = el.childNodes;
        if (newChild) {
          cs[cs.length++] = newChild;
        } else {
          var child = el.firstChild;
          var i = 0;
          while (child) {
            cs[i++] = child;
            child = child.nextSibling;
          }
          cs.length = i;
          delete cs[cs.length];
        }
      }
    }
    function _removeChild(parentNode, child) {
      var previous = child.previousSibling;
      var next = child.nextSibling;
      if (previous) {
        previous.nextSibling = next;
      } else {
        parentNode.firstChild = next;
      }
      if (next) {
        next.previousSibling = previous;
      } else {
        parentNode.lastChild = previous;
      }
      child.parentNode = null;
      child.previousSibling = null;
      child.nextSibling = null;
      _onUpdateChild(parentNode.ownerDocument, parentNode);
      return child;
    }
    function hasValidParentNodeType(node) {
      return node && (node.nodeType === Node.DOCUMENT_NODE || node.nodeType === Node.DOCUMENT_FRAGMENT_NODE || node.nodeType === Node.ELEMENT_NODE);
    }
    function hasInsertableNodeType(node) {
      return node && (isElementNode(node) || isTextNode(node) || isDocTypeNode(node) || node.nodeType === Node.DOCUMENT_FRAGMENT_NODE || node.nodeType === Node.COMMENT_NODE || node.nodeType === Node.PROCESSING_INSTRUCTION_NODE);
    }
    function isDocTypeNode(node) {
      return node && node.nodeType === Node.DOCUMENT_TYPE_NODE;
    }
    function isElementNode(node) {
      return node && node.nodeType === Node.ELEMENT_NODE;
    }
    function isTextNode(node) {
      return node && node.nodeType === Node.TEXT_NODE;
    }
    function isElementInsertionPossible(doc, child) {
      var parentChildNodes = doc.childNodes || [];
      if (find2(parentChildNodes, isElementNode) || isDocTypeNode(child)) {
        return false;
      }
      var docTypeNode = find2(parentChildNodes, isDocTypeNode);
      return !(child && docTypeNode && parentChildNodes.indexOf(docTypeNode) > parentChildNodes.indexOf(child));
    }
    function isElementReplacementPossible(doc, child) {
      var parentChildNodes = doc.childNodes || [];
      function hasElementChildThatIsNotChild(node) {
        return isElementNode(node) && node !== child;
      }
      if (find2(parentChildNodes, hasElementChildThatIsNotChild)) {
        return false;
      }
      var docTypeNode = find2(parentChildNodes, isDocTypeNode);
      return !(child && docTypeNode && parentChildNodes.indexOf(docTypeNode) > parentChildNodes.indexOf(child));
    }
    function assertPreInsertionValidity1to5(parent, node, child) {
      if (!hasValidParentNodeType(parent)) {
        throw new DOMException(HIERARCHY_REQUEST_ERR, "Unexpected parent node type " + parent.nodeType);
      }
      if (child && child.parentNode !== parent) {
        throw new DOMException(NOT_FOUND_ERR, "child not in parent");
      }
      if (
        // 4. If `node` is not a DocumentFragment, DocumentType, Element, or CharacterData node, then throw a "HierarchyRequestError" DOMException.
        !hasInsertableNodeType(node) || // 5. If either `node` is a Text node and `parent` is a document,
        // the sax parser currently adds top level text nodes, this will be fixed in 0.9.0
        // || (node.nodeType === Node.TEXT_NODE && parent.nodeType === Node.DOCUMENT_NODE)
        // or `node` is a doctype and `parent` is not a document, then throw a "HierarchyRequestError" DOMException.
        isDocTypeNode(node) && parent.nodeType !== Node.DOCUMENT_NODE
      ) {
        throw new DOMException(HIERARCHY_REQUEST_ERR, "Unexpected node type " + node.nodeType + " for parent node type " + parent.nodeType);
      }
    }
    function assertPreInsertionValidityInDocument(parent, node, child) {
      var parentChildNodes = parent.childNodes || [];
      var nodeChildNodes = node.childNodes || [];
      if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
        var nodeChildElements = nodeChildNodes.filter(isElementNode);
        if (nodeChildElements.length > 1 || find2(nodeChildNodes, isTextNode)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "More than one element or text in fragment");
        }
        if (nodeChildElements.length === 1 && !isElementInsertionPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Element in fragment can not be inserted before doctype");
        }
      }
      if (isElementNode(node)) {
        if (!isElementInsertionPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one element can be added and only after doctype");
        }
      }
      if (isDocTypeNode(node)) {
        if (find2(parentChildNodes, isDocTypeNode)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one doctype is allowed");
        }
        var parentElementChild = find2(parentChildNodes, isElementNode);
        if (child && parentChildNodes.indexOf(parentElementChild) < parentChildNodes.indexOf(child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Doctype can only be inserted before an element");
        }
        if (!child && parentElementChild) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Doctype can not be appended since element is present");
        }
      }
    }
    function assertPreReplacementValidityInDocument(parent, node, child) {
      var parentChildNodes = parent.childNodes || [];
      var nodeChildNodes = node.childNodes || [];
      if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
        var nodeChildElements = nodeChildNodes.filter(isElementNode);
        if (nodeChildElements.length > 1 || find2(nodeChildNodes, isTextNode)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "More than one element or text in fragment");
        }
        if (nodeChildElements.length === 1 && !isElementReplacementPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Element in fragment can not be inserted before doctype");
        }
      }
      if (isElementNode(node)) {
        if (!isElementReplacementPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one element can be added and only after doctype");
        }
      }
      if (isDocTypeNode(node)) {
        let hasDoctypeChildThatIsNotChild2 = function(node2) {
          return isDocTypeNode(node2) && node2 !== child;
        };
        var hasDoctypeChildThatIsNotChild = hasDoctypeChildThatIsNotChild2;
        if (find2(parentChildNodes, hasDoctypeChildThatIsNotChild2)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one doctype is allowed");
        }
        var parentElementChild = find2(parentChildNodes, isElementNode);
        if (child && parentChildNodes.indexOf(parentElementChild) < parentChildNodes.indexOf(child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Doctype can only be inserted before an element");
        }
      }
    }
    function _insertBefore(parent, node, child, _inDocumentAssertion) {
      assertPreInsertionValidity1to5(parent, node, child);
      if (parent.nodeType === Node.DOCUMENT_NODE) {
        (_inDocumentAssertion || assertPreInsertionValidityInDocument)(parent, node, child);
      }
      var cp = node.parentNode;
      if (cp) {
        cp.removeChild(node);
      }
      if (node.nodeType === DOCUMENT_FRAGMENT_NODE) {
        var newFirst = node.firstChild;
        if (newFirst == null) {
          return node;
        }
        var newLast = node.lastChild;
      } else {
        newFirst = newLast = node;
      }
      var pre = child ? child.previousSibling : parent.lastChild;
      newFirst.previousSibling = pre;
      newLast.nextSibling = child;
      if (pre) {
        pre.nextSibling = newFirst;
      } else {
        parent.firstChild = newFirst;
      }
      if (child == null) {
        parent.lastChild = newLast;
      } else {
        child.previousSibling = newLast;
      }
      do {
        newFirst.parentNode = parent;
      } while (newFirst !== newLast && (newFirst = newFirst.nextSibling));
      _onUpdateChild(parent.ownerDocument || parent, parent);
      if (node.nodeType == DOCUMENT_FRAGMENT_NODE) {
        node.firstChild = node.lastChild = null;
      }
      return node;
    }
    function _appendSingleChild(parentNode, newChild) {
      if (newChild.parentNode) {
        newChild.parentNode.removeChild(newChild);
      }
      newChild.parentNode = parentNode;
      newChild.previousSibling = parentNode.lastChild;
      newChild.nextSibling = null;
      if (newChild.previousSibling) {
        newChild.previousSibling.nextSibling = newChild;
      } else {
        parentNode.firstChild = newChild;
      }
      parentNode.lastChild = newChild;
      _onUpdateChild(parentNode.ownerDocument, parentNode, newChild);
      return newChild;
    }
    Document.prototype = {
      //implementation : null,
      nodeName: "#document",
      nodeType: DOCUMENT_NODE,
      /**
       * The DocumentType node of the document.
       *
       * @readonly
       * @type DocumentType
       */
      doctype: null,
      documentElement: null,
      _inc: 1,
      insertBefore: function(newChild, refChild) {
        if (newChild.nodeType == DOCUMENT_FRAGMENT_NODE) {
          var child = newChild.firstChild;
          while (child) {
            var next = child.nextSibling;
            this.insertBefore(child, refChild);
            child = next;
          }
          return newChild;
        }
        _insertBefore(this, newChild, refChild);
        newChild.ownerDocument = this;
        if (this.documentElement === null && newChild.nodeType === ELEMENT_NODE) {
          this.documentElement = newChild;
        }
        return newChild;
      },
      removeChild: function(oldChild) {
        if (this.documentElement == oldChild) {
          this.documentElement = null;
        }
        return _removeChild(this, oldChild);
      },
      replaceChild: function(newChild, oldChild) {
        _insertBefore(this, newChild, oldChild, assertPreReplacementValidityInDocument);
        newChild.ownerDocument = this;
        if (oldChild) {
          this.removeChild(oldChild);
        }
        if (isElementNode(newChild)) {
          this.documentElement = newChild;
        }
      },
      // Introduced in DOM Level 2:
      importNode: function(importedNode, deep) {
        return importNode(this, importedNode, deep);
      },
      // Introduced in DOM Level 2:
      getElementById: function(id) {
        var rtv = null;
        _visitNode(this.documentElement, function(node) {
          if (node.nodeType == ELEMENT_NODE) {
            if (node.getAttribute("id") == id) {
              rtv = node;
              return true;
            }
          }
        });
        return rtv;
      },
      /**
       * The `getElementsByClassName` method of `Document` interface returns an array-like object
       * of all child elements which have **all** of the given class name(s).
       *
       * Returns an empty list if `classeNames` is an empty string or only contains HTML white space characters.
       *
       *
       * Warning: This is a live LiveNodeList.
       * Changes in the DOM will reflect in the array as the changes occur.
       * If an element selected by this array no longer qualifies for the selector,
       * it will automatically be removed. Be aware of this for iteration purposes.
       *
       * @param {string} classNames is a string representing the class name(s) to match; multiple class names are separated by (ASCII-)whitespace
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementsByClassName
       * @see https://dom.spec.whatwg.org/#concept-getelementsbyclassname
       */
      getElementsByClassName: function(classNames) {
        var classNamesSet = toOrderedSet(classNames);
        return new LiveNodeList(this, function(base) {
          var ls = [];
          if (classNamesSet.length > 0) {
            _visitNode(base.documentElement, function(node) {
              if (node !== base && node.nodeType === ELEMENT_NODE) {
                var nodeClassNames = node.getAttribute("class");
                if (nodeClassNames) {
                  var matches = classNames === nodeClassNames;
                  if (!matches) {
                    var nodeClassNamesSet = toOrderedSet(nodeClassNames);
                    matches = classNamesSet.every(arrayIncludes(nodeClassNamesSet));
                  }
                  if (matches) {
                    ls.push(node);
                  }
                }
              }
            });
          }
          return ls;
        });
      },
      //document factory method:
      createElement: function(tagName) {
        var node = new Element();
        node.ownerDocument = this;
        node.nodeName = tagName;
        node.tagName = tagName;
        node.localName = tagName;
        node.childNodes = new NodeList();
        var attrs = node.attributes = new NamedNodeMap();
        attrs._ownerElement = node;
        return node;
      },
      createDocumentFragment: function() {
        var node = new DocumentFragment();
        node.ownerDocument = this;
        node.childNodes = new NodeList();
        return node;
      },
      createTextNode: function(data) {
        var node = new Text();
        node.ownerDocument = this;
        node.appendData(data);
        return node;
      },
      createComment: function(data) {
        var node = new Comment();
        node.ownerDocument = this;
        node.appendData(data);
        return node;
      },
      createCDATASection: function(data) {
        var node = new CDATASection();
        node.ownerDocument = this;
        node.appendData(data);
        return node;
      },
      createProcessingInstruction: function(target, data) {
        var node = new ProcessingInstruction();
        node.ownerDocument = this;
        node.tagName = node.nodeName = node.target = target;
        node.nodeValue = node.data = data;
        return node;
      },
      createAttribute: function(name) {
        var node = new Attr();
        node.ownerDocument = this;
        node.name = name;
        node.nodeName = name;
        node.localName = name;
        node.specified = true;
        return node;
      },
      createEntityReference: function(name) {
        var node = new EntityReference();
        node.ownerDocument = this;
        node.nodeName = name;
        return node;
      },
      // Introduced in DOM Level 2:
      createElementNS: function(namespaceURI, qualifiedName) {
        var node = new Element();
        var pl = qualifiedName.split(":");
        var attrs = node.attributes = new NamedNodeMap();
        node.childNodes = new NodeList();
        node.ownerDocument = this;
        node.nodeName = qualifiedName;
        node.tagName = qualifiedName;
        node.namespaceURI = namespaceURI;
        if (pl.length == 2) {
          node.prefix = pl[0];
          node.localName = pl[1];
        } else {
          node.localName = qualifiedName;
        }
        attrs._ownerElement = node;
        return node;
      },
      // Introduced in DOM Level 2:
      createAttributeNS: function(namespaceURI, qualifiedName) {
        var node = new Attr();
        var pl = qualifiedName.split(":");
        node.ownerDocument = this;
        node.nodeName = qualifiedName;
        node.name = qualifiedName;
        node.namespaceURI = namespaceURI;
        node.specified = true;
        if (pl.length == 2) {
          node.prefix = pl[0];
          node.localName = pl[1];
        } else {
          node.localName = qualifiedName;
        }
        return node;
      }
    };
    _extends(Document, Node);
    function Element() {
      this._nsMap = {};
    }
    Element.prototype = {
      nodeType: ELEMENT_NODE,
      hasAttribute: function(name) {
        return this.getAttributeNode(name) != null;
      },
      getAttribute: function(name) {
        var attr = this.getAttributeNode(name);
        return attr && attr.value || "";
      },
      getAttributeNode: function(name) {
        return this.attributes.getNamedItem(name);
      },
      setAttribute: function(name, value) {
        var attr = this.ownerDocument.createAttribute(name);
        attr.value = attr.nodeValue = "" + value;
        this.setAttributeNode(attr);
      },
      removeAttribute: function(name) {
        var attr = this.getAttributeNode(name);
        attr && this.removeAttributeNode(attr);
      },
      //four real opeartion method
      appendChild: function(newChild) {
        if (newChild.nodeType === DOCUMENT_FRAGMENT_NODE) {
          return this.insertBefore(newChild, null);
        } else {
          return _appendSingleChild(this, newChild);
        }
      },
      setAttributeNode: function(newAttr) {
        return this.attributes.setNamedItem(newAttr);
      },
      setAttributeNodeNS: function(newAttr) {
        return this.attributes.setNamedItemNS(newAttr);
      },
      removeAttributeNode: function(oldAttr) {
        return this.attributes.removeNamedItem(oldAttr.nodeName);
      },
      //get real attribute name,and remove it by removeAttributeNode
      removeAttributeNS: function(namespaceURI, localName) {
        var old = this.getAttributeNodeNS(namespaceURI, localName);
        old && this.removeAttributeNode(old);
      },
      hasAttributeNS: function(namespaceURI, localName) {
        return this.getAttributeNodeNS(namespaceURI, localName) != null;
      },
      getAttributeNS: function(namespaceURI, localName) {
        var attr = this.getAttributeNodeNS(namespaceURI, localName);
        return attr && attr.value || "";
      },
      setAttributeNS: function(namespaceURI, qualifiedName, value) {
        var attr = this.ownerDocument.createAttributeNS(namespaceURI, qualifiedName);
        attr.value = attr.nodeValue = "" + value;
        this.setAttributeNode(attr);
      },
      getAttributeNodeNS: function(namespaceURI, localName) {
        return this.attributes.getNamedItemNS(namespaceURI, localName);
      },
      getElementsByTagName: function(tagName) {
        return new LiveNodeList(this, function(base) {
          var ls = [];
          _visitNode(base, function(node) {
            if (node !== base && node.nodeType == ELEMENT_NODE && (tagName === "*" || node.tagName == tagName)) {
              ls.push(node);
            }
          });
          return ls;
        });
      },
      getElementsByTagNameNS: function(namespaceURI, localName) {
        return new LiveNodeList(this, function(base) {
          var ls = [];
          _visitNode(base, function(node) {
            if (node !== base && node.nodeType === ELEMENT_NODE && (namespaceURI === "*" || node.namespaceURI === namespaceURI) && (localName === "*" || node.localName == localName)) {
              ls.push(node);
            }
          });
          return ls;
        });
      }
    };
    Document.prototype.getElementsByTagName = Element.prototype.getElementsByTagName;
    Document.prototype.getElementsByTagNameNS = Element.prototype.getElementsByTagNameNS;
    _extends(Element, Node);
    function Attr() {
    }
    Attr.prototype.nodeType = ATTRIBUTE_NODE;
    _extends(Attr, Node);
    function CharacterData() {
    }
    CharacterData.prototype = {
      data: "",
      substringData: function(offset, count) {
        return this.data.substring(offset, offset + count);
      },
      appendData: function(text) {
        text = this.data + text;
        this.nodeValue = this.data = text;
        this.length = text.length;
      },
      insertData: function(offset, text) {
        this.replaceData(offset, 0, text);
      },
      appendChild: function(newChild) {
        throw new Error(ExceptionMessage[HIERARCHY_REQUEST_ERR]);
      },
      deleteData: function(offset, count) {
        this.replaceData(offset, count, "");
      },
      replaceData: function(offset, count, text) {
        var start = this.data.substring(0, offset);
        var end = this.data.substring(offset + count);
        text = start + text + end;
        this.nodeValue = this.data = text;
        this.length = text.length;
      }
    };
    _extends(CharacterData, Node);
    function Text() {
    }
    Text.prototype = {
      nodeName: "#text",
      nodeType: TEXT_NODE,
      splitText: function(offset) {
        var text = this.data;
        var newText = text.substring(offset);
        text = text.substring(0, offset);
        this.data = this.nodeValue = text;
        this.length = text.length;
        var newNode = this.ownerDocument.createTextNode(newText);
        if (this.parentNode) {
          this.parentNode.insertBefore(newNode, this.nextSibling);
        }
        return newNode;
      }
    };
    _extends(Text, CharacterData);
    function Comment() {
    }
    Comment.prototype = {
      nodeName: "#comment",
      nodeType: COMMENT_NODE
    };
    _extends(Comment, CharacterData);
    function CDATASection() {
    }
    CDATASection.prototype = {
      nodeName: "#cdata-section",
      nodeType: CDATA_SECTION_NODE
    };
    _extends(CDATASection, CharacterData);
    function DocumentType() {
    }
    DocumentType.prototype.nodeType = DOCUMENT_TYPE_NODE;
    _extends(DocumentType, Node);
    function Notation() {
    }
    Notation.prototype.nodeType = NOTATION_NODE;
    _extends(Notation, Node);
    function Entity() {
    }
    Entity.prototype.nodeType = ENTITY_NODE;
    _extends(Entity, Node);
    function EntityReference() {
    }
    EntityReference.prototype.nodeType = ENTITY_REFERENCE_NODE;
    _extends(EntityReference, Node);
    function DocumentFragment() {
    }
    DocumentFragment.prototype.nodeName = "#document-fragment";
    DocumentFragment.prototype.nodeType = DOCUMENT_FRAGMENT_NODE;
    _extends(DocumentFragment, Node);
    function ProcessingInstruction() {
    }
    ProcessingInstruction.prototype.nodeType = PROCESSING_INSTRUCTION_NODE;
    _extends(ProcessingInstruction, Node);
    function XMLSerializer() {
    }
    XMLSerializer.prototype.serializeToString = function(node, isHtml, nodeFilter) {
      return nodeSerializeToString.call(node, isHtml, nodeFilter);
    };
    Node.prototype.toString = nodeSerializeToString;
    function nodeSerializeToString(isHtml, nodeFilter) {
      var buf = [];
      var refNode = this.nodeType == 9 && this.documentElement || this;
      var prefix = refNode.prefix;
      var uri = refNode.namespaceURI;
      if (uri && prefix == null) {
        var prefix = refNode.lookupPrefix(uri);
        if (prefix == null) {
          var visibleNamespaces = [
            {
              namespace: uri,
              prefix: null
            }
            //{namespace:uri,prefix:''}
          ];
        }
      }
      serializeToString(this, buf, isHtml, nodeFilter, visibleNamespaces);
      return buf.join("");
    }
    function needNamespaceDefine(node, isHTML, visibleNamespaces) {
      var prefix = node.prefix || "";
      var uri = node.namespaceURI;
      if (!uri) {
        return false;
      }
      if (prefix === "xml" && uri === NAMESPACE.XML || uri === NAMESPACE.XMLNS) {
        return false;
      }
      var i = visibleNamespaces.length;
      while (i--) {
        var ns = visibleNamespaces[i];
        if (ns.prefix === prefix) {
          return ns.namespace !== uri;
        }
      }
      return true;
    }
    function addSerializedAttribute(buf, qualifiedName, value) {
      buf.push(" ", qualifiedName, '="', value.replace(/[<>&"\t\n\r]/g, _xmlEncoder), '"');
    }
    function serializeToString(node, buf, isHTML, nodeFilter, visibleNamespaces) {
      if (!visibleNamespaces) {
        visibleNamespaces = [];
      }
      if (nodeFilter) {
        node = nodeFilter(node);
        if (node) {
          if (typeof node == "string") {
            buf.push(node);
            return;
          }
        } else {
          return;
        }
      }
      switch (node.nodeType) {
        case ELEMENT_NODE:
          var attrs = node.attributes;
          var len = attrs.length;
          var child = node.firstChild;
          var nodeName = node.tagName;
          isHTML = NAMESPACE.isHTML(node.namespaceURI) || isHTML;
          var prefixedNodeName = nodeName;
          if (!isHTML && !node.prefix && node.namespaceURI) {
            var defaultNS;
            for (var ai = 0; ai < attrs.length; ai++) {
              if (attrs.item(ai).name === "xmlns") {
                defaultNS = attrs.item(ai).value;
                break;
              }
            }
            if (!defaultNS) {
              for (var nsi = visibleNamespaces.length - 1; nsi >= 0; nsi--) {
                var namespace = visibleNamespaces[nsi];
                if (namespace.prefix === "" && namespace.namespace === node.namespaceURI) {
                  defaultNS = namespace.namespace;
                  break;
                }
              }
            }
            if (defaultNS !== node.namespaceURI) {
              for (var nsi = visibleNamespaces.length - 1; nsi >= 0; nsi--) {
                var namespace = visibleNamespaces[nsi];
                if (namespace.namespace === node.namespaceURI) {
                  if (namespace.prefix) {
                    prefixedNodeName = namespace.prefix + ":" + nodeName;
                  }
                  break;
                }
              }
            }
          }
          buf.push("<", prefixedNodeName);
          for (var i = 0; i < len; i++) {
            var attr = attrs.item(i);
            if (attr.prefix == "xmlns") {
              visibleNamespaces.push({
                prefix: attr.localName,
                namespace: attr.value
              });
            } else if (attr.nodeName == "xmlns") {
              visibleNamespaces.push({
                prefix: "",
                namespace: attr.value
              });
            }
          }
          for (var i = 0; i < len; i++) {
            var attr = attrs.item(i);
            if (needNamespaceDefine(attr, isHTML, visibleNamespaces)) {
              var prefix = attr.prefix || "";
              var uri = attr.namespaceURI;
              addSerializedAttribute(buf, prefix ? "xmlns:" + prefix : "xmlns", uri);
              visibleNamespaces.push({
                prefix,
                namespace: uri
              });
            }
            serializeToString(attr, buf, isHTML, nodeFilter, visibleNamespaces);
          }
          if (nodeName === prefixedNodeName && needNamespaceDefine(node, isHTML, visibleNamespaces)) {
            var prefix = node.prefix || "";
            var uri = node.namespaceURI;
            addSerializedAttribute(buf, prefix ? "xmlns:" + prefix : "xmlns", uri);
            visibleNamespaces.push({
              prefix,
              namespace: uri
            });
          }
          if (child || isHTML && !/^(?:meta|link|img|br|hr|input)$/i.test(nodeName)) {
            buf.push(">");
            if (isHTML && /^script$/i.test(nodeName)) {
              while (child) {
                if (child.data) {
                  buf.push(child.data);
                } else {
                  serializeToString(child, buf, isHTML, nodeFilter, visibleNamespaces.slice());
                }
                child = child.nextSibling;
              }
            } else {
              while (child) {
                serializeToString(child, buf, isHTML, nodeFilter, visibleNamespaces.slice());
                child = child.nextSibling;
              }
            }
            buf.push("</", prefixedNodeName, ">");
          } else {
            buf.push("/>");
          }
          return;
        case DOCUMENT_NODE:
        case DOCUMENT_FRAGMENT_NODE:
          var child = node.firstChild;
          while (child) {
            serializeToString(child, buf, isHTML, nodeFilter, visibleNamespaces.slice());
            child = child.nextSibling;
          }
          return;
        case ATTRIBUTE_NODE:
          return addSerializedAttribute(buf, node.name, node.value);
        case TEXT_NODE:
          return buf.push(node.data.replace(/[<&>]/g, _xmlEncoder));
        case CDATA_SECTION_NODE:
          return buf.push("<![CDATA[", node.data, "]]>");
        case COMMENT_NODE:
          return buf.push("<!--", node.data, "-->");
        case DOCUMENT_TYPE_NODE:
          var pubid = node.publicId;
          var sysid = node.systemId;
          buf.push("<!DOCTYPE ", node.name);
          if (pubid) {
            buf.push(" PUBLIC ", pubid);
            if (sysid && sysid != ".") {
              buf.push(" ", sysid);
            }
            buf.push(">");
          } else if (sysid && sysid != ".") {
            buf.push(" SYSTEM ", sysid, ">");
          } else {
            var sub = node.internalSubset;
            if (sub) {
              buf.push(" [", sub, "]");
            }
            buf.push(">");
          }
          return;
        case PROCESSING_INSTRUCTION_NODE:
          return buf.push("<?", node.target, " ", node.data, "?>");
        case ENTITY_REFERENCE_NODE:
          return buf.push("&", node.nodeName, ";");
        //case ENTITY_NODE:
        //case NOTATION_NODE:
        default:
          buf.push("??", node.nodeName);
      }
    }
    function importNode(doc, node, deep) {
      var node2;
      switch (node.nodeType) {
        case ELEMENT_NODE:
          node2 = node.cloneNode(false);
          node2.ownerDocument = doc;
        //var attrs = node2.attributes;
        //var len = attrs.length;
        //for(var i=0;i<len;i++){
        //node2.setAttributeNodeNS(importNode(doc,attrs.item(i),deep));
        //}
        case DOCUMENT_FRAGMENT_NODE:
          break;
        case ATTRIBUTE_NODE:
          deep = true;
          break;
      }
      if (!node2) {
        node2 = node.cloneNode(false);
      }
      node2.ownerDocument = doc;
      node2.parentNode = null;
      if (deep) {
        var child = node.firstChild;
        while (child) {
          node2.appendChild(importNode(doc, child, deep));
          child = child.nextSibling;
        }
      }
      return node2;
    }
    function cloneNode(doc, node, deep) {
      var node2 = new node.constructor();
      for (var n in node) {
        if (Object.prototype.hasOwnProperty.call(node, n)) {
          var v = node[n];
          if (typeof v != "object") {
            if (v != node2[n]) {
              node2[n] = v;
            }
          }
        }
      }
      if (node.childNodes) {
        node2.childNodes = new NodeList();
      }
      node2.ownerDocument = doc;
      switch (node2.nodeType) {
        case ELEMENT_NODE:
          var attrs = node.attributes;
          var attrs2 = node2.attributes = new NamedNodeMap();
          var len = attrs.length;
          attrs2._ownerElement = node2;
          for (var i = 0; i < len; i++) {
            node2.setAttributeNode(cloneNode(doc, attrs.item(i), true));
          }
          break;
          ;
        case ATTRIBUTE_NODE:
          deep = true;
      }
      if (deep) {
        var child = node.firstChild;
        while (child) {
          node2.appendChild(cloneNode(doc, child, deep));
          child = child.nextSibling;
        }
      }
      return node2;
    }
    function __set__(object2, key, value) {
      object2[key] = value;
    }
    try {
      if (Object.defineProperty) {
        let getTextContent2 = function(node) {
          switch (node.nodeType) {
            case ELEMENT_NODE:
            case DOCUMENT_FRAGMENT_NODE:
              var buf = [];
              node = node.firstChild;
              while (node) {
                if (node.nodeType !== 7 && node.nodeType !== 8) {
                  buf.push(getTextContent2(node));
                }
                node = node.nextSibling;
              }
              return buf.join("");
            default:
              return node.nodeValue;
          }
        };
        getTextContent = getTextContent2;
        Object.defineProperty(LiveNodeList.prototype, "length", {
          get: function() {
            _updateLiveList(this);
            return this.$$length;
          }
        });
        Object.defineProperty(Node.prototype, "textContent", {
          get: function() {
            return getTextContent2(this);
          },
          set: function(data) {
            switch (this.nodeType) {
              case ELEMENT_NODE:
              case DOCUMENT_FRAGMENT_NODE:
                while (this.firstChild) {
                  this.removeChild(this.firstChild);
                }
                if (data || String(data)) {
                  this.appendChild(this.ownerDocument.createTextNode(data));
                }
                break;
              default:
                this.data = data;
                this.value = data;
                this.nodeValue = data;
            }
          }
        });
        __set__ = function(object2, key, value) {
          object2["$$" + key] = value;
        };
      }
    } catch (e) {
    }
    var getTextContent;
    exports2.DocumentType = DocumentType;
    exports2.DOMException = DOMException;
    exports2.DOMImplementation = DOMImplementation;
    exports2.Element = Element;
    exports2.Node = Node;
    exports2.NodeList = NodeList;
    exports2.XMLSerializer = XMLSerializer;
  }
});

// node_modules/@xmldom/xmldom/lib/entities.js
var require_entities = __commonJS({
  "node_modules/@xmldom/xmldom/lib/entities.js"(exports2) {
    "use strict";
    var freeze = require_conventions().freeze;
    exports2.XML_ENTITIES = freeze({
      amp: "&",
      apos: "'",
      gt: ">",
      lt: "<",
      quot: '"'
    });
    exports2.HTML_ENTITIES = freeze({
      Aacute: "Á",
      aacute: "á",
      Abreve: "Ă",
      abreve: "ă",
      ac: "∾",
      acd: "∿",
      acE: "∾̳",
      Acirc: "Â",
      acirc: "â",
      acute: "´",
      Acy: "А",
      acy: "а",
      AElig: "Æ",
      aelig: "æ",
      af: "⁡",
      Afr: "𝔄",
      afr: "𝔞",
      Agrave: "À",
      agrave: "à",
      alefsym: "ℵ",
      aleph: "ℵ",
      Alpha: "Α",
      alpha: "α",
      Amacr: "Ā",
      amacr: "ā",
      amalg: "⨿",
      AMP: "&",
      amp: "&",
      And: "⩓",
      and: "∧",
      andand: "⩕",
      andd: "⩜",
      andslope: "⩘",
      andv: "⩚",
      ang: "∠",
      ange: "⦤",
      angle: "∠",
      angmsd: "∡",
      angmsdaa: "⦨",
      angmsdab: "⦩",
      angmsdac: "⦪",
      angmsdad: "⦫",
      angmsdae: "⦬",
      angmsdaf: "⦭",
      angmsdag: "⦮",
      angmsdah: "⦯",
      angrt: "∟",
      angrtvb: "⊾",
      angrtvbd: "⦝",
      angsph: "∢",
      angst: "Å",
      angzarr: "⍼",
      Aogon: "Ą",
      aogon: "ą",
      Aopf: "𝔸",
      aopf: "𝕒",
      ap: "≈",
      apacir: "⩯",
      apE: "⩰",
      ape: "≊",
      apid: "≋",
      apos: "'",
      ApplyFunction: "⁡",
      approx: "≈",
      approxeq: "≊",
      Aring: "Å",
      aring: "å",
      Ascr: "𝒜",
      ascr: "𝒶",
      Assign: "≔",
      ast: "*",
      asymp: "≈",
      asympeq: "≍",
      Atilde: "Ã",
      atilde: "ã",
      Auml: "Ä",
      auml: "ä",
      awconint: "∳",
      awint: "⨑",
      backcong: "≌",
      backepsilon: "϶",
      backprime: "‵",
      backsim: "∽",
      backsimeq: "⋍",
      Backslash: "∖",
      Barv: "⫧",
      barvee: "⊽",
      Barwed: "⌆",
      barwed: "⌅",
      barwedge: "⌅",
      bbrk: "⎵",
      bbrktbrk: "⎶",
      bcong: "≌",
      Bcy: "Б",
      bcy: "б",
      bdquo: "„",
      becaus: "∵",
      Because: "∵",
      because: "∵",
      bemptyv: "⦰",
      bepsi: "϶",
      bernou: "ℬ",
      Bernoullis: "ℬ",
      Beta: "Β",
      beta: "β",
      beth: "ℶ",
      between: "≬",
      Bfr: "𝔅",
      bfr: "𝔟",
      bigcap: "⋂",
      bigcirc: "◯",
      bigcup: "⋃",
      bigodot: "⨀",
      bigoplus: "⨁",
      bigotimes: "⨂",
      bigsqcup: "⨆",
      bigstar: "★",
      bigtriangledown: "▽",
      bigtriangleup: "△",
      biguplus: "⨄",
      bigvee: "⋁",
      bigwedge: "⋀",
      bkarow: "⤍",
      blacklozenge: "⧫",
      blacksquare: "▪",
      blacktriangle: "▴",
      blacktriangledown: "▾",
      blacktriangleleft: "◂",
      blacktriangleright: "▸",
      blank: "␣",
      blk12: "▒",
      blk14: "░",
      blk34: "▓",
      block: "█",
      bne: "=⃥",
      bnequiv: "≡⃥",
      bNot: "⫭",
      bnot: "⌐",
      Bopf: "𝔹",
      bopf: "𝕓",
      bot: "⊥",
      bottom: "⊥",
      bowtie: "⋈",
      boxbox: "⧉",
      boxDL: "╗",
      boxDl: "╖",
      boxdL: "╕",
      boxdl: "┐",
      boxDR: "╔",
      boxDr: "╓",
      boxdR: "╒",
      boxdr: "┌",
      boxH: "═",
      boxh: "─",
      boxHD: "╦",
      boxHd: "╤",
      boxhD: "╥",
      boxhd: "┬",
      boxHU: "╩",
      boxHu: "╧",
      boxhU: "╨",
      boxhu: "┴",
      boxminus: "⊟",
      boxplus: "⊞",
      boxtimes: "⊠",
      boxUL: "╝",
      boxUl: "╜",
      boxuL: "╛",
      boxul: "┘",
      boxUR: "╚",
      boxUr: "╙",
      boxuR: "╘",
      boxur: "└",
      boxV: "║",
      boxv: "│",
      boxVH: "╬",
      boxVh: "╫",
      boxvH: "╪",
      boxvh: "┼",
      boxVL: "╣",
      boxVl: "╢",
      boxvL: "╡",
      boxvl: "┤",
      boxVR: "╠",
      boxVr: "╟",
      boxvR: "╞",
      boxvr: "├",
      bprime: "‵",
      Breve: "˘",
      breve: "˘",
      brvbar: "¦",
      Bscr: "ℬ",
      bscr: "𝒷",
      bsemi: "⁏",
      bsim: "∽",
      bsime: "⋍",
      bsol: "\\",
      bsolb: "⧅",
      bsolhsub: "⟈",
      bull: "•",
      bullet: "•",
      bump: "≎",
      bumpE: "⪮",
      bumpe: "≏",
      Bumpeq: "≎",
      bumpeq: "≏",
      Cacute: "Ć",
      cacute: "ć",
      Cap: "⋒",
      cap: "∩",
      capand: "⩄",
      capbrcup: "⩉",
      capcap: "⩋",
      capcup: "⩇",
      capdot: "⩀",
      CapitalDifferentialD: "ⅅ",
      caps: "∩︀",
      caret: "⁁",
      caron: "ˇ",
      Cayleys: "ℭ",
      ccaps: "⩍",
      Ccaron: "Č",
      ccaron: "č",
      Ccedil: "Ç",
      ccedil: "ç",
      Ccirc: "Ĉ",
      ccirc: "ĉ",
      Cconint: "∰",
      ccups: "⩌",
      ccupssm: "⩐",
      Cdot: "Ċ",
      cdot: "ċ",
      cedil: "¸",
      Cedilla: "¸",
      cemptyv: "⦲",
      cent: "¢",
      CenterDot: "·",
      centerdot: "·",
      Cfr: "ℭ",
      cfr: "𝔠",
      CHcy: "Ч",
      chcy: "ч",
      check: "✓",
      checkmark: "✓",
      Chi: "Χ",
      chi: "χ",
      cir: "○",
      circ: "ˆ",
      circeq: "≗",
      circlearrowleft: "↺",
      circlearrowright: "↻",
      circledast: "⊛",
      circledcirc: "⊚",
      circleddash: "⊝",
      CircleDot: "⊙",
      circledR: "®",
      circledS: "Ⓢ",
      CircleMinus: "⊖",
      CirclePlus: "⊕",
      CircleTimes: "⊗",
      cirE: "⧃",
      cire: "≗",
      cirfnint: "⨐",
      cirmid: "⫯",
      cirscir: "⧂",
      ClockwiseContourIntegral: "∲",
      CloseCurlyDoubleQuote: "”",
      CloseCurlyQuote: "’",
      clubs: "♣",
      clubsuit: "♣",
      Colon: "∷",
      colon: ":",
      Colone: "⩴",
      colone: "≔",
      coloneq: "≔",
      comma: ",",
      commat: "@",
      comp: "∁",
      compfn: "∘",
      complement: "∁",
      complexes: "ℂ",
      cong: "≅",
      congdot: "⩭",
      Congruent: "≡",
      Conint: "∯",
      conint: "∮",
      ContourIntegral: "∮",
      Copf: "ℂ",
      copf: "𝕔",
      coprod: "∐",
      Coproduct: "∐",
      COPY: "©",
      copy: "©",
      copysr: "℗",
      CounterClockwiseContourIntegral: "∳",
      crarr: "↵",
      Cross: "⨯",
      cross: "✗",
      Cscr: "𝒞",
      cscr: "𝒸",
      csub: "⫏",
      csube: "⫑",
      csup: "⫐",
      csupe: "⫒",
      ctdot: "⋯",
      cudarrl: "⤸",
      cudarrr: "⤵",
      cuepr: "⋞",
      cuesc: "⋟",
      cularr: "↶",
      cularrp: "⤽",
      Cup: "⋓",
      cup: "∪",
      cupbrcap: "⩈",
      CupCap: "≍",
      cupcap: "⩆",
      cupcup: "⩊",
      cupdot: "⊍",
      cupor: "⩅",
      cups: "∪︀",
      curarr: "↷",
      curarrm: "⤼",
      curlyeqprec: "⋞",
      curlyeqsucc: "⋟",
      curlyvee: "⋎",
      curlywedge: "⋏",
      curren: "¤",
      curvearrowleft: "↶",
      curvearrowright: "↷",
      cuvee: "⋎",
      cuwed: "⋏",
      cwconint: "∲",
      cwint: "∱",
      cylcty: "⌭",
      Dagger: "‡",
      dagger: "†",
      daleth: "ℸ",
      Darr: "↡",
      dArr: "⇓",
      darr: "↓",
      dash: "‐",
      Dashv: "⫤",
      dashv: "⊣",
      dbkarow: "⤏",
      dblac: "˝",
      Dcaron: "Ď",
      dcaron: "ď",
      Dcy: "Д",
      dcy: "д",
      DD: "ⅅ",
      dd: "ⅆ",
      ddagger: "‡",
      ddarr: "⇊",
      DDotrahd: "⤑",
      ddotseq: "⩷",
      deg: "°",
      Del: "∇",
      Delta: "Δ",
      delta: "δ",
      demptyv: "⦱",
      dfisht: "⥿",
      Dfr: "𝔇",
      dfr: "𝔡",
      dHar: "⥥",
      dharl: "⇃",
      dharr: "⇂",
      DiacriticalAcute: "´",
      DiacriticalDot: "˙",
      DiacriticalDoubleAcute: "˝",
      DiacriticalGrave: "`",
      DiacriticalTilde: "˜",
      diam: "⋄",
      Diamond: "⋄",
      diamond: "⋄",
      diamondsuit: "♦",
      diams: "♦",
      die: "¨",
      DifferentialD: "ⅆ",
      digamma: "ϝ",
      disin: "⋲",
      div: "÷",
      divide: "÷",
      divideontimes: "⋇",
      divonx: "⋇",
      DJcy: "Ђ",
      djcy: "ђ",
      dlcorn: "⌞",
      dlcrop: "⌍",
      dollar: "$",
      Dopf: "𝔻",
      dopf: "𝕕",
      Dot: "¨",
      dot: "˙",
      DotDot: "⃜",
      doteq: "≐",
      doteqdot: "≑",
      DotEqual: "≐",
      dotminus: "∸",
      dotplus: "∔",
      dotsquare: "⊡",
      doublebarwedge: "⌆",
      DoubleContourIntegral: "∯",
      DoubleDot: "¨",
      DoubleDownArrow: "⇓",
      DoubleLeftArrow: "⇐",
      DoubleLeftRightArrow: "⇔",
      DoubleLeftTee: "⫤",
      DoubleLongLeftArrow: "⟸",
      DoubleLongLeftRightArrow: "⟺",
      DoubleLongRightArrow: "⟹",
      DoubleRightArrow: "⇒",
      DoubleRightTee: "⊨",
      DoubleUpArrow: "⇑",
      DoubleUpDownArrow: "⇕",
      DoubleVerticalBar: "∥",
      DownArrow: "↓",
      Downarrow: "⇓",
      downarrow: "↓",
      DownArrowBar: "⤓",
      DownArrowUpArrow: "⇵",
      DownBreve: "̑",
      downdownarrows: "⇊",
      downharpoonleft: "⇃",
      downharpoonright: "⇂",
      DownLeftRightVector: "⥐",
      DownLeftTeeVector: "⥞",
      DownLeftVector: "↽",
      DownLeftVectorBar: "⥖",
      DownRightTeeVector: "⥟",
      DownRightVector: "⇁",
      DownRightVectorBar: "⥗",
      DownTee: "⊤",
      DownTeeArrow: "↧",
      drbkarow: "⤐",
      drcorn: "⌟",
      drcrop: "⌌",
      Dscr: "𝒟",
      dscr: "𝒹",
      DScy: "Ѕ",
      dscy: "ѕ",
      dsol: "⧶",
      Dstrok: "Đ",
      dstrok: "đ",
      dtdot: "⋱",
      dtri: "▿",
      dtrif: "▾",
      duarr: "⇵",
      duhar: "⥯",
      dwangle: "⦦",
      DZcy: "Џ",
      dzcy: "џ",
      dzigrarr: "⟿",
      Eacute: "É",
      eacute: "é",
      easter: "⩮",
      Ecaron: "Ě",
      ecaron: "ě",
      ecir: "≖",
      Ecirc: "Ê",
      ecirc: "ê",
      ecolon: "≕",
      Ecy: "Э",
      ecy: "э",
      eDDot: "⩷",
      Edot: "Ė",
      eDot: "≑",
      edot: "ė",
      ee: "ⅇ",
      efDot: "≒",
      Efr: "𝔈",
      efr: "𝔢",
      eg: "⪚",
      Egrave: "È",
      egrave: "è",
      egs: "⪖",
      egsdot: "⪘",
      el: "⪙",
      Element: "∈",
      elinters: "⏧",
      ell: "ℓ",
      els: "⪕",
      elsdot: "⪗",
      Emacr: "Ē",
      emacr: "ē",
      empty: "∅",
      emptyset: "∅",
      EmptySmallSquare: "◻",
      emptyv: "∅",
      EmptyVerySmallSquare: "▫",
      emsp: " ",
      emsp13: " ",
      emsp14: " ",
      ENG: "Ŋ",
      eng: "ŋ",
      ensp: " ",
      Eogon: "Ę",
      eogon: "ę",
      Eopf: "𝔼",
      eopf: "𝕖",
      epar: "⋕",
      eparsl: "⧣",
      eplus: "⩱",
      epsi: "ε",
      Epsilon: "Ε",
      epsilon: "ε",
      epsiv: "ϵ",
      eqcirc: "≖",
      eqcolon: "≕",
      eqsim: "≂",
      eqslantgtr: "⪖",
      eqslantless: "⪕",
      Equal: "⩵",
      equals: "=",
      EqualTilde: "≂",
      equest: "≟",
      Equilibrium: "⇌",
      equiv: "≡",
      equivDD: "⩸",
      eqvparsl: "⧥",
      erarr: "⥱",
      erDot: "≓",
      Escr: "ℰ",
      escr: "ℯ",
      esdot: "≐",
      Esim: "⩳",
      esim: "≂",
      Eta: "Η",
      eta: "η",
      ETH: "Ð",
      eth: "ð",
      Euml: "Ë",
      euml: "ë",
      euro: "€",
      excl: "!",
      exist: "∃",
      Exists: "∃",
      expectation: "ℰ",
      ExponentialE: "ⅇ",
      exponentiale: "ⅇ",
      fallingdotseq: "≒",
      Fcy: "Ф",
      fcy: "ф",
      female: "♀",
      ffilig: "ﬃ",
      fflig: "ﬀ",
      ffllig: "ﬄ",
      Ffr: "𝔉",
      ffr: "𝔣",
      filig: "ﬁ",
      FilledSmallSquare: "◼",
      FilledVerySmallSquare: "▪",
      fjlig: "fj",
      flat: "♭",
      fllig: "ﬂ",
      fltns: "▱",
      fnof: "ƒ",
      Fopf: "𝔽",
      fopf: "𝕗",
      ForAll: "∀",
      forall: "∀",
      fork: "⋔",
      forkv: "⫙",
      Fouriertrf: "ℱ",
      fpartint: "⨍",
      frac12: "½",
      frac13: "⅓",
      frac14: "¼",
      frac15: "⅕",
      frac16: "⅙",
      frac18: "⅛",
      frac23: "⅔",
      frac25: "⅖",
      frac34: "¾",
      frac35: "⅗",
      frac38: "⅜",
      frac45: "⅘",
      frac56: "⅚",
      frac58: "⅝",
      frac78: "⅞",
      frasl: "⁄",
      frown: "⌢",
      Fscr: "ℱ",
      fscr: "𝒻",
      gacute: "ǵ",
      Gamma: "Γ",
      gamma: "γ",
      Gammad: "Ϝ",
      gammad: "ϝ",
      gap: "⪆",
      Gbreve: "Ğ",
      gbreve: "ğ",
      Gcedil: "Ģ",
      Gcirc: "Ĝ",
      gcirc: "ĝ",
      Gcy: "Г",
      gcy: "г",
      Gdot: "Ġ",
      gdot: "ġ",
      gE: "≧",
      ge: "≥",
      gEl: "⪌",
      gel: "⋛",
      geq: "≥",
      geqq: "≧",
      geqslant: "⩾",
      ges: "⩾",
      gescc: "⪩",
      gesdot: "⪀",
      gesdoto: "⪂",
      gesdotol: "⪄",
      gesl: "⋛︀",
      gesles: "⪔",
      Gfr: "𝔊",
      gfr: "𝔤",
      Gg: "⋙",
      gg: "≫",
      ggg: "⋙",
      gimel: "ℷ",
      GJcy: "Ѓ",
      gjcy: "ѓ",
      gl: "≷",
      gla: "⪥",
      glE: "⪒",
      glj: "⪤",
      gnap: "⪊",
      gnapprox: "⪊",
      gnE: "≩",
      gne: "⪈",
      gneq: "⪈",
      gneqq: "≩",
      gnsim: "⋧",
      Gopf: "𝔾",
      gopf: "𝕘",
      grave: "`",
      GreaterEqual: "≥",
      GreaterEqualLess: "⋛",
      GreaterFullEqual: "≧",
      GreaterGreater: "⪢",
      GreaterLess: "≷",
      GreaterSlantEqual: "⩾",
      GreaterTilde: "≳",
      Gscr: "𝒢",
      gscr: "ℊ",
      gsim: "≳",
      gsime: "⪎",
      gsiml: "⪐",
      Gt: "≫",
      GT: ">",
      gt: ">",
      gtcc: "⪧",
      gtcir: "⩺",
      gtdot: "⋗",
      gtlPar: "⦕",
      gtquest: "⩼",
      gtrapprox: "⪆",
      gtrarr: "⥸",
      gtrdot: "⋗",
      gtreqless: "⋛",
      gtreqqless: "⪌",
      gtrless: "≷",
      gtrsim: "≳",
      gvertneqq: "≩︀",
      gvnE: "≩︀",
      Hacek: "ˇ",
      hairsp: " ",
      half: "½",
      hamilt: "ℋ",
      HARDcy: "Ъ",
      hardcy: "ъ",
      hArr: "⇔",
      harr: "↔",
      harrcir: "⥈",
      harrw: "↭",
      Hat: "^",
      hbar: "ℏ",
      Hcirc: "Ĥ",
      hcirc: "ĥ",
      hearts: "♥",
      heartsuit: "♥",
      hellip: "…",
      hercon: "⊹",
      Hfr: "ℌ",
      hfr: "𝔥",
      HilbertSpace: "ℋ",
      hksearow: "⤥",
      hkswarow: "⤦",
      hoarr: "⇿",
      homtht: "∻",
      hookleftarrow: "↩",
      hookrightarrow: "↪",
      Hopf: "ℍ",
      hopf: "𝕙",
      horbar: "―",
      HorizontalLine: "─",
      Hscr: "ℋ",
      hscr: "𝒽",
      hslash: "ℏ",
      Hstrok: "Ħ",
      hstrok: "ħ",
      HumpDownHump: "≎",
      HumpEqual: "≏",
      hybull: "⁃",
      hyphen: "‐",
      Iacute: "Í",
      iacute: "í",
      ic: "⁣",
      Icirc: "Î",
      icirc: "î",
      Icy: "И",
      icy: "и",
      Idot: "İ",
      IEcy: "Е",
      iecy: "е",
      iexcl: "¡",
      iff: "⇔",
      Ifr: "ℑ",
      ifr: "𝔦",
      Igrave: "Ì",
      igrave: "ì",
      ii: "ⅈ",
      iiiint: "⨌",
      iiint: "∭",
      iinfin: "⧜",
      iiota: "℩",
      IJlig: "Ĳ",
      ijlig: "ĳ",
      Im: "ℑ",
      Imacr: "Ī",
      imacr: "ī",
      image: "ℑ",
      ImaginaryI: "ⅈ",
      imagline: "ℐ",
      imagpart: "ℑ",
      imath: "ı",
      imof: "⊷",
      imped: "Ƶ",
      Implies: "⇒",
      in: "∈",
      incare: "℅",
      infin: "∞",
      infintie: "⧝",
      inodot: "ı",
      Int: "∬",
      int: "∫",
      intcal: "⊺",
      integers: "ℤ",
      Integral: "∫",
      intercal: "⊺",
      Intersection: "⋂",
      intlarhk: "⨗",
      intprod: "⨼",
      InvisibleComma: "⁣",
      InvisibleTimes: "⁢",
      IOcy: "Ё",
      iocy: "ё",
      Iogon: "Į",
      iogon: "į",
      Iopf: "𝕀",
      iopf: "𝕚",
      Iota: "Ι",
      iota: "ι",
      iprod: "⨼",
      iquest: "¿",
      Iscr: "ℐ",
      iscr: "𝒾",
      isin: "∈",
      isindot: "⋵",
      isinE: "⋹",
      isins: "⋴",
      isinsv: "⋳",
      isinv: "∈",
      it: "⁢",
      Itilde: "Ĩ",
      itilde: "ĩ",
      Iukcy: "І",
      iukcy: "і",
      Iuml: "Ï",
      iuml: "ï",
      Jcirc: "Ĵ",
      jcirc: "ĵ",
      Jcy: "Й",
      jcy: "й",
      Jfr: "𝔍",
      jfr: "𝔧",
      jmath: "ȷ",
      Jopf: "𝕁",
      jopf: "𝕛",
      Jscr: "𝒥",
      jscr: "𝒿",
      Jsercy: "Ј",
      jsercy: "ј",
      Jukcy: "Є",
      jukcy: "є",
      Kappa: "Κ",
      kappa: "κ",
      kappav: "ϰ",
      Kcedil: "Ķ",
      kcedil: "ķ",
      Kcy: "К",
      kcy: "к",
      Kfr: "𝔎",
      kfr: "𝔨",
      kgreen: "ĸ",
      KHcy: "Х",
      khcy: "х",
      KJcy: "Ќ",
      kjcy: "ќ",
      Kopf: "𝕂",
      kopf: "𝕜",
      Kscr: "𝒦",
      kscr: "𝓀",
      lAarr: "⇚",
      Lacute: "Ĺ",
      lacute: "ĺ",
      laemptyv: "⦴",
      lagran: "ℒ",
      Lambda: "Λ",
      lambda: "λ",
      Lang: "⟪",
      lang: "⟨",
      langd: "⦑",
      langle: "⟨",
      lap: "⪅",
      Laplacetrf: "ℒ",
      laquo: "«",
      Larr: "↞",
      lArr: "⇐",
      larr: "←",
      larrb: "⇤",
      larrbfs: "⤟",
      larrfs: "⤝",
      larrhk: "↩",
      larrlp: "↫",
      larrpl: "⤹",
      larrsim: "⥳",
      larrtl: "↢",
      lat: "⪫",
      lAtail: "⤛",
      latail: "⤙",
      late: "⪭",
      lates: "⪭︀",
      lBarr: "⤎",
      lbarr: "⤌",
      lbbrk: "❲",
      lbrace: "{",
      lbrack: "[",
      lbrke: "⦋",
      lbrksld: "⦏",
      lbrkslu: "⦍",
      Lcaron: "Ľ",
      lcaron: "ľ",
      Lcedil: "Ļ",
      lcedil: "ļ",
      lceil: "⌈",
      lcub: "{",
      Lcy: "Л",
      lcy: "л",
      ldca: "⤶",
      ldquo: "“",
      ldquor: "„",
      ldrdhar: "⥧",
      ldrushar: "⥋",
      ldsh: "↲",
      lE: "≦",
      le: "≤",
      LeftAngleBracket: "⟨",
      LeftArrow: "←",
      Leftarrow: "⇐",
      leftarrow: "←",
      LeftArrowBar: "⇤",
      LeftArrowRightArrow: "⇆",
      leftarrowtail: "↢",
      LeftCeiling: "⌈",
      LeftDoubleBracket: "⟦",
      LeftDownTeeVector: "⥡",
      LeftDownVector: "⇃",
      LeftDownVectorBar: "⥙",
      LeftFloor: "⌊",
      leftharpoondown: "↽",
      leftharpoonup: "↼",
      leftleftarrows: "⇇",
      LeftRightArrow: "↔",
      Leftrightarrow: "⇔",
      leftrightarrow: "↔",
      leftrightarrows: "⇆",
      leftrightharpoons: "⇋",
      leftrightsquigarrow: "↭",
      LeftRightVector: "⥎",
      LeftTee: "⊣",
      LeftTeeArrow: "↤",
      LeftTeeVector: "⥚",
      leftthreetimes: "⋋",
      LeftTriangle: "⊲",
      LeftTriangleBar: "⧏",
      LeftTriangleEqual: "⊴",
      LeftUpDownVector: "⥑",
      LeftUpTeeVector: "⥠",
      LeftUpVector: "↿",
      LeftUpVectorBar: "⥘",
      LeftVector: "↼",
      LeftVectorBar: "⥒",
      lEg: "⪋",
      leg: "⋚",
      leq: "≤",
      leqq: "≦",
      leqslant: "⩽",
      les: "⩽",
      lescc: "⪨",
      lesdot: "⩿",
      lesdoto: "⪁",
      lesdotor: "⪃",
      lesg: "⋚︀",
      lesges: "⪓",
      lessapprox: "⪅",
      lessdot: "⋖",
      lesseqgtr: "⋚",
      lesseqqgtr: "⪋",
      LessEqualGreater: "⋚",
      LessFullEqual: "≦",
      LessGreater: "≶",
      lessgtr: "≶",
      LessLess: "⪡",
      lesssim: "≲",
      LessSlantEqual: "⩽",
      LessTilde: "≲",
      lfisht: "⥼",
      lfloor: "⌊",
      Lfr: "𝔏",
      lfr: "𝔩",
      lg: "≶",
      lgE: "⪑",
      lHar: "⥢",
      lhard: "↽",
      lharu: "↼",
      lharul: "⥪",
      lhblk: "▄",
      LJcy: "Љ",
      ljcy: "љ",
      Ll: "⋘",
      ll: "≪",
      llarr: "⇇",
      llcorner: "⌞",
      Lleftarrow: "⇚",
      llhard: "⥫",
      lltri: "◺",
      Lmidot: "Ŀ",
      lmidot: "ŀ",
      lmoust: "⎰",
      lmoustache: "⎰",
      lnap: "⪉",
      lnapprox: "⪉",
      lnE: "≨",
      lne: "⪇",
      lneq: "⪇",
      lneqq: "≨",
      lnsim: "⋦",
      loang: "⟬",
      loarr: "⇽",
      lobrk: "⟦",
      LongLeftArrow: "⟵",
      Longleftarrow: "⟸",
      longleftarrow: "⟵",
      LongLeftRightArrow: "⟷",
      Longleftrightarrow: "⟺",
      longleftrightarrow: "⟷",
      longmapsto: "⟼",
      LongRightArrow: "⟶",
      Longrightarrow: "⟹",
      longrightarrow: "⟶",
      looparrowleft: "↫",
      looparrowright: "↬",
      lopar: "⦅",
      Lopf: "𝕃",
      lopf: "𝕝",
      loplus: "⨭",
      lotimes: "⨴",
      lowast: "∗",
      lowbar: "_",
      LowerLeftArrow: "↙",
      LowerRightArrow: "↘",
      loz: "◊",
      lozenge: "◊",
      lozf: "⧫",
      lpar: "(",
      lparlt: "⦓",
      lrarr: "⇆",
      lrcorner: "⌟",
      lrhar: "⇋",
      lrhard: "⥭",
      lrm: "‎",
      lrtri: "⊿",
      lsaquo: "‹",
      Lscr: "ℒ",
      lscr: "𝓁",
      Lsh: "↰",
      lsh: "↰",
      lsim: "≲",
      lsime: "⪍",
      lsimg: "⪏",
      lsqb: "[",
      lsquo: "‘",
      lsquor: "‚",
      Lstrok: "Ł",
      lstrok: "ł",
      Lt: "≪",
      LT: "<",
      lt: "<",
      ltcc: "⪦",
      ltcir: "⩹",
      ltdot: "⋖",
      lthree: "⋋",
      ltimes: "⋉",
      ltlarr: "⥶",
      ltquest: "⩻",
      ltri: "◃",
      ltrie: "⊴",
      ltrif: "◂",
      ltrPar: "⦖",
      lurdshar: "⥊",
      luruhar: "⥦",
      lvertneqq: "≨︀",
      lvnE: "≨︀",
      macr: "¯",
      male: "♂",
      malt: "✠",
      maltese: "✠",
      Map: "⤅",
      map: "↦",
      mapsto: "↦",
      mapstodown: "↧",
      mapstoleft: "↤",
      mapstoup: "↥",
      marker: "▮",
      mcomma: "⨩",
      Mcy: "М",
      mcy: "м",
      mdash: "—",
      mDDot: "∺",
      measuredangle: "∡",
      MediumSpace: " ",
      Mellintrf: "ℳ",
      Mfr: "𝔐",
      mfr: "𝔪",
      mho: "℧",
      micro: "µ",
      mid: "∣",
      midast: "*",
      midcir: "⫰",
      middot: "·",
      minus: "−",
      minusb: "⊟",
      minusd: "∸",
      minusdu: "⨪",
      MinusPlus: "∓",
      mlcp: "⫛",
      mldr: "…",
      mnplus: "∓",
      models: "⊧",
      Mopf: "𝕄",
      mopf: "𝕞",
      mp: "∓",
      Mscr: "ℳ",
      mscr: "𝓂",
      mstpos: "∾",
      Mu: "Μ",
      mu: "μ",
      multimap: "⊸",
      mumap: "⊸",
      nabla: "∇",
      Nacute: "Ń",
      nacute: "ń",
      nang: "∠⃒",
      nap: "≉",
      napE: "⩰̸",
      napid: "≋̸",
      napos: "ŉ",
      napprox: "≉",
      natur: "♮",
      natural: "♮",
      naturals: "ℕ",
      nbsp: " ",
      nbump: "≎̸",
      nbumpe: "≏̸",
      ncap: "⩃",
      Ncaron: "Ň",
      ncaron: "ň",
      Ncedil: "Ņ",
      ncedil: "ņ",
      ncong: "≇",
      ncongdot: "⩭̸",
      ncup: "⩂",
      Ncy: "Н",
      ncy: "н",
      ndash: "–",
      ne: "≠",
      nearhk: "⤤",
      neArr: "⇗",
      nearr: "↗",
      nearrow: "↗",
      nedot: "≐̸",
      NegativeMediumSpace: "​",
      NegativeThickSpace: "​",
      NegativeThinSpace: "​",
      NegativeVeryThinSpace: "​",
      nequiv: "≢",
      nesear: "⤨",
      nesim: "≂̸",
      NestedGreaterGreater: "≫",
      NestedLessLess: "≪",
      NewLine: "\n",
      nexist: "∄",
      nexists: "∄",
      Nfr: "𝔑",
      nfr: "𝔫",
      ngE: "≧̸",
      nge: "≱",
      ngeq: "≱",
      ngeqq: "≧̸",
      ngeqslant: "⩾̸",
      nges: "⩾̸",
      nGg: "⋙̸",
      ngsim: "≵",
      nGt: "≫⃒",
      ngt: "≯",
      ngtr: "≯",
      nGtv: "≫̸",
      nhArr: "⇎",
      nharr: "↮",
      nhpar: "⫲",
      ni: "∋",
      nis: "⋼",
      nisd: "⋺",
      niv: "∋",
      NJcy: "Њ",
      njcy: "њ",
      nlArr: "⇍",
      nlarr: "↚",
      nldr: "‥",
      nlE: "≦̸",
      nle: "≰",
      nLeftarrow: "⇍",
      nleftarrow: "↚",
      nLeftrightarrow: "⇎",
      nleftrightarrow: "↮",
      nleq: "≰",
      nleqq: "≦̸",
      nleqslant: "⩽̸",
      nles: "⩽̸",
      nless: "≮",
      nLl: "⋘̸",
      nlsim: "≴",
      nLt: "≪⃒",
      nlt: "≮",
      nltri: "⋪",
      nltrie: "⋬",
      nLtv: "≪̸",
      nmid: "∤",
      NoBreak: "⁠",
      NonBreakingSpace: " ",
      Nopf: "ℕ",
      nopf: "𝕟",
      Not: "⫬",
      not: "¬",
      NotCongruent: "≢",
      NotCupCap: "≭",
      NotDoubleVerticalBar: "∦",
      NotElement: "∉",
      NotEqual: "≠",
      NotEqualTilde: "≂̸",
      NotExists: "∄",
      NotGreater: "≯",
      NotGreaterEqual: "≱",
      NotGreaterFullEqual: "≧̸",
      NotGreaterGreater: "≫̸",
      NotGreaterLess: "≹",
      NotGreaterSlantEqual: "⩾̸",
      NotGreaterTilde: "≵",
      NotHumpDownHump: "≎̸",
      NotHumpEqual: "≏̸",
      notin: "∉",
      notindot: "⋵̸",
      notinE: "⋹̸",
      notinva: "∉",
      notinvb: "⋷",
      notinvc: "⋶",
      NotLeftTriangle: "⋪",
      NotLeftTriangleBar: "⧏̸",
      NotLeftTriangleEqual: "⋬",
      NotLess: "≮",
      NotLessEqual: "≰",
      NotLessGreater: "≸",
      NotLessLess: "≪̸",
      NotLessSlantEqual: "⩽̸",
      NotLessTilde: "≴",
      NotNestedGreaterGreater: "⪢̸",
      NotNestedLessLess: "⪡̸",
      notni: "∌",
      notniva: "∌",
      notnivb: "⋾",
      notnivc: "⋽",
      NotPrecedes: "⊀",
      NotPrecedesEqual: "⪯̸",
      NotPrecedesSlantEqual: "⋠",
      NotReverseElement: "∌",
      NotRightTriangle: "⋫",
      NotRightTriangleBar: "⧐̸",
      NotRightTriangleEqual: "⋭",
      NotSquareSubset: "⊏̸",
      NotSquareSubsetEqual: "⋢",
      NotSquareSuperset: "⊐̸",
      NotSquareSupersetEqual: "⋣",
      NotSubset: "⊂⃒",
      NotSubsetEqual: "⊈",
      NotSucceeds: "⊁",
      NotSucceedsEqual: "⪰̸",
      NotSucceedsSlantEqual: "⋡",
      NotSucceedsTilde: "≿̸",
      NotSuperset: "⊃⃒",
      NotSupersetEqual: "⊉",
      NotTilde: "≁",
      NotTildeEqual: "≄",
      NotTildeFullEqual: "≇",
      NotTildeTilde: "≉",
      NotVerticalBar: "∤",
      npar: "∦",
      nparallel: "∦",
      nparsl: "⫽⃥",
      npart: "∂̸",
      npolint: "⨔",
      npr: "⊀",
      nprcue: "⋠",
      npre: "⪯̸",
      nprec: "⊀",
      npreceq: "⪯̸",
      nrArr: "⇏",
      nrarr: "↛",
      nrarrc: "⤳̸",
      nrarrw: "↝̸",
      nRightarrow: "⇏",
      nrightarrow: "↛",
      nrtri: "⋫",
      nrtrie: "⋭",
      nsc: "⊁",
      nsccue: "⋡",
      nsce: "⪰̸",
      Nscr: "𝒩",
      nscr: "𝓃",
      nshortmid: "∤",
      nshortparallel: "∦",
      nsim: "≁",
      nsime: "≄",
      nsimeq: "≄",
      nsmid: "∤",
      nspar: "∦",
      nsqsube: "⋢",
      nsqsupe: "⋣",
      nsub: "⊄",
      nsubE: "⫅̸",
      nsube: "⊈",
      nsubset: "⊂⃒",
      nsubseteq: "⊈",
      nsubseteqq: "⫅̸",
      nsucc: "⊁",
      nsucceq: "⪰̸",
      nsup: "⊅",
      nsupE: "⫆̸",
      nsupe: "⊉",
      nsupset: "⊃⃒",
      nsupseteq: "⊉",
      nsupseteqq: "⫆̸",
      ntgl: "≹",
      Ntilde: "Ñ",
      ntilde: "ñ",
      ntlg: "≸",
      ntriangleleft: "⋪",
      ntrianglelefteq: "⋬",
      ntriangleright: "⋫",
      ntrianglerighteq: "⋭",
      Nu: "Ν",
      nu: "ν",
      num: "#",
      numero: "№",
      numsp: " ",
      nvap: "≍⃒",
      nVDash: "⊯",
      nVdash: "⊮",
      nvDash: "⊭",
      nvdash: "⊬",
      nvge: "≥⃒",
      nvgt: ">⃒",
      nvHarr: "⤄",
      nvinfin: "⧞",
      nvlArr: "⤂",
      nvle: "≤⃒",
      nvlt: "<⃒",
      nvltrie: "⊴⃒",
      nvrArr: "⤃",
      nvrtrie: "⊵⃒",
      nvsim: "∼⃒",
      nwarhk: "⤣",
      nwArr: "⇖",
      nwarr: "↖",
      nwarrow: "↖",
      nwnear: "⤧",
      Oacute: "Ó",
      oacute: "ó",
      oast: "⊛",
      ocir: "⊚",
      Ocirc: "Ô",
      ocirc: "ô",
      Ocy: "О",
      ocy: "о",
      odash: "⊝",
      Odblac: "Ő",
      odblac: "ő",
      odiv: "⨸",
      odot: "⊙",
      odsold: "⦼",
      OElig: "Œ",
      oelig: "œ",
      ofcir: "⦿",
      Ofr: "𝔒",
      ofr: "𝔬",
      ogon: "˛",
      Ograve: "Ò",
      ograve: "ò",
      ogt: "⧁",
      ohbar: "⦵",
      ohm: "Ω",
      oint: "∮",
      olarr: "↺",
      olcir: "⦾",
      olcross: "⦻",
      oline: "‾",
      olt: "⧀",
      Omacr: "Ō",
      omacr: "ō",
      Omega: "Ω",
      omega: "ω",
      Omicron: "Ο",
      omicron: "ο",
      omid: "⦶",
      ominus: "⊖",
      Oopf: "𝕆",
      oopf: "𝕠",
      opar: "⦷",
      OpenCurlyDoubleQuote: "“",
      OpenCurlyQuote: "‘",
      operp: "⦹",
      oplus: "⊕",
      Or: "⩔",
      or: "∨",
      orarr: "↻",
      ord: "⩝",
      order: "ℴ",
      orderof: "ℴ",
      ordf: "ª",
      ordm: "º",
      origof: "⊶",
      oror: "⩖",
      orslope: "⩗",
      orv: "⩛",
      oS: "Ⓢ",
      Oscr: "𝒪",
      oscr: "ℴ",
      Oslash: "Ø",
      oslash: "ø",
      osol: "⊘",
      Otilde: "Õ",
      otilde: "õ",
      Otimes: "⨷",
      otimes: "⊗",
      otimesas: "⨶",
      Ouml: "Ö",
      ouml: "ö",
      ovbar: "⌽",
      OverBar: "‾",
      OverBrace: "⏞",
      OverBracket: "⎴",
      OverParenthesis: "⏜",
      par: "∥",
      para: "¶",
      parallel: "∥",
      parsim: "⫳",
      parsl: "⫽",
      part: "∂",
      PartialD: "∂",
      Pcy: "П",
      pcy: "п",
      percnt: "%",
      period: ".",
      permil: "‰",
      perp: "⊥",
      pertenk: "‱",
      Pfr: "𝔓",
      pfr: "𝔭",
      Phi: "Φ",
      phi: "φ",
      phiv: "ϕ",
      phmmat: "ℳ",
      phone: "☎",
      Pi: "Π",
      pi: "π",
      pitchfork: "⋔",
      piv: "ϖ",
      planck: "ℏ",
      planckh: "ℎ",
      plankv: "ℏ",
      plus: "+",
      plusacir: "⨣",
      plusb: "⊞",
      pluscir: "⨢",
      plusdo: "∔",
      plusdu: "⨥",
      pluse: "⩲",
      PlusMinus: "±",
      plusmn: "±",
      plussim: "⨦",
      plustwo: "⨧",
      pm: "±",
      Poincareplane: "ℌ",
      pointint: "⨕",
      Popf: "ℙ",
      popf: "𝕡",
      pound: "£",
      Pr: "⪻",
      pr: "≺",
      prap: "⪷",
      prcue: "≼",
      prE: "⪳",
      pre: "⪯",
      prec: "≺",
      precapprox: "⪷",
      preccurlyeq: "≼",
      Precedes: "≺",
      PrecedesEqual: "⪯",
      PrecedesSlantEqual: "≼",
      PrecedesTilde: "≾",
      preceq: "⪯",
      precnapprox: "⪹",
      precneqq: "⪵",
      precnsim: "⋨",
      precsim: "≾",
      Prime: "″",
      prime: "′",
      primes: "ℙ",
      prnap: "⪹",
      prnE: "⪵",
      prnsim: "⋨",
      prod: "∏",
      Product: "∏",
      profalar: "⌮",
      profline: "⌒",
      profsurf: "⌓",
      prop: "∝",
      Proportion: "∷",
      Proportional: "∝",
      propto: "∝",
      prsim: "≾",
      prurel: "⊰",
      Pscr: "𝒫",
      pscr: "𝓅",
      Psi: "Ψ",
      psi: "ψ",
      puncsp: " ",
      Qfr: "𝔔",
      qfr: "𝔮",
      qint: "⨌",
      Qopf: "ℚ",
      qopf: "𝕢",
      qprime: "⁗",
      Qscr: "𝒬",
      qscr: "𝓆",
      quaternions: "ℍ",
      quatint: "⨖",
      quest: "?",
      questeq: "≟",
      QUOT: '"',
      quot: '"',
      rAarr: "⇛",
      race: "∽̱",
      Racute: "Ŕ",
      racute: "ŕ",
      radic: "√",
      raemptyv: "⦳",
      Rang: "⟫",
      rang: "⟩",
      rangd: "⦒",
      range: "⦥",
      rangle: "⟩",
      raquo: "»",
      Rarr: "↠",
      rArr: "⇒",
      rarr: "→",
      rarrap: "⥵",
      rarrb: "⇥",
      rarrbfs: "⤠",
      rarrc: "⤳",
      rarrfs: "⤞",
      rarrhk: "↪",
      rarrlp: "↬",
      rarrpl: "⥅",
      rarrsim: "⥴",
      Rarrtl: "⤖",
      rarrtl: "↣",
      rarrw: "↝",
      rAtail: "⤜",
      ratail: "⤚",
      ratio: "∶",
      rationals: "ℚ",
      RBarr: "⤐",
      rBarr: "⤏",
      rbarr: "⤍",
      rbbrk: "❳",
      rbrace: "}",
      rbrack: "]",
      rbrke: "⦌",
      rbrksld: "⦎",
      rbrkslu: "⦐",
      Rcaron: "Ř",
      rcaron: "ř",
      Rcedil: "Ŗ",
      rcedil: "ŗ",
      rceil: "⌉",
      rcub: "}",
      Rcy: "Р",
      rcy: "р",
      rdca: "⤷",
      rdldhar: "⥩",
      rdquo: "”",
      rdquor: "”",
      rdsh: "↳",
      Re: "ℜ",
      real: "ℜ",
      realine: "ℛ",
      realpart: "ℜ",
      reals: "ℝ",
      rect: "▭",
      REG: "®",
      reg: "®",
      ReverseElement: "∋",
      ReverseEquilibrium: "⇋",
      ReverseUpEquilibrium: "⥯",
      rfisht: "⥽",
      rfloor: "⌋",
      Rfr: "ℜ",
      rfr: "𝔯",
      rHar: "⥤",
      rhard: "⇁",
      rharu: "⇀",
      rharul: "⥬",
      Rho: "Ρ",
      rho: "ρ",
      rhov: "ϱ",
      RightAngleBracket: "⟩",
      RightArrow: "→",
      Rightarrow: "⇒",
      rightarrow: "→",
      RightArrowBar: "⇥",
      RightArrowLeftArrow: "⇄",
      rightarrowtail: "↣",
      RightCeiling: "⌉",
      RightDoubleBracket: "⟧",
      RightDownTeeVector: "⥝",
      RightDownVector: "⇂",
      RightDownVectorBar: "⥕",
      RightFloor: "⌋",
      rightharpoondown: "⇁",
      rightharpoonup: "⇀",
      rightleftarrows: "⇄",
      rightleftharpoons: "⇌",
      rightrightarrows: "⇉",
      rightsquigarrow: "↝",
      RightTee: "⊢",
      RightTeeArrow: "↦",
      RightTeeVector: "⥛",
      rightthreetimes: "⋌",
      RightTriangle: "⊳",
      RightTriangleBar: "⧐",
      RightTriangleEqual: "⊵",
      RightUpDownVector: "⥏",
      RightUpTeeVector: "⥜",
      RightUpVector: "↾",
      RightUpVectorBar: "⥔",
      RightVector: "⇀",
      RightVectorBar: "⥓",
      ring: "˚",
      risingdotseq: "≓",
      rlarr: "⇄",
      rlhar: "⇌",
      rlm: "‏",
      rmoust: "⎱",
      rmoustache: "⎱",
      rnmid: "⫮",
      roang: "⟭",
      roarr: "⇾",
      robrk: "⟧",
      ropar: "⦆",
      Ropf: "ℝ",
      ropf: "𝕣",
      roplus: "⨮",
      rotimes: "⨵",
      RoundImplies: "⥰",
      rpar: ")",
      rpargt: "⦔",
      rppolint: "⨒",
      rrarr: "⇉",
      Rrightarrow: "⇛",
      rsaquo: "›",
      Rscr: "ℛ",
      rscr: "𝓇",
      Rsh: "↱",
      rsh: "↱",
      rsqb: "]",
      rsquo: "’",
      rsquor: "’",
      rthree: "⋌",
      rtimes: "⋊",
      rtri: "▹",
      rtrie: "⊵",
      rtrif: "▸",
      rtriltri: "⧎",
      RuleDelayed: "⧴",
      ruluhar: "⥨",
      rx: "℞",
      Sacute: "Ś",
      sacute: "ś",
      sbquo: "‚",
      Sc: "⪼",
      sc: "≻",
      scap: "⪸",
      Scaron: "Š",
      scaron: "š",
      sccue: "≽",
      scE: "⪴",
      sce: "⪰",
      Scedil: "Ş",
      scedil: "ş",
      Scirc: "Ŝ",
      scirc: "ŝ",
      scnap: "⪺",
      scnE: "⪶",
      scnsim: "⋩",
      scpolint: "⨓",
      scsim: "≿",
      Scy: "С",
      scy: "с",
      sdot: "⋅",
      sdotb: "⊡",
      sdote: "⩦",
      searhk: "⤥",
      seArr: "⇘",
      searr: "↘",
      searrow: "↘",
      sect: "§",
      semi: ";",
      seswar: "⤩",
      setminus: "∖",
      setmn: "∖",
      sext: "✶",
      Sfr: "𝔖",
      sfr: "𝔰",
      sfrown: "⌢",
      sharp: "♯",
      SHCHcy: "Щ",
      shchcy: "щ",
      SHcy: "Ш",
      shcy: "ш",
      ShortDownArrow: "↓",
      ShortLeftArrow: "←",
      shortmid: "∣",
      shortparallel: "∥",
      ShortRightArrow: "→",
      ShortUpArrow: "↑",
      shy: "­",
      Sigma: "Σ",
      sigma: "σ",
      sigmaf: "ς",
      sigmav: "ς",
      sim: "∼",
      simdot: "⩪",
      sime: "≃",
      simeq: "≃",
      simg: "⪞",
      simgE: "⪠",
      siml: "⪝",
      simlE: "⪟",
      simne: "≆",
      simplus: "⨤",
      simrarr: "⥲",
      slarr: "←",
      SmallCircle: "∘",
      smallsetminus: "∖",
      smashp: "⨳",
      smeparsl: "⧤",
      smid: "∣",
      smile: "⌣",
      smt: "⪪",
      smte: "⪬",
      smtes: "⪬︀",
      SOFTcy: "Ь",
      softcy: "ь",
      sol: "/",
      solb: "⧄",
      solbar: "⌿",
      Sopf: "𝕊",
      sopf: "𝕤",
      spades: "♠",
      spadesuit: "♠",
      spar: "∥",
      sqcap: "⊓",
      sqcaps: "⊓︀",
      sqcup: "⊔",
      sqcups: "⊔︀",
      Sqrt: "√",
      sqsub: "⊏",
      sqsube: "⊑",
      sqsubset: "⊏",
      sqsubseteq: "⊑",
      sqsup: "⊐",
      sqsupe: "⊒",
      sqsupset: "⊐",
      sqsupseteq: "⊒",
      squ: "□",
      Square: "□",
      square: "□",
      SquareIntersection: "⊓",
      SquareSubset: "⊏",
      SquareSubsetEqual: "⊑",
      SquareSuperset: "⊐",
      SquareSupersetEqual: "⊒",
      SquareUnion: "⊔",
      squarf: "▪",
      squf: "▪",
      srarr: "→",
      Sscr: "𝒮",
      sscr: "𝓈",
      ssetmn: "∖",
      ssmile: "⌣",
      sstarf: "⋆",
      Star: "⋆",
      star: "☆",
      starf: "★",
      straightepsilon: "ϵ",
      straightphi: "ϕ",
      strns: "¯",
      Sub: "⋐",
      sub: "⊂",
      subdot: "⪽",
      subE: "⫅",
      sube: "⊆",
      subedot: "⫃",
      submult: "⫁",
      subnE: "⫋",
      subne: "⊊",
      subplus: "⪿",
      subrarr: "⥹",
      Subset: "⋐",
      subset: "⊂",
      subseteq: "⊆",
      subseteqq: "⫅",
      SubsetEqual: "⊆",
      subsetneq: "⊊",
      subsetneqq: "⫋",
      subsim: "⫇",
      subsub: "⫕",
      subsup: "⫓",
      succ: "≻",
      succapprox: "⪸",
      succcurlyeq: "≽",
      Succeeds: "≻",
      SucceedsEqual: "⪰",
      SucceedsSlantEqual: "≽",
      SucceedsTilde: "≿",
      succeq: "⪰",
      succnapprox: "⪺",
      succneqq: "⪶",
      succnsim: "⋩",
      succsim: "≿",
      SuchThat: "∋",
      Sum: "∑",
      sum: "∑",
      sung: "♪",
      Sup: "⋑",
      sup: "⊃",
      sup1: "¹",
      sup2: "²",
      sup3: "³",
      supdot: "⪾",
      supdsub: "⫘",
      supE: "⫆",
      supe: "⊇",
      supedot: "⫄",
      Superset: "⊃",
      SupersetEqual: "⊇",
      suphsol: "⟉",
      suphsub: "⫗",
      suplarr: "⥻",
      supmult: "⫂",
      supnE: "⫌",
      supne: "⊋",
      supplus: "⫀",
      Supset: "⋑",
      supset: "⊃",
      supseteq: "⊇",
      supseteqq: "⫆",
      supsetneq: "⊋",
      supsetneqq: "⫌",
      supsim: "⫈",
      supsub: "⫔",
      supsup: "⫖",
      swarhk: "⤦",
      swArr: "⇙",
      swarr: "↙",
      swarrow: "↙",
      swnwar: "⤪",
      szlig: "ß",
      Tab: "	",
      target: "⌖",
      Tau: "Τ",
      tau: "τ",
      tbrk: "⎴",
      Tcaron: "Ť",
      tcaron: "ť",
      Tcedil: "Ţ",
      tcedil: "ţ",
      Tcy: "Т",
      tcy: "т",
      tdot: "⃛",
      telrec: "⌕",
      Tfr: "𝔗",
      tfr: "𝔱",
      there4: "∴",
      Therefore: "∴",
      therefore: "∴",
      Theta: "Θ",
      theta: "θ",
      thetasym: "ϑ",
      thetav: "ϑ",
      thickapprox: "≈",
      thicksim: "∼",
      ThickSpace: "  ",
      thinsp: " ",
      ThinSpace: " ",
      thkap: "≈",
      thksim: "∼",
      THORN: "Þ",
      thorn: "þ",
      Tilde: "∼",
      tilde: "˜",
      TildeEqual: "≃",
      TildeFullEqual: "≅",
      TildeTilde: "≈",
      times: "×",
      timesb: "⊠",
      timesbar: "⨱",
      timesd: "⨰",
      tint: "∭",
      toea: "⤨",
      top: "⊤",
      topbot: "⌶",
      topcir: "⫱",
      Topf: "𝕋",
      topf: "𝕥",
      topfork: "⫚",
      tosa: "⤩",
      tprime: "‴",
      TRADE: "™",
      trade: "™",
      triangle: "▵",
      triangledown: "▿",
      triangleleft: "◃",
      trianglelefteq: "⊴",
      triangleq: "≜",
      triangleright: "▹",
      trianglerighteq: "⊵",
      tridot: "◬",
      trie: "≜",
      triminus: "⨺",
      TripleDot: "⃛",
      triplus: "⨹",
      trisb: "⧍",
      tritime: "⨻",
      trpezium: "⏢",
      Tscr: "𝒯",
      tscr: "𝓉",
      TScy: "Ц",
      tscy: "ц",
      TSHcy: "Ћ",
      tshcy: "ћ",
      Tstrok: "Ŧ",
      tstrok: "ŧ",
      twixt: "≬",
      twoheadleftarrow: "↞",
      twoheadrightarrow: "↠",
      Uacute: "Ú",
      uacute: "ú",
      Uarr: "↟",
      uArr: "⇑",
      uarr: "↑",
      Uarrocir: "⥉",
      Ubrcy: "Ў",
      ubrcy: "ў",
      Ubreve: "Ŭ",
      ubreve: "ŭ",
      Ucirc: "Û",
      ucirc: "û",
      Ucy: "У",
      ucy: "у",
      udarr: "⇅",
      Udblac: "Ű",
      udblac: "ű",
      udhar: "⥮",
      ufisht: "⥾",
      Ufr: "𝔘",
      ufr: "𝔲",
      Ugrave: "Ù",
      ugrave: "ù",
      uHar: "⥣",
      uharl: "↿",
      uharr: "↾",
      uhblk: "▀",
      ulcorn: "⌜",
      ulcorner: "⌜",
      ulcrop: "⌏",
      ultri: "◸",
      Umacr: "Ū",
      umacr: "ū",
      uml: "¨",
      UnderBar: "_",
      UnderBrace: "⏟",
      UnderBracket: "⎵",
      UnderParenthesis: "⏝",
      Union: "⋃",
      UnionPlus: "⊎",
      Uogon: "Ų",
      uogon: "ų",
      Uopf: "𝕌",
      uopf: "𝕦",
      UpArrow: "↑",
      Uparrow: "⇑",
      uparrow: "↑",
      UpArrowBar: "⤒",
      UpArrowDownArrow: "⇅",
      UpDownArrow: "↕",
      Updownarrow: "⇕",
      updownarrow: "↕",
      UpEquilibrium: "⥮",
      upharpoonleft: "↿",
      upharpoonright: "↾",
      uplus: "⊎",
      UpperLeftArrow: "↖",
      UpperRightArrow: "↗",
      Upsi: "ϒ",
      upsi: "υ",
      upsih: "ϒ",
      Upsilon: "Υ",
      upsilon: "υ",
      UpTee: "⊥",
      UpTeeArrow: "↥",
      upuparrows: "⇈",
      urcorn: "⌝",
      urcorner: "⌝",
      urcrop: "⌎",
      Uring: "Ů",
      uring: "ů",
      urtri: "◹",
      Uscr: "𝒰",
      uscr: "𝓊",
      utdot: "⋰",
      Utilde: "Ũ",
      utilde: "ũ",
      utri: "▵",
      utrif: "▴",
      uuarr: "⇈",
      Uuml: "Ü",
      uuml: "ü",
      uwangle: "⦧",
      vangrt: "⦜",
      varepsilon: "ϵ",
      varkappa: "ϰ",
      varnothing: "∅",
      varphi: "ϕ",
      varpi: "ϖ",
      varpropto: "∝",
      vArr: "⇕",
      varr: "↕",
      varrho: "ϱ",
      varsigma: "ς",
      varsubsetneq: "⊊︀",
      varsubsetneqq: "⫋︀",
      varsupsetneq: "⊋︀",
      varsupsetneqq: "⫌︀",
      vartheta: "ϑ",
      vartriangleleft: "⊲",
      vartriangleright: "⊳",
      Vbar: "⫫",
      vBar: "⫨",
      vBarv: "⫩",
      Vcy: "В",
      vcy: "в",
      VDash: "⊫",
      Vdash: "⊩",
      vDash: "⊨",
      vdash: "⊢",
      Vdashl: "⫦",
      Vee: "⋁",
      vee: "∨",
      veebar: "⊻",
      veeeq: "≚",
      vellip: "⋮",
      Verbar: "‖",
      verbar: "|",
      Vert: "‖",
      vert: "|",
      VerticalBar: "∣",
      VerticalLine: "|",
      VerticalSeparator: "❘",
      VerticalTilde: "≀",
      VeryThinSpace: " ",
      Vfr: "𝔙",
      vfr: "𝔳",
      vltri: "⊲",
      vnsub: "⊂⃒",
      vnsup: "⊃⃒",
      Vopf: "𝕍",
      vopf: "𝕧",
      vprop: "∝",
      vrtri: "⊳",
      Vscr: "𝒱",
      vscr: "𝓋",
      vsubnE: "⫋︀",
      vsubne: "⊊︀",
      vsupnE: "⫌︀",
      vsupne: "⊋︀",
      Vvdash: "⊪",
      vzigzag: "⦚",
      Wcirc: "Ŵ",
      wcirc: "ŵ",
      wedbar: "⩟",
      Wedge: "⋀",
      wedge: "∧",
      wedgeq: "≙",
      weierp: "℘",
      Wfr: "𝔚",
      wfr: "𝔴",
      Wopf: "𝕎",
      wopf: "𝕨",
      wp: "℘",
      wr: "≀",
      wreath: "≀",
      Wscr: "𝒲",
      wscr: "𝓌",
      xcap: "⋂",
      xcirc: "◯",
      xcup: "⋃",
      xdtri: "▽",
      Xfr: "𝔛",
      xfr: "𝔵",
      xhArr: "⟺",
      xharr: "⟷",
      Xi: "Ξ",
      xi: "ξ",
      xlArr: "⟸",
      xlarr: "⟵",
      xmap: "⟼",
      xnis: "⋻",
      xodot: "⨀",
      Xopf: "𝕏",
      xopf: "𝕩",
      xoplus: "⨁",
      xotime: "⨂",
      xrArr: "⟹",
      xrarr: "⟶",
      Xscr: "𝒳",
      xscr: "𝓍",
      xsqcup: "⨆",
      xuplus: "⨄",
      xutri: "△",
      xvee: "⋁",
      xwedge: "⋀",
      Yacute: "Ý",
      yacute: "ý",
      YAcy: "Я",
      yacy: "я",
      Ycirc: "Ŷ",
      ycirc: "ŷ",
      Ycy: "Ы",
      ycy: "ы",
      yen: "¥",
      Yfr: "𝔜",
      yfr: "𝔶",
      YIcy: "Ї",
      yicy: "ї",
      Yopf: "𝕐",
      yopf: "𝕪",
      Yscr: "𝒴",
      yscr: "𝓎",
      YUcy: "Ю",
      yucy: "ю",
      Yuml: "Ÿ",
      yuml: "ÿ",
      Zacute: "Ź",
      zacute: "ź",
      Zcaron: "Ž",
      zcaron: "ž",
      Zcy: "З",
      zcy: "з",
      Zdot: "Ż",
      zdot: "ż",
      zeetrf: "ℨ",
      ZeroWidthSpace: "​",
      Zeta: "Ζ",
      zeta: "ζ",
      Zfr: "ℨ",
      zfr: "𝔷",
      ZHcy: "Ж",
      zhcy: "ж",
      zigrarr: "⇝",
      Zopf: "ℤ",
      zopf: "𝕫",
      Zscr: "𝒵",
      zscr: "𝓏",
      zwj: "‍",
      zwnj: "‌"
    });
    exports2.entityMap = exports2.HTML_ENTITIES;
  }
});

// node_modules/@xmldom/xmldom/lib/sax.js
var require_sax = __commonJS({
  "node_modules/@xmldom/xmldom/lib/sax.js"(exports2) {
    var NAMESPACE = require_conventions().NAMESPACE;
    var nameStartChar = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
    var nameChar = new RegExp("[\\-\\.0-9" + nameStartChar.source.slice(1, -1) + "\\u00B7\\u0300-\\u036F\\u203F-\\u2040]");
    var tagNamePattern = new RegExp("^" + nameStartChar.source + nameChar.source + "*(?::" + nameStartChar.source + nameChar.source + "*)?$");
    var S_TAG = 0;
    var S_ATTR = 1;
    var S_ATTR_SPACE = 2;
    var S_EQ = 3;
    var S_ATTR_NOQUOT_VALUE = 4;
    var S_ATTR_END = 5;
    var S_TAG_SPACE = 6;
    var S_TAG_CLOSE = 7;
    function ParseError(message, locator) {
      this.message = message;
      this.locator = locator;
      if (Error.captureStackTrace) Error.captureStackTrace(this, ParseError);
    }
    ParseError.prototype = new Error();
    ParseError.prototype.name = ParseError.name;
    function XMLReader() {
    }
    XMLReader.prototype = {
      parse: function(source, defaultNSMap, entityMap) {
        var domBuilder = this.domBuilder;
        domBuilder.startDocument();
        _copy(defaultNSMap, defaultNSMap = {});
        parse(source, defaultNSMap, entityMap, domBuilder, this.errorHandler);
        domBuilder.endDocument();
      }
    };
    function parse(source, defaultNSMapCopy, entityMap, domBuilder, errorHandler) {
      function fixedFromCharCode(code) {
        if (code > 65535) {
          code -= 65536;
          var surrogate1 = 55296 + (code >> 10), surrogate2 = 56320 + (code & 1023);
          return String.fromCharCode(surrogate1, surrogate2);
        } else {
          return String.fromCharCode(code);
        }
      }
      function entityReplacer(a2) {
        var k = a2.slice(1, -1);
        if (Object.hasOwnProperty.call(entityMap, k)) {
          return entityMap[k];
        } else if (k.charAt(0) === "#") {
          return fixedFromCharCode(parseInt(k.substr(1).replace("x", "0x")));
        } else {
          errorHandler.error("entity not found:" + a2);
          return a2;
        }
      }
      function appendText(end2) {
        if (end2 > start) {
          var xt = source.substring(start, end2).replace(/&#?\w+;/g, entityReplacer);
          locator && position(start);
          domBuilder.characters(xt, 0, end2 - start);
          start = end2;
        }
      }
      function position(p, m) {
        while (p >= lineEnd && (m = linePattern.exec(source))) {
          lineStart = m.index;
          lineEnd = lineStart + m[0].length;
          locator.lineNumber++;
        }
        locator.columnNumber = p - lineStart + 1;
      }
      var lineStart = 0;
      var lineEnd = 0;
      var linePattern = /.*(?:\r\n?|\n)|.*$/g;
      var locator = domBuilder.locator;
      var parseStack = [{
        currentNSMap: defaultNSMapCopy
      }];
      var closeMap = {};
      var start = 0;
      while (true) {
        try {
          var tagStart = source.indexOf("<", start);
          if (tagStart < 0) {
            if (!source.substr(start).match(/^\s*$/)) {
              var doc = domBuilder.doc;
              var text = doc.createTextNode(source.substr(start));
              doc.appendChild(text);
              domBuilder.currentElement = text;
            }
            return;
          }
          if (tagStart > start) {
            appendText(tagStart);
          }
          switch (source.charAt(tagStart + 1)) {
            case "/":
              var end = source.indexOf(">", tagStart + 3);
              var tagName = source.substring(tagStart + 2, end).replace(/[ \t\n\r]+$/g, "");
              var config = parseStack.pop();
              if (end < 0) {
                tagName = source.substring(tagStart + 2).replace(/[\s<].*/, "");
                errorHandler.error("end tag name: " + tagName + " is not complete:" + config.tagName);
                end = tagStart + 1 + tagName.length;
              } else if (tagName.match(/\s</)) {
                tagName = tagName.replace(/[\s<].*/, "");
                errorHandler.error("end tag name: " + tagName + " maybe not complete");
                end = tagStart + 1 + tagName.length;
              }
              var localNSMap = config.localNSMap;
              var endMatch = config.tagName == tagName;
              var endIgnoreCaseMach = endMatch || config.tagName && config.tagName.toLowerCase() == tagName.toLowerCase();
              if (endIgnoreCaseMach) {
                domBuilder.endElement(config.uri, config.localName, tagName);
                if (localNSMap) {
                  for (var prefix in localNSMap) {
                    if (Object.prototype.hasOwnProperty.call(localNSMap, prefix)) {
                      domBuilder.endPrefixMapping(prefix);
                    }
                  }
                }
                if (!endMatch) {
                  errorHandler.fatalError("end tag name: " + tagName + " is not match the current start tagName:" + config.tagName);
                }
              } else {
                parseStack.push(config);
              }
              end++;
              break;
            // end elment
            case "?":
              locator && position(tagStart);
              end = parseInstruction(source, tagStart, domBuilder);
              break;
            case "!":
              locator && position(tagStart);
              end = parseDCC(source, tagStart, domBuilder, errorHandler);
              break;
            default:
              locator && position(tagStart);
              var el = new ElementAttributes();
              var currentNSMap = parseStack[parseStack.length - 1].currentNSMap;
              var end = parseElementStartPart(source, tagStart, el, currentNSMap, entityReplacer, errorHandler);
              var len = el.length;
              if (!el.closed && fixSelfClosed(source, end, el.tagName, closeMap)) {
                el.closed = true;
                if (!entityMap.nbsp) {
                  errorHandler.warning("unclosed xml attribute");
                }
              }
              if (locator && len) {
                var locator2 = copyLocator(locator, {});
                for (var i = 0; i < len; i++) {
                  var a = el[i];
                  position(a.offset);
                  a.locator = copyLocator(locator, {});
                }
                domBuilder.locator = locator2;
                if (appendElement(el, domBuilder, currentNSMap)) {
                  parseStack.push(el);
                }
                domBuilder.locator = locator;
              } else {
                if (appendElement(el, domBuilder, currentNSMap)) {
                  parseStack.push(el);
                }
              }
              if (NAMESPACE.isHTML(el.uri) && !el.closed) {
                end = parseHtmlSpecialContent(source, end, el.tagName, entityReplacer, domBuilder);
              } else {
                end++;
              }
          }
        } catch (e) {
          if (e instanceof ParseError) {
            throw e;
          }
          errorHandler.error("element parse error: " + e);
          end = -1;
        }
        if (end > start) {
          start = end;
        } else {
          appendText(Math.max(tagStart, start) + 1);
        }
      }
    }
    function copyLocator(f, t) {
      t.lineNumber = f.lineNumber;
      t.columnNumber = f.columnNumber;
      return t;
    }
    function parseElementStartPart(source, start, el, currentNSMap, entityReplacer, errorHandler) {
      function addAttribute(qname, value2, startIndex) {
        if (el.attributeNames.hasOwnProperty(qname)) {
          errorHandler.fatalError("Attribute " + qname + " redefined");
        }
        el.addValue(
          qname,
          // @see https://www.w3.org/TR/xml/#AVNormalize
          // since the xmldom sax parser does not "interpret" DTD the following is not implemented:
          // - recursive replacement of (DTD) entity references
          // - trimming and collapsing multiple spaces into a single one for attributes that are not of type CDATA
          value2.replace(/[\t\n\r]/g, " ").replace(/&#?\w+;/g, entityReplacer),
          startIndex
        );
      }
      var attrName;
      var value;
      var p = ++start;
      var s = S_TAG;
      while (true) {
        var c = source.charAt(p);
        switch (c) {
          case "=":
            if (s === S_ATTR) {
              attrName = source.slice(start, p);
              s = S_EQ;
            } else if (s === S_ATTR_SPACE) {
              s = S_EQ;
            } else {
              throw new Error("attribute equal must after attrName");
            }
            break;
          case "'":
          case '"':
            if (s === S_EQ || s === S_ATTR) {
              if (s === S_ATTR) {
                errorHandler.warning('attribute value must after "="');
                attrName = source.slice(start, p);
              }
              start = p + 1;
              p = source.indexOf(c, start);
              if (p > 0) {
                value = source.slice(start, p);
                addAttribute(attrName, value, start - 1);
                s = S_ATTR_END;
              } else {
                throw new Error("attribute value no end '" + c + "' match");
              }
            } else if (s == S_ATTR_NOQUOT_VALUE) {
              value = source.slice(start, p);
              addAttribute(attrName, value, start);
              errorHandler.warning('attribute "' + attrName + '" missed start quot(' + c + ")!!");
              start = p + 1;
              s = S_ATTR_END;
            } else {
              throw new Error('attribute value must after "="');
            }
            break;
          case "/":
            switch (s) {
              case S_TAG:
                el.setTagName(source.slice(start, p));
              case S_ATTR_END:
              case S_TAG_SPACE:
              case S_TAG_CLOSE:
                s = S_TAG_CLOSE;
                el.closed = true;
              case S_ATTR_NOQUOT_VALUE:
              case S_ATTR:
                break;
              case S_ATTR_SPACE:
                el.closed = true;
                break;
              //case S_EQ:
              default:
                throw new Error("attribute invalid close char('/')");
            }
            break;
          case "":
            errorHandler.error("unexpected end of input");
            if (s == S_TAG) {
              el.setTagName(source.slice(start, p));
            }
            return p;
          case ">":
            switch (s) {
              case S_TAG:
                el.setTagName(source.slice(start, p));
              case S_ATTR_END:
              case S_TAG_SPACE:
              case S_TAG_CLOSE:
                break;
              //normal
              case S_ATTR_NOQUOT_VALUE:
              //Compatible state
              case S_ATTR:
                value = source.slice(start, p);
                if (value.slice(-1) === "/") {
                  el.closed = true;
                  value = value.slice(0, -1);
                }
              case S_ATTR_SPACE:
                if (s === S_ATTR_SPACE) {
                  value = attrName;
                }
                if (s == S_ATTR_NOQUOT_VALUE) {
                  errorHandler.warning('attribute "' + value + '" missed quot(")!');
                  addAttribute(attrName, value, start);
                } else {
                  if (!NAMESPACE.isHTML(currentNSMap[""]) || !value.match(/^(?:disabled|checked|selected)$/i)) {
                    errorHandler.warning('attribute "' + value + '" missed value!! "' + value + '" instead!!');
                  }
                  addAttribute(value, value, start);
                }
                break;
              case S_EQ:
                throw new Error("attribute value missed!!");
            }
            return p;
          /*xml space '\x20' | #x9 | #xD | #xA; */
          case "":
            c = " ";
          default:
            if (c <= " ") {
              switch (s) {
                case S_TAG:
                  el.setTagName(source.slice(start, p));
                  s = S_TAG_SPACE;
                  break;
                case S_ATTR:
                  attrName = source.slice(start, p);
                  s = S_ATTR_SPACE;
                  break;
                case S_ATTR_NOQUOT_VALUE:
                  var value = source.slice(start, p);
                  errorHandler.warning('attribute "' + value + '" missed quot(")!!');
                  addAttribute(attrName, value, start);
                case S_ATTR_END:
                  s = S_TAG_SPACE;
                  break;
              }
            } else {
              switch (s) {
                //case S_TAG:void();break;
                //case S_ATTR:void();break;
                //case S_ATTR_NOQUOT_VALUE:void();break;
                case S_ATTR_SPACE:
                  var tagName = el.tagName;
                  if (!NAMESPACE.isHTML(currentNSMap[""]) || !attrName.match(/^(?:disabled|checked|selected)$/i)) {
                    errorHandler.warning('attribute "' + attrName + '" missed value!! "' + attrName + '" instead2!!');
                  }
                  addAttribute(attrName, attrName, start);
                  start = p;
                  s = S_ATTR;
                  break;
                case S_ATTR_END:
                  errorHandler.warning('attribute space is required"' + attrName + '"!!');
                case S_TAG_SPACE:
                  s = S_ATTR;
                  start = p;
                  break;
                case S_EQ:
                  s = S_ATTR_NOQUOT_VALUE;
                  start = p;
                  break;
                case S_TAG_CLOSE:
                  throw new Error("elements closed character '/' and '>' must be connected to");
              }
            }
        }
        p++;
      }
    }
    function appendElement(el, domBuilder, currentNSMap) {
      var tagName = el.tagName;
      var localNSMap = null;
      var i = el.length;
      while (i--) {
        var a = el[i];
        var qName = a.qName;
        var value = a.value;
        var nsp = qName.indexOf(":");
        if (nsp > 0) {
          var prefix = a.prefix = qName.slice(0, nsp);
          var localName = qName.slice(nsp + 1);
          var nsPrefix = prefix === "xmlns" && localName;
        } else {
          localName = qName;
          prefix = null;
          nsPrefix = qName === "xmlns" && "";
        }
        a.localName = localName;
        if (nsPrefix !== false) {
          if (localNSMap == null) {
            localNSMap = {};
            _copy(currentNSMap, currentNSMap = {});
          }
          currentNSMap[nsPrefix] = localNSMap[nsPrefix] = value;
          a.uri = NAMESPACE.XMLNS;
          domBuilder.startPrefixMapping(nsPrefix, value);
        }
      }
      var i = el.length;
      while (i--) {
        a = el[i];
        var prefix = a.prefix;
        if (prefix) {
          if (prefix === "xml") {
            a.uri = NAMESPACE.XML;
          }
          if (prefix !== "xmlns") {
            a.uri = currentNSMap[prefix || ""];
          }
        }
      }
      var nsp = tagName.indexOf(":");
      if (nsp > 0) {
        prefix = el.prefix = tagName.slice(0, nsp);
        localName = el.localName = tagName.slice(nsp + 1);
      } else {
        prefix = null;
        localName = el.localName = tagName;
      }
      var ns = el.uri = currentNSMap[prefix || ""];
      domBuilder.startElement(ns, localName, tagName, el);
      if (el.closed) {
        domBuilder.endElement(ns, localName, tagName);
        if (localNSMap) {
          for (prefix in localNSMap) {
            if (Object.prototype.hasOwnProperty.call(localNSMap, prefix)) {
              domBuilder.endPrefixMapping(prefix);
            }
          }
        }
      } else {
        el.currentNSMap = currentNSMap;
        el.localNSMap = localNSMap;
        return true;
      }
    }
    function parseHtmlSpecialContent(source, elStartEnd, tagName, entityReplacer, domBuilder) {
      if (/^(?:script|textarea)$/i.test(tagName)) {
        var elEndStart = source.indexOf("</" + tagName + ">", elStartEnd);
        var text = source.substring(elStartEnd + 1, elEndStart);
        if (/[&<]/.test(text)) {
          if (/^script$/i.test(tagName)) {
            domBuilder.characters(text, 0, text.length);
            return elEndStart;
          }
          text = text.replace(/&#?\w+;/g, entityReplacer);
          domBuilder.characters(text, 0, text.length);
          return elEndStart;
        }
      }
      return elStartEnd + 1;
    }
    function fixSelfClosed(source, elStartEnd, tagName, closeMap) {
      var pos = closeMap[tagName];
      if (pos == null) {
        pos = source.lastIndexOf("</" + tagName + ">");
        if (pos < elStartEnd) {
          pos = source.lastIndexOf("</" + tagName);
        }
        closeMap[tagName] = pos;
      }
      return pos < elStartEnd;
    }
    function _copy(source, target) {
      for (var n in source) {
        if (Object.prototype.hasOwnProperty.call(source, n)) {
          target[n] = source[n];
        }
      }
    }
    function parseDCC(source, start, domBuilder, errorHandler) {
      var next = source.charAt(start + 2);
      switch (next) {
        case "-":
          if (source.charAt(start + 3) === "-") {
            var end = source.indexOf("-->", start + 4);
            if (end > start) {
              domBuilder.comment(source, start + 4, end - start - 4);
              return end + 3;
            } else {
              errorHandler.error("Unclosed comment");
              return -1;
            }
          } else {
            return -1;
          }
        default:
          if (source.substr(start + 3, 6) == "CDATA[") {
            var end = source.indexOf("]]>", start + 9);
            domBuilder.startCDATA();
            domBuilder.characters(source, start + 9, end - start - 9);
            domBuilder.endCDATA();
            return end + 3;
          }
          var matchs = split(source, start);
          var len = matchs.length;
          if (len > 1 && /!doctype/i.test(matchs[0][0])) {
            var name = matchs[1][0];
            var pubid = false;
            var sysid = false;
            if (len > 3) {
              if (/^public$/i.test(matchs[2][0])) {
                pubid = matchs[3][0];
                sysid = len > 4 && matchs[4][0];
              } else if (/^system$/i.test(matchs[2][0])) {
                sysid = matchs[3][0];
              }
            }
            var lastMatch = matchs[len - 1];
            domBuilder.startDTD(name, pubid, sysid);
            domBuilder.endDTD();
            return lastMatch.index + lastMatch[0].length;
          }
      }
      return -1;
    }
    function parseInstruction(source, start, domBuilder) {
      var end = source.indexOf("?>", start);
      if (end) {
        var match = source.substring(start, end).match(/^<\?(\S*)\s*([\s\S]*?)\s*$/);
        if (match) {
          var len = match[0].length;
          domBuilder.processingInstruction(match[1], match[2]);
          return end + 2;
        } else {
          return -1;
        }
      }
      return -1;
    }
    function ElementAttributes() {
      this.attributeNames = {};
    }
    ElementAttributes.prototype = {
      setTagName: function(tagName) {
        if (!tagNamePattern.test(tagName)) {
          throw new Error("invalid tagName:" + tagName);
        }
        this.tagName = tagName;
      },
      addValue: function(qName, value, offset) {
        if (!tagNamePattern.test(qName)) {
          throw new Error("invalid attribute:" + qName);
        }
        this.attributeNames[qName] = this.length;
        this[this.length++] = {
          qName,
          value,
          offset
        };
      },
      length: 0,
      getLocalName: function(i) {
        return this[i].localName;
      },
      getLocator: function(i) {
        return this[i].locator;
      },
      getQName: function(i) {
        return this[i].qName;
      },
      getURI: function(i) {
        return this[i].uri;
      },
      getValue: function(i) {
        return this[i].value;
      }
      //	,getIndex:function(uri, localName)){
      //		if(localName){
      //
      //		}else{
      //			var qName = uri
      //		}
      //	},
      //	getValue:function(){return this.getValue(this.getIndex.apply(this,arguments))},
      //	getType:function(uri,localName){}
      //	getType:function(i){},
    };
    function split(source, start) {
      var match;
      var buf = [];
      var reg = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
      reg.lastIndex = start;
      reg.exec(source);
      while (match = reg.exec(source)) {
        buf.push(match);
        if (match[1]) return buf;
      }
    }
    exports2.XMLReader = XMLReader;
    exports2.ParseError = ParseError;
  }
});

// node_modules/@xmldom/xmldom/lib/dom-parser.js
var require_dom_parser = __commonJS({
  "node_modules/@xmldom/xmldom/lib/dom-parser.js"(exports2) {
    var conventions = require_conventions();
    var dom = require_dom();
    var entities = require_entities();
    var sax = require_sax();
    var DOMImplementation = dom.DOMImplementation;
    var NAMESPACE = conventions.NAMESPACE;
    var ParseError = sax.ParseError;
    var XMLReader = sax.XMLReader;
    function normalizeLineEndings(input) {
      return input.replace(/\r[\n\u0085]/g, "\n").replace(/[\r\u0085\u2028]/g, "\n");
    }
    function DOMParser(options) {
      this.options = options || {
        locator: {}
      };
    }
    DOMParser.prototype.parseFromString = function(source, mimeType) {
      var options = this.options;
      var sax2 = new XMLReader();
      var domBuilder = options.domBuilder || new DOMHandler();
      var errorHandler = options.errorHandler;
      var locator = options.locator;
      var defaultNSMap = options.xmlns || {};
      var isHTML = /\/x?html?$/.test(mimeType);
      var entityMap = isHTML ? entities.HTML_ENTITIES : entities.XML_ENTITIES;
      if (locator) {
        domBuilder.setDocumentLocator(locator);
      }
      sax2.errorHandler = buildErrorHandler(errorHandler, domBuilder, locator);
      sax2.domBuilder = options.domBuilder || domBuilder;
      if (isHTML) {
        defaultNSMap[""] = NAMESPACE.HTML;
      }
      defaultNSMap.xml = defaultNSMap.xml || NAMESPACE.XML;
      var normalize = options.normalizeLineEndings || normalizeLineEndings;
      if (source && typeof source === "string") {
        sax2.parse(normalize(source), defaultNSMap, entityMap);
      } else {
        sax2.errorHandler.error("invalid doc source");
      }
      return domBuilder.doc;
    };
    function buildErrorHandler(errorImpl, domBuilder, locator) {
      if (!errorImpl) {
        if (domBuilder instanceof DOMHandler) {
          return domBuilder;
        }
        errorImpl = domBuilder;
      }
      var errorHandler = {};
      var isCallback = errorImpl instanceof Function;
      locator = locator || {};
      function build(key) {
        var fn = errorImpl[key];
        if (!fn && isCallback) {
          fn = errorImpl.length == 2 ? function(msg) {
            errorImpl(key, msg);
          } : errorImpl;
        }
        errorHandler[key] = fn && function(msg) {
          fn("[xmldom " + key + "]	" + msg + _locator(locator));
        } || function() {
        };
      }
      build("warning");
      build("error");
      build("fatalError");
      return errorHandler;
    }
    function DOMHandler() {
      this.cdata = false;
    }
    function position(locator, node) {
      node.lineNumber = locator.lineNumber;
      node.columnNumber = locator.columnNumber;
    }
    DOMHandler.prototype = {
      startDocument: function() {
        this.doc = new DOMImplementation().createDocument(null, null, null);
        if (this.locator) {
          this.doc.documentURI = this.locator.systemId;
        }
      },
      startElement: function(namespaceURI, localName, qName, attrs) {
        var doc = this.doc;
        var el = doc.createElementNS(namespaceURI, qName || localName);
        var len = attrs.length;
        appendElement(this, el);
        this.currentElement = el;
        this.locator && position(this.locator, el);
        for (var i = 0; i < len; i++) {
          var namespaceURI = attrs.getURI(i);
          var value = attrs.getValue(i);
          var qName = attrs.getQName(i);
          var attr = doc.createAttributeNS(namespaceURI, qName);
          this.locator && position(attrs.getLocator(i), attr);
          attr.value = attr.nodeValue = value;
          el.setAttributeNode(attr);
        }
      },
      endElement: function(namespaceURI, localName, qName) {
        var current = this.currentElement;
        var tagName = current.tagName;
        this.currentElement = current.parentNode;
      },
      startPrefixMapping: function(prefix, uri) {
      },
      endPrefixMapping: function(prefix) {
      },
      processingInstruction: function(target, data) {
        var ins = this.doc.createProcessingInstruction(target, data);
        this.locator && position(this.locator, ins);
        appendElement(this, ins);
      },
      ignorableWhitespace: function(ch, start, length) {
      },
      characters: function(chars, start, length) {
        chars = _toString.apply(this, arguments);
        if (chars) {
          if (this.cdata) {
            var charNode = this.doc.createCDATASection(chars);
          } else {
            var charNode = this.doc.createTextNode(chars);
          }
          if (this.currentElement) {
            this.currentElement.appendChild(charNode);
          } else if (/^\s*$/.test(chars)) {
            this.doc.appendChild(charNode);
          }
          this.locator && position(this.locator, charNode);
        }
      },
      skippedEntity: function(name) {
      },
      endDocument: function() {
        this.doc.normalize();
      },
      setDocumentLocator: function(locator) {
        if (this.locator = locator) {
          locator.lineNumber = 0;
        }
      },
      //LexicalHandler
      comment: function(chars, start, length) {
        chars = _toString.apply(this, arguments);
        var comm = this.doc.createComment(chars);
        this.locator && position(this.locator, comm);
        appendElement(this, comm);
      },
      startCDATA: function() {
        this.cdata = true;
      },
      endCDATA: function() {
        this.cdata = false;
      },
      startDTD: function(name, publicId, systemId) {
        var impl = this.doc.implementation;
        if (impl && impl.createDocumentType) {
          var dt = impl.createDocumentType(name, publicId, systemId);
          this.locator && position(this.locator, dt);
          appendElement(this, dt);
          this.doc.doctype = dt;
        }
      },
      /**
       * @see org.xml.sax.ErrorHandler
       * @link http://www.saxproject.org/apidoc/org/xml/sax/ErrorHandler.html
       */
      warning: function(error) {
        console.warn("[xmldom warning]	" + error, _locator(this.locator));
      },
      error: function(error) {
        console.error("[xmldom error]	" + error, _locator(this.locator));
      },
      fatalError: function(error) {
        throw new ParseError(error, this.locator);
      }
    };
    function _locator(l2) {
      if (l2) {
        return "\n@" + (l2.systemId || "") + "#[line:" + l2.lineNumber + ",col:" + l2.columnNumber + "]";
      }
    }
    function _toString(chars, start, length) {
      if (typeof chars == "string") {
        return chars.substr(start, length);
      } else {
        if (chars.length >= start + length || start) {
          return new java.lang.String(chars, start, length) + "";
        }
        return chars;
      }
    }
    "endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g, function(key) {
      DOMHandler.prototype[key] = function() {
        return null;
      };
    });
    function appendElement(hander, node) {
      if (!hander.currentElement) {
        hander.doc.appendChild(node);
      } else {
        hander.currentElement.appendChild(node);
      }
    }
    exports2.__DOMHandler = DOMHandler;
    exports2.normalizeLineEndings = normalizeLineEndings;
    exports2.DOMParser = DOMParser;
  }
});

// node_modules/@xmldom/xmldom/lib/index.js
var require_lib = __commonJS({
  "node_modules/@xmldom/xmldom/lib/index.js"(exports2) {
    var dom = require_dom();
    exports2.DOMImplementation = dom.DOMImplementation;
    exports2.XMLSerializer = dom.XMLSerializer;
    exports2.DOMParser = require_dom_parser().DOMParser;
  }
});

// node_modules/mammoth/lib/xml/xmldom.js
var require_xmldom = __commonJS({
  "node_modules/mammoth/lib/xml/xmldom.js"(exports2) {
    var xmldom = require_lib();
    var dom = require_dom();
    function parseFromString(string) {
      var error = null;
      var domParser = new xmldom.DOMParser({
        errorHandler: function(level, message) {
          error = {
            level,
            message
          };
        }
      });
      var document2 = domParser.parseFromString(string);
      if (error === null) {
        return document2;
      } else {
        throw new Error(error.level + ": " + error.message);
      }
    }
    exports2.parseFromString = parseFromString;
    exports2.Node = dom.Node;
  }
});

// node_modules/mammoth/lib/xml/reader.js
var require_reader = __commonJS({
  "node_modules/mammoth/lib/xml/reader.js"(exports2) {
    var promises = require_promises();
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var xmldom = require_xmldom();
    var nodes = require_nodes();
    var Element = nodes.Element;
    exports2.readString = readString;
    var Node = xmldom.Node;
    function readString(xmlString, namespaceMap) {
      namespaceMap = namespaceMap || {};
      try {
        var document2 = xmldom.parseFromString(xmlString, "text/xml");
      } catch (error) {
        return promises.reject(error);
      }
      if (document2.documentElement.tagName === "parsererror") {
        return promises.resolve(new Error(document2.documentElement.textContent));
      }
      function convertNode(node) {
        switch (node.nodeType) {
          case Node.ELEMENT_NODE:
            return convertElement(node);
          case Node.TEXT_NODE:
            return nodes.text(node.nodeValue);
        }
      }
      function convertElement(element) {
        var convertedName = convertName(element);
        var convertedChildren = [];
        _3.forEach(element.childNodes, function(childNode) {
          var convertedNode = convertNode(childNode);
          if (convertedNode) {
            convertedChildren.push(convertedNode);
          }
        });
        var convertedAttributes = {};
        _3.forEach(element.attributes, function(attribute) {
          convertedAttributes[convertName(attribute)] = attribute.value;
        });
        return new Element(convertedName, convertedAttributes, convertedChildren);
      }
      function convertName(node) {
        if (node.namespaceURI) {
          var mappedPrefix = namespaceMap[node.namespaceURI];
          var prefix;
          if (mappedPrefix) {
            prefix = mappedPrefix + ":";
          } else {
            prefix = "{" + node.namespaceURI + "}";
          }
          return prefix + node.localName;
        } else {
          return node.localName;
        }
      }
      return promises.resolve(convertNode(document2.documentElement));
    }
  }
});

// node_modules/xmlbuilder/lib/Utility.js
var require_Utility = __commonJS({
  "node_modules/xmlbuilder/lib/Utility.js"(exports2, module2) {
    (function() {
      var assign, getValue, isArray, isEmpty2, isFunction2, isObject3, isPlainObject, slice2 = [].slice, hasProp = {}.hasOwnProperty;
      assign = function() {
        var i, key, len, source, sources, target;
        target = arguments[0], sources = 2 <= arguments.length ? slice2.call(arguments, 1) : [];
        if (isFunction2(Object.assign)) {
          Object.assign.apply(null, arguments);
        } else {
          for (i = 0, len = sources.length; i < len; i++) {
            source = sources[i];
            if (source != null) {
              for (key in source) {
                if (!hasProp.call(source, key)) continue;
                target[key] = source[key];
              }
            }
          }
        }
        return target;
      };
      isFunction2 = function(val) {
        return !!val && Object.prototype.toString.call(val) === "[object Function]";
      };
      isObject3 = function(val) {
        var ref;
        return !!val && ((ref = typeof val) === "function" || ref === "object");
      };
      isArray = function(val) {
        if (isFunction2(Array.isArray)) {
          return Array.isArray(val);
        } else {
          return Object.prototype.toString.call(val) === "[object Array]";
        }
      };
      isEmpty2 = function(val) {
        var key;
        if (isArray(val)) {
          return !val.length;
        } else {
          for (key in val) {
            if (!hasProp.call(val, key)) continue;
            return false;
          }
          return true;
        }
      };
      isPlainObject = function(val) {
        var ctor2, proto;
        return isObject3(val) && (proto = Object.getPrototypeOf(val)) && (ctor2 = proto.constructor) && typeof ctor2 === "function" && ctor2 instanceof ctor2 && Function.prototype.toString.call(ctor2) === Function.prototype.toString.call(Object);
      };
      getValue = function(obj2) {
        if (isFunction2(obj2.valueOf)) {
          return obj2.valueOf();
        } else {
          return obj2;
        }
      };
      module2.exports.assign = assign;
      module2.exports.isFunction = isFunction2;
      module2.exports.isObject = isObject3;
      module2.exports.isArray = isArray;
      module2.exports.isEmpty = isEmpty2;
      module2.exports.isPlainObject = isPlainObject;
      module2.exports.getValue = getValue;
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLAttribute.js
var require_XMLAttribute = __commonJS({
  "node_modules/xmlbuilder/lib/XMLAttribute.js"(exports2, module2) {
    (function() {
      var XMLAttribute;
      module2.exports = XMLAttribute = function() {
        function XMLAttribute2(parent, name, value) {
          this.options = parent.options;
          this.stringify = parent.stringify;
          this.parent = parent;
          if (name == null) {
            throw new Error("Missing attribute name. " + this.debugInfo(name));
          }
          if (value == null) {
            throw new Error("Missing attribute value. " + this.debugInfo(name));
          }
          this.name = this.stringify.attName(name);
          this.value = this.stringify.attValue(value);
        }
        XMLAttribute2.prototype.clone = function() {
          return Object.create(this);
        };
        XMLAttribute2.prototype.toString = function(options) {
          return this.options.writer.set(options).attribute(this);
        };
        XMLAttribute2.prototype.debugInfo = function(name) {
          name = name || this.name;
          if (name == null) {
            return "parent: <" + this.parent.name + ">";
          } else {
            return "attribute: {" + name + "}, parent: <" + this.parent.name + ">";
          }
        };
        return XMLAttribute2;
      }();
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLElement.js
var require_XMLElement = __commonJS({
  "node_modules/xmlbuilder/lib/XMLElement.js"(exports2, module2) {
    (function() {
      var XMLAttribute, XMLElement, XMLNode, getValue, isFunction2, isObject3, ref, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      ref = require_Utility(), isObject3 = ref.isObject, isFunction2 = ref.isFunction, getValue = ref.getValue;
      XMLNode = require_XMLNode();
      XMLAttribute = require_XMLAttribute();
      module2.exports = XMLElement = function(superClass) {
        extend(XMLElement2, superClass);
        function XMLElement2(parent, name, attributes) {
          XMLElement2.__super__.constructor.call(this, parent);
          if (name == null) {
            throw new Error("Missing element name. " + this.debugInfo());
          }
          this.name = this.stringify.eleName(name);
          this.attributes = {};
          if (attributes != null) {
            this.attribute(attributes);
          }
          if (parent.isDocument) {
            this.isRoot = true;
            this.documentObject = parent;
            parent.rootObject = this;
          }
        }
        XMLElement2.prototype.clone = function() {
          var att, attName, clonedSelf, ref1;
          clonedSelf = Object.create(this);
          if (clonedSelf.isRoot) {
            clonedSelf.documentObject = null;
          }
          clonedSelf.attributes = {};
          ref1 = this.attributes;
          for (attName in ref1) {
            if (!hasProp.call(ref1, attName)) continue;
            att = ref1[attName];
            clonedSelf.attributes[attName] = att.clone();
          }
          clonedSelf.children = [];
          this.children.forEach(function(child) {
            var clonedChild;
            clonedChild = child.clone();
            clonedChild.parent = clonedSelf;
            return clonedSelf.children.push(clonedChild);
          });
          return clonedSelf;
        };
        XMLElement2.prototype.attribute = function(name, value) {
          var attName, attValue;
          if (name != null) {
            name = getValue(name);
          }
          if (isObject3(name)) {
            for (attName in name) {
              if (!hasProp.call(name, attName)) continue;
              attValue = name[attName];
              this.attribute(attName, attValue);
            }
          } else {
            if (isFunction2(value)) {
              value = value.apply();
            }
            if (!this.options.skipNullAttributes || value != null) {
              this.attributes[name] = new XMLAttribute(this, name, value);
            }
          }
          return this;
        };
        XMLElement2.prototype.removeAttribute = function(name) {
          var attName, i, len;
          if (name == null) {
            throw new Error("Missing attribute name. " + this.debugInfo());
          }
          name = getValue(name);
          if (Array.isArray(name)) {
            for (i = 0, len = name.length; i < len; i++) {
              attName = name[i];
              delete this.attributes[attName];
            }
          } else {
            delete this.attributes[name];
          }
          return this;
        };
        XMLElement2.prototype.toString = function(options) {
          return this.options.writer.set(options).element(this);
        };
        XMLElement2.prototype.att = function(name, value) {
          return this.attribute(name, value);
        };
        XMLElement2.prototype.a = function(name, value) {
          return this.attribute(name, value);
        };
        return XMLElement2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLCData.js
var require_XMLCData = __commonJS({
  "node_modules/xmlbuilder/lib/XMLCData.js"(exports2, module2) {
    (function() {
      var XMLCData, XMLNode, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLCData = function(superClass) {
        extend(XMLCData2, superClass);
        function XMLCData2(parent, text) {
          XMLCData2.__super__.constructor.call(this, parent);
          if (text == null) {
            throw new Error("Missing CDATA text. " + this.debugInfo());
          }
          this.text = this.stringify.cdata(text);
        }
        XMLCData2.prototype.clone = function() {
          return Object.create(this);
        };
        XMLCData2.prototype.toString = function(options) {
          return this.options.writer.set(options).cdata(this);
        };
        return XMLCData2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLComment.js
var require_XMLComment = __commonJS({
  "node_modules/xmlbuilder/lib/XMLComment.js"(exports2, module2) {
    (function() {
      var XMLComment, XMLNode, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLComment = function(superClass) {
        extend(XMLComment2, superClass);
        function XMLComment2(parent, text) {
          XMLComment2.__super__.constructor.call(this, parent);
          if (text == null) {
            throw new Error("Missing comment text. " + this.debugInfo());
          }
          this.text = this.stringify.comment(text);
        }
        XMLComment2.prototype.clone = function() {
          return Object.create(this);
        };
        XMLComment2.prototype.toString = function(options) {
          return this.options.writer.set(options).comment(this);
        };
        return XMLComment2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDeclaration.js
var require_XMLDeclaration = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDeclaration.js"(exports2, module2) {
    (function() {
      var XMLDeclaration, XMLNode, isObject3, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      isObject3 = require_Utility().isObject;
      XMLNode = require_XMLNode();
      module2.exports = XMLDeclaration = function(superClass) {
        extend(XMLDeclaration2, superClass);
        function XMLDeclaration2(parent, version, encoding, standalone) {
          var ref;
          XMLDeclaration2.__super__.constructor.call(this, parent);
          if (isObject3(version)) {
            ref = version, version = ref.version, encoding = ref.encoding, standalone = ref.standalone;
          }
          if (!version) {
            version = "1.0";
          }
          this.version = this.stringify.xmlVersion(version);
          if (encoding != null) {
            this.encoding = this.stringify.xmlEncoding(encoding);
          }
          if (standalone != null) {
            this.standalone = this.stringify.xmlStandalone(standalone);
          }
        }
        XMLDeclaration2.prototype.toString = function(options) {
          return this.options.writer.set(options).declaration(this);
        };
        return XMLDeclaration2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDTDAttList.js
var require_XMLDTDAttList = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDTDAttList.js"(exports2, module2) {
    (function() {
      var XMLDTDAttList, XMLNode, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLDTDAttList = function(superClass) {
        extend(XMLDTDAttList2, superClass);
        function XMLDTDAttList2(parent, elementName, attributeName, attributeType, defaultValueType, defaultValue) {
          XMLDTDAttList2.__super__.constructor.call(this, parent);
          if (elementName == null) {
            throw new Error("Missing DTD element name. " + this.debugInfo());
          }
          if (attributeName == null) {
            throw new Error("Missing DTD attribute name. " + this.debugInfo(elementName));
          }
          if (!attributeType) {
            throw new Error("Missing DTD attribute type. " + this.debugInfo(elementName));
          }
          if (!defaultValueType) {
            throw new Error("Missing DTD attribute default. " + this.debugInfo(elementName));
          }
          if (defaultValueType.indexOf("#") !== 0) {
            defaultValueType = "#" + defaultValueType;
          }
          if (!defaultValueType.match(/^(#REQUIRED|#IMPLIED|#FIXED|#DEFAULT)$/)) {
            throw new Error("Invalid default value type; expected: #REQUIRED, #IMPLIED, #FIXED or #DEFAULT. " + this.debugInfo(elementName));
          }
          if (defaultValue && !defaultValueType.match(/^(#FIXED|#DEFAULT)$/)) {
            throw new Error("Default value only applies to #FIXED or #DEFAULT. " + this.debugInfo(elementName));
          }
          this.elementName = this.stringify.eleName(elementName);
          this.attributeName = this.stringify.attName(attributeName);
          this.attributeType = this.stringify.dtdAttType(attributeType);
          this.defaultValue = this.stringify.dtdAttDefault(defaultValue);
          this.defaultValueType = defaultValueType;
        }
        XMLDTDAttList2.prototype.toString = function(options) {
          return this.options.writer.set(options).dtdAttList(this);
        };
        return XMLDTDAttList2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDTDEntity.js
var require_XMLDTDEntity = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDTDEntity.js"(exports2, module2) {
    (function() {
      var XMLDTDEntity, XMLNode, isObject3, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      isObject3 = require_Utility().isObject;
      XMLNode = require_XMLNode();
      module2.exports = XMLDTDEntity = function(superClass) {
        extend(XMLDTDEntity2, superClass);
        function XMLDTDEntity2(parent, pe, name, value) {
          XMLDTDEntity2.__super__.constructor.call(this, parent);
          if (name == null) {
            throw new Error("Missing DTD entity name. " + this.debugInfo(name));
          }
          if (value == null) {
            throw new Error("Missing DTD entity value. " + this.debugInfo(name));
          }
          this.pe = !!pe;
          this.name = this.stringify.eleName(name);
          if (!isObject3(value)) {
            this.value = this.stringify.dtdEntityValue(value);
          } else {
            if (!value.pubID && !value.sysID) {
              throw new Error("Public and/or system identifiers are required for an external entity. " + this.debugInfo(name));
            }
            if (value.pubID && !value.sysID) {
              throw new Error("System identifier is required for a public external entity. " + this.debugInfo(name));
            }
            if (value.pubID != null) {
              this.pubID = this.stringify.dtdPubID(value.pubID);
            }
            if (value.sysID != null) {
              this.sysID = this.stringify.dtdSysID(value.sysID);
            }
            if (value.nData != null) {
              this.nData = this.stringify.dtdNData(value.nData);
            }
            if (this.pe && this.nData) {
              throw new Error("Notation declaration is not allowed in a parameter entity. " + this.debugInfo(name));
            }
          }
        }
        XMLDTDEntity2.prototype.toString = function(options) {
          return this.options.writer.set(options).dtdEntity(this);
        };
        return XMLDTDEntity2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDTDElement.js
var require_XMLDTDElement = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDTDElement.js"(exports2, module2) {
    (function() {
      var XMLDTDElement, XMLNode, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLDTDElement = function(superClass) {
        extend(XMLDTDElement2, superClass);
        function XMLDTDElement2(parent, name, value) {
          XMLDTDElement2.__super__.constructor.call(this, parent);
          if (name == null) {
            throw new Error("Missing DTD element name. " + this.debugInfo());
          }
          if (!value) {
            value = "(#PCDATA)";
          }
          if (Array.isArray(value)) {
            value = "(" + value.join(",") + ")";
          }
          this.name = this.stringify.eleName(name);
          this.value = this.stringify.dtdElementValue(value);
        }
        XMLDTDElement2.prototype.toString = function(options) {
          return this.options.writer.set(options).dtdElement(this);
        };
        return XMLDTDElement2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDTDNotation.js
var require_XMLDTDNotation = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDTDNotation.js"(exports2, module2) {
    (function() {
      var XMLDTDNotation, XMLNode, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLDTDNotation = function(superClass) {
        extend(XMLDTDNotation2, superClass);
        function XMLDTDNotation2(parent, name, value) {
          XMLDTDNotation2.__super__.constructor.call(this, parent);
          if (name == null) {
            throw new Error("Missing DTD notation name. " + this.debugInfo(name));
          }
          if (!value.pubID && !value.sysID) {
            throw new Error("Public or system identifiers are required for an external entity. " + this.debugInfo(name));
          }
          this.name = this.stringify.eleName(name);
          if (value.pubID != null) {
            this.pubID = this.stringify.dtdPubID(value.pubID);
          }
          if (value.sysID != null) {
            this.sysID = this.stringify.dtdSysID(value.sysID);
          }
        }
        XMLDTDNotation2.prototype.toString = function(options) {
          return this.options.writer.set(options).dtdNotation(this);
        };
        return XMLDTDNotation2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDocType.js
var require_XMLDocType = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDocType.js"(exports2, module2) {
    (function() {
      var XMLDTDAttList, XMLDTDElement, XMLDTDEntity, XMLDTDNotation, XMLDocType, XMLNode, isObject3, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      isObject3 = require_Utility().isObject;
      XMLNode = require_XMLNode();
      XMLDTDAttList = require_XMLDTDAttList();
      XMLDTDEntity = require_XMLDTDEntity();
      XMLDTDElement = require_XMLDTDElement();
      XMLDTDNotation = require_XMLDTDNotation();
      module2.exports = XMLDocType = function(superClass) {
        extend(XMLDocType2, superClass);
        function XMLDocType2(parent, pubID, sysID) {
          var ref, ref1;
          XMLDocType2.__super__.constructor.call(this, parent);
          this.name = "!DOCTYPE";
          this.documentObject = parent;
          if (isObject3(pubID)) {
            ref = pubID, pubID = ref.pubID, sysID = ref.sysID;
          }
          if (sysID == null) {
            ref1 = [pubID, sysID], sysID = ref1[0], pubID = ref1[1];
          }
          if (pubID != null) {
            this.pubID = this.stringify.dtdPubID(pubID);
          }
          if (sysID != null) {
            this.sysID = this.stringify.dtdSysID(sysID);
          }
        }
        XMLDocType2.prototype.element = function(name, value) {
          var child;
          child = new XMLDTDElement(this, name, value);
          this.children.push(child);
          return this;
        };
        XMLDocType2.prototype.attList = function(elementName, attributeName, attributeType, defaultValueType, defaultValue) {
          var child;
          child = new XMLDTDAttList(this, elementName, attributeName, attributeType, defaultValueType, defaultValue);
          this.children.push(child);
          return this;
        };
        XMLDocType2.prototype.entity = function(name, value) {
          var child;
          child = new XMLDTDEntity(this, false, name, value);
          this.children.push(child);
          return this;
        };
        XMLDocType2.prototype.pEntity = function(name, value) {
          var child;
          child = new XMLDTDEntity(this, true, name, value);
          this.children.push(child);
          return this;
        };
        XMLDocType2.prototype.notation = function(name, value) {
          var child;
          child = new XMLDTDNotation(this, name, value);
          this.children.push(child);
          return this;
        };
        XMLDocType2.prototype.toString = function(options) {
          return this.options.writer.set(options).docType(this);
        };
        XMLDocType2.prototype.ele = function(name, value) {
          return this.element(name, value);
        };
        XMLDocType2.prototype.att = function(elementName, attributeName, attributeType, defaultValueType, defaultValue) {
          return this.attList(elementName, attributeName, attributeType, defaultValueType, defaultValue);
        };
        XMLDocType2.prototype.ent = function(name, value) {
          return this.entity(name, value);
        };
        XMLDocType2.prototype.pent = function(name, value) {
          return this.pEntity(name, value);
        };
        XMLDocType2.prototype.not = function(name, value) {
          return this.notation(name, value);
        };
        XMLDocType2.prototype.up = function() {
          return this.root() || this.documentObject;
        };
        return XMLDocType2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLRaw.js
var require_XMLRaw = __commonJS({
  "node_modules/xmlbuilder/lib/XMLRaw.js"(exports2, module2) {
    (function() {
      var XMLNode, XMLRaw, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLRaw = function(superClass) {
        extend(XMLRaw2, superClass);
        function XMLRaw2(parent, text) {
          XMLRaw2.__super__.constructor.call(this, parent);
          if (text == null) {
            throw new Error("Missing raw text. " + this.debugInfo());
          }
          this.value = this.stringify.raw(text);
        }
        XMLRaw2.prototype.clone = function() {
          return Object.create(this);
        };
        XMLRaw2.prototype.toString = function(options) {
          return this.options.writer.set(options).raw(this);
        };
        return XMLRaw2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLText.js
var require_XMLText = __commonJS({
  "node_modules/xmlbuilder/lib/XMLText.js"(exports2, module2) {
    (function() {
      var XMLNode, XMLText, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLText = function(superClass) {
        extend(XMLText2, superClass);
        function XMLText2(parent, text) {
          XMLText2.__super__.constructor.call(this, parent);
          if (text == null) {
            throw new Error("Missing element text. " + this.debugInfo());
          }
          this.value = this.stringify.eleText(text);
        }
        XMLText2.prototype.clone = function() {
          return Object.create(this);
        };
        XMLText2.prototype.toString = function(options) {
          return this.options.writer.set(options).text(this);
        };
        return XMLText2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLProcessingInstruction.js
var require_XMLProcessingInstruction = __commonJS({
  "node_modules/xmlbuilder/lib/XMLProcessingInstruction.js"(exports2, module2) {
    (function() {
      var XMLNode, XMLProcessingInstruction, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLProcessingInstruction = function(superClass) {
        extend(XMLProcessingInstruction2, superClass);
        function XMLProcessingInstruction2(parent, target, value) {
          XMLProcessingInstruction2.__super__.constructor.call(this, parent);
          if (target == null) {
            throw new Error("Missing instruction target. " + this.debugInfo());
          }
          this.target = this.stringify.insTarget(target);
          if (value) {
            this.value = this.stringify.insValue(value);
          }
        }
        XMLProcessingInstruction2.prototype.clone = function() {
          return Object.create(this);
        };
        XMLProcessingInstruction2.prototype.toString = function(options) {
          return this.options.writer.set(options).processingInstruction(this);
        };
        return XMLProcessingInstruction2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDummy.js
var require_XMLDummy = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDummy.js"(exports2, module2) {
    (function() {
      var XMLDummy, XMLNode, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLNode = require_XMLNode();
      module2.exports = XMLDummy = function(superClass) {
        extend(XMLDummy2, superClass);
        function XMLDummy2(parent) {
          XMLDummy2.__super__.constructor.call(this, parent);
          this.isDummy = true;
        }
        XMLDummy2.prototype.clone = function() {
          return Object.create(this);
        };
        XMLDummy2.prototype.toString = function(options) {
          return "";
        };
        return XMLDummy2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLNode.js
var require_XMLNode = __commonJS({
  "node_modules/xmlbuilder/lib/XMLNode.js"(exports2, module2) {
    (function() {
      var XMLCData, XMLComment, XMLDeclaration, XMLDocType, XMLDummy, XMLElement, XMLNode, XMLProcessingInstruction, XMLRaw, XMLText, getValue, isEmpty2, isFunction2, isObject3, ref, hasProp = {}.hasOwnProperty;
      ref = require_Utility(), isObject3 = ref.isObject, isFunction2 = ref.isFunction, isEmpty2 = ref.isEmpty, getValue = ref.getValue;
      XMLElement = null;
      XMLCData = null;
      XMLComment = null;
      XMLDeclaration = null;
      XMLDocType = null;
      XMLRaw = null;
      XMLText = null;
      XMLProcessingInstruction = null;
      XMLDummy = null;
      module2.exports = XMLNode = function() {
        function XMLNode2(parent) {
          this.parent = parent;
          if (this.parent) {
            this.options = this.parent.options;
            this.stringify = this.parent.stringify;
          }
          this.children = [];
          if (!XMLElement) {
            XMLElement = require_XMLElement();
            XMLCData = require_XMLCData();
            XMLComment = require_XMLComment();
            XMLDeclaration = require_XMLDeclaration();
            XMLDocType = require_XMLDocType();
            XMLRaw = require_XMLRaw();
            XMLText = require_XMLText();
            XMLProcessingInstruction = require_XMLProcessingInstruction();
            XMLDummy = require_XMLDummy();
          }
        }
        XMLNode2.prototype.element = function(name, attributes, text) {
          var childNode, item, j, k, key, lastChild, len, len1, ref1, ref2, val;
          lastChild = null;
          if (attributes === null && text == null) {
            ref1 = [{}, null], attributes = ref1[0], text = ref1[1];
          }
          if (attributes == null) {
            attributes = {};
          }
          attributes = getValue(attributes);
          if (!isObject3(attributes)) {
            ref2 = [attributes, text], text = ref2[0], attributes = ref2[1];
          }
          if (name != null) {
            name = getValue(name);
          }
          if (Array.isArray(name)) {
            for (j = 0, len = name.length; j < len; j++) {
              item = name[j];
              lastChild = this.element(item);
            }
          } else if (isFunction2(name)) {
            lastChild = this.element(name.apply());
          } else if (isObject3(name)) {
            for (key in name) {
              if (!hasProp.call(name, key)) continue;
              val = name[key];
              if (isFunction2(val)) {
                val = val.apply();
              }
              if (isObject3(val) && isEmpty2(val)) {
                val = null;
              }
              if (!this.options.ignoreDecorators && this.stringify.convertAttKey && key.indexOf(this.stringify.convertAttKey) === 0) {
                lastChild = this.attribute(key.substr(this.stringify.convertAttKey.length), val);
              } else if (!this.options.separateArrayItems && Array.isArray(val)) {
                for (k = 0, len1 = val.length; k < len1; k++) {
                  item = val[k];
                  childNode = {};
                  childNode[key] = item;
                  lastChild = this.element(childNode);
                }
              } else if (isObject3(val)) {
                lastChild = this.element(key);
                lastChild.element(val);
              } else {
                lastChild = this.element(key, val);
              }
            }
          } else if (this.options.skipNullNodes && text === null) {
            lastChild = this.dummy();
          } else {
            if (!this.options.ignoreDecorators && this.stringify.convertTextKey && name.indexOf(this.stringify.convertTextKey) === 0) {
              lastChild = this.text(text);
            } else if (!this.options.ignoreDecorators && this.stringify.convertCDataKey && name.indexOf(this.stringify.convertCDataKey) === 0) {
              lastChild = this.cdata(text);
            } else if (!this.options.ignoreDecorators && this.stringify.convertCommentKey && name.indexOf(this.stringify.convertCommentKey) === 0) {
              lastChild = this.comment(text);
            } else if (!this.options.ignoreDecorators && this.stringify.convertRawKey && name.indexOf(this.stringify.convertRawKey) === 0) {
              lastChild = this.raw(text);
            } else if (!this.options.ignoreDecorators && this.stringify.convertPIKey && name.indexOf(this.stringify.convertPIKey) === 0) {
              lastChild = this.instruction(name.substr(this.stringify.convertPIKey.length), text);
            } else {
              lastChild = this.node(name, attributes, text);
            }
          }
          if (lastChild == null) {
            throw new Error("Could not create any elements with: " + name + ". " + this.debugInfo());
          }
          return lastChild;
        };
        XMLNode2.prototype.insertBefore = function(name, attributes, text) {
          var child, i, removed;
          if (this.isRoot) {
            throw new Error("Cannot insert elements at root level. " + this.debugInfo(name));
          }
          i = this.parent.children.indexOf(this);
          removed = this.parent.children.splice(i);
          child = this.parent.element(name, attributes, text);
          Array.prototype.push.apply(this.parent.children, removed);
          return child;
        };
        XMLNode2.prototype.insertAfter = function(name, attributes, text) {
          var child, i, removed;
          if (this.isRoot) {
            throw new Error("Cannot insert elements at root level. " + this.debugInfo(name));
          }
          i = this.parent.children.indexOf(this);
          removed = this.parent.children.splice(i + 1);
          child = this.parent.element(name, attributes, text);
          Array.prototype.push.apply(this.parent.children, removed);
          return child;
        };
        XMLNode2.prototype.remove = function() {
          var i, ref1;
          if (this.isRoot) {
            throw new Error("Cannot remove the root element. " + this.debugInfo());
          }
          i = this.parent.children.indexOf(this);
          [].splice.apply(this.parent.children, [i, i - i + 1].concat(ref1 = [])), ref1;
          return this.parent;
        };
        XMLNode2.prototype.node = function(name, attributes, text) {
          var child, ref1;
          if (name != null) {
            name = getValue(name);
          }
          attributes || (attributes = {});
          attributes = getValue(attributes);
          if (!isObject3(attributes)) {
            ref1 = [attributes, text], text = ref1[0], attributes = ref1[1];
          }
          child = new XMLElement(this, name, attributes);
          if (text != null) {
            child.text(text);
          }
          this.children.push(child);
          return child;
        };
        XMLNode2.prototype.text = function(value) {
          var child;
          child = new XMLText(this, value);
          this.children.push(child);
          return this;
        };
        XMLNode2.prototype.cdata = function(value) {
          var child;
          child = new XMLCData(this, value);
          this.children.push(child);
          return this;
        };
        XMLNode2.prototype.comment = function(value) {
          var child;
          child = new XMLComment(this, value);
          this.children.push(child);
          return this;
        };
        XMLNode2.prototype.commentBefore = function(value) {
          var child, i, removed;
          i = this.parent.children.indexOf(this);
          removed = this.parent.children.splice(i);
          child = this.parent.comment(value);
          Array.prototype.push.apply(this.parent.children, removed);
          return this;
        };
        XMLNode2.prototype.commentAfter = function(value) {
          var child, i, removed;
          i = this.parent.children.indexOf(this);
          removed = this.parent.children.splice(i + 1);
          child = this.parent.comment(value);
          Array.prototype.push.apply(this.parent.children, removed);
          return this;
        };
        XMLNode2.prototype.raw = function(value) {
          var child;
          child = new XMLRaw(this, value);
          this.children.push(child);
          return this;
        };
        XMLNode2.prototype.dummy = function() {
          var child;
          child = new XMLDummy(this);
          this.children.push(child);
          return child;
        };
        XMLNode2.prototype.instruction = function(target, value) {
          var insTarget, insValue, instruction, j, len;
          if (target != null) {
            target = getValue(target);
          }
          if (value != null) {
            value = getValue(value);
          }
          if (Array.isArray(target)) {
            for (j = 0, len = target.length; j < len; j++) {
              insTarget = target[j];
              this.instruction(insTarget);
            }
          } else if (isObject3(target)) {
            for (insTarget in target) {
              if (!hasProp.call(target, insTarget)) continue;
              insValue = target[insTarget];
              this.instruction(insTarget, insValue);
            }
          } else {
            if (isFunction2(value)) {
              value = value.apply();
            }
            instruction = new XMLProcessingInstruction(this, target, value);
            this.children.push(instruction);
          }
          return this;
        };
        XMLNode2.prototype.instructionBefore = function(target, value) {
          var child, i, removed;
          i = this.parent.children.indexOf(this);
          removed = this.parent.children.splice(i);
          child = this.parent.instruction(target, value);
          Array.prototype.push.apply(this.parent.children, removed);
          return this;
        };
        XMLNode2.prototype.instructionAfter = function(target, value) {
          var child, i, removed;
          i = this.parent.children.indexOf(this);
          removed = this.parent.children.splice(i + 1);
          child = this.parent.instruction(target, value);
          Array.prototype.push.apply(this.parent.children, removed);
          return this;
        };
        XMLNode2.prototype.declaration = function(version, encoding, standalone) {
          var doc, xmldec;
          doc = this.document();
          xmldec = new XMLDeclaration(doc, version, encoding, standalone);
          if (doc.children[0] instanceof XMLDeclaration) {
            doc.children[0] = xmldec;
          } else {
            doc.children.unshift(xmldec);
          }
          return doc.root() || doc;
        };
        XMLNode2.prototype.doctype = function(pubID, sysID) {
          var child, doc, doctype, i, j, k, len, len1, ref1, ref2;
          doc = this.document();
          doctype = new XMLDocType(doc, pubID, sysID);
          ref1 = doc.children;
          for (i = j = 0, len = ref1.length; j < len; i = ++j) {
            child = ref1[i];
            if (child instanceof XMLDocType) {
              doc.children[i] = doctype;
              return doctype;
            }
          }
          ref2 = doc.children;
          for (i = k = 0, len1 = ref2.length; k < len1; i = ++k) {
            child = ref2[i];
            if (child.isRoot) {
              doc.children.splice(i, 0, doctype);
              return doctype;
            }
          }
          doc.children.push(doctype);
          return doctype;
        };
        XMLNode2.prototype.up = function() {
          if (this.isRoot) {
            throw new Error("The root node has no parent. Use doc() if you need to get the document object.");
          }
          return this.parent;
        };
        XMLNode2.prototype.root = function() {
          var node;
          node = this;
          while (node) {
            if (node.isDocument) {
              return node.rootObject;
            } else if (node.isRoot) {
              return node;
            } else {
              node = node.parent;
            }
          }
        };
        XMLNode2.prototype.document = function() {
          var node;
          node = this;
          while (node) {
            if (node.isDocument) {
              return node;
            } else {
              node = node.parent;
            }
          }
        };
        XMLNode2.prototype.end = function(options) {
          return this.document().end(options);
        };
        XMLNode2.prototype.prev = function() {
          var i;
          i = this.parent.children.indexOf(this);
          while (i > 0 && this.parent.children[i - 1].isDummy) {
            i = i - 1;
          }
          if (i < 1) {
            throw new Error("Already at the first node. " + this.debugInfo());
          }
          return this.parent.children[i - 1];
        };
        XMLNode2.prototype.next = function() {
          var i;
          i = this.parent.children.indexOf(this);
          while (i < this.parent.children.length - 1 && this.parent.children[i + 1].isDummy) {
            i = i + 1;
          }
          if (i === -1 || i === this.parent.children.length - 1) {
            throw new Error("Already at the last node. " + this.debugInfo());
          }
          return this.parent.children[i + 1];
        };
        XMLNode2.prototype.importDocument = function(doc) {
          var clonedRoot;
          clonedRoot = doc.root().clone();
          clonedRoot.parent = this;
          clonedRoot.isRoot = false;
          this.children.push(clonedRoot);
          return this;
        };
        XMLNode2.prototype.debugInfo = function(name) {
          var ref1, ref2;
          name = name || this.name;
          if (name == null && !((ref1 = this.parent) != null ? ref1.name : void 0)) {
            return "";
          } else if (name == null) {
            return "parent: <" + this.parent.name + ">";
          } else if (!((ref2 = this.parent) != null ? ref2.name : void 0)) {
            return "node: <" + name + ">";
          } else {
            return "node: <" + name + ">, parent: <" + this.parent.name + ">";
          }
        };
        XMLNode2.prototype.ele = function(name, attributes, text) {
          return this.element(name, attributes, text);
        };
        XMLNode2.prototype.nod = function(name, attributes, text) {
          return this.node(name, attributes, text);
        };
        XMLNode2.prototype.txt = function(value) {
          return this.text(value);
        };
        XMLNode2.prototype.dat = function(value) {
          return this.cdata(value);
        };
        XMLNode2.prototype.com = function(value) {
          return this.comment(value);
        };
        XMLNode2.prototype.ins = function(target, value) {
          return this.instruction(target, value);
        };
        XMLNode2.prototype.doc = function() {
          return this.document();
        };
        XMLNode2.prototype.dec = function(version, encoding, standalone) {
          return this.declaration(version, encoding, standalone);
        };
        XMLNode2.prototype.dtd = function(pubID, sysID) {
          return this.doctype(pubID, sysID);
        };
        XMLNode2.prototype.e = function(name, attributes, text) {
          return this.element(name, attributes, text);
        };
        XMLNode2.prototype.n = function(name, attributes, text) {
          return this.node(name, attributes, text);
        };
        XMLNode2.prototype.t = function(value) {
          return this.text(value);
        };
        XMLNode2.prototype.d = function(value) {
          return this.cdata(value);
        };
        XMLNode2.prototype.c = function(value) {
          return this.comment(value);
        };
        XMLNode2.prototype.r = function(value) {
          return this.raw(value);
        };
        XMLNode2.prototype.i = function(target, value) {
          return this.instruction(target, value);
        };
        XMLNode2.prototype.u = function() {
          return this.up();
        };
        XMLNode2.prototype.importXMLBuilder = function(doc) {
          return this.importDocument(doc);
        };
        return XMLNode2;
      }();
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLStringifier.js
var require_XMLStringifier = __commonJS({
  "node_modules/xmlbuilder/lib/XMLStringifier.js"(exports2, module2) {
    (function() {
      var XMLStringifier, bind = function(fn, me) {
        return function() {
          return fn.apply(me, arguments);
        };
      }, hasProp = {}.hasOwnProperty;
      module2.exports = XMLStringifier = function() {
        function XMLStringifier2(options) {
          this.assertLegalChar = bind(this.assertLegalChar, this);
          var key, ref, value;
          options || (options = {});
          this.noDoubleEncoding = options.noDoubleEncoding;
          ref = options.stringify || {};
          for (key in ref) {
            if (!hasProp.call(ref, key)) continue;
            value = ref[key];
            this[key] = value;
          }
        }
        XMLStringifier2.prototype.eleName = function(val) {
          val = "" + val || "";
          return this.assertLegalChar(val);
        };
        XMLStringifier2.prototype.eleText = function(val) {
          val = "" + val || "";
          return this.assertLegalChar(this.elEscape(val));
        };
        XMLStringifier2.prototype.cdata = function(val) {
          val = "" + val || "";
          val = val.replace("]]>", "]]]]><![CDATA[>");
          return this.assertLegalChar(val);
        };
        XMLStringifier2.prototype.comment = function(val) {
          val = "" + val || "";
          if (val.match(/--/)) {
            throw new Error("Comment text cannot contain double-hypen: " + val);
          }
          return this.assertLegalChar(val);
        };
        XMLStringifier2.prototype.raw = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.attName = function(val) {
          return val = "" + val || "";
        };
        XMLStringifier2.prototype.attValue = function(val) {
          val = "" + val || "";
          return this.attEscape(val);
        };
        XMLStringifier2.prototype.insTarget = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.insValue = function(val) {
          val = "" + val || "";
          if (val.match(/\?>/)) {
            throw new Error("Invalid processing instruction value: " + val);
          }
          return val;
        };
        XMLStringifier2.prototype.xmlVersion = function(val) {
          val = "" + val || "";
          if (!val.match(/1\.[0-9]+/)) {
            throw new Error("Invalid version number: " + val);
          }
          return val;
        };
        XMLStringifier2.prototype.xmlEncoding = function(val) {
          val = "" + val || "";
          if (!val.match(/^[A-Za-z](?:[A-Za-z0-9._-])*$/)) {
            throw new Error("Invalid encoding: " + val);
          }
          return val;
        };
        XMLStringifier2.prototype.xmlStandalone = function(val) {
          if (val) {
            return "yes";
          } else {
            return "no";
          }
        };
        XMLStringifier2.prototype.dtdPubID = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.dtdSysID = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.dtdElementValue = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.dtdAttType = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.dtdAttDefault = function(val) {
          if (val != null) {
            return "" + val || "";
          } else {
            return val;
          }
        };
        XMLStringifier2.prototype.dtdEntityValue = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.dtdNData = function(val) {
          return "" + val || "";
        };
        XMLStringifier2.prototype.convertAttKey = "@";
        XMLStringifier2.prototype.convertPIKey = "?";
        XMLStringifier2.prototype.convertTextKey = "#text";
        XMLStringifier2.prototype.convertCDataKey = "#cdata";
        XMLStringifier2.prototype.convertCommentKey = "#comment";
        XMLStringifier2.prototype.convertRawKey = "#raw";
        XMLStringifier2.prototype.assertLegalChar = function(str) {
          var res;
          res = str.match(/[\0\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/);
          if (res) {
            throw new Error("Invalid character in string: " + str + " at index " + res.index);
          }
          return str;
        };
        XMLStringifier2.prototype.elEscape = function(str) {
          var ampregex;
          ampregex = this.noDoubleEncoding ? /(?!&\S+;)&/g : /&/g;
          return str.replace(ampregex, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\r/g, "&#xD;");
        };
        XMLStringifier2.prototype.attEscape = function(str) {
          var ampregex;
          ampregex = this.noDoubleEncoding ? /(?!&\S+;)&/g : /&/g;
          return str.replace(ampregex, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;").replace(/\t/g, "&#x9;").replace(/\n/g, "&#xA;").replace(/\r/g, "&#xD;");
        };
        return XMLStringifier2;
      }();
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLWriterBase.js
var require_XMLWriterBase = __commonJS({
  "node_modules/xmlbuilder/lib/XMLWriterBase.js"(exports2, module2) {
    (function() {
      var XMLWriterBase, hasProp = {}.hasOwnProperty;
      module2.exports = XMLWriterBase = function() {
        function XMLWriterBase2(options) {
          var key, ref, ref1, ref2, ref3, ref4, ref5, ref6, value;
          options || (options = {});
          this.pretty = options.pretty || false;
          this.allowEmpty = (ref = options.allowEmpty) != null ? ref : false;
          if (this.pretty) {
            this.indent = (ref1 = options.indent) != null ? ref1 : "  ";
            this.newline = (ref2 = options.newline) != null ? ref2 : "\n";
            this.offset = (ref3 = options.offset) != null ? ref3 : 0;
            this.dontprettytextnodes = (ref4 = options.dontprettytextnodes) != null ? ref4 : 0;
          } else {
            this.indent = "";
            this.newline = "";
            this.offset = 0;
            this.dontprettytextnodes = 0;
          }
          this.spacebeforeslash = (ref5 = options.spacebeforeslash) != null ? ref5 : "";
          if (this.spacebeforeslash === true) {
            this.spacebeforeslash = " ";
          }
          this.newlinedefault = this.newline;
          this.prettydefault = this.pretty;
          ref6 = options.writer || {};
          for (key in ref6) {
            if (!hasProp.call(ref6, key)) continue;
            value = ref6[key];
            this[key] = value;
          }
        }
        XMLWriterBase2.prototype.set = function(options) {
          var key, ref, value;
          options || (options = {});
          if ("pretty" in options) {
            this.pretty = options.pretty;
          }
          if ("allowEmpty" in options) {
            this.allowEmpty = options.allowEmpty;
          }
          if (this.pretty) {
            this.indent = "indent" in options ? options.indent : "  ";
            this.newline = "newline" in options ? options.newline : "\n";
            this.offset = "offset" in options ? options.offset : 0;
            this.dontprettytextnodes = "dontprettytextnodes" in options ? options.dontprettytextnodes : 0;
          } else {
            this.indent = "";
            this.newline = "";
            this.offset = 0;
            this.dontprettytextnodes = 0;
          }
          this.spacebeforeslash = "spacebeforeslash" in options ? options.spacebeforeslash : "";
          if (this.spacebeforeslash === true) {
            this.spacebeforeslash = " ";
          }
          this.newlinedefault = this.newline;
          this.prettydefault = this.pretty;
          ref = options.writer || {};
          for (key in ref) {
            if (!hasProp.call(ref, key)) continue;
            value = ref[key];
            this[key] = value;
          }
          return this;
        };
        XMLWriterBase2.prototype.space = function(level) {
          var indent;
          if (this.pretty) {
            indent = (level || 0) + this.offset + 1;
            if (indent > 0) {
              return new Array(indent).join(this.indent);
            } else {
              return "";
            }
          } else {
            return "";
          }
        };
        return XMLWriterBase2;
      }();
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLStringWriter.js
var require_XMLStringWriter = __commonJS({
  "node_modules/xmlbuilder/lib/XMLStringWriter.js"(exports2, module2) {
    (function() {
      var XMLCData, XMLComment, XMLDTDAttList, XMLDTDElement, XMLDTDEntity, XMLDTDNotation, XMLDeclaration, XMLDocType, XMLDummy, XMLElement, XMLProcessingInstruction, XMLRaw, XMLStringWriter, XMLText, XMLWriterBase, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLDeclaration = require_XMLDeclaration();
      XMLDocType = require_XMLDocType();
      XMLCData = require_XMLCData();
      XMLComment = require_XMLComment();
      XMLElement = require_XMLElement();
      XMLRaw = require_XMLRaw();
      XMLText = require_XMLText();
      XMLProcessingInstruction = require_XMLProcessingInstruction();
      XMLDummy = require_XMLDummy();
      XMLDTDAttList = require_XMLDTDAttList();
      XMLDTDElement = require_XMLDTDElement();
      XMLDTDEntity = require_XMLDTDEntity();
      XMLDTDNotation = require_XMLDTDNotation();
      XMLWriterBase = require_XMLWriterBase();
      module2.exports = XMLStringWriter = function(superClass) {
        extend(XMLStringWriter2, superClass);
        function XMLStringWriter2(options) {
          XMLStringWriter2.__super__.constructor.call(this, options);
        }
        XMLStringWriter2.prototype.document = function(doc) {
          var child, i, len, r, ref;
          this.textispresent = false;
          r = "";
          ref = doc.children;
          for (i = 0, len = ref.length; i < len; i++) {
            child = ref[i];
            if (child instanceof XMLDummy) {
              continue;
            }
            r += function() {
              switch (false) {
                case !(child instanceof XMLDeclaration):
                  return this.declaration(child);
                case !(child instanceof XMLDocType):
                  return this.docType(child);
                case !(child instanceof XMLComment):
                  return this.comment(child);
                case !(child instanceof XMLProcessingInstruction):
                  return this.processingInstruction(child);
                default:
                  return this.element(child, 0);
              }
            }.call(this);
          }
          if (this.pretty && r.slice(-this.newline.length) === this.newline) {
            r = r.slice(0, -this.newline.length);
          }
          return r;
        };
        XMLStringWriter2.prototype.attribute = function(att) {
          return " " + att.name + '="' + att.value + '"';
        };
        XMLStringWriter2.prototype.cdata = function(node, level) {
          return this.space(level) + "<![CDATA[" + node.text + "]]>" + this.newline;
        };
        XMLStringWriter2.prototype.comment = function(node, level) {
          return this.space(level) + "<!-- " + node.text + " -->" + this.newline;
        };
        XMLStringWriter2.prototype.declaration = function(node, level) {
          var r;
          r = this.space(level);
          r += '<?xml version="' + node.version + '"';
          if (node.encoding != null) {
            r += ' encoding="' + node.encoding + '"';
          }
          if (node.standalone != null) {
            r += ' standalone="' + node.standalone + '"';
          }
          r += this.spacebeforeslash + "?>";
          r += this.newline;
          return r;
        };
        XMLStringWriter2.prototype.docType = function(node, level) {
          var child, i, len, r, ref;
          level || (level = 0);
          r = this.space(level);
          r += "<!DOCTYPE " + node.root().name;
          if (node.pubID && node.sysID) {
            r += ' PUBLIC "' + node.pubID + '" "' + node.sysID + '"';
          } else if (node.sysID) {
            r += ' SYSTEM "' + node.sysID + '"';
          }
          if (node.children.length > 0) {
            r += " [";
            r += this.newline;
            ref = node.children;
            for (i = 0, len = ref.length; i < len; i++) {
              child = ref[i];
              r += function() {
                switch (false) {
                  case !(child instanceof XMLDTDAttList):
                    return this.dtdAttList(child, level + 1);
                  case !(child instanceof XMLDTDElement):
                    return this.dtdElement(child, level + 1);
                  case !(child instanceof XMLDTDEntity):
                    return this.dtdEntity(child, level + 1);
                  case !(child instanceof XMLDTDNotation):
                    return this.dtdNotation(child, level + 1);
                  case !(child instanceof XMLCData):
                    return this.cdata(child, level + 1);
                  case !(child instanceof XMLComment):
                    return this.comment(child, level + 1);
                  case !(child instanceof XMLProcessingInstruction):
                    return this.processingInstruction(child, level + 1);
                  default:
                    throw new Error("Unknown DTD node type: " + child.constructor.name);
                }
              }.call(this);
            }
            r += "]";
          }
          r += this.spacebeforeslash + ">";
          r += this.newline;
          return r;
        };
        XMLStringWriter2.prototype.element = function(node, level) {
          var att, child, i, j, len, len1, name, r, ref, ref1, ref2, space, textispresentwasset;
          level || (level = 0);
          textispresentwasset = false;
          if (this.textispresent) {
            this.newline = "";
            this.pretty = false;
          } else {
            this.newline = this.newlinedefault;
            this.pretty = this.prettydefault;
          }
          space = this.space(level);
          r = "";
          r += space + "<" + node.name;
          ref = node.attributes;
          for (name in ref) {
            if (!hasProp.call(ref, name)) continue;
            att = ref[name];
            r += this.attribute(att);
          }
          if (node.children.length === 0 || node.children.every(function(e) {
            return e.value === "";
          })) {
            if (this.allowEmpty) {
              r += "></" + node.name + ">" + this.newline;
            } else {
              r += this.spacebeforeslash + "/>" + this.newline;
            }
          } else if (this.pretty && node.children.length === 1 && node.children[0].value != null) {
            r += ">";
            r += node.children[0].value;
            r += "</" + node.name + ">" + this.newline;
          } else {
            if (this.dontprettytextnodes) {
              ref1 = node.children;
              for (i = 0, len = ref1.length; i < len; i++) {
                child = ref1[i];
                if (child.value != null) {
                  this.textispresent++;
                  textispresentwasset = true;
                  break;
                }
              }
            }
            if (this.textispresent) {
              this.newline = "";
              this.pretty = false;
              space = this.space(level);
            }
            r += ">" + this.newline;
            ref2 = node.children;
            for (j = 0, len1 = ref2.length; j < len1; j++) {
              child = ref2[j];
              r += function() {
                switch (false) {
                  case !(child instanceof XMLCData):
                    return this.cdata(child, level + 1);
                  case !(child instanceof XMLComment):
                    return this.comment(child, level + 1);
                  case !(child instanceof XMLElement):
                    return this.element(child, level + 1);
                  case !(child instanceof XMLRaw):
                    return this.raw(child, level + 1);
                  case !(child instanceof XMLText):
                    return this.text(child, level + 1);
                  case !(child instanceof XMLProcessingInstruction):
                    return this.processingInstruction(child, level + 1);
                  case !(child instanceof XMLDummy):
                    return "";
                  default:
                    throw new Error("Unknown XML node type: " + child.constructor.name);
                }
              }.call(this);
            }
            if (textispresentwasset) {
              this.textispresent--;
            }
            if (!this.textispresent) {
              this.newline = this.newlinedefault;
              this.pretty = this.prettydefault;
            }
            r += space + "</" + node.name + ">" + this.newline;
          }
          return r;
        };
        XMLStringWriter2.prototype.processingInstruction = function(node, level) {
          var r;
          r = this.space(level) + "<?" + node.target;
          if (node.value) {
            r += " " + node.value;
          }
          r += this.spacebeforeslash + "?>" + this.newline;
          return r;
        };
        XMLStringWriter2.prototype.raw = function(node, level) {
          return this.space(level) + node.value + this.newline;
        };
        XMLStringWriter2.prototype.text = function(node, level) {
          return this.space(level) + node.value + this.newline;
        };
        XMLStringWriter2.prototype.dtdAttList = function(node, level) {
          var r;
          r = this.space(level) + "<!ATTLIST " + node.elementName + " " + node.attributeName + " " + node.attributeType;
          if (node.defaultValueType !== "#DEFAULT") {
            r += " " + node.defaultValueType;
          }
          if (node.defaultValue) {
            r += ' "' + node.defaultValue + '"';
          }
          r += this.spacebeforeslash + ">" + this.newline;
          return r;
        };
        XMLStringWriter2.prototype.dtdElement = function(node, level) {
          return this.space(level) + "<!ELEMENT " + node.name + " " + node.value + this.spacebeforeslash + ">" + this.newline;
        };
        XMLStringWriter2.prototype.dtdEntity = function(node, level) {
          var r;
          r = this.space(level) + "<!ENTITY";
          if (node.pe) {
            r += " %";
          }
          r += " " + node.name;
          if (node.value) {
            r += ' "' + node.value + '"';
          } else {
            if (node.pubID && node.sysID) {
              r += ' PUBLIC "' + node.pubID + '" "' + node.sysID + '"';
            } else if (node.sysID) {
              r += ' SYSTEM "' + node.sysID + '"';
            }
            if (node.nData) {
              r += " NDATA " + node.nData;
            }
          }
          r += this.spacebeforeslash + ">" + this.newline;
          return r;
        };
        XMLStringWriter2.prototype.dtdNotation = function(node, level) {
          var r;
          r = this.space(level) + "<!NOTATION " + node.name;
          if (node.pubID && node.sysID) {
            r += ' PUBLIC "' + node.pubID + '" "' + node.sysID + '"';
          } else if (node.pubID) {
            r += ' PUBLIC "' + node.pubID + '"';
          } else if (node.sysID) {
            r += ' SYSTEM "' + node.sysID + '"';
          }
          r += this.spacebeforeslash + ">" + this.newline;
          return r;
        };
        XMLStringWriter2.prototype.openNode = function(node, level) {
          var att, name, r, ref;
          level || (level = 0);
          if (node instanceof XMLElement) {
            r = this.space(level) + "<" + node.name;
            ref = node.attributes;
            for (name in ref) {
              if (!hasProp.call(ref, name)) continue;
              att = ref[name];
              r += this.attribute(att);
            }
            r += (node.children ? ">" : "/>") + this.newline;
            return r;
          } else {
            r = this.space(level) + "<!DOCTYPE " + node.rootNodeName;
            if (node.pubID && node.sysID) {
              r += ' PUBLIC "' + node.pubID + '" "' + node.sysID + '"';
            } else if (node.sysID) {
              r += ' SYSTEM "' + node.sysID + '"';
            }
            r += (node.children ? " [" : ">") + this.newline;
            return r;
          }
        };
        XMLStringWriter2.prototype.closeNode = function(node, level) {
          level || (level = 0);
          switch (false) {
            case !(node instanceof XMLElement):
              return this.space(level) + "</" + node.name + ">" + this.newline;
            case !(node instanceof XMLDocType):
              return this.space(level) + "]>" + this.newline;
          }
        };
        return XMLStringWriter2;
      }(XMLWriterBase);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDocument.js
var require_XMLDocument = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDocument.js"(exports2, module2) {
    (function() {
      var XMLDocument, XMLNode, XMLStringWriter, XMLStringifier, isPlainObject, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      isPlainObject = require_Utility().isPlainObject;
      XMLNode = require_XMLNode();
      XMLStringifier = require_XMLStringifier();
      XMLStringWriter = require_XMLStringWriter();
      module2.exports = XMLDocument = function(superClass) {
        extend(XMLDocument2, superClass);
        function XMLDocument2(options) {
          XMLDocument2.__super__.constructor.call(this, null);
          this.name = "?xml";
          options || (options = {});
          if (!options.writer) {
            options.writer = new XMLStringWriter();
          }
          this.options = options;
          this.stringify = new XMLStringifier(options);
          this.isDocument = true;
        }
        XMLDocument2.prototype.end = function(writer) {
          var writerOptions;
          if (!writer) {
            writer = this.options.writer;
          } else if (isPlainObject(writer)) {
            writerOptions = writer;
            writer = this.options.writer.set(writerOptions);
          }
          return writer.document(this);
        };
        XMLDocument2.prototype.toString = function(options) {
          return this.options.writer.set(options).document(this);
        };
        return XMLDocument2;
      }(XMLNode);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLDocumentCB.js
var require_XMLDocumentCB = __commonJS({
  "node_modules/xmlbuilder/lib/XMLDocumentCB.js"(exports2, module2) {
    (function() {
      var XMLAttribute, XMLCData, XMLComment, XMLDTDAttList, XMLDTDElement, XMLDTDEntity, XMLDTDNotation, XMLDeclaration, XMLDocType, XMLDocumentCB, XMLElement, XMLProcessingInstruction, XMLRaw, XMLStringWriter, XMLStringifier, XMLText, getValue, isFunction2, isObject3, isPlainObject, ref, hasProp = {}.hasOwnProperty;
      ref = require_Utility(), isObject3 = ref.isObject, isFunction2 = ref.isFunction, isPlainObject = ref.isPlainObject, getValue = ref.getValue;
      XMLElement = require_XMLElement();
      XMLCData = require_XMLCData();
      XMLComment = require_XMLComment();
      XMLRaw = require_XMLRaw();
      XMLText = require_XMLText();
      XMLProcessingInstruction = require_XMLProcessingInstruction();
      XMLDeclaration = require_XMLDeclaration();
      XMLDocType = require_XMLDocType();
      XMLDTDAttList = require_XMLDTDAttList();
      XMLDTDEntity = require_XMLDTDEntity();
      XMLDTDElement = require_XMLDTDElement();
      XMLDTDNotation = require_XMLDTDNotation();
      XMLAttribute = require_XMLAttribute();
      XMLStringifier = require_XMLStringifier();
      XMLStringWriter = require_XMLStringWriter();
      module2.exports = XMLDocumentCB = function() {
        function XMLDocumentCB2(options, onData, onEnd) {
          var writerOptions;
          this.name = "?xml";
          options || (options = {});
          if (!options.writer) {
            options.writer = new XMLStringWriter(options);
          } else if (isPlainObject(options.writer)) {
            writerOptions = options.writer;
            options.writer = new XMLStringWriter(writerOptions);
          }
          this.options = options;
          this.writer = options.writer;
          this.stringify = new XMLStringifier(options);
          this.onDataCallback = onData || function() {
          };
          this.onEndCallback = onEnd || function() {
          };
          this.currentNode = null;
          this.currentLevel = -1;
          this.openTags = {};
          this.documentStarted = false;
          this.documentCompleted = false;
          this.root = null;
        }
        XMLDocumentCB2.prototype.node = function(name, attributes, text) {
          var ref1, ref2;
          if (name == null) {
            throw new Error("Missing node name.");
          }
          if (this.root && this.currentLevel === -1) {
            throw new Error("Document can only have one root node. " + this.debugInfo(name));
          }
          this.openCurrent();
          name = getValue(name);
          if (attributes === null && text == null) {
            ref1 = [{}, null], attributes = ref1[0], text = ref1[1];
          }
          if (attributes == null) {
            attributes = {};
          }
          attributes = getValue(attributes);
          if (!isObject3(attributes)) {
            ref2 = [attributes, text], text = ref2[0], attributes = ref2[1];
          }
          this.currentNode = new XMLElement(this, name, attributes);
          this.currentNode.children = false;
          this.currentLevel++;
          this.openTags[this.currentLevel] = this.currentNode;
          if (text != null) {
            this.text(text);
          }
          return this;
        };
        XMLDocumentCB2.prototype.element = function(name, attributes, text) {
          if (this.currentNode && this.currentNode instanceof XMLDocType) {
            return this.dtdElement.apply(this, arguments);
          } else {
            return this.node(name, attributes, text);
          }
        };
        XMLDocumentCB2.prototype.attribute = function(name, value) {
          var attName, attValue;
          if (!this.currentNode || this.currentNode.children) {
            throw new Error("att() can only be used immediately after an ele() call in callback mode. " + this.debugInfo(name));
          }
          if (name != null) {
            name = getValue(name);
          }
          if (isObject3(name)) {
            for (attName in name) {
              if (!hasProp.call(name, attName)) continue;
              attValue = name[attName];
              this.attribute(attName, attValue);
            }
          } else {
            if (isFunction2(value)) {
              value = value.apply();
            }
            if (!this.options.skipNullAttributes || value != null) {
              this.currentNode.attributes[name] = new XMLAttribute(this, name, value);
            }
          }
          return this;
        };
        XMLDocumentCB2.prototype.text = function(value) {
          var node;
          this.openCurrent();
          node = new XMLText(this, value);
          this.onData(this.writer.text(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.cdata = function(value) {
          var node;
          this.openCurrent();
          node = new XMLCData(this, value);
          this.onData(this.writer.cdata(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.comment = function(value) {
          var node;
          this.openCurrent();
          node = new XMLComment(this, value);
          this.onData(this.writer.comment(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.raw = function(value) {
          var node;
          this.openCurrent();
          node = new XMLRaw(this, value);
          this.onData(this.writer.raw(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.instruction = function(target, value) {
          var i, insTarget, insValue, len, node;
          this.openCurrent();
          if (target != null) {
            target = getValue(target);
          }
          if (value != null) {
            value = getValue(value);
          }
          if (Array.isArray(target)) {
            for (i = 0, len = target.length; i < len; i++) {
              insTarget = target[i];
              this.instruction(insTarget);
            }
          } else if (isObject3(target)) {
            for (insTarget in target) {
              if (!hasProp.call(target, insTarget)) continue;
              insValue = target[insTarget];
              this.instruction(insTarget, insValue);
            }
          } else {
            if (isFunction2(value)) {
              value = value.apply();
            }
            node = new XMLProcessingInstruction(this, target, value);
            this.onData(this.writer.processingInstruction(node, this.currentLevel + 1), this.currentLevel + 1);
          }
          return this;
        };
        XMLDocumentCB2.prototype.declaration = function(version, encoding, standalone) {
          var node;
          this.openCurrent();
          if (this.documentStarted) {
            throw new Error("declaration() must be the first node.");
          }
          node = new XMLDeclaration(this, version, encoding, standalone);
          this.onData(this.writer.declaration(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.doctype = function(root2, pubID, sysID) {
          this.openCurrent();
          if (root2 == null) {
            throw new Error("Missing root node name.");
          }
          if (this.root) {
            throw new Error("dtd() must come before the root node.");
          }
          this.currentNode = new XMLDocType(this, pubID, sysID);
          this.currentNode.rootNodeName = root2;
          this.currentNode.children = false;
          this.currentLevel++;
          this.openTags[this.currentLevel] = this.currentNode;
          return this;
        };
        XMLDocumentCB2.prototype.dtdElement = function(name, value) {
          var node;
          this.openCurrent();
          node = new XMLDTDElement(this, name, value);
          this.onData(this.writer.dtdElement(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.attList = function(elementName, attributeName, attributeType, defaultValueType, defaultValue) {
          var node;
          this.openCurrent();
          node = new XMLDTDAttList(this, elementName, attributeName, attributeType, defaultValueType, defaultValue);
          this.onData(this.writer.dtdAttList(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.entity = function(name, value) {
          var node;
          this.openCurrent();
          node = new XMLDTDEntity(this, false, name, value);
          this.onData(this.writer.dtdEntity(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.pEntity = function(name, value) {
          var node;
          this.openCurrent();
          node = new XMLDTDEntity(this, true, name, value);
          this.onData(this.writer.dtdEntity(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.notation = function(name, value) {
          var node;
          this.openCurrent();
          node = new XMLDTDNotation(this, name, value);
          this.onData(this.writer.dtdNotation(node, this.currentLevel + 1), this.currentLevel + 1);
          return this;
        };
        XMLDocumentCB2.prototype.up = function() {
          if (this.currentLevel < 0) {
            throw new Error("The document node has no parent.");
          }
          if (this.currentNode) {
            if (this.currentNode.children) {
              this.closeNode(this.currentNode);
            } else {
              this.openNode(this.currentNode);
            }
            this.currentNode = null;
          } else {
            this.closeNode(this.openTags[this.currentLevel]);
          }
          delete this.openTags[this.currentLevel];
          this.currentLevel--;
          return this;
        };
        XMLDocumentCB2.prototype.end = function() {
          while (this.currentLevel >= 0) {
            this.up();
          }
          return this.onEnd();
        };
        XMLDocumentCB2.prototype.openCurrent = function() {
          if (this.currentNode) {
            this.currentNode.children = true;
            return this.openNode(this.currentNode);
          }
        };
        XMLDocumentCB2.prototype.openNode = function(node) {
          if (!node.isOpen) {
            if (!this.root && this.currentLevel === 0 && node instanceof XMLElement) {
              this.root = node;
            }
            this.onData(this.writer.openNode(node, this.currentLevel), this.currentLevel);
            return node.isOpen = true;
          }
        };
        XMLDocumentCB2.prototype.closeNode = function(node) {
          if (!node.isClosed) {
            this.onData(this.writer.closeNode(node, this.currentLevel), this.currentLevel);
            return node.isClosed = true;
          }
        };
        XMLDocumentCB2.prototype.onData = function(chunk2, level) {
          this.documentStarted = true;
          return this.onDataCallback(chunk2, level + 1);
        };
        XMLDocumentCB2.prototype.onEnd = function() {
          this.documentCompleted = true;
          return this.onEndCallback();
        };
        XMLDocumentCB2.prototype.debugInfo = function(name) {
          if (name == null) {
            return "";
          } else {
            return "node: <" + name + ">";
          }
        };
        XMLDocumentCB2.prototype.ele = function() {
          return this.element.apply(this, arguments);
        };
        XMLDocumentCB2.prototype.nod = function(name, attributes, text) {
          return this.node(name, attributes, text);
        };
        XMLDocumentCB2.prototype.txt = function(value) {
          return this.text(value);
        };
        XMLDocumentCB2.prototype.dat = function(value) {
          return this.cdata(value);
        };
        XMLDocumentCB2.prototype.com = function(value) {
          return this.comment(value);
        };
        XMLDocumentCB2.prototype.ins = function(target, value) {
          return this.instruction(target, value);
        };
        XMLDocumentCB2.prototype.dec = function(version, encoding, standalone) {
          return this.declaration(version, encoding, standalone);
        };
        XMLDocumentCB2.prototype.dtd = function(root2, pubID, sysID) {
          return this.doctype(root2, pubID, sysID);
        };
        XMLDocumentCB2.prototype.e = function(name, attributes, text) {
          return this.element(name, attributes, text);
        };
        XMLDocumentCB2.prototype.n = function(name, attributes, text) {
          return this.node(name, attributes, text);
        };
        XMLDocumentCB2.prototype.t = function(value) {
          return this.text(value);
        };
        XMLDocumentCB2.prototype.d = function(value) {
          return this.cdata(value);
        };
        XMLDocumentCB2.prototype.c = function(value) {
          return this.comment(value);
        };
        XMLDocumentCB2.prototype.r = function(value) {
          return this.raw(value);
        };
        XMLDocumentCB2.prototype.i = function(target, value) {
          return this.instruction(target, value);
        };
        XMLDocumentCB2.prototype.att = function() {
          if (this.currentNode && this.currentNode instanceof XMLDocType) {
            return this.attList.apply(this, arguments);
          } else {
            return this.attribute.apply(this, arguments);
          }
        };
        XMLDocumentCB2.prototype.a = function() {
          if (this.currentNode && this.currentNode instanceof XMLDocType) {
            return this.attList.apply(this, arguments);
          } else {
            return this.attribute.apply(this, arguments);
          }
        };
        XMLDocumentCB2.prototype.ent = function(name, value) {
          return this.entity(name, value);
        };
        XMLDocumentCB2.prototype.pent = function(name, value) {
          return this.pEntity(name, value);
        };
        XMLDocumentCB2.prototype.not = function(name, value) {
          return this.notation(name, value);
        };
        return XMLDocumentCB2;
      }();
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/XMLStreamWriter.js
var require_XMLStreamWriter = __commonJS({
  "node_modules/xmlbuilder/lib/XMLStreamWriter.js"(exports2, module2) {
    (function() {
      var XMLCData, XMLComment, XMLDTDAttList, XMLDTDElement, XMLDTDEntity, XMLDTDNotation, XMLDeclaration, XMLDocType, XMLDummy, XMLElement, XMLProcessingInstruction, XMLRaw, XMLStreamWriter, XMLText, XMLWriterBase, extend = function(child, parent) {
        for (var key in parent) {
          if (hasProp.call(parent, key)) child[key] = parent[key];
        }
        function ctor2() {
          this.constructor = child;
        }
        ctor2.prototype = parent.prototype;
        child.prototype = new ctor2();
        child.__super__ = parent.prototype;
        return child;
      }, hasProp = {}.hasOwnProperty;
      XMLDeclaration = require_XMLDeclaration();
      XMLDocType = require_XMLDocType();
      XMLCData = require_XMLCData();
      XMLComment = require_XMLComment();
      XMLElement = require_XMLElement();
      XMLRaw = require_XMLRaw();
      XMLText = require_XMLText();
      XMLProcessingInstruction = require_XMLProcessingInstruction();
      XMLDummy = require_XMLDummy();
      XMLDTDAttList = require_XMLDTDAttList();
      XMLDTDElement = require_XMLDTDElement();
      XMLDTDEntity = require_XMLDTDEntity();
      XMLDTDNotation = require_XMLDTDNotation();
      XMLWriterBase = require_XMLWriterBase();
      module2.exports = XMLStreamWriter = function(superClass) {
        extend(XMLStreamWriter2, superClass);
        function XMLStreamWriter2(stream, options) {
          XMLStreamWriter2.__super__.constructor.call(this, options);
          this.stream = stream;
        }
        XMLStreamWriter2.prototype.document = function(doc) {
          var child, i, j, len, len1, ref, ref1, results;
          ref = doc.children;
          for (i = 0, len = ref.length; i < len; i++) {
            child = ref[i];
            child.isLastRootNode = false;
          }
          doc.children[doc.children.length - 1].isLastRootNode = true;
          ref1 = doc.children;
          results = [];
          for (j = 0, len1 = ref1.length; j < len1; j++) {
            child = ref1[j];
            if (child instanceof XMLDummy) {
              continue;
            }
            switch (false) {
              case !(child instanceof XMLDeclaration):
                results.push(this.declaration(child));
                break;
              case !(child instanceof XMLDocType):
                results.push(this.docType(child));
                break;
              case !(child instanceof XMLComment):
                results.push(this.comment(child));
                break;
              case !(child instanceof XMLProcessingInstruction):
                results.push(this.processingInstruction(child));
                break;
              default:
                results.push(this.element(child));
            }
          }
          return results;
        };
        XMLStreamWriter2.prototype.attribute = function(att) {
          return this.stream.write(" " + att.name + '="' + att.value + '"');
        };
        XMLStreamWriter2.prototype.cdata = function(node, level) {
          return this.stream.write(this.space(level) + "<![CDATA[" + node.text + "]]>" + this.endline(node));
        };
        XMLStreamWriter2.prototype.comment = function(node, level) {
          return this.stream.write(this.space(level) + "<!-- " + node.text + " -->" + this.endline(node));
        };
        XMLStreamWriter2.prototype.declaration = function(node, level) {
          this.stream.write(this.space(level));
          this.stream.write('<?xml version="' + node.version + '"');
          if (node.encoding != null) {
            this.stream.write(' encoding="' + node.encoding + '"');
          }
          if (node.standalone != null) {
            this.stream.write(' standalone="' + node.standalone + '"');
          }
          this.stream.write(this.spacebeforeslash + "?>");
          return this.stream.write(this.endline(node));
        };
        XMLStreamWriter2.prototype.docType = function(node, level) {
          var child, i, len, ref;
          level || (level = 0);
          this.stream.write(this.space(level));
          this.stream.write("<!DOCTYPE " + node.root().name);
          if (node.pubID && node.sysID) {
            this.stream.write(' PUBLIC "' + node.pubID + '" "' + node.sysID + '"');
          } else if (node.sysID) {
            this.stream.write(' SYSTEM "' + node.sysID + '"');
          }
          if (node.children.length > 0) {
            this.stream.write(" [");
            this.stream.write(this.endline(node));
            ref = node.children;
            for (i = 0, len = ref.length; i < len; i++) {
              child = ref[i];
              switch (false) {
                case !(child instanceof XMLDTDAttList):
                  this.dtdAttList(child, level + 1);
                  break;
                case !(child instanceof XMLDTDElement):
                  this.dtdElement(child, level + 1);
                  break;
                case !(child instanceof XMLDTDEntity):
                  this.dtdEntity(child, level + 1);
                  break;
                case !(child instanceof XMLDTDNotation):
                  this.dtdNotation(child, level + 1);
                  break;
                case !(child instanceof XMLCData):
                  this.cdata(child, level + 1);
                  break;
                case !(child instanceof XMLComment):
                  this.comment(child, level + 1);
                  break;
                case !(child instanceof XMLProcessingInstruction):
                  this.processingInstruction(child, level + 1);
                  break;
                default:
                  throw new Error("Unknown DTD node type: " + child.constructor.name);
              }
            }
            this.stream.write("]");
          }
          this.stream.write(this.spacebeforeslash + ">");
          return this.stream.write(this.endline(node));
        };
        XMLStreamWriter2.prototype.element = function(node, level) {
          var att, child, i, len, name, ref, ref1, space;
          level || (level = 0);
          space = this.space(level);
          this.stream.write(space + "<" + node.name);
          ref = node.attributes;
          for (name in ref) {
            if (!hasProp.call(ref, name)) continue;
            att = ref[name];
            this.attribute(att);
          }
          if (node.children.length === 0 || node.children.every(function(e) {
            return e.value === "";
          })) {
            if (this.allowEmpty) {
              this.stream.write("></" + node.name + ">");
            } else {
              this.stream.write(this.spacebeforeslash + "/>");
            }
          } else if (this.pretty && node.children.length === 1 && node.children[0].value != null) {
            this.stream.write(">");
            this.stream.write(node.children[0].value);
            this.stream.write("</" + node.name + ">");
          } else {
            this.stream.write(">" + this.newline);
            ref1 = node.children;
            for (i = 0, len = ref1.length; i < len; i++) {
              child = ref1[i];
              switch (false) {
                case !(child instanceof XMLCData):
                  this.cdata(child, level + 1);
                  break;
                case !(child instanceof XMLComment):
                  this.comment(child, level + 1);
                  break;
                case !(child instanceof XMLElement):
                  this.element(child, level + 1);
                  break;
                case !(child instanceof XMLRaw):
                  this.raw(child, level + 1);
                  break;
                case !(child instanceof XMLText):
                  this.text(child, level + 1);
                  break;
                case !(child instanceof XMLProcessingInstruction):
                  this.processingInstruction(child, level + 1);
                  break;
                case !(child instanceof XMLDummy):
                  "";
                  break;
                default:
                  throw new Error("Unknown XML node type: " + child.constructor.name);
              }
            }
            this.stream.write(space + "</" + node.name + ">");
          }
          return this.stream.write(this.endline(node));
        };
        XMLStreamWriter2.prototype.processingInstruction = function(node, level) {
          this.stream.write(this.space(level) + "<?" + node.target);
          if (node.value) {
            this.stream.write(" " + node.value);
          }
          return this.stream.write(this.spacebeforeslash + "?>" + this.endline(node));
        };
        XMLStreamWriter2.prototype.raw = function(node, level) {
          return this.stream.write(this.space(level) + node.value + this.endline(node));
        };
        XMLStreamWriter2.prototype.text = function(node, level) {
          return this.stream.write(this.space(level) + node.value + this.endline(node));
        };
        XMLStreamWriter2.prototype.dtdAttList = function(node, level) {
          this.stream.write(this.space(level) + "<!ATTLIST " + node.elementName + " " + node.attributeName + " " + node.attributeType);
          if (node.defaultValueType !== "#DEFAULT") {
            this.stream.write(" " + node.defaultValueType);
          }
          if (node.defaultValue) {
            this.stream.write(' "' + node.defaultValue + '"');
          }
          return this.stream.write(this.spacebeforeslash + ">" + this.endline(node));
        };
        XMLStreamWriter2.prototype.dtdElement = function(node, level) {
          this.stream.write(this.space(level) + "<!ELEMENT " + node.name + " " + node.value);
          return this.stream.write(this.spacebeforeslash + ">" + this.endline(node));
        };
        XMLStreamWriter2.prototype.dtdEntity = function(node, level) {
          this.stream.write(this.space(level) + "<!ENTITY");
          if (node.pe) {
            this.stream.write(" %");
          }
          this.stream.write(" " + node.name);
          if (node.value) {
            this.stream.write(' "' + node.value + '"');
          } else {
            if (node.pubID && node.sysID) {
              this.stream.write(' PUBLIC "' + node.pubID + '" "' + node.sysID + '"');
            } else if (node.sysID) {
              this.stream.write(' SYSTEM "' + node.sysID + '"');
            }
            if (node.nData) {
              this.stream.write(" NDATA " + node.nData);
            }
          }
          return this.stream.write(this.spacebeforeslash + ">" + this.endline(node));
        };
        XMLStreamWriter2.prototype.dtdNotation = function(node, level) {
          this.stream.write(this.space(level) + "<!NOTATION " + node.name);
          if (node.pubID && node.sysID) {
            this.stream.write(' PUBLIC "' + node.pubID + '" "' + node.sysID + '"');
          } else if (node.pubID) {
            this.stream.write(' PUBLIC "' + node.pubID + '"');
          } else if (node.sysID) {
            this.stream.write(' SYSTEM "' + node.sysID + '"');
          }
          return this.stream.write(this.spacebeforeslash + ">" + this.endline(node));
        };
        XMLStreamWriter2.prototype.endline = function(node) {
          if (!node.isLastRootNode) {
            return this.newline;
          } else {
            return "";
          }
        };
        return XMLStreamWriter2;
      }(XMLWriterBase);
    }).call(exports2);
  }
});

// node_modules/xmlbuilder/lib/index.js
var require_lib2 = __commonJS({
  "node_modules/xmlbuilder/lib/index.js"(exports2, module2) {
    (function() {
      var XMLDocument, XMLDocumentCB, XMLStreamWriter, XMLStringWriter, assign, isFunction2, ref;
      ref = require_Utility(), assign = ref.assign, isFunction2 = ref.isFunction;
      XMLDocument = require_XMLDocument();
      XMLDocumentCB = require_XMLDocumentCB();
      XMLStringWriter = require_XMLStringWriter();
      XMLStreamWriter = require_XMLStreamWriter();
      module2.exports.create = function(name, xmldec, doctype, options) {
        var doc, root2;
        if (name == null) {
          throw new Error("Root element needs a name.");
        }
        options = assign({}, xmldec, doctype, options);
        doc = new XMLDocument(options);
        root2 = doc.element(name);
        if (!options.headless) {
          doc.declaration(options);
          if (options.pubID != null || options.sysID != null) {
            doc.doctype(options);
          }
        }
        return root2;
      };
      module2.exports.begin = function(options, onData, onEnd) {
        var ref1;
        if (isFunction2(options)) {
          ref1 = [options, onData], onData = ref1[0], onEnd = ref1[1];
          options = {};
        }
        if (onData) {
          return new XMLDocumentCB(options, onData, onEnd);
        } else {
          return new XMLDocument(options);
        }
      };
      module2.exports.stringWriter = function(options) {
        return new XMLStringWriter(options);
      };
      module2.exports.streamWriter = function(stream, options) {
        return new XMLStreamWriter(stream, options);
      };
    }).call(exports2);
  }
});

// node_modules/mammoth/lib/xml/writer.js
var require_writer = __commonJS({
  "node_modules/mammoth/lib/xml/writer.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var xmlbuilder = require_lib2();
    exports2.writeString = writeString;
    function writeString(root2, namespaces) {
      var uriToPrefix = _3.invert(namespaces);
      var nodeWriters = {
        element: writeElement,
        text: writeTextNode
      };
      function writeNode(builder, node) {
        return nodeWriters[node.type](builder, node);
      }
      function writeElement(builder, element) {
        var elementBuilder = builder.element(mapElementName(element.name), element.attributes);
        element.children.forEach(function(child) {
          writeNode(elementBuilder, child);
        });
      }
      function mapElementName(name) {
        var longFormMatch = /^\{(.*)\}(.*)$/.exec(name);
        if (longFormMatch) {
          var prefix = uriToPrefix[longFormMatch[1]];
          return prefix + (prefix === "" ? "" : ":") + longFormMatch[2];
        } else {
          return name;
        }
      }
      function writeDocument(root3) {
        var builder = xmlbuilder.create(mapElementName(root3.name), {
          version: "1.0",
          encoding: "UTF-8",
          standalone: true
        });
        _3.forEach(namespaces, function(uri, prefix) {
          var key = "xmlns" + (prefix === "" ? "" : ":" + prefix);
          builder.attribute(key, uri);
        });
        root3.children.forEach(function(child) {
          writeNode(builder, child);
        });
        return builder.end();
      }
      return writeDocument(root2);
    }
    function writeTextNode(builder, node) {
      builder.text(node.value);
    }
  }
});

// node_modules/mammoth/lib/xml/index.js
var require_xml = __commonJS({
  "node_modules/mammoth/lib/xml/index.js"(exports2) {
    var nodes = require_nodes();
    exports2.Element = nodes.Element;
    exports2.element = nodes.element;
    exports2.emptyElement = nodes.emptyElement;
    exports2.text = nodes.text;
    exports2.readString = require_reader().readString;
    exports2.writeString = require_writer().writeString;
  }
});

// node_modules/mammoth/lib/docx/office-xml-reader.js
var require_office_xml_reader = __commonJS({
  "node_modules/mammoth/lib/docx/office-xml-reader.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var promises = require_promises();
    var xml = require_xml();
    exports2.read = read;
    exports2.readXmlFromZipFile = readXmlFromZipFile;
    var xmlNamespaceMap = {
      // Transitional format
      "http://schemas.openxmlformats.org/wordprocessingml/2006/main": "w",
      "http://schemas.openxmlformats.org/officeDocument/2006/relationships": "r",
      "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing": "wp",
      "http://schemas.openxmlformats.org/drawingml/2006/main": "a",
      "http://schemas.openxmlformats.org/drawingml/2006/picture": "pic",
      // Strict format
      "http://purl.oclc.org/ooxml/wordprocessingml/main": "w",
      "http://purl.oclc.org/ooxml/officeDocument/relationships": "r",
      "http://purl.oclc.org/ooxml/drawingml/wordprocessingDrawing": "wp",
      "http://purl.oclc.org/ooxml/drawingml/main": "a",
      "http://purl.oclc.org/ooxml/drawingml/picture": "pic",
      // Common
      "http://schemas.openxmlformats.org/package/2006/content-types": "content-types",
      "http://schemas.openxmlformats.org/package/2006/relationships": "relationships",
      "http://schemas.openxmlformats.org/markup-compatibility/2006": "mc",
      "urn:schemas-microsoft-com:vml": "v",
      "urn:schemas-microsoft-com:office:word": "office-word",
      // [MS-DOCX]: Word Extensions to the Office Open XML (.docx) File Format
      // https://learn.microsoft.com/en-us/openspecs/office_standards/ms-docx/b839fe1f-e1ca-4fa6-8c26-5954d0abbccd
      "http://schemas.microsoft.com/office/word/2010/wordml": "wordml"
    };
    function read(xmlString) {
      return xml.readString(xmlString, xmlNamespaceMap).then(function(document2) {
        return collapseAlternateContent(document2)[0];
      });
    }
    function readXmlFromZipFile(docxFile, path) {
      if (docxFile.exists(path)) {
        return docxFile.read(path, "utf-8").then(stripUtf8Bom).then(read);
      } else {
        return promises.resolve(null);
      }
    }
    function stripUtf8Bom(xmlString) {
      return xmlString.replace(/^\uFEFF/g, "");
    }
    function collapseAlternateContent(node) {
      if (node.type === "element") {
        if (node.name === "mc:AlternateContent") {
          return node.firstOrEmpty("mc:Fallback").children;
        } else {
          node.children = _3.flatten(node.children.map(collapseAlternateContent, true));
          return [node];
        }
      } else {
        return [node];
      }
    }
  }
});

// node_modules/dingbat-to-unicode/dist/dingbats.js
var require_dingbats = __commonJS({
  "node_modules/dingbat-to-unicode/dist/dingbats.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    var dingbats = [{
      "Typeface name": "Symbol",
      "Dingbat dec": "32",
      "Dingbat hex": "20",
      "Unicode dec": "32",
      "Unicode hex": "20"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "33",
      "Dingbat hex": "21",
      "Unicode dec": "33",
      "Unicode hex": "21"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "34",
      "Dingbat hex": "22",
      "Unicode dec": "8704",
      "Unicode hex": "2200"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "35",
      "Dingbat hex": "23",
      "Unicode dec": "35",
      "Unicode hex": "23"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "36",
      "Dingbat hex": "24",
      "Unicode dec": "8707",
      "Unicode hex": "2203"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "37",
      "Dingbat hex": "25",
      "Unicode dec": "37",
      "Unicode hex": "25"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "38",
      "Dingbat hex": "26",
      "Unicode dec": "38",
      "Unicode hex": "26"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "39",
      "Dingbat hex": "27",
      "Unicode dec": "8717",
      "Unicode hex": "220D"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "40",
      "Dingbat hex": "28",
      "Unicode dec": "40",
      "Unicode hex": "28"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "41",
      "Dingbat hex": "29",
      "Unicode dec": "41",
      "Unicode hex": "29"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "42",
      "Dingbat hex": "2A",
      "Unicode dec": "42",
      "Unicode hex": "2A"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "43",
      "Dingbat hex": "2B",
      "Unicode dec": "43",
      "Unicode hex": "2B"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "44",
      "Dingbat hex": "2C",
      "Unicode dec": "44",
      "Unicode hex": "2C"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "45",
      "Dingbat hex": "2D",
      "Unicode dec": "8722",
      "Unicode hex": "2212"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "46",
      "Dingbat hex": "2E",
      "Unicode dec": "46",
      "Unicode hex": "2E"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "47",
      "Dingbat hex": "2F",
      "Unicode dec": "47",
      "Unicode hex": "2F"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "48",
      "Dingbat hex": "30",
      "Unicode dec": "48",
      "Unicode hex": "30"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "49",
      "Dingbat hex": "31",
      "Unicode dec": "49",
      "Unicode hex": "31"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "50",
      "Dingbat hex": "32",
      "Unicode dec": "50",
      "Unicode hex": "32"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "51",
      "Dingbat hex": "33",
      "Unicode dec": "51",
      "Unicode hex": "33"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "52",
      "Dingbat hex": "34",
      "Unicode dec": "52",
      "Unicode hex": "34"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "53",
      "Dingbat hex": "35",
      "Unicode dec": "53",
      "Unicode hex": "35"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "54",
      "Dingbat hex": "36",
      "Unicode dec": "54",
      "Unicode hex": "36"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "55",
      "Dingbat hex": "37",
      "Unicode dec": "55",
      "Unicode hex": "37"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "56",
      "Dingbat hex": "38",
      "Unicode dec": "56",
      "Unicode hex": "38"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "57",
      "Dingbat hex": "39",
      "Unicode dec": "57",
      "Unicode hex": "39"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "58",
      "Dingbat hex": "3A",
      "Unicode dec": "58",
      "Unicode hex": "3A"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "59",
      "Dingbat hex": "3B",
      "Unicode dec": "59",
      "Unicode hex": "3B"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "60",
      "Dingbat hex": "3C",
      "Unicode dec": "60",
      "Unicode hex": "3C"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "61",
      "Dingbat hex": "3D",
      "Unicode dec": "61",
      "Unicode hex": "3D"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "62",
      "Dingbat hex": "3E",
      "Unicode dec": "62",
      "Unicode hex": "3E"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "63",
      "Dingbat hex": "3F",
      "Unicode dec": "63",
      "Unicode hex": "3F"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "64",
      "Dingbat hex": "40",
      "Unicode dec": "8773",
      "Unicode hex": "2245"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "65",
      "Dingbat hex": "41",
      "Unicode dec": "913",
      "Unicode hex": "391"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "66",
      "Dingbat hex": "42",
      "Unicode dec": "914",
      "Unicode hex": "392"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "67",
      "Dingbat hex": "43",
      "Unicode dec": "935",
      "Unicode hex": "3A7"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "68",
      "Dingbat hex": "44",
      "Unicode dec": "916",
      "Unicode hex": "394"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "69",
      "Dingbat hex": "45",
      "Unicode dec": "917",
      "Unicode hex": "395"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "70",
      "Dingbat hex": "46",
      "Unicode dec": "934",
      "Unicode hex": "3A6"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "71",
      "Dingbat hex": "47",
      "Unicode dec": "915",
      "Unicode hex": "393"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "72",
      "Dingbat hex": "48",
      "Unicode dec": "919",
      "Unicode hex": "397"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "73",
      "Dingbat hex": "49",
      "Unicode dec": "921",
      "Unicode hex": "399"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "74",
      "Dingbat hex": "4A",
      "Unicode dec": "977",
      "Unicode hex": "3D1"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "75",
      "Dingbat hex": "4B",
      "Unicode dec": "922",
      "Unicode hex": "39A"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "76",
      "Dingbat hex": "4C",
      "Unicode dec": "923",
      "Unicode hex": "39B"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "77",
      "Dingbat hex": "4D",
      "Unicode dec": "924",
      "Unicode hex": "39C"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "78",
      "Dingbat hex": "4E",
      "Unicode dec": "925",
      "Unicode hex": "39D"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "79",
      "Dingbat hex": "4F",
      "Unicode dec": "927",
      "Unicode hex": "39F"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "80",
      "Dingbat hex": "50",
      "Unicode dec": "928",
      "Unicode hex": "3A0"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "81",
      "Dingbat hex": "51",
      "Unicode dec": "920",
      "Unicode hex": "398"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "82",
      "Dingbat hex": "52",
      "Unicode dec": "929",
      "Unicode hex": "3A1"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "83",
      "Dingbat hex": "53",
      "Unicode dec": "931",
      "Unicode hex": "3A3"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "84",
      "Dingbat hex": "54",
      "Unicode dec": "932",
      "Unicode hex": "3A4"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "85",
      "Dingbat hex": "55",
      "Unicode dec": "933",
      "Unicode hex": "3A5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "86",
      "Dingbat hex": "56",
      "Unicode dec": "962",
      "Unicode hex": "3C2"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "87",
      "Dingbat hex": "57",
      "Unicode dec": "937",
      "Unicode hex": "3A9"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "88",
      "Dingbat hex": "58",
      "Unicode dec": "926",
      "Unicode hex": "39E"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "89",
      "Dingbat hex": "59",
      "Unicode dec": "936",
      "Unicode hex": "3A8"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "90",
      "Dingbat hex": "5A",
      "Unicode dec": "918",
      "Unicode hex": "396"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "91",
      "Dingbat hex": "5B",
      "Unicode dec": "91",
      "Unicode hex": "5B"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "92",
      "Dingbat hex": "5C",
      "Unicode dec": "8756",
      "Unicode hex": "2234"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "93",
      "Dingbat hex": "5D",
      "Unicode dec": "93",
      "Unicode hex": "5D"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "94",
      "Dingbat hex": "5E",
      "Unicode dec": "8869",
      "Unicode hex": "22A5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "95",
      "Dingbat hex": "5F",
      "Unicode dec": "95",
      "Unicode hex": "5F"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "96",
      "Dingbat hex": "60",
      "Unicode dec": "8254",
      "Unicode hex": "203E"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "97",
      "Dingbat hex": "61",
      "Unicode dec": "945",
      "Unicode hex": "3B1"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "98",
      "Dingbat hex": "62",
      "Unicode dec": "946",
      "Unicode hex": "3B2"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "99",
      "Dingbat hex": "63",
      "Unicode dec": "967",
      "Unicode hex": "3C7"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "100",
      "Dingbat hex": "64",
      "Unicode dec": "948",
      "Unicode hex": "3B4"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "101",
      "Dingbat hex": "65",
      "Unicode dec": "949",
      "Unicode hex": "3B5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "102",
      "Dingbat hex": "66",
      "Unicode dec": "966",
      "Unicode hex": "3C6"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "103",
      "Dingbat hex": "67",
      "Unicode dec": "947",
      "Unicode hex": "3B3"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "104",
      "Dingbat hex": "68",
      "Unicode dec": "951",
      "Unicode hex": "3B7"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "105",
      "Dingbat hex": "69",
      "Unicode dec": "953",
      "Unicode hex": "3B9"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "106",
      "Dingbat hex": "6A",
      "Unicode dec": "981",
      "Unicode hex": "3D5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "107",
      "Dingbat hex": "6B",
      "Unicode dec": "954",
      "Unicode hex": "3BA"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "108",
      "Dingbat hex": "6C",
      "Unicode dec": "955",
      "Unicode hex": "3BB"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "109",
      "Dingbat hex": "6D",
      "Unicode dec": "956",
      "Unicode hex": "3BC"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "110",
      "Dingbat hex": "6E",
      "Unicode dec": "957",
      "Unicode hex": "3BD"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "111",
      "Dingbat hex": "6F",
      "Unicode dec": "959",
      "Unicode hex": "3BF"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "112",
      "Dingbat hex": "70",
      "Unicode dec": "960",
      "Unicode hex": "3C0"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "113",
      "Dingbat hex": "71",
      "Unicode dec": "952",
      "Unicode hex": "3B8"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "114",
      "Dingbat hex": "72",
      "Unicode dec": "961",
      "Unicode hex": "3C1"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "115",
      "Dingbat hex": "73",
      "Unicode dec": "963",
      "Unicode hex": "3C3"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "116",
      "Dingbat hex": "74",
      "Unicode dec": "964",
      "Unicode hex": "3C4"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "117",
      "Dingbat hex": "75",
      "Unicode dec": "965",
      "Unicode hex": "3C5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "118",
      "Dingbat hex": "76",
      "Unicode dec": "982",
      "Unicode hex": "3D6"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "119",
      "Dingbat hex": "77",
      "Unicode dec": "969",
      "Unicode hex": "3C9"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "120",
      "Dingbat hex": "78",
      "Unicode dec": "958",
      "Unicode hex": "3BE"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "121",
      "Dingbat hex": "79",
      "Unicode dec": "968",
      "Unicode hex": "3C8"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "122",
      "Dingbat hex": "7A",
      "Unicode dec": "950",
      "Unicode hex": "3B6"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "123",
      "Dingbat hex": "7B",
      "Unicode dec": "123",
      "Unicode hex": "7B"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "124",
      "Dingbat hex": "7C",
      "Unicode dec": "124",
      "Unicode hex": "7C"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "125",
      "Dingbat hex": "7D",
      "Unicode dec": "125",
      "Unicode hex": "7D"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "126",
      "Dingbat hex": "7E",
      "Unicode dec": "126",
      "Unicode hex": "7E"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "160",
      "Dingbat hex": "A0",
      "Unicode dec": "8364",
      "Unicode hex": "20AC"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "161",
      "Dingbat hex": "A1",
      "Unicode dec": "978",
      "Unicode hex": "3D2"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "162",
      "Dingbat hex": "A2",
      "Unicode dec": "8242",
      "Unicode hex": "2032"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "163",
      "Dingbat hex": "A3",
      "Unicode dec": "8804",
      "Unicode hex": "2264"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "164",
      "Dingbat hex": "A4",
      "Unicode dec": "8260",
      "Unicode hex": "2044"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "165",
      "Dingbat hex": "A5",
      "Unicode dec": "8734",
      "Unicode hex": "221E"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "166",
      "Dingbat hex": "A6",
      "Unicode dec": "402",
      "Unicode hex": "192"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "167",
      "Dingbat hex": "A7",
      "Unicode dec": "9827",
      "Unicode hex": "2663"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "168",
      "Dingbat hex": "A8",
      "Unicode dec": "9830",
      "Unicode hex": "2666"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "169",
      "Dingbat hex": "A9",
      "Unicode dec": "9829",
      "Unicode hex": "2665"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "170",
      "Dingbat hex": "AA",
      "Unicode dec": "9824",
      "Unicode hex": "2660"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "171",
      "Dingbat hex": "AB",
      "Unicode dec": "8596",
      "Unicode hex": "2194"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "172",
      "Dingbat hex": "AC",
      "Unicode dec": "8592",
      "Unicode hex": "2190"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "173",
      "Dingbat hex": "AD",
      "Unicode dec": "8593",
      "Unicode hex": "2191"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "174",
      "Dingbat hex": "AE",
      "Unicode dec": "8594",
      "Unicode hex": "2192"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "175",
      "Dingbat hex": "AF",
      "Unicode dec": "8595",
      "Unicode hex": "2193"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "176",
      "Dingbat hex": "B0",
      "Unicode dec": "176",
      "Unicode hex": "B0"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "177",
      "Dingbat hex": "B1",
      "Unicode dec": "177",
      "Unicode hex": "B1"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "178",
      "Dingbat hex": "B2",
      "Unicode dec": "8243",
      "Unicode hex": "2033"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "179",
      "Dingbat hex": "B3",
      "Unicode dec": "8805",
      "Unicode hex": "2265"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "180",
      "Dingbat hex": "B4",
      "Unicode dec": "215",
      "Unicode hex": "D7"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "181",
      "Dingbat hex": "B5",
      "Unicode dec": "8733",
      "Unicode hex": "221D"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "182",
      "Dingbat hex": "B6",
      "Unicode dec": "8706",
      "Unicode hex": "2202"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "183",
      "Dingbat hex": "B7",
      "Unicode dec": "8226",
      "Unicode hex": "2022"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "184",
      "Dingbat hex": "B8",
      "Unicode dec": "247",
      "Unicode hex": "F7"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "185",
      "Dingbat hex": "B9",
      "Unicode dec": "8800",
      "Unicode hex": "2260"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "186",
      "Dingbat hex": "BA",
      "Unicode dec": "8801",
      "Unicode hex": "2261"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "187",
      "Dingbat hex": "BB",
      "Unicode dec": "8776",
      "Unicode hex": "2248"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "188",
      "Dingbat hex": "BC",
      "Unicode dec": "8230",
      "Unicode hex": "2026"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "189",
      "Dingbat hex": "BD",
      "Unicode dec": "9168",
      "Unicode hex": "23D0"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "190",
      "Dingbat hex": "BE",
      "Unicode dec": "9135",
      "Unicode hex": "23AF"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "191",
      "Dingbat hex": "BF",
      "Unicode dec": "8629",
      "Unicode hex": "21B5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "192",
      "Dingbat hex": "C0",
      "Unicode dec": "8501",
      "Unicode hex": "2135"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "193",
      "Dingbat hex": "C1",
      "Unicode dec": "8465",
      "Unicode hex": "2111"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "194",
      "Dingbat hex": "C2",
      "Unicode dec": "8476",
      "Unicode hex": "211C"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "195",
      "Dingbat hex": "C3",
      "Unicode dec": "8472",
      "Unicode hex": "2118"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "196",
      "Dingbat hex": "C4",
      "Unicode dec": "8855",
      "Unicode hex": "2297"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "197",
      "Dingbat hex": "C5",
      "Unicode dec": "8853",
      "Unicode hex": "2295"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "198",
      "Dingbat hex": "C6",
      "Unicode dec": "8709",
      "Unicode hex": "2205"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "199",
      "Dingbat hex": "C7",
      "Unicode dec": "8745",
      "Unicode hex": "2229"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "200",
      "Dingbat hex": "C8",
      "Unicode dec": "8746",
      "Unicode hex": "222A"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "201",
      "Dingbat hex": "C9",
      "Unicode dec": "8835",
      "Unicode hex": "2283"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "202",
      "Dingbat hex": "CA",
      "Unicode dec": "8839",
      "Unicode hex": "2287"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "203",
      "Dingbat hex": "CB",
      "Unicode dec": "8836",
      "Unicode hex": "2284"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "204",
      "Dingbat hex": "CC",
      "Unicode dec": "8834",
      "Unicode hex": "2282"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "205",
      "Dingbat hex": "CD",
      "Unicode dec": "8838",
      "Unicode hex": "2286"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "206",
      "Dingbat hex": "CE",
      "Unicode dec": "8712",
      "Unicode hex": "2208"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "207",
      "Dingbat hex": "CF",
      "Unicode dec": "8713",
      "Unicode hex": "2209"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "208",
      "Dingbat hex": "D0",
      "Unicode dec": "8736",
      "Unicode hex": "2220"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "209",
      "Dingbat hex": "D1",
      "Unicode dec": "8711",
      "Unicode hex": "2207"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "210",
      "Dingbat hex": "D2",
      "Unicode dec": "174",
      "Unicode hex": "AE"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "211",
      "Dingbat hex": "D3",
      "Unicode dec": "169",
      "Unicode hex": "A9"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "212",
      "Dingbat hex": "D4",
      "Unicode dec": "8482",
      "Unicode hex": "2122"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "213",
      "Dingbat hex": "D5",
      "Unicode dec": "8719",
      "Unicode hex": "220F"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "214",
      "Dingbat hex": "D6",
      "Unicode dec": "8730",
      "Unicode hex": "221A"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "215",
      "Dingbat hex": "D7",
      "Unicode dec": "8901",
      "Unicode hex": "22C5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "216",
      "Dingbat hex": "D8",
      "Unicode dec": "172",
      "Unicode hex": "AC"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "217",
      "Dingbat hex": "D9",
      "Unicode dec": "8743",
      "Unicode hex": "2227"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "218",
      "Dingbat hex": "DA",
      "Unicode dec": "8744",
      "Unicode hex": "2228"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "219",
      "Dingbat hex": "DB",
      "Unicode dec": "8660",
      "Unicode hex": "21D4"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "220",
      "Dingbat hex": "DC",
      "Unicode dec": "8656",
      "Unicode hex": "21D0"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "221",
      "Dingbat hex": "DD",
      "Unicode dec": "8657",
      "Unicode hex": "21D1"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "222",
      "Dingbat hex": "DE",
      "Unicode dec": "8658",
      "Unicode hex": "21D2"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "223",
      "Dingbat hex": "DF",
      "Unicode dec": "8659",
      "Unicode hex": "21D3"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "224",
      "Dingbat hex": "E0",
      "Unicode dec": "9674",
      "Unicode hex": "25CA"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "225",
      "Dingbat hex": "E1",
      "Unicode dec": "12296",
      "Unicode hex": "3008"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "226",
      "Dingbat hex": "E2",
      "Unicode dec": "174",
      "Unicode hex": "AE"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "227",
      "Dingbat hex": "E3",
      "Unicode dec": "169",
      "Unicode hex": "A9"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "228",
      "Dingbat hex": "E4",
      "Unicode dec": "8482",
      "Unicode hex": "2122"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "229",
      "Dingbat hex": "E5",
      "Unicode dec": "8721",
      "Unicode hex": "2211"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "230",
      "Dingbat hex": "E6",
      "Unicode dec": "9115",
      "Unicode hex": "239B"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "231",
      "Dingbat hex": "E7",
      "Unicode dec": "9116",
      "Unicode hex": "239C"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "232",
      "Dingbat hex": "E8",
      "Unicode dec": "9117",
      "Unicode hex": "239D"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "233",
      "Dingbat hex": "E9",
      "Unicode dec": "9121",
      "Unicode hex": "23A1"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "234",
      "Dingbat hex": "EA",
      "Unicode dec": "9122",
      "Unicode hex": "23A2"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "235",
      "Dingbat hex": "EB",
      "Unicode dec": "9123",
      "Unicode hex": "23A3"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "236",
      "Dingbat hex": "EC",
      "Unicode dec": "9127",
      "Unicode hex": "23A7"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "237",
      "Dingbat hex": "ED",
      "Unicode dec": "9128",
      "Unicode hex": "23A8"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "238",
      "Dingbat hex": "EE",
      "Unicode dec": "9129",
      "Unicode hex": "23A9"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "239",
      "Dingbat hex": "EF",
      "Unicode dec": "9130",
      "Unicode hex": "23AA"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "240",
      "Dingbat hex": "F0",
      "Unicode dec": "63743",
      "Unicode hex": "F8FF"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "241",
      "Dingbat hex": "F1",
      "Unicode dec": "12297",
      "Unicode hex": "3009"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "242",
      "Dingbat hex": "F2",
      "Unicode dec": "8747",
      "Unicode hex": "222B"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "243",
      "Dingbat hex": "F3",
      "Unicode dec": "8992",
      "Unicode hex": "2320"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "244",
      "Dingbat hex": "F4",
      "Unicode dec": "9134",
      "Unicode hex": "23AE"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "245",
      "Dingbat hex": "F5",
      "Unicode dec": "8993",
      "Unicode hex": "2321"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "246",
      "Dingbat hex": "F6",
      "Unicode dec": "9118",
      "Unicode hex": "239E"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "247",
      "Dingbat hex": "F7",
      "Unicode dec": "9119",
      "Unicode hex": "239F"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "248",
      "Dingbat hex": "F8",
      "Unicode dec": "9120",
      "Unicode hex": "23A0"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "249",
      "Dingbat hex": "F9",
      "Unicode dec": "9124",
      "Unicode hex": "23A4"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "250",
      "Dingbat hex": "FA",
      "Unicode dec": "9125",
      "Unicode hex": "23A5"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "251",
      "Dingbat hex": "FB",
      "Unicode dec": "9126",
      "Unicode hex": "23A6"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "252",
      "Dingbat hex": "FC",
      "Unicode dec": "9131",
      "Unicode hex": "23AB"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "253",
      "Dingbat hex": "FD",
      "Unicode dec": "9132",
      "Unicode hex": "23AC"
    }, {
      "Typeface name": "Symbol",
      "Dingbat dec": "254",
      "Dingbat hex": "FE",
      "Unicode dec": "9133",
      "Unicode hex": "23AD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "32",
      "Dingbat hex": "20",
      "Unicode dec": "32",
      "Unicode hex": "20"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "33",
      "Dingbat hex": "21",
      "Unicode dec": "128375",
      "Unicode hex": "1F577"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "34",
      "Dingbat hex": "22",
      "Unicode dec": "128376",
      "Unicode hex": "1F578"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "35",
      "Dingbat hex": "23",
      "Unicode dec": "128370",
      "Unicode hex": "1F572"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "36",
      "Dingbat hex": "24",
      "Unicode dec": "128374",
      "Unicode hex": "1F576"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "37",
      "Dingbat hex": "25",
      "Unicode dec": "127942",
      "Unicode hex": "1F3C6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "38",
      "Dingbat hex": "26",
      "Unicode dec": "127894",
      "Unicode hex": "1F396"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "39",
      "Dingbat hex": "27",
      "Unicode dec": "128391",
      "Unicode hex": "1F587"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "40",
      "Dingbat hex": "28",
      "Unicode dec": "128488",
      "Unicode hex": "1F5E8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "41",
      "Dingbat hex": "29",
      "Unicode dec": "128489",
      "Unicode hex": "1F5E9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "42",
      "Dingbat hex": "2A",
      "Unicode dec": "128496",
      "Unicode hex": "1F5F0"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "43",
      "Dingbat hex": "2B",
      "Unicode dec": "128497",
      "Unicode hex": "1F5F1"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "44",
      "Dingbat hex": "2C",
      "Unicode dec": "127798",
      "Unicode hex": "1F336"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "45",
      "Dingbat hex": "2D",
      "Unicode dec": "127895",
      "Unicode hex": "1F397"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "46",
      "Dingbat hex": "2E",
      "Unicode dec": "128638",
      "Unicode hex": "1F67E"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "47",
      "Dingbat hex": "2F",
      "Unicode dec": "128636",
      "Unicode hex": "1F67C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "48",
      "Dingbat hex": "30",
      "Unicode dec": "128469",
      "Unicode hex": "1F5D5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "49",
      "Dingbat hex": "31",
      "Unicode dec": "128470",
      "Unicode hex": "1F5D6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "50",
      "Dingbat hex": "32",
      "Unicode dec": "128471",
      "Unicode hex": "1F5D7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "51",
      "Dingbat hex": "33",
      "Unicode dec": "9204",
      "Unicode hex": "23F4"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "52",
      "Dingbat hex": "34",
      "Unicode dec": "9205",
      "Unicode hex": "23F5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "53",
      "Dingbat hex": "35",
      "Unicode dec": "9206",
      "Unicode hex": "23F6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "54",
      "Dingbat hex": "36",
      "Unicode dec": "9207",
      "Unicode hex": "23F7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "55",
      "Dingbat hex": "37",
      "Unicode dec": "9194",
      "Unicode hex": "23EA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "56",
      "Dingbat hex": "38",
      "Unicode dec": "9193",
      "Unicode hex": "23E9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "57",
      "Dingbat hex": "39",
      "Unicode dec": "9198",
      "Unicode hex": "23EE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "58",
      "Dingbat hex": "3A",
      "Unicode dec": "9197",
      "Unicode hex": "23ED"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "59",
      "Dingbat hex": "3B",
      "Unicode dec": "9208",
      "Unicode hex": "23F8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "60",
      "Dingbat hex": "3C",
      "Unicode dec": "9209",
      "Unicode hex": "23F9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "61",
      "Dingbat hex": "3D",
      "Unicode dec": "9210",
      "Unicode hex": "23FA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "62",
      "Dingbat hex": "3E",
      "Unicode dec": "128474",
      "Unicode hex": "1F5DA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "63",
      "Dingbat hex": "3F",
      "Unicode dec": "128499",
      "Unicode hex": "1F5F3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "64",
      "Dingbat hex": "40",
      "Unicode dec": "128736",
      "Unicode hex": "1F6E0"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "65",
      "Dingbat hex": "41",
      "Unicode dec": "127959",
      "Unicode hex": "1F3D7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "66",
      "Dingbat hex": "42",
      "Unicode dec": "127960",
      "Unicode hex": "1F3D8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "67",
      "Dingbat hex": "43",
      "Unicode dec": "127961",
      "Unicode hex": "1F3D9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "68",
      "Dingbat hex": "44",
      "Unicode dec": "127962",
      "Unicode hex": "1F3DA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "69",
      "Dingbat hex": "45",
      "Unicode dec": "127964",
      "Unicode hex": "1F3DC"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "70",
      "Dingbat hex": "46",
      "Unicode dec": "127981",
      "Unicode hex": "1F3ED"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "71",
      "Dingbat hex": "47",
      "Unicode dec": "127963",
      "Unicode hex": "1F3DB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "72",
      "Dingbat hex": "48",
      "Unicode dec": "127968",
      "Unicode hex": "1F3E0"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "73",
      "Dingbat hex": "49",
      "Unicode dec": "127958",
      "Unicode hex": "1F3D6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "74",
      "Dingbat hex": "4A",
      "Unicode dec": "127965",
      "Unicode hex": "1F3DD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "75",
      "Dingbat hex": "4B",
      "Unicode dec": "128739",
      "Unicode hex": "1F6E3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "76",
      "Dingbat hex": "4C",
      "Unicode dec": "128269",
      "Unicode hex": "1F50D"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "77",
      "Dingbat hex": "4D",
      "Unicode dec": "127956",
      "Unicode hex": "1F3D4"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "78",
      "Dingbat hex": "4E",
      "Unicode dec": "128065",
      "Unicode hex": "1F441"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "79",
      "Dingbat hex": "4F",
      "Unicode dec": "128066",
      "Unicode hex": "1F442"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "80",
      "Dingbat hex": "50",
      "Unicode dec": "127966",
      "Unicode hex": "1F3DE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "81",
      "Dingbat hex": "51",
      "Unicode dec": "127957",
      "Unicode hex": "1F3D5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "82",
      "Dingbat hex": "52",
      "Unicode dec": "128740",
      "Unicode hex": "1F6E4"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "83",
      "Dingbat hex": "53",
      "Unicode dec": "127967",
      "Unicode hex": "1F3DF"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "84",
      "Dingbat hex": "54",
      "Unicode dec": "128755",
      "Unicode hex": "1F6F3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "85",
      "Dingbat hex": "55",
      "Unicode dec": "128364",
      "Unicode hex": "1F56C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "86",
      "Dingbat hex": "56",
      "Unicode dec": "128363",
      "Unicode hex": "1F56B"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "87",
      "Dingbat hex": "57",
      "Unicode dec": "128360",
      "Unicode hex": "1F568"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "88",
      "Dingbat hex": "58",
      "Unicode dec": "128264",
      "Unicode hex": "1F508"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "89",
      "Dingbat hex": "59",
      "Unicode dec": "127892",
      "Unicode hex": "1F394"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "90",
      "Dingbat hex": "5A",
      "Unicode dec": "127893",
      "Unicode hex": "1F395"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "91",
      "Dingbat hex": "5B",
      "Unicode dec": "128492",
      "Unicode hex": "1F5EC"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "92",
      "Dingbat hex": "5C",
      "Unicode dec": "128637",
      "Unicode hex": "1F67D"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "93",
      "Dingbat hex": "5D",
      "Unicode dec": "128493",
      "Unicode hex": "1F5ED"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "94",
      "Dingbat hex": "5E",
      "Unicode dec": "128490",
      "Unicode hex": "1F5EA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "95",
      "Dingbat hex": "5F",
      "Unicode dec": "128491",
      "Unicode hex": "1F5EB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "96",
      "Dingbat hex": "60",
      "Unicode dec": "11156",
      "Unicode hex": "2B94"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "97",
      "Dingbat hex": "61",
      "Unicode dec": "10004",
      "Unicode hex": "2714"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "98",
      "Dingbat hex": "62",
      "Unicode dec": "128690",
      "Unicode hex": "1F6B2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "99",
      "Dingbat hex": "63",
      "Unicode dec": "11036",
      "Unicode hex": "2B1C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "100",
      "Dingbat hex": "64",
      "Unicode dec": "128737",
      "Unicode hex": "1F6E1"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "101",
      "Dingbat hex": "65",
      "Unicode dec": "128230",
      "Unicode hex": "1F4E6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "102",
      "Dingbat hex": "66",
      "Unicode dec": "128753",
      "Unicode hex": "1F6F1"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "103",
      "Dingbat hex": "67",
      "Unicode dec": "11035",
      "Unicode hex": "2B1B"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "104",
      "Dingbat hex": "68",
      "Unicode dec": "128657",
      "Unicode hex": "1F691"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "105",
      "Dingbat hex": "69",
      "Unicode dec": "128712",
      "Unicode hex": "1F6C8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "106",
      "Dingbat hex": "6A",
      "Unicode dec": "128745",
      "Unicode hex": "1F6E9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "107",
      "Dingbat hex": "6B",
      "Unicode dec": "128752",
      "Unicode hex": "1F6F0"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "108",
      "Dingbat hex": "6C",
      "Unicode dec": "128968",
      "Unicode hex": "1F7C8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "109",
      "Dingbat hex": "6D",
      "Unicode dec": "128372",
      "Unicode hex": "1F574"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "110",
      "Dingbat hex": "6E",
      "Unicode dec": "11044",
      "Unicode hex": "2B24"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "111",
      "Dingbat hex": "6F",
      "Unicode dec": "128741",
      "Unicode hex": "1F6E5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "112",
      "Dingbat hex": "70",
      "Unicode dec": "128660",
      "Unicode hex": "1F694"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "113",
      "Dingbat hex": "71",
      "Unicode dec": "128472",
      "Unicode hex": "1F5D8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "114",
      "Dingbat hex": "72",
      "Unicode dec": "128473",
      "Unicode hex": "1F5D9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "115",
      "Dingbat hex": "73",
      "Unicode dec": "10067",
      "Unicode hex": "2753"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "116",
      "Dingbat hex": "74",
      "Unicode dec": "128754",
      "Unicode hex": "1F6F2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "117",
      "Dingbat hex": "75",
      "Unicode dec": "128647",
      "Unicode hex": "1F687"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "118",
      "Dingbat hex": "76",
      "Unicode dec": "128653",
      "Unicode hex": "1F68D"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "119",
      "Dingbat hex": "77",
      "Unicode dec": "9971",
      "Unicode hex": "26F3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "120",
      "Dingbat hex": "78",
      "Unicode dec": "10680",
      "Unicode hex": "29B8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "121",
      "Dingbat hex": "79",
      "Unicode dec": "8854",
      "Unicode hex": "2296"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "122",
      "Dingbat hex": "7A",
      "Unicode dec": "128685",
      "Unicode hex": "1F6AD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "123",
      "Dingbat hex": "7B",
      "Unicode dec": "128494",
      "Unicode hex": "1F5EE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "124",
      "Dingbat hex": "7C",
      "Unicode dec": "9168",
      "Unicode hex": "23D0"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "125",
      "Dingbat hex": "7D",
      "Unicode dec": "128495",
      "Unicode hex": "1F5EF"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "126",
      "Dingbat hex": "7E",
      "Unicode dec": "128498",
      "Unicode hex": "1F5F2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "128",
      "Dingbat hex": "80",
      "Unicode dec": "128697",
      "Unicode hex": "1F6B9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "129",
      "Dingbat hex": "81",
      "Unicode dec": "128698",
      "Unicode hex": "1F6BA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "130",
      "Dingbat hex": "82",
      "Unicode dec": "128713",
      "Unicode hex": "1F6C9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "131",
      "Dingbat hex": "83",
      "Unicode dec": "128714",
      "Unicode hex": "1F6CA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "132",
      "Dingbat hex": "84",
      "Unicode dec": "128700",
      "Unicode hex": "1F6BC"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "133",
      "Dingbat hex": "85",
      "Unicode dec": "128125",
      "Unicode hex": "1F47D"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "134",
      "Dingbat hex": "86",
      "Unicode dec": "127947",
      "Unicode hex": "1F3CB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "135",
      "Dingbat hex": "87",
      "Unicode dec": "9975",
      "Unicode hex": "26F7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "136",
      "Dingbat hex": "88",
      "Unicode dec": "127938",
      "Unicode hex": "1F3C2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "137",
      "Dingbat hex": "89",
      "Unicode dec": "127948",
      "Unicode hex": "1F3CC"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "138",
      "Dingbat hex": "8A",
      "Unicode dec": "127946",
      "Unicode hex": "1F3CA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "139",
      "Dingbat hex": "8B",
      "Unicode dec": "127940",
      "Unicode hex": "1F3C4"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "140",
      "Dingbat hex": "8C",
      "Unicode dec": "127949",
      "Unicode hex": "1F3CD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "141",
      "Dingbat hex": "8D",
      "Unicode dec": "127950",
      "Unicode hex": "1F3CE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "142",
      "Dingbat hex": "8E",
      "Unicode dec": "128664",
      "Unicode hex": "1F698"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "143",
      "Dingbat hex": "8F",
      "Unicode dec": "128480",
      "Unicode hex": "1F5E0"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "144",
      "Dingbat hex": "90",
      "Unicode dec": "128738",
      "Unicode hex": "1F6E2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "145",
      "Dingbat hex": "91",
      "Unicode dec": "128176",
      "Unicode hex": "1F4B0"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "146",
      "Dingbat hex": "92",
      "Unicode dec": "127991",
      "Unicode hex": "1F3F7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "147",
      "Dingbat hex": "93",
      "Unicode dec": "128179",
      "Unicode hex": "1F4B3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "148",
      "Dingbat hex": "94",
      "Unicode dec": "128106",
      "Unicode hex": "1F46A"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "149",
      "Dingbat hex": "95",
      "Unicode dec": "128481",
      "Unicode hex": "1F5E1"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "150",
      "Dingbat hex": "96",
      "Unicode dec": "128482",
      "Unicode hex": "1F5E2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "151",
      "Dingbat hex": "97",
      "Unicode dec": "128483",
      "Unicode hex": "1F5E3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "152",
      "Dingbat hex": "98",
      "Unicode dec": "10031",
      "Unicode hex": "272F"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "153",
      "Dingbat hex": "99",
      "Unicode dec": "128388",
      "Unicode hex": "1F584"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "154",
      "Dingbat hex": "9A",
      "Unicode dec": "128389",
      "Unicode hex": "1F585"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "155",
      "Dingbat hex": "9B",
      "Unicode dec": "128387",
      "Unicode hex": "1F583"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "156",
      "Dingbat hex": "9C",
      "Unicode dec": "128390",
      "Unicode hex": "1F586"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "157",
      "Dingbat hex": "9D",
      "Unicode dec": "128441",
      "Unicode hex": "1F5B9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "158",
      "Dingbat hex": "9E",
      "Unicode dec": "128442",
      "Unicode hex": "1F5BA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "159",
      "Dingbat hex": "9F",
      "Unicode dec": "128443",
      "Unicode hex": "1F5BB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "160",
      "Dingbat hex": "A0",
      "Unicode dec": "128373",
      "Unicode hex": "1F575"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "161",
      "Dingbat hex": "A1",
      "Unicode dec": "128368",
      "Unicode hex": "1F570"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "162",
      "Dingbat hex": "A2",
      "Unicode dec": "128445",
      "Unicode hex": "1F5BD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "163",
      "Dingbat hex": "A3",
      "Unicode dec": "128446",
      "Unicode hex": "1F5BE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "164",
      "Dingbat hex": "A4",
      "Unicode dec": "128203",
      "Unicode hex": "1F4CB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "165",
      "Dingbat hex": "A5",
      "Unicode dec": "128466",
      "Unicode hex": "1F5D2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "166",
      "Dingbat hex": "A6",
      "Unicode dec": "128467",
      "Unicode hex": "1F5D3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "167",
      "Dingbat hex": "A7",
      "Unicode dec": "128366",
      "Unicode hex": "1F56E"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "168",
      "Dingbat hex": "A8",
      "Unicode dec": "128218",
      "Unicode hex": "1F4DA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "169",
      "Dingbat hex": "A9",
      "Unicode dec": "128478",
      "Unicode hex": "1F5DE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "170",
      "Dingbat hex": "AA",
      "Unicode dec": "128479",
      "Unicode hex": "1F5DF"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "171",
      "Dingbat hex": "AB",
      "Unicode dec": "128451",
      "Unicode hex": "1F5C3"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "172",
      "Dingbat hex": "AC",
      "Unicode dec": "128450",
      "Unicode hex": "1F5C2"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "173",
      "Dingbat hex": "AD",
      "Unicode dec": "128444",
      "Unicode hex": "1F5BC"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "174",
      "Dingbat hex": "AE",
      "Unicode dec": "127917",
      "Unicode hex": "1F3AD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "175",
      "Dingbat hex": "AF",
      "Unicode dec": "127900",
      "Unicode hex": "1F39C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "176",
      "Dingbat hex": "B0",
      "Unicode dec": "127896",
      "Unicode hex": "1F398"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "177",
      "Dingbat hex": "B1",
      "Unicode dec": "127897",
      "Unicode hex": "1F399"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "178",
      "Dingbat hex": "B2",
      "Unicode dec": "127911",
      "Unicode hex": "1F3A7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "179",
      "Dingbat hex": "B3",
      "Unicode dec": "128191",
      "Unicode hex": "1F4BF"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "180",
      "Dingbat hex": "B4",
      "Unicode dec": "127902",
      "Unicode hex": "1F39E"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "181",
      "Dingbat hex": "B5",
      "Unicode dec": "128247",
      "Unicode hex": "1F4F7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "182",
      "Dingbat hex": "B6",
      "Unicode dec": "127903",
      "Unicode hex": "1F39F"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "183",
      "Dingbat hex": "B7",
      "Unicode dec": "127916",
      "Unicode hex": "1F3AC"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "184",
      "Dingbat hex": "B8",
      "Unicode dec": "128253",
      "Unicode hex": "1F4FD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "185",
      "Dingbat hex": "B9",
      "Unicode dec": "128249",
      "Unicode hex": "1F4F9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "186",
      "Dingbat hex": "BA",
      "Unicode dec": "128254",
      "Unicode hex": "1F4FE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "187",
      "Dingbat hex": "BB",
      "Unicode dec": "128251",
      "Unicode hex": "1F4FB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "188",
      "Dingbat hex": "BC",
      "Unicode dec": "127898",
      "Unicode hex": "1F39A"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "189",
      "Dingbat hex": "BD",
      "Unicode dec": "127899",
      "Unicode hex": "1F39B"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "190",
      "Dingbat hex": "BE",
      "Unicode dec": "128250",
      "Unicode hex": "1F4FA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "191",
      "Dingbat hex": "BF",
      "Unicode dec": "128187",
      "Unicode hex": "1F4BB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "192",
      "Dingbat hex": "C0",
      "Unicode dec": "128421",
      "Unicode hex": "1F5A5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "193",
      "Dingbat hex": "C1",
      "Unicode dec": "128422",
      "Unicode hex": "1F5A6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "194",
      "Dingbat hex": "C2",
      "Unicode dec": "128423",
      "Unicode hex": "1F5A7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "195",
      "Dingbat hex": "C3",
      "Unicode dec": "128377",
      "Unicode hex": "1F579"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "196",
      "Dingbat hex": "C4",
      "Unicode dec": "127918",
      "Unicode hex": "1F3AE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "197",
      "Dingbat hex": "C5",
      "Unicode dec": "128379",
      "Unicode hex": "1F57B"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "198",
      "Dingbat hex": "C6",
      "Unicode dec": "128380",
      "Unicode hex": "1F57C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "199",
      "Dingbat hex": "C7",
      "Unicode dec": "128223",
      "Unicode hex": "1F4DF"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "200",
      "Dingbat hex": "C8",
      "Unicode dec": "128385",
      "Unicode hex": "1F581"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "201",
      "Dingbat hex": "C9",
      "Unicode dec": "128384",
      "Unicode hex": "1F580"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "202",
      "Dingbat hex": "CA",
      "Unicode dec": "128424",
      "Unicode hex": "1F5A8"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "203",
      "Dingbat hex": "CB",
      "Unicode dec": "128425",
      "Unicode hex": "1F5A9"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "204",
      "Dingbat hex": "CC",
      "Unicode dec": "128447",
      "Unicode hex": "1F5BF"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "205",
      "Dingbat hex": "CD",
      "Unicode dec": "128426",
      "Unicode hex": "1F5AA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "206",
      "Dingbat hex": "CE",
      "Unicode dec": "128476",
      "Unicode hex": "1F5DC"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "207",
      "Dingbat hex": "CF",
      "Unicode dec": "128274",
      "Unicode hex": "1F512"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "208",
      "Dingbat hex": "D0",
      "Unicode dec": "128275",
      "Unicode hex": "1F513"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "209",
      "Dingbat hex": "D1",
      "Unicode dec": "128477",
      "Unicode hex": "1F5DD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "210",
      "Dingbat hex": "D2",
      "Unicode dec": "128229",
      "Unicode hex": "1F4E5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "211",
      "Dingbat hex": "D3",
      "Unicode dec": "128228",
      "Unicode hex": "1F4E4"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "212",
      "Dingbat hex": "D4",
      "Unicode dec": "128371",
      "Unicode hex": "1F573"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "213",
      "Dingbat hex": "D5",
      "Unicode dec": "127779",
      "Unicode hex": "1F323"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "214",
      "Dingbat hex": "D6",
      "Unicode dec": "127780",
      "Unicode hex": "1F324"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "215",
      "Dingbat hex": "D7",
      "Unicode dec": "127781",
      "Unicode hex": "1F325"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "216",
      "Dingbat hex": "D8",
      "Unicode dec": "127782",
      "Unicode hex": "1F326"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "217",
      "Dingbat hex": "D9",
      "Unicode dec": "9729",
      "Unicode hex": "2601"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "218",
      "Dingbat hex": "DA",
      "Unicode dec": "127784",
      "Unicode hex": "1F328"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "219",
      "Dingbat hex": "DB",
      "Unicode dec": "127783",
      "Unicode hex": "1F327"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "220",
      "Dingbat hex": "DC",
      "Unicode dec": "127785",
      "Unicode hex": "1F329"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "221",
      "Dingbat hex": "DD",
      "Unicode dec": "127786",
      "Unicode hex": "1F32A"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "222",
      "Dingbat hex": "DE",
      "Unicode dec": "127788",
      "Unicode hex": "1F32C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "223",
      "Dingbat hex": "DF",
      "Unicode dec": "127787",
      "Unicode hex": "1F32B"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "224",
      "Dingbat hex": "E0",
      "Unicode dec": "127772",
      "Unicode hex": "1F31C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "225",
      "Dingbat hex": "E1",
      "Unicode dec": "127777",
      "Unicode hex": "1F321"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "226",
      "Dingbat hex": "E2",
      "Unicode dec": "128715",
      "Unicode hex": "1F6CB"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "227",
      "Dingbat hex": "E3",
      "Unicode dec": "128719",
      "Unicode hex": "1F6CF"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "228",
      "Dingbat hex": "E4",
      "Unicode dec": "127869",
      "Unicode hex": "1F37D"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "229",
      "Dingbat hex": "E5",
      "Unicode dec": "127864",
      "Unicode hex": "1F378"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "230",
      "Dingbat hex": "E6",
      "Unicode dec": "128718",
      "Unicode hex": "1F6CE"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "231",
      "Dingbat hex": "E7",
      "Unicode dec": "128717",
      "Unicode hex": "1F6CD"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "232",
      "Dingbat hex": "E8",
      "Unicode dec": "9413",
      "Unicode hex": "24C5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "233",
      "Dingbat hex": "E9",
      "Unicode dec": "9855",
      "Unicode hex": "267F"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "234",
      "Dingbat hex": "EA",
      "Unicode dec": "128710",
      "Unicode hex": "1F6C6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "235",
      "Dingbat hex": "EB",
      "Unicode dec": "128392",
      "Unicode hex": "1F588"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "236",
      "Dingbat hex": "EC",
      "Unicode dec": "127891",
      "Unicode hex": "1F393"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "237",
      "Dingbat hex": "ED",
      "Unicode dec": "128484",
      "Unicode hex": "1F5E4"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "238",
      "Dingbat hex": "EE",
      "Unicode dec": "128485",
      "Unicode hex": "1F5E5"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "239",
      "Dingbat hex": "EF",
      "Unicode dec": "128486",
      "Unicode hex": "1F5E6"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "240",
      "Dingbat hex": "F0",
      "Unicode dec": "128487",
      "Unicode hex": "1F5E7"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "241",
      "Dingbat hex": "F1",
      "Unicode dec": "128746",
      "Unicode hex": "1F6EA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "242",
      "Dingbat hex": "F2",
      "Unicode dec": "128063",
      "Unicode hex": "1F43F"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "243",
      "Dingbat hex": "F3",
      "Unicode dec": "128038",
      "Unicode hex": "1F426"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "244",
      "Dingbat hex": "F4",
      "Unicode dec": "128031",
      "Unicode hex": "1F41F"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "245",
      "Dingbat hex": "F5",
      "Unicode dec": "128021",
      "Unicode hex": "1F415"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "246",
      "Dingbat hex": "F6",
      "Unicode dec": "128008",
      "Unicode hex": "1F408"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "247",
      "Dingbat hex": "F7",
      "Unicode dec": "128620",
      "Unicode hex": "1F66C"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "248",
      "Dingbat hex": "F8",
      "Unicode dec": "128622",
      "Unicode hex": "1F66E"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "249",
      "Dingbat hex": "F9",
      "Unicode dec": "128621",
      "Unicode hex": "1F66D"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "250",
      "Dingbat hex": "FA",
      "Unicode dec": "128623",
      "Unicode hex": "1F66F"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "251",
      "Dingbat hex": "FB",
      "Unicode dec": "128506",
      "Unicode hex": "1F5FA"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "252",
      "Dingbat hex": "FC",
      "Unicode dec": "127757",
      "Unicode hex": "1F30D"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "253",
      "Dingbat hex": "FD",
      "Unicode dec": "127759",
      "Unicode hex": "1F30F"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "254",
      "Dingbat hex": "FE",
      "Unicode dec": "127758",
      "Unicode hex": "1F30E"
    }, {
      "Typeface name": "Webdings",
      "Dingbat dec": "255",
      "Dingbat hex": "FF",
      "Unicode dec": "128330",
      "Unicode hex": "1F54A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "32",
      "Dingbat hex": "20",
      "Unicode dec": "32",
      "Unicode hex": "20"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "33",
      "Dingbat hex": "21",
      "Unicode dec": "128393",
      "Unicode hex": "1F589"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "34",
      "Dingbat hex": "22",
      "Unicode dec": "9986",
      "Unicode hex": "2702"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "35",
      "Dingbat hex": "23",
      "Unicode dec": "9985",
      "Unicode hex": "2701"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "36",
      "Dingbat hex": "24",
      "Unicode dec": "128083",
      "Unicode hex": "1F453"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "37",
      "Dingbat hex": "25",
      "Unicode dec": "128365",
      "Unicode hex": "1F56D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "38",
      "Dingbat hex": "26",
      "Unicode dec": "128366",
      "Unicode hex": "1F56E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "39",
      "Dingbat hex": "27",
      "Unicode dec": "128367",
      "Unicode hex": "1F56F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "40",
      "Dingbat hex": "28",
      "Unicode dec": "128383",
      "Unicode hex": "1F57F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "41",
      "Dingbat hex": "29",
      "Unicode dec": "9990",
      "Unicode hex": "2706"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "42",
      "Dingbat hex": "2A",
      "Unicode dec": "128386",
      "Unicode hex": "1F582"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "43",
      "Dingbat hex": "2B",
      "Unicode dec": "128387",
      "Unicode hex": "1F583"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "44",
      "Dingbat hex": "2C",
      "Unicode dec": "128234",
      "Unicode hex": "1F4EA"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "45",
      "Dingbat hex": "2D",
      "Unicode dec": "128235",
      "Unicode hex": "1F4EB"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "46",
      "Dingbat hex": "2E",
      "Unicode dec": "128236",
      "Unicode hex": "1F4EC"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "47",
      "Dingbat hex": "2F",
      "Unicode dec": "128237",
      "Unicode hex": "1F4ED"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "48",
      "Dingbat hex": "30",
      "Unicode dec": "128448",
      "Unicode hex": "1F5C0"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "49",
      "Dingbat hex": "31",
      "Unicode dec": "128449",
      "Unicode hex": "1F5C1"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "50",
      "Dingbat hex": "32",
      "Unicode dec": "128462",
      "Unicode hex": "1F5CE"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "51",
      "Dingbat hex": "33",
      "Unicode dec": "128463",
      "Unicode hex": "1F5CF"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "52",
      "Dingbat hex": "34",
      "Unicode dec": "128464",
      "Unicode hex": "1F5D0"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "53",
      "Dingbat hex": "35",
      "Unicode dec": "128452",
      "Unicode hex": "1F5C4"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "54",
      "Dingbat hex": "36",
      "Unicode dec": "8987",
      "Unicode hex": "231B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "55",
      "Dingbat hex": "37",
      "Unicode dec": "128430",
      "Unicode hex": "1F5AE"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "56",
      "Dingbat hex": "38",
      "Unicode dec": "128432",
      "Unicode hex": "1F5B0"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "57",
      "Dingbat hex": "39",
      "Unicode dec": "128434",
      "Unicode hex": "1F5B2"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "58",
      "Dingbat hex": "3A",
      "Unicode dec": "128435",
      "Unicode hex": "1F5B3"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "59",
      "Dingbat hex": "3B",
      "Unicode dec": "128436",
      "Unicode hex": "1F5B4"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "60",
      "Dingbat hex": "3C",
      "Unicode dec": "128427",
      "Unicode hex": "1F5AB"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "61",
      "Dingbat hex": "3D",
      "Unicode dec": "128428",
      "Unicode hex": "1F5AC"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "62",
      "Dingbat hex": "3E",
      "Unicode dec": "9991",
      "Unicode hex": "2707"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "63",
      "Dingbat hex": "3F",
      "Unicode dec": "9997",
      "Unicode hex": "270D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "64",
      "Dingbat hex": "40",
      "Unicode dec": "128398",
      "Unicode hex": "1F58E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "65",
      "Dingbat hex": "41",
      "Unicode dec": "9996",
      "Unicode hex": "270C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "66",
      "Dingbat hex": "42",
      "Unicode dec": "128399",
      "Unicode hex": "1F58F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "67",
      "Dingbat hex": "43",
      "Unicode dec": "128077",
      "Unicode hex": "1F44D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "68",
      "Dingbat hex": "44",
      "Unicode dec": "128078",
      "Unicode hex": "1F44E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "69",
      "Dingbat hex": "45",
      "Unicode dec": "9756",
      "Unicode hex": "261C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "70",
      "Dingbat hex": "46",
      "Unicode dec": "9758",
      "Unicode hex": "261E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "71",
      "Dingbat hex": "47",
      "Unicode dec": "9757",
      "Unicode hex": "261D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "72",
      "Dingbat hex": "48",
      "Unicode dec": "9759",
      "Unicode hex": "261F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "73",
      "Dingbat hex": "49",
      "Unicode dec": "128400",
      "Unicode hex": "1F590"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "74",
      "Dingbat hex": "4A",
      "Unicode dec": "9786",
      "Unicode hex": "263A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "75",
      "Dingbat hex": "4B",
      "Unicode dec": "128528",
      "Unicode hex": "1F610"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "76",
      "Dingbat hex": "4C",
      "Unicode dec": "9785",
      "Unicode hex": "2639"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "77",
      "Dingbat hex": "4D",
      "Unicode dec": "128163",
      "Unicode hex": "1F4A3"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "78",
      "Dingbat hex": "4E",
      "Unicode dec": "128369",
      "Unicode hex": "1F571"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "79",
      "Dingbat hex": "4F",
      "Unicode dec": "127987",
      "Unicode hex": "1F3F3"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "80",
      "Dingbat hex": "50",
      "Unicode dec": "127985",
      "Unicode hex": "1F3F1"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "81",
      "Dingbat hex": "51",
      "Unicode dec": "9992",
      "Unicode hex": "2708"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "82",
      "Dingbat hex": "52",
      "Unicode dec": "9788",
      "Unicode hex": "263C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "83",
      "Dingbat hex": "53",
      "Unicode dec": "127778",
      "Unicode hex": "1F322"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "84",
      "Dingbat hex": "54",
      "Unicode dec": "10052",
      "Unicode hex": "2744"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "85",
      "Dingbat hex": "55",
      "Unicode dec": "128326",
      "Unicode hex": "1F546"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "86",
      "Dingbat hex": "56",
      "Unicode dec": "10014",
      "Unicode hex": "271E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "87",
      "Dingbat hex": "57",
      "Unicode dec": "128328",
      "Unicode hex": "1F548"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "88",
      "Dingbat hex": "58",
      "Unicode dec": "10016",
      "Unicode hex": "2720"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "89",
      "Dingbat hex": "59",
      "Unicode dec": "10017",
      "Unicode hex": "2721"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "90",
      "Dingbat hex": "5A",
      "Unicode dec": "9770",
      "Unicode hex": "262A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "91",
      "Dingbat hex": "5B",
      "Unicode dec": "9775",
      "Unicode hex": "262F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "92",
      "Dingbat hex": "5C",
      "Unicode dec": "128329",
      "Unicode hex": "1F549"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "93",
      "Dingbat hex": "5D",
      "Unicode dec": "9784",
      "Unicode hex": "2638"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "94",
      "Dingbat hex": "5E",
      "Unicode dec": "9800",
      "Unicode hex": "2648"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "95",
      "Dingbat hex": "5F",
      "Unicode dec": "9801",
      "Unicode hex": "2649"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "96",
      "Dingbat hex": "60",
      "Unicode dec": "9802",
      "Unicode hex": "264A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "97",
      "Dingbat hex": "61",
      "Unicode dec": "9803",
      "Unicode hex": "264B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "98",
      "Dingbat hex": "62",
      "Unicode dec": "9804",
      "Unicode hex": "264C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "99",
      "Dingbat hex": "63",
      "Unicode dec": "9805",
      "Unicode hex": "264D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "100",
      "Dingbat hex": "64",
      "Unicode dec": "9806",
      "Unicode hex": "264E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "101",
      "Dingbat hex": "65",
      "Unicode dec": "9807",
      "Unicode hex": "264F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "102",
      "Dingbat hex": "66",
      "Unicode dec": "9808",
      "Unicode hex": "2650"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "103",
      "Dingbat hex": "67",
      "Unicode dec": "9809",
      "Unicode hex": "2651"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "104",
      "Dingbat hex": "68",
      "Unicode dec": "9810",
      "Unicode hex": "2652"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "105",
      "Dingbat hex": "69",
      "Unicode dec": "9811",
      "Unicode hex": "2653"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "106",
      "Dingbat hex": "6A",
      "Unicode dec": "128624",
      "Unicode hex": "1F670"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "107",
      "Dingbat hex": "6B",
      "Unicode dec": "128629",
      "Unicode hex": "1F675"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "108",
      "Dingbat hex": "6C",
      "Unicode dec": "9899",
      "Unicode hex": "26AB"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "109",
      "Dingbat hex": "6D",
      "Unicode dec": "128318",
      "Unicode hex": "1F53E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "110",
      "Dingbat hex": "6E",
      "Unicode dec": "9724",
      "Unicode hex": "25FC"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "111",
      "Dingbat hex": "6F",
      "Unicode dec": "128911",
      "Unicode hex": "1F78F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "112",
      "Dingbat hex": "70",
      "Unicode dec": "128912",
      "Unicode hex": "1F790"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "113",
      "Dingbat hex": "71",
      "Unicode dec": "10065",
      "Unicode hex": "2751"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "114",
      "Dingbat hex": "72",
      "Unicode dec": "10066",
      "Unicode hex": "2752"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "115",
      "Dingbat hex": "73",
      "Unicode dec": "128927",
      "Unicode hex": "1F79F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "116",
      "Dingbat hex": "74",
      "Unicode dec": "10731",
      "Unicode hex": "29EB"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "117",
      "Dingbat hex": "75",
      "Unicode dec": "9670",
      "Unicode hex": "25C6"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "118",
      "Dingbat hex": "76",
      "Unicode dec": "10070",
      "Unicode hex": "2756"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "119",
      "Dingbat hex": "77",
      "Unicode dec": "11049",
      "Unicode hex": "2B29"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "120",
      "Dingbat hex": "78",
      "Unicode dec": "8999",
      "Unicode hex": "2327"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "121",
      "Dingbat hex": "79",
      "Unicode dec": "11193",
      "Unicode hex": "2BB9"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "122",
      "Dingbat hex": "7A",
      "Unicode dec": "8984",
      "Unicode hex": "2318"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "123",
      "Dingbat hex": "7B",
      "Unicode dec": "127989",
      "Unicode hex": "1F3F5"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "124",
      "Dingbat hex": "7C",
      "Unicode dec": "127990",
      "Unicode hex": "1F3F6"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "125",
      "Dingbat hex": "7D",
      "Unicode dec": "128630",
      "Unicode hex": "1F676"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "126",
      "Dingbat hex": "7E",
      "Unicode dec": "128631",
      "Unicode hex": "1F677"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "127",
      "Dingbat hex": "7F",
      "Unicode dec": "9647",
      "Unicode hex": "25AF"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "128",
      "Dingbat hex": "80",
      "Unicode dec": "127243",
      "Unicode hex": "1F10B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "129",
      "Dingbat hex": "81",
      "Unicode dec": "10112",
      "Unicode hex": "2780"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "130",
      "Dingbat hex": "82",
      "Unicode dec": "10113",
      "Unicode hex": "2781"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "131",
      "Dingbat hex": "83",
      "Unicode dec": "10114",
      "Unicode hex": "2782"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "132",
      "Dingbat hex": "84",
      "Unicode dec": "10115",
      "Unicode hex": "2783"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "133",
      "Dingbat hex": "85",
      "Unicode dec": "10116",
      "Unicode hex": "2784"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "134",
      "Dingbat hex": "86",
      "Unicode dec": "10117",
      "Unicode hex": "2785"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "135",
      "Dingbat hex": "87",
      "Unicode dec": "10118",
      "Unicode hex": "2786"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "136",
      "Dingbat hex": "88",
      "Unicode dec": "10119",
      "Unicode hex": "2787"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "137",
      "Dingbat hex": "89",
      "Unicode dec": "10120",
      "Unicode hex": "2788"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "138",
      "Dingbat hex": "8A",
      "Unicode dec": "10121",
      "Unicode hex": "2789"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "139",
      "Dingbat hex": "8B",
      "Unicode dec": "127244",
      "Unicode hex": "1F10C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "140",
      "Dingbat hex": "8C",
      "Unicode dec": "10122",
      "Unicode hex": "278A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "141",
      "Dingbat hex": "8D",
      "Unicode dec": "10123",
      "Unicode hex": "278B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "142",
      "Dingbat hex": "8E",
      "Unicode dec": "10124",
      "Unicode hex": "278C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "143",
      "Dingbat hex": "8F",
      "Unicode dec": "10125",
      "Unicode hex": "278D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "144",
      "Dingbat hex": "90",
      "Unicode dec": "10126",
      "Unicode hex": "278E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "145",
      "Dingbat hex": "91",
      "Unicode dec": "10127",
      "Unicode hex": "278F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "146",
      "Dingbat hex": "92",
      "Unicode dec": "10128",
      "Unicode hex": "2790"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "147",
      "Dingbat hex": "93",
      "Unicode dec": "10129",
      "Unicode hex": "2791"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "148",
      "Dingbat hex": "94",
      "Unicode dec": "10130",
      "Unicode hex": "2792"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "149",
      "Dingbat hex": "95",
      "Unicode dec": "10131",
      "Unicode hex": "2793"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "150",
      "Dingbat hex": "96",
      "Unicode dec": "128610",
      "Unicode hex": "1F662"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "151",
      "Dingbat hex": "97",
      "Unicode dec": "128608",
      "Unicode hex": "1F660"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "152",
      "Dingbat hex": "98",
      "Unicode dec": "128609",
      "Unicode hex": "1F661"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "153",
      "Dingbat hex": "99",
      "Unicode dec": "128611",
      "Unicode hex": "1F663"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "154",
      "Dingbat hex": "9A",
      "Unicode dec": "128606",
      "Unicode hex": "1F65E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "155",
      "Dingbat hex": "9B",
      "Unicode dec": "128604",
      "Unicode hex": "1F65C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "156",
      "Dingbat hex": "9C",
      "Unicode dec": "128605",
      "Unicode hex": "1F65D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "157",
      "Dingbat hex": "9D",
      "Unicode dec": "128607",
      "Unicode hex": "1F65F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "158",
      "Dingbat hex": "9E",
      "Unicode dec": "8729",
      "Unicode hex": "2219"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "159",
      "Dingbat hex": "9F",
      "Unicode dec": "8226",
      "Unicode hex": "2022"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "160",
      "Dingbat hex": "A0",
      "Unicode dec": "11037",
      "Unicode hex": "2B1D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "161",
      "Dingbat hex": "A1",
      "Unicode dec": "11096",
      "Unicode hex": "2B58"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "162",
      "Dingbat hex": "A2",
      "Unicode dec": "128902",
      "Unicode hex": "1F786"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "163",
      "Dingbat hex": "A3",
      "Unicode dec": "128904",
      "Unicode hex": "1F788"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "164",
      "Dingbat hex": "A4",
      "Unicode dec": "128906",
      "Unicode hex": "1F78A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "165",
      "Dingbat hex": "A5",
      "Unicode dec": "128907",
      "Unicode hex": "1F78B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "166",
      "Dingbat hex": "A6",
      "Unicode dec": "128319",
      "Unicode hex": "1F53F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "167",
      "Dingbat hex": "A7",
      "Unicode dec": "9642",
      "Unicode hex": "25AA"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "168",
      "Dingbat hex": "A8",
      "Unicode dec": "128910",
      "Unicode hex": "1F78E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "169",
      "Dingbat hex": "A9",
      "Unicode dec": "128961",
      "Unicode hex": "1F7C1"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "170",
      "Dingbat hex": "AA",
      "Unicode dec": "128965",
      "Unicode hex": "1F7C5"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "171",
      "Dingbat hex": "AB",
      "Unicode dec": "9733",
      "Unicode hex": "2605"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "172",
      "Dingbat hex": "AC",
      "Unicode dec": "128971",
      "Unicode hex": "1F7CB"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "173",
      "Dingbat hex": "AD",
      "Unicode dec": "128975",
      "Unicode hex": "1F7CF"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "174",
      "Dingbat hex": "AE",
      "Unicode dec": "128979",
      "Unicode hex": "1F7D3"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "175",
      "Dingbat hex": "AF",
      "Unicode dec": "128977",
      "Unicode hex": "1F7D1"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "176",
      "Dingbat hex": "B0",
      "Unicode dec": "11216",
      "Unicode hex": "2BD0"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "177",
      "Dingbat hex": "B1",
      "Unicode dec": "8982",
      "Unicode hex": "2316"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "178",
      "Dingbat hex": "B2",
      "Unicode dec": "11214",
      "Unicode hex": "2BCE"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "179",
      "Dingbat hex": "B3",
      "Unicode dec": "11215",
      "Unicode hex": "2BCF"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "180",
      "Dingbat hex": "B4",
      "Unicode dec": "11217",
      "Unicode hex": "2BD1"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "181",
      "Dingbat hex": "B5",
      "Unicode dec": "10026",
      "Unicode hex": "272A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "182",
      "Dingbat hex": "B6",
      "Unicode dec": "10032",
      "Unicode hex": "2730"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "183",
      "Dingbat hex": "B7",
      "Unicode dec": "128336",
      "Unicode hex": "1F550"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "184",
      "Dingbat hex": "B8",
      "Unicode dec": "128337",
      "Unicode hex": "1F551"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "185",
      "Dingbat hex": "B9",
      "Unicode dec": "128338",
      "Unicode hex": "1F552"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "186",
      "Dingbat hex": "BA",
      "Unicode dec": "128339",
      "Unicode hex": "1F553"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "187",
      "Dingbat hex": "BB",
      "Unicode dec": "128340",
      "Unicode hex": "1F554"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "188",
      "Dingbat hex": "BC",
      "Unicode dec": "128341",
      "Unicode hex": "1F555"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "189",
      "Dingbat hex": "BD",
      "Unicode dec": "128342",
      "Unicode hex": "1F556"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "190",
      "Dingbat hex": "BE",
      "Unicode dec": "128343",
      "Unicode hex": "1F557"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "191",
      "Dingbat hex": "BF",
      "Unicode dec": "128344",
      "Unicode hex": "1F558"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "192",
      "Dingbat hex": "C0",
      "Unicode dec": "128345",
      "Unicode hex": "1F559"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "193",
      "Dingbat hex": "C1",
      "Unicode dec": "128346",
      "Unicode hex": "1F55A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "194",
      "Dingbat hex": "C2",
      "Unicode dec": "128347",
      "Unicode hex": "1F55B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "195",
      "Dingbat hex": "C3",
      "Unicode dec": "11184",
      "Unicode hex": "2BB0"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "196",
      "Dingbat hex": "C4",
      "Unicode dec": "11185",
      "Unicode hex": "2BB1"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "197",
      "Dingbat hex": "C5",
      "Unicode dec": "11186",
      "Unicode hex": "2BB2"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "198",
      "Dingbat hex": "C6",
      "Unicode dec": "11187",
      "Unicode hex": "2BB3"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "199",
      "Dingbat hex": "C7",
      "Unicode dec": "11188",
      "Unicode hex": "2BB4"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "200",
      "Dingbat hex": "C8",
      "Unicode dec": "11189",
      "Unicode hex": "2BB5"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "201",
      "Dingbat hex": "C9",
      "Unicode dec": "11190",
      "Unicode hex": "2BB6"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "202",
      "Dingbat hex": "CA",
      "Unicode dec": "11191",
      "Unicode hex": "2BB7"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "203",
      "Dingbat hex": "CB",
      "Unicode dec": "128618",
      "Unicode hex": "1F66A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "204",
      "Dingbat hex": "CC",
      "Unicode dec": "128619",
      "Unicode hex": "1F66B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "205",
      "Dingbat hex": "CD",
      "Unicode dec": "128597",
      "Unicode hex": "1F655"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "206",
      "Dingbat hex": "CE",
      "Unicode dec": "128596",
      "Unicode hex": "1F654"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "207",
      "Dingbat hex": "CF",
      "Unicode dec": "128599",
      "Unicode hex": "1F657"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "208",
      "Dingbat hex": "D0",
      "Unicode dec": "128598",
      "Unicode hex": "1F656"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "209",
      "Dingbat hex": "D1",
      "Unicode dec": "128592",
      "Unicode hex": "1F650"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "210",
      "Dingbat hex": "D2",
      "Unicode dec": "128593",
      "Unicode hex": "1F651"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "211",
      "Dingbat hex": "D3",
      "Unicode dec": "128594",
      "Unicode hex": "1F652"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "212",
      "Dingbat hex": "D4",
      "Unicode dec": "128595",
      "Unicode hex": "1F653"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "213",
      "Dingbat hex": "D5",
      "Unicode dec": "9003",
      "Unicode hex": "232B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "214",
      "Dingbat hex": "D6",
      "Unicode dec": "8998",
      "Unicode hex": "2326"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "215",
      "Dingbat hex": "D7",
      "Unicode dec": "11160",
      "Unicode hex": "2B98"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "216",
      "Dingbat hex": "D8",
      "Unicode dec": "11162",
      "Unicode hex": "2B9A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "217",
      "Dingbat hex": "D9",
      "Unicode dec": "11161",
      "Unicode hex": "2B99"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "218",
      "Dingbat hex": "DA",
      "Unicode dec": "11163",
      "Unicode hex": "2B9B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "219",
      "Dingbat hex": "DB",
      "Unicode dec": "11144",
      "Unicode hex": "2B88"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "220",
      "Dingbat hex": "DC",
      "Unicode dec": "11146",
      "Unicode hex": "2B8A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "221",
      "Dingbat hex": "DD",
      "Unicode dec": "11145",
      "Unicode hex": "2B89"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "222",
      "Dingbat hex": "DE",
      "Unicode dec": "11147",
      "Unicode hex": "2B8B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "223",
      "Dingbat hex": "DF",
      "Unicode dec": "129128",
      "Unicode hex": "1F868"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "224",
      "Dingbat hex": "E0",
      "Unicode dec": "129130",
      "Unicode hex": "1F86A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "225",
      "Dingbat hex": "E1",
      "Unicode dec": "129129",
      "Unicode hex": "1F869"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "226",
      "Dingbat hex": "E2",
      "Unicode dec": "129131",
      "Unicode hex": "1F86B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "227",
      "Dingbat hex": "E3",
      "Unicode dec": "129132",
      "Unicode hex": "1F86C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "228",
      "Dingbat hex": "E4",
      "Unicode dec": "129133",
      "Unicode hex": "1F86D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "229",
      "Dingbat hex": "E5",
      "Unicode dec": "129135",
      "Unicode hex": "1F86F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "230",
      "Dingbat hex": "E6",
      "Unicode dec": "129134",
      "Unicode hex": "1F86E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "231",
      "Dingbat hex": "E7",
      "Unicode dec": "129144",
      "Unicode hex": "1F878"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "232",
      "Dingbat hex": "E8",
      "Unicode dec": "129146",
      "Unicode hex": "1F87A"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "233",
      "Dingbat hex": "E9",
      "Unicode dec": "129145",
      "Unicode hex": "1F879"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "234",
      "Dingbat hex": "EA",
      "Unicode dec": "129147",
      "Unicode hex": "1F87B"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "235",
      "Dingbat hex": "EB",
      "Unicode dec": "129148",
      "Unicode hex": "1F87C"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "236",
      "Dingbat hex": "EC",
      "Unicode dec": "129149",
      "Unicode hex": "1F87D"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "237",
      "Dingbat hex": "ED",
      "Unicode dec": "129151",
      "Unicode hex": "1F87F"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "238",
      "Dingbat hex": "EE",
      "Unicode dec": "129150",
      "Unicode hex": "1F87E"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "239",
      "Dingbat hex": "EF",
      "Unicode dec": "8678",
      "Unicode hex": "21E6"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "240",
      "Dingbat hex": "F0",
      "Unicode dec": "8680",
      "Unicode hex": "21E8"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "241",
      "Dingbat hex": "F1",
      "Unicode dec": "8679",
      "Unicode hex": "21E7"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "242",
      "Dingbat hex": "F2",
      "Unicode dec": "8681",
      "Unicode hex": "21E9"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "243",
      "Dingbat hex": "F3",
      "Unicode dec": "11012",
      "Unicode hex": "2B04"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "244",
      "Dingbat hex": "F4",
      "Unicode dec": "8691",
      "Unicode hex": "21F3"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "245",
      "Dingbat hex": "F5",
      "Unicode dec": "11009",
      "Unicode hex": "2B01"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "246",
      "Dingbat hex": "F6",
      "Unicode dec": "11008",
      "Unicode hex": "2B00"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "247",
      "Dingbat hex": "F7",
      "Unicode dec": "11011",
      "Unicode hex": "2B03"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "248",
      "Dingbat hex": "F8",
      "Unicode dec": "11010",
      "Unicode hex": "2B02"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "249",
      "Dingbat hex": "F9",
      "Unicode dec": "129196",
      "Unicode hex": "1F8AC"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "250",
      "Dingbat hex": "FA",
      "Unicode dec": "129197",
      "Unicode hex": "1F8AD"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "251",
      "Dingbat hex": "FB",
      "Unicode dec": "128502",
      "Unicode hex": "1F5F6"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "252",
      "Dingbat hex": "FC",
      "Unicode dec": "10003",
      "Unicode hex": "2713"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "253",
      "Dingbat hex": "FD",
      "Unicode dec": "128503",
      "Unicode hex": "1F5F7"
    }, {
      "Typeface name": "Wingdings",
      "Dingbat dec": "254",
      "Dingbat hex": "FE",
      "Unicode dec": "128505",
      "Unicode hex": "1F5F9"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "32",
      "Dingbat hex": "20",
      "Unicode dec": "32",
      "Unicode hex": "20"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "33",
      "Dingbat hex": "21",
      "Unicode dec": "128394",
      "Unicode hex": "1F58A"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "34",
      "Dingbat hex": "22",
      "Unicode dec": "128395",
      "Unicode hex": "1F58B"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "35",
      "Dingbat hex": "23",
      "Unicode dec": "128396",
      "Unicode hex": "1F58C"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "36",
      "Dingbat hex": "24",
      "Unicode dec": "128397",
      "Unicode hex": "1F58D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "37",
      "Dingbat hex": "25",
      "Unicode dec": "9988",
      "Unicode hex": "2704"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "38",
      "Dingbat hex": "26",
      "Unicode dec": "9984",
      "Unicode hex": "2700"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "39",
      "Dingbat hex": "27",
      "Unicode dec": "128382",
      "Unicode hex": "1F57E"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "40",
      "Dingbat hex": "28",
      "Unicode dec": "128381",
      "Unicode hex": "1F57D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "41",
      "Dingbat hex": "29",
      "Unicode dec": "128453",
      "Unicode hex": "1F5C5"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "42",
      "Dingbat hex": "2A",
      "Unicode dec": "128454",
      "Unicode hex": "1F5C6"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "43",
      "Dingbat hex": "2B",
      "Unicode dec": "128455",
      "Unicode hex": "1F5C7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "44",
      "Dingbat hex": "2C",
      "Unicode dec": "128456",
      "Unicode hex": "1F5C8"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "45",
      "Dingbat hex": "2D",
      "Unicode dec": "128457",
      "Unicode hex": "1F5C9"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "46",
      "Dingbat hex": "2E",
      "Unicode dec": "128458",
      "Unicode hex": "1F5CA"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "47",
      "Dingbat hex": "2F",
      "Unicode dec": "128459",
      "Unicode hex": "1F5CB"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "48",
      "Dingbat hex": "30",
      "Unicode dec": "128460",
      "Unicode hex": "1F5CC"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "49",
      "Dingbat hex": "31",
      "Unicode dec": "128461",
      "Unicode hex": "1F5CD"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "50",
      "Dingbat hex": "32",
      "Unicode dec": "128203",
      "Unicode hex": "1F4CB"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "51",
      "Dingbat hex": "33",
      "Unicode dec": "128465",
      "Unicode hex": "1F5D1"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "52",
      "Dingbat hex": "34",
      "Unicode dec": "128468",
      "Unicode hex": "1F5D4"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "53",
      "Dingbat hex": "35",
      "Unicode dec": "128437",
      "Unicode hex": "1F5B5"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "54",
      "Dingbat hex": "36",
      "Unicode dec": "128438",
      "Unicode hex": "1F5B6"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "55",
      "Dingbat hex": "37",
      "Unicode dec": "128439",
      "Unicode hex": "1F5B7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "56",
      "Dingbat hex": "38",
      "Unicode dec": "128440",
      "Unicode hex": "1F5B8"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "57",
      "Dingbat hex": "39",
      "Unicode dec": "128429",
      "Unicode hex": "1F5AD"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "58",
      "Dingbat hex": "3A",
      "Unicode dec": "128431",
      "Unicode hex": "1F5AF"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "59",
      "Dingbat hex": "3B",
      "Unicode dec": "128433",
      "Unicode hex": "1F5B1"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "60",
      "Dingbat hex": "3C",
      "Unicode dec": "128402",
      "Unicode hex": "1F592"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "61",
      "Dingbat hex": "3D",
      "Unicode dec": "128403",
      "Unicode hex": "1F593"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "62",
      "Dingbat hex": "3E",
      "Unicode dec": "128408",
      "Unicode hex": "1F598"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "63",
      "Dingbat hex": "3F",
      "Unicode dec": "128409",
      "Unicode hex": "1F599"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "64",
      "Dingbat hex": "40",
      "Unicode dec": "128410",
      "Unicode hex": "1F59A"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "65",
      "Dingbat hex": "41",
      "Unicode dec": "128411",
      "Unicode hex": "1F59B"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "66",
      "Dingbat hex": "42",
      "Unicode dec": "128072",
      "Unicode hex": "1F448"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "67",
      "Dingbat hex": "43",
      "Unicode dec": "128073",
      "Unicode hex": "1F449"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "68",
      "Dingbat hex": "44",
      "Unicode dec": "128412",
      "Unicode hex": "1F59C"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "69",
      "Dingbat hex": "45",
      "Unicode dec": "128413",
      "Unicode hex": "1F59D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "70",
      "Dingbat hex": "46",
      "Unicode dec": "128414",
      "Unicode hex": "1F59E"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "71",
      "Dingbat hex": "47",
      "Unicode dec": "128415",
      "Unicode hex": "1F59F"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "72",
      "Dingbat hex": "48",
      "Unicode dec": "128416",
      "Unicode hex": "1F5A0"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "73",
      "Dingbat hex": "49",
      "Unicode dec": "128417",
      "Unicode hex": "1F5A1"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "74",
      "Dingbat hex": "4A",
      "Unicode dec": "128070",
      "Unicode hex": "1F446"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "75",
      "Dingbat hex": "4B",
      "Unicode dec": "128071",
      "Unicode hex": "1F447"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "76",
      "Dingbat hex": "4C",
      "Unicode dec": "128418",
      "Unicode hex": "1F5A2"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "77",
      "Dingbat hex": "4D",
      "Unicode dec": "128419",
      "Unicode hex": "1F5A3"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "78",
      "Dingbat hex": "4E",
      "Unicode dec": "128401",
      "Unicode hex": "1F591"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "79",
      "Dingbat hex": "4F",
      "Unicode dec": "128500",
      "Unicode hex": "1F5F4"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "80",
      "Dingbat hex": "50",
      "Unicode dec": "128504",
      "Unicode hex": "1F5F8"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "81",
      "Dingbat hex": "51",
      "Unicode dec": "128501",
      "Unicode hex": "1F5F5"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "82",
      "Dingbat hex": "52",
      "Unicode dec": "9745",
      "Unicode hex": "2611"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "83",
      "Dingbat hex": "53",
      "Unicode dec": "11197",
      "Unicode hex": "2BBD"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "84",
      "Dingbat hex": "54",
      "Unicode dec": "9746",
      "Unicode hex": "2612"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "85",
      "Dingbat hex": "55",
      "Unicode dec": "11198",
      "Unicode hex": "2BBE"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "86",
      "Dingbat hex": "56",
      "Unicode dec": "11199",
      "Unicode hex": "2BBF"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "87",
      "Dingbat hex": "57",
      "Unicode dec": "128711",
      "Unicode hex": "1F6C7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "88",
      "Dingbat hex": "58",
      "Unicode dec": "10680",
      "Unicode hex": "29B8"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "89",
      "Dingbat hex": "59",
      "Unicode dec": "128625",
      "Unicode hex": "1F671"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "90",
      "Dingbat hex": "5A",
      "Unicode dec": "128628",
      "Unicode hex": "1F674"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "91",
      "Dingbat hex": "5B",
      "Unicode dec": "128626",
      "Unicode hex": "1F672"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "92",
      "Dingbat hex": "5C",
      "Unicode dec": "128627",
      "Unicode hex": "1F673"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "93",
      "Dingbat hex": "5D",
      "Unicode dec": "8253",
      "Unicode hex": "203D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "94",
      "Dingbat hex": "5E",
      "Unicode dec": "128633",
      "Unicode hex": "1F679"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "95",
      "Dingbat hex": "5F",
      "Unicode dec": "128634",
      "Unicode hex": "1F67A"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "96",
      "Dingbat hex": "60",
      "Unicode dec": "128635",
      "Unicode hex": "1F67B"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "97",
      "Dingbat hex": "61",
      "Unicode dec": "128614",
      "Unicode hex": "1F666"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "98",
      "Dingbat hex": "62",
      "Unicode dec": "128612",
      "Unicode hex": "1F664"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "99",
      "Dingbat hex": "63",
      "Unicode dec": "128613",
      "Unicode hex": "1F665"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "100",
      "Dingbat hex": "64",
      "Unicode dec": "128615",
      "Unicode hex": "1F667"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "101",
      "Dingbat hex": "65",
      "Unicode dec": "128602",
      "Unicode hex": "1F65A"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "102",
      "Dingbat hex": "66",
      "Unicode dec": "128600",
      "Unicode hex": "1F658"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "103",
      "Dingbat hex": "67",
      "Unicode dec": "128601",
      "Unicode hex": "1F659"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "104",
      "Dingbat hex": "68",
      "Unicode dec": "128603",
      "Unicode hex": "1F65B"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "105",
      "Dingbat hex": "69",
      "Unicode dec": "9450",
      "Unicode hex": "24EA"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "106",
      "Dingbat hex": "6A",
      "Unicode dec": "9312",
      "Unicode hex": "2460"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "107",
      "Dingbat hex": "6B",
      "Unicode dec": "9313",
      "Unicode hex": "2461"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "108",
      "Dingbat hex": "6C",
      "Unicode dec": "9314",
      "Unicode hex": "2462"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "109",
      "Dingbat hex": "6D",
      "Unicode dec": "9315",
      "Unicode hex": "2463"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "110",
      "Dingbat hex": "6E",
      "Unicode dec": "9316",
      "Unicode hex": "2464"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "111",
      "Dingbat hex": "6F",
      "Unicode dec": "9317",
      "Unicode hex": "2465"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "112",
      "Dingbat hex": "70",
      "Unicode dec": "9318",
      "Unicode hex": "2466"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "113",
      "Dingbat hex": "71",
      "Unicode dec": "9319",
      "Unicode hex": "2467"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "114",
      "Dingbat hex": "72",
      "Unicode dec": "9320",
      "Unicode hex": "2468"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "115",
      "Dingbat hex": "73",
      "Unicode dec": "9321",
      "Unicode hex": "2469"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "116",
      "Dingbat hex": "74",
      "Unicode dec": "9471",
      "Unicode hex": "24FF"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "117",
      "Dingbat hex": "75",
      "Unicode dec": "10102",
      "Unicode hex": "2776"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "118",
      "Dingbat hex": "76",
      "Unicode dec": "10103",
      "Unicode hex": "2777"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "119",
      "Dingbat hex": "77",
      "Unicode dec": "10104",
      "Unicode hex": "2778"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "120",
      "Dingbat hex": "78",
      "Unicode dec": "10105",
      "Unicode hex": "2779"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "121",
      "Dingbat hex": "79",
      "Unicode dec": "10106",
      "Unicode hex": "277A"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "122",
      "Dingbat hex": "7A",
      "Unicode dec": "10107",
      "Unicode hex": "277B"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "123",
      "Dingbat hex": "7B",
      "Unicode dec": "10108",
      "Unicode hex": "277C"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "124",
      "Dingbat hex": "7C",
      "Unicode dec": "10109",
      "Unicode hex": "277D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "125",
      "Dingbat hex": "7D",
      "Unicode dec": "10110",
      "Unicode hex": "277E"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "126",
      "Dingbat hex": "7E",
      "Unicode dec": "10111",
      "Unicode hex": "277F"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "128",
      "Dingbat hex": "80",
      "Unicode dec": "9737",
      "Unicode hex": "2609"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "129",
      "Dingbat hex": "81",
      "Unicode dec": "127765",
      "Unicode hex": "1F315"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "130",
      "Dingbat hex": "82",
      "Unicode dec": "9789",
      "Unicode hex": "263D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "131",
      "Dingbat hex": "83",
      "Unicode dec": "9790",
      "Unicode hex": "263E"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "132",
      "Dingbat hex": "84",
      "Unicode dec": "11839",
      "Unicode hex": "2E3F"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "133",
      "Dingbat hex": "85",
      "Unicode dec": "10013",
      "Unicode hex": "271D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "134",
      "Dingbat hex": "86",
      "Unicode dec": "128327",
      "Unicode hex": "1F547"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "135",
      "Dingbat hex": "87",
      "Unicode dec": "128348",
      "Unicode hex": "1F55C"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "136",
      "Dingbat hex": "88",
      "Unicode dec": "128349",
      "Unicode hex": "1F55D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "137",
      "Dingbat hex": "89",
      "Unicode dec": "128350",
      "Unicode hex": "1F55E"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "138",
      "Dingbat hex": "8A",
      "Unicode dec": "128351",
      "Unicode hex": "1F55F"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "139",
      "Dingbat hex": "8B",
      "Unicode dec": "128352",
      "Unicode hex": "1F560"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "140",
      "Dingbat hex": "8C",
      "Unicode dec": "128353",
      "Unicode hex": "1F561"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "141",
      "Dingbat hex": "8D",
      "Unicode dec": "128354",
      "Unicode hex": "1F562"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "142",
      "Dingbat hex": "8E",
      "Unicode dec": "128355",
      "Unicode hex": "1F563"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "143",
      "Dingbat hex": "8F",
      "Unicode dec": "128356",
      "Unicode hex": "1F564"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "144",
      "Dingbat hex": "90",
      "Unicode dec": "128357",
      "Unicode hex": "1F565"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "145",
      "Dingbat hex": "91",
      "Unicode dec": "128358",
      "Unicode hex": "1F566"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "146",
      "Dingbat hex": "92",
      "Unicode dec": "128359",
      "Unicode hex": "1F567"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "147",
      "Dingbat hex": "93",
      "Unicode dec": "128616",
      "Unicode hex": "1F668"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "148",
      "Dingbat hex": "94",
      "Unicode dec": "128617",
      "Unicode hex": "1F669"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "149",
      "Dingbat hex": "95",
      "Unicode dec": "8901",
      "Unicode hex": "22C5"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "150",
      "Dingbat hex": "96",
      "Unicode dec": "128900",
      "Unicode hex": "1F784"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "151",
      "Dingbat hex": "97",
      "Unicode dec": "10625",
      "Unicode hex": "2981"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "152",
      "Dingbat hex": "98",
      "Unicode dec": "9679",
      "Unicode hex": "25CF"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "153",
      "Dingbat hex": "99",
      "Unicode dec": "9675",
      "Unicode hex": "25CB"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "154",
      "Dingbat hex": "9A",
      "Unicode dec": "128901",
      "Unicode hex": "1F785"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "155",
      "Dingbat hex": "9B",
      "Unicode dec": "128903",
      "Unicode hex": "1F787"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "156",
      "Dingbat hex": "9C",
      "Unicode dec": "128905",
      "Unicode hex": "1F789"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "157",
      "Dingbat hex": "9D",
      "Unicode dec": "8857",
      "Unicode hex": "2299"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "158",
      "Dingbat hex": "9E",
      "Unicode dec": "10687",
      "Unicode hex": "29BF"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "159",
      "Dingbat hex": "9F",
      "Unicode dec": "128908",
      "Unicode hex": "1F78C"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "160",
      "Dingbat hex": "A0",
      "Unicode dec": "128909",
      "Unicode hex": "1F78D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "161",
      "Dingbat hex": "A1",
      "Unicode dec": "9726",
      "Unicode hex": "25FE"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "162",
      "Dingbat hex": "A2",
      "Unicode dec": "9632",
      "Unicode hex": "25A0"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "163",
      "Dingbat hex": "A3",
      "Unicode dec": "9633",
      "Unicode hex": "25A1"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "164",
      "Dingbat hex": "A4",
      "Unicode dec": "128913",
      "Unicode hex": "1F791"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "165",
      "Dingbat hex": "A5",
      "Unicode dec": "128914",
      "Unicode hex": "1F792"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "166",
      "Dingbat hex": "A6",
      "Unicode dec": "128915",
      "Unicode hex": "1F793"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "167",
      "Dingbat hex": "A7",
      "Unicode dec": "128916",
      "Unicode hex": "1F794"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "168",
      "Dingbat hex": "A8",
      "Unicode dec": "9635",
      "Unicode hex": "25A3"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "169",
      "Dingbat hex": "A9",
      "Unicode dec": "128917",
      "Unicode hex": "1F795"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "170",
      "Dingbat hex": "AA",
      "Unicode dec": "128918",
      "Unicode hex": "1F796"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "171",
      "Dingbat hex": "AB",
      "Unicode dec": "128919",
      "Unicode hex": "1F797"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "172",
      "Dingbat hex": "AC",
      "Unicode dec": "128920",
      "Unicode hex": "1F798"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "173",
      "Dingbat hex": "AD",
      "Unicode dec": "11049",
      "Unicode hex": "2B29"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "174",
      "Dingbat hex": "AE",
      "Unicode dec": "11045",
      "Unicode hex": "2B25"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "175",
      "Dingbat hex": "AF",
      "Unicode dec": "9671",
      "Unicode hex": "25C7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "176",
      "Dingbat hex": "B0",
      "Unicode dec": "128922",
      "Unicode hex": "1F79A"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "177",
      "Dingbat hex": "B1",
      "Unicode dec": "9672",
      "Unicode hex": "25C8"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "178",
      "Dingbat hex": "B2",
      "Unicode dec": "128923",
      "Unicode hex": "1F79B"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "179",
      "Dingbat hex": "B3",
      "Unicode dec": "128924",
      "Unicode hex": "1F79C"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "180",
      "Dingbat hex": "B4",
      "Unicode dec": "128925",
      "Unicode hex": "1F79D"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "181",
      "Dingbat hex": "B5",
      "Unicode dec": "128926",
      "Unicode hex": "1F79E"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "182",
      "Dingbat hex": "B6",
      "Unicode dec": "11050",
      "Unicode hex": "2B2A"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "183",
      "Dingbat hex": "B7",
      "Unicode dec": "11047",
      "Unicode hex": "2B27"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "184",
      "Dingbat hex": "B8",
      "Unicode dec": "9674",
      "Unicode hex": "25CA"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "185",
      "Dingbat hex": "B9",
      "Unicode dec": "128928",
      "Unicode hex": "1F7A0"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "186",
      "Dingbat hex": "BA",
      "Unicode dec": "9686",
      "Unicode hex": "25D6"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "187",
      "Dingbat hex": "BB",
      "Unicode dec": "9687",
      "Unicode hex": "25D7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "188",
      "Dingbat hex": "BC",
      "Unicode dec": "11210",
      "Unicode hex": "2BCA"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "189",
      "Dingbat hex": "BD",
      "Unicode dec": "11211",
      "Unicode hex": "2BCB"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "190",
      "Dingbat hex": "BE",
      "Unicode dec": "11200",
      "Unicode hex": "2BC0"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "191",
      "Dingbat hex": "BF",
      "Unicode dec": "11201",
      "Unicode hex": "2BC1"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "192",
      "Dingbat hex": "C0",
      "Unicode dec": "11039",
      "Unicode hex": "2B1F"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "193",
      "Dingbat hex": "C1",
      "Unicode dec": "11202",
      "Unicode hex": "2BC2"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "194",
      "Dingbat hex": "C2",
      "Unicode dec": "11043",
      "Unicode hex": "2B23"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "195",
      "Dingbat hex": "C3",
      "Unicode dec": "11042",
      "Unicode hex": "2B22"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "196",
      "Dingbat hex": "C4",
      "Unicode dec": "11203",
      "Unicode hex": "2BC3"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "197",
      "Dingbat hex": "C5",
      "Unicode dec": "11204",
      "Unicode hex": "2BC4"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "198",
      "Dingbat hex": "C6",
      "Unicode dec": "128929",
      "Unicode hex": "1F7A1"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "199",
      "Dingbat hex": "C7",
      "Unicode dec": "128930",
      "Unicode hex": "1F7A2"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "200",
      "Dingbat hex": "C8",
      "Unicode dec": "128931",
      "Unicode hex": "1F7A3"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "201",
      "Dingbat hex": "C9",
      "Unicode dec": "128932",
      "Unicode hex": "1F7A4"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "202",
      "Dingbat hex": "CA",
      "Unicode dec": "128933",
      "Unicode hex": "1F7A5"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "203",
      "Dingbat hex": "CB",
      "Unicode dec": "128934",
      "Unicode hex": "1F7A6"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "204",
      "Dingbat hex": "CC",
      "Unicode dec": "128935",
      "Unicode hex": "1F7A7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "205",
      "Dingbat hex": "CD",
      "Unicode dec": "128936",
      "Unicode hex": "1F7A8"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "206",
      "Dingbat hex": "CE",
      "Unicode dec": "128937",
      "Unicode hex": "1F7A9"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "207",
      "Dingbat hex": "CF",
      "Unicode dec": "128938",
      "Unicode hex": "1F7AA"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "208",
      "Dingbat hex": "D0",
      "Unicode dec": "128939",
      "Unicode hex": "1F7AB"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "209",
      "Dingbat hex": "D1",
      "Unicode dec": "128940",
      "Unicode hex": "1F7AC"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "210",
      "Dingbat hex": "D2",
      "Unicode dec": "128941",
      "Unicode hex": "1F7AD"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "211",
      "Dingbat hex": "D3",
      "Unicode dec": "128942",
      "Unicode hex": "1F7AE"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "212",
      "Dingbat hex": "D4",
      "Unicode dec": "128943",
      "Unicode hex": "1F7AF"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "213",
      "Dingbat hex": "D5",
      "Unicode dec": "128944",
      "Unicode hex": "1F7B0"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "214",
      "Dingbat hex": "D6",
      "Unicode dec": "128945",
      "Unicode hex": "1F7B1"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "215",
      "Dingbat hex": "D7",
      "Unicode dec": "128946",
      "Unicode hex": "1F7B2"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "216",
      "Dingbat hex": "D8",
      "Unicode dec": "128947",
      "Unicode hex": "1F7B3"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "217",
      "Dingbat hex": "D9",
      "Unicode dec": "128948",
      "Unicode hex": "1F7B4"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "218",
      "Dingbat hex": "DA",
      "Unicode dec": "128949",
      "Unicode hex": "1F7B5"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "219",
      "Dingbat hex": "DB",
      "Unicode dec": "128950",
      "Unicode hex": "1F7B6"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "220",
      "Dingbat hex": "DC",
      "Unicode dec": "128951",
      "Unicode hex": "1F7B7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "221",
      "Dingbat hex": "DD",
      "Unicode dec": "128952",
      "Unicode hex": "1F7B8"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "222",
      "Dingbat hex": "DE",
      "Unicode dec": "128953",
      "Unicode hex": "1F7B9"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "223",
      "Dingbat hex": "DF",
      "Unicode dec": "128954",
      "Unicode hex": "1F7BA"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "224",
      "Dingbat hex": "E0",
      "Unicode dec": "128955",
      "Unicode hex": "1F7BB"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "225",
      "Dingbat hex": "E1",
      "Unicode dec": "128956",
      "Unicode hex": "1F7BC"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "226",
      "Dingbat hex": "E2",
      "Unicode dec": "128957",
      "Unicode hex": "1F7BD"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "227",
      "Dingbat hex": "E3",
      "Unicode dec": "128958",
      "Unicode hex": "1F7BE"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "228",
      "Dingbat hex": "E4",
      "Unicode dec": "128959",
      "Unicode hex": "1F7BF"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "229",
      "Dingbat hex": "E5",
      "Unicode dec": "128960",
      "Unicode hex": "1F7C0"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "230",
      "Dingbat hex": "E6",
      "Unicode dec": "128962",
      "Unicode hex": "1F7C2"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "231",
      "Dingbat hex": "E7",
      "Unicode dec": "128964",
      "Unicode hex": "1F7C4"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "232",
      "Dingbat hex": "E8",
      "Unicode dec": "128966",
      "Unicode hex": "1F7C6"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "233",
      "Dingbat hex": "E9",
      "Unicode dec": "128969",
      "Unicode hex": "1F7C9"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "234",
      "Dingbat hex": "EA",
      "Unicode dec": "128970",
      "Unicode hex": "1F7CA"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "235",
      "Dingbat hex": "EB",
      "Unicode dec": "10038",
      "Unicode hex": "2736"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "236",
      "Dingbat hex": "EC",
      "Unicode dec": "128972",
      "Unicode hex": "1F7CC"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "237",
      "Dingbat hex": "ED",
      "Unicode dec": "128974",
      "Unicode hex": "1F7CE"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "238",
      "Dingbat hex": "EE",
      "Unicode dec": "128976",
      "Unicode hex": "1F7D0"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "239",
      "Dingbat hex": "EF",
      "Unicode dec": "128978",
      "Unicode hex": "1F7D2"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "240",
      "Dingbat hex": "F0",
      "Unicode dec": "10041",
      "Unicode hex": "2739"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "241",
      "Dingbat hex": "F1",
      "Unicode dec": "128963",
      "Unicode hex": "1F7C3"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "242",
      "Dingbat hex": "F2",
      "Unicode dec": "128967",
      "Unicode hex": "1F7C7"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "243",
      "Dingbat hex": "F3",
      "Unicode dec": "10031",
      "Unicode hex": "272F"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "244",
      "Dingbat hex": "F4",
      "Unicode dec": "128973",
      "Unicode hex": "1F7CD"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "245",
      "Dingbat hex": "F5",
      "Unicode dec": "128980",
      "Unicode hex": "1F7D4"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "246",
      "Dingbat hex": "F6",
      "Unicode dec": "11212",
      "Unicode hex": "2BCC"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "247",
      "Dingbat hex": "F7",
      "Unicode dec": "11213",
      "Unicode hex": "2BCD"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "248",
      "Dingbat hex": "F8",
      "Unicode dec": "8251",
      "Unicode hex": "203B"
    }, {
      "Typeface name": "Wingdings 2",
      "Dingbat dec": "249",
      "Dingbat hex": "F9",
      "Unicode dec": "8258",
      "Unicode hex": "2042"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "32",
      "Dingbat hex": "20",
      "Unicode dec": "32",
      "Unicode hex": "20"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "33",
      "Dingbat hex": "21",
      "Unicode dec": "11104",
      "Unicode hex": "2B60"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "34",
      "Dingbat hex": "22",
      "Unicode dec": "11106",
      "Unicode hex": "2B62"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "35",
      "Dingbat hex": "23",
      "Unicode dec": "11105",
      "Unicode hex": "2B61"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "36",
      "Dingbat hex": "24",
      "Unicode dec": "11107",
      "Unicode hex": "2B63"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "37",
      "Dingbat hex": "25",
      "Unicode dec": "11110",
      "Unicode hex": "2B66"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "38",
      "Dingbat hex": "26",
      "Unicode dec": "11111",
      "Unicode hex": "2B67"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "39",
      "Dingbat hex": "27",
      "Unicode dec": "11113",
      "Unicode hex": "2B69"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "40",
      "Dingbat hex": "28",
      "Unicode dec": "11112",
      "Unicode hex": "2B68"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "41",
      "Dingbat hex": "29",
      "Unicode dec": "11120",
      "Unicode hex": "2B70"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "42",
      "Dingbat hex": "2A",
      "Unicode dec": "11122",
      "Unicode hex": "2B72"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "43",
      "Dingbat hex": "2B",
      "Unicode dec": "11121",
      "Unicode hex": "2B71"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "44",
      "Dingbat hex": "2C",
      "Unicode dec": "11123",
      "Unicode hex": "2B73"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "45",
      "Dingbat hex": "2D",
      "Unicode dec": "11126",
      "Unicode hex": "2B76"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "46",
      "Dingbat hex": "2E",
      "Unicode dec": "11128",
      "Unicode hex": "2B78"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "47",
      "Dingbat hex": "2F",
      "Unicode dec": "11131",
      "Unicode hex": "2B7B"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "48",
      "Dingbat hex": "30",
      "Unicode dec": "11133",
      "Unicode hex": "2B7D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "49",
      "Dingbat hex": "31",
      "Unicode dec": "11108",
      "Unicode hex": "2B64"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "50",
      "Dingbat hex": "32",
      "Unicode dec": "11109",
      "Unicode hex": "2B65"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "51",
      "Dingbat hex": "33",
      "Unicode dec": "11114",
      "Unicode hex": "2B6A"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "52",
      "Dingbat hex": "34",
      "Unicode dec": "11116",
      "Unicode hex": "2B6C"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "53",
      "Dingbat hex": "35",
      "Unicode dec": "11115",
      "Unicode hex": "2B6B"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "54",
      "Dingbat hex": "36",
      "Unicode dec": "11117",
      "Unicode hex": "2B6D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "55",
      "Dingbat hex": "37",
      "Unicode dec": "11085",
      "Unicode hex": "2B4D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "56",
      "Dingbat hex": "38",
      "Unicode dec": "11168",
      "Unicode hex": "2BA0"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "57",
      "Dingbat hex": "39",
      "Unicode dec": "11169",
      "Unicode hex": "2BA1"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "58",
      "Dingbat hex": "3A",
      "Unicode dec": "11170",
      "Unicode hex": "2BA2"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "59",
      "Dingbat hex": "3B",
      "Unicode dec": "11171",
      "Unicode hex": "2BA3"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "60",
      "Dingbat hex": "3C",
      "Unicode dec": "11172",
      "Unicode hex": "2BA4"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "61",
      "Dingbat hex": "3D",
      "Unicode dec": "11173",
      "Unicode hex": "2BA5"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "62",
      "Dingbat hex": "3E",
      "Unicode dec": "11174",
      "Unicode hex": "2BA6"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "63",
      "Dingbat hex": "3F",
      "Unicode dec": "11175",
      "Unicode hex": "2BA7"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "64",
      "Dingbat hex": "40",
      "Unicode dec": "11152",
      "Unicode hex": "2B90"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "65",
      "Dingbat hex": "41",
      "Unicode dec": "11153",
      "Unicode hex": "2B91"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "66",
      "Dingbat hex": "42",
      "Unicode dec": "11154",
      "Unicode hex": "2B92"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "67",
      "Dingbat hex": "43",
      "Unicode dec": "11155",
      "Unicode hex": "2B93"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "68",
      "Dingbat hex": "44",
      "Unicode dec": "11136",
      "Unicode hex": "2B80"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "69",
      "Dingbat hex": "45",
      "Unicode dec": "11139",
      "Unicode hex": "2B83"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "70",
      "Dingbat hex": "46",
      "Unicode dec": "11134",
      "Unicode hex": "2B7E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "71",
      "Dingbat hex": "47",
      "Unicode dec": "11135",
      "Unicode hex": "2B7F"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "72",
      "Dingbat hex": "48",
      "Unicode dec": "11140",
      "Unicode hex": "2B84"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "73",
      "Dingbat hex": "49",
      "Unicode dec": "11142",
      "Unicode hex": "2B86"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "74",
      "Dingbat hex": "4A",
      "Unicode dec": "11141",
      "Unicode hex": "2B85"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "75",
      "Dingbat hex": "4B",
      "Unicode dec": "11143",
      "Unicode hex": "2B87"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "76",
      "Dingbat hex": "4C",
      "Unicode dec": "11151",
      "Unicode hex": "2B8F"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "77",
      "Dingbat hex": "4D",
      "Unicode dec": "11149",
      "Unicode hex": "2B8D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "78",
      "Dingbat hex": "4E",
      "Unicode dec": "11150",
      "Unicode hex": "2B8E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "79",
      "Dingbat hex": "4F",
      "Unicode dec": "11148",
      "Unicode hex": "2B8C"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "80",
      "Dingbat hex": "50",
      "Unicode dec": "11118",
      "Unicode hex": "2B6E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "81",
      "Dingbat hex": "51",
      "Unicode dec": "11119",
      "Unicode hex": "2B6F"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "82",
      "Dingbat hex": "52",
      "Unicode dec": "9099",
      "Unicode hex": "238B"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "83",
      "Dingbat hex": "53",
      "Unicode dec": "8996",
      "Unicode hex": "2324"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "84",
      "Dingbat hex": "54",
      "Unicode dec": "8963",
      "Unicode hex": "2303"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "85",
      "Dingbat hex": "55",
      "Unicode dec": "8997",
      "Unicode hex": "2325"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "86",
      "Dingbat hex": "56",
      "Unicode dec": "9251",
      "Unicode hex": "2423"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "87",
      "Dingbat hex": "57",
      "Unicode dec": "9085",
      "Unicode hex": "237D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "88",
      "Dingbat hex": "58",
      "Unicode dec": "8682",
      "Unicode hex": "21EA"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "89",
      "Dingbat hex": "59",
      "Unicode dec": "11192",
      "Unicode hex": "2BB8"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "90",
      "Dingbat hex": "5A",
      "Unicode dec": "129184",
      "Unicode hex": "1F8A0"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "91",
      "Dingbat hex": "5B",
      "Unicode dec": "129185",
      "Unicode hex": "1F8A1"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "92",
      "Dingbat hex": "5C",
      "Unicode dec": "129186",
      "Unicode hex": "1F8A2"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "93",
      "Dingbat hex": "5D",
      "Unicode dec": "129187",
      "Unicode hex": "1F8A3"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "94",
      "Dingbat hex": "5E",
      "Unicode dec": "129188",
      "Unicode hex": "1F8A4"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "95",
      "Dingbat hex": "5F",
      "Unicode dec": "129189",
      "Unicode hex": "1F8A5"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "96",
      "Dingbat hex": "60",
      "Unicode dec": "129190",
      "Unicode hex": "1F8A6"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "97",
      "Dingbat hex": "61",
      "Unicode dec": "129191",
      "Unicode hex": "1F8A7"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "98",
      "Dingbat hex": "62",
      "Unicode dec": "129192",
      "Unicode hex": "1F8A8"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "99",
      "Dingbat hex": "63",
      "Unicode dec": "129193",
      "Unicode hex": "1F8A9"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "100",
      "Dingbat hex": "64",
      "Unicode dec": "129194",
      "Unicode hex": "1F8AA"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "101",
      "Dingbat hex": "65",
      "Unicode dec": "129195",
      "Unicode hex": "1F8AB"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "102",
      "Dingbat hex": "66",
      "Unicode dec": "129104",
      "Unicode hex": "1F850"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "103",
      "Dingbat hex": "67",
      "Unicode dec": "129106",
      "Unicode hex": "1F852"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "104",
      "Dingbat hex": "68",
      "Unicode dec": "129105",
      "Unicode hex": "1F851"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "105",
      "Dingbat hex": "69",
      "Unicode dec": "129107",
      "Unicode hex": "1F853"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "106",
      "Dingbat hex": "6A",
      "Unicode dec": "129108",
      "Unicode hex": "1F854"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "107",
      "Dingbat hex": "6B",
      "Unicode dec": "129109",
      "Unicode hex": "1F855"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "108",
      "Dingbat hex": "6C",
      "Unicode dec": "129111",
      "Unicode hex": "1F857"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "109",
      "Dingbat hex": "6D",
      "Unicode dec": "129110",
      "Unicode hex": "1F856"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "110",
      "Dingbat hex": "6E",
      "Unicode dec": "129112",
      "Unicode hex": "1F858"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "111",
      "Dingbat hex": "6F",
      "Unicode dec": "129113",
      "Unicode hex": "1F859"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "112",
      "Dingbat hex": "70",
      "Unicode dec": "9650",
      "Unicode hex": "25B2"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "113",
      "Dingbat hex": "71",
      "Unicode dec": "9660",
      "Unicode hex": "25BC"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "114",
      "Dingbat hex": "72",
      "Unicode dec": "9651",
      "Unicode hex": "25B3"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "115",
      "Dingbat hex": "73",
      "Unicode dec": "9661",
      "Unicode hex": "25BD"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "116",
      "Dingbat hex": "74",
      "Unicode dec": "9664",
      "Unicode hex": "25C0"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "117",
      "Dingbat hex": "75",
      "Unicode dec": "9654",
      "Unicode hex": "25B6"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "118",
      "Dingbat hex": "76",
      "Unicode dec": "9665",
      "Unicode hex": "25C1"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "119",
      "Dingbat hex": "77",
      "Unicode dec": "9655",
      "Unicode hex": "25B7"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "120",
      "Dingbat hex": "78",
      "Unicode dec": "9699",
      "Unicode hex": "25E3"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "121",
      "Dingbat hex": "79",
      "Unicode dec": "9698",
      "Unicode hex": "25E2"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "122",
      "Dingbat hex": "7A",
      "Unicode dec": "9700",
      "Unicode hex": "25E4"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "123",
      "Dingbat hex": "7B",
      "Unicode dec": "9701",
      "Unicode hex": "25E5"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "124",
      "Dingbat hex": "7C",
      "Unicode dec": "128896",
      "Unicode hex": "1F780"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "125",
      "Dingbat hex": "7D",
      "Unicode dec": "128898",
      "Unicode hex": "1F782"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "126",
      "Dingbat hex": "7E",
      "Unicode dec": "128897",
      "Unicode hex": "1F781"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "128",
      "Dingbat hex": "80",
      "Unicode dec": "128899",
      "Unicode hex": "1F783"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "129",
      "Dingbat hex": "81",
      "Unicode dec": "11205",
      "Unicode hex": "2BC5"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "130",
      "Dingbat hex": "82",
      "Unicode dec": "11206",
      "Unicode hex": "2BC6"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "131",
      "Dingbat hex": "83",
      "Unicode dec": "11207",
      "Unicode hex": "2BC7"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "132",
      "Dingbat hex": "84",
      "Unicode dec": "11208",
      "Unicode hex": "2BC8"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "133",
      "Dingbat hex": "85",
      "Unicode dec": "11164",
      "Unicode hex": "2B9C"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "134",
      "Dingbat hex": "86",
      "Unicode dec": "11166",
      "Unicode hex": "2B9E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "135",
      "Dingbat hex": "87",
      "Unicode dec": "11165",
      "Unicode hex": "2B9D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "136",
      "Dingbat hex": "88",
      "Unicode dec": "11167",
      "Unicode hex": "2B9F"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "137",
      "Dingbat hex": "89",
      "Unicode dec": "129040",
      "Unicode hex": "1F810"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "138",
      "Dingbat hex": "8A",
      "Unicode dec": "129042",
      "Unicode hex": "1F812"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "139",
      "Dingbat hex": "8B",
      "Unicode dec": "129041",
      "Unicode hex": "1F811"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "140",
      "Dingbat hex": "8C",
      "Unicode dec": "129043",
      "Unicode hex": "1F813"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "141",
      "Dingbat hex": "8D",
      "Unicode dec": "129044",
      "Unicode hex": "1F814"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "142",
      "Dingbat hex": "8E",
      "Unicode dec": "129046",
      "Unicode hex": "1F816"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "143",
      "Dingbat hex": "8F",
      "Unicode dec": "129045",
      "Unicode hex": "1F815"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "144",
      "Dingbat hex": "90",
      "Unicode dec": "129047",
      "Unicode hex": "1F817"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "145",
      "Dingbat hex": "91",
      "Unicode dec": "129048",
      "Unicode hex": "1F818"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "146",
      "Dingbat hex": "92",
      "Unicode dec": "129050",
      "Unicode hex": "1F81A"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "147",
      "Dingbat hex": "93",
      "Unicode dec": "129049",
      "Unicode hex": "1F819"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "148",
      "Dingbat hex": "94",
      "Unicode dec": "129051",
      "Unicode hex": "1F81B"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "149",
      "Dingbat hex": "95",
      "Unicode dec": "129052",
      "Unicode hex": "1F81C"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "150",
      "Dingbat hex": "96",
      "Unicode dec": "129054",
      "Unicode hex": "1F81E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "151",
      "Dingbat hex": "97",
      "Unicode dec": "129053",
      "Unicode hex": "1F81D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "152",
      "Dingbat hex": "98",
      "Unicode dec": "129055",
      "Unicode hex": "1F81F"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "153",
      "Dingbat hex": "99",
      "Unicode dec": "129024",
      "Unicode hex": "1F800"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "154",
      "Dingbat hex": "9A",
      "Unicode dec": "129026",
      "Unicode hex": "1F802"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "155",
      "Dingbat hex": "9B",
      "Unicode dec": "129025",
      "Unicode hex": "1F801"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "156",
      "Dingbat hex": "9C",
      "Unicode dec": "129027",
      "Unicode hex": "1F803"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "157",
      "Dingbat hex": "9D",
      "Unicode dec": "129028",
      "Unicode hex": "1F804"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "158",
      "Dingbat hex": "9E",
      "Unicode dec": "129030",
      "Unicode hex": "1F806"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "159",
      "Dingbat hex": "9F",
      "Unicode dec": "129029",
      "Unicode hex": "1F805"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "160",
      "Dingbat hex": "A0",
      "Unicode dec": "129031",
      "Unicode hex": "1F807"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "161",
      "Dingbat hex": "A1",
      "Unicode dec": "129032",
      "Unicode hex": "1F808"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "162",
      "Dingbat hex": "A2",
      "Unicode dec": "129034",
      "Unicode hex": "1F80A"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "163",
      "Dingbat hex": "A3",
      "Unicode dec": "129033",
      "Unicode hex": "1F809"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "164",
      "Dingbat hex": "A4",
      "Unicode dec": "129035",
      "Unicode hex": "1F80B"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "165",
      "Dingbat hex": "A5",
      "Unicode dec": "129056",
      "Unicode hex": "1F820"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "166",
      "Dingbat hex": "A6",
      "Unicode dec": "129058",
      "Unicode hex": "1F822"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "167",
      "Dingbat hex": "A7",
      "Unicode dec": "129060",
      "Unicode hex": "1F824"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "168",
      "Dingbat hex": "A8",
      "Unicode dec": "129062",
      "Unicode hex": "1F826"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "169",
      "Dingbat hex": "A9",
      "Unicode dec": "129064",
      "Unicode hex": "1F828"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "170",
      "Dingbat hex": "AA",
      "Unicode dec": "129066",
      "Unicode hex": "1F82A"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "171",
      "Dingbat hex": "AB",
      "Unicode dec": "129068",
      "Unicode hex": "1F82C"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "172",
      "Dingbat hex": "AC",
      "Unicode dec": "129180",
      "Unicode hex": "1F89C"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "173",
      "Dingbat hex": "AD",
      "Unicode dec": "129181",
      "Unicode hex": "1F89D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "174",
      "Dingbat hex": "AE",
      "Unicode dec": "129182",
      "Unicode hex": "1F89E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "175",
      "Dingbat hex": "AF",
      "Unicode dec": "129183",
      "Unicode hex": "1F89F"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "176",
      "Dingbat hex": "B0",
      "Unicode dec": "129070",
      "Unicode hex": "1F82E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "177",
      "Dingbat hex": "B1",
      "Unicode dec": "129072",
      "Unicode hex": "1F830"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "178",
      "Dingbat hex": "B2",
      "Unicode dec": "129074",
      "Unicode hex": "1F832"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "179",
      "Dingbat hex": "B3",
      "Unicode dec": "129076",
      "Unicode hex": "1F834"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "180",
      "Dingbat hex": "B4",
      "Unicode dec": "129078",
      "Unicode hex": "1F836"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "181",
      "Dingbat hex": "B5",
      "Unicode dec": "129080",
      "Unicode hex": "1F838"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "182",
      "Dingbat hex": "B6",
      "Unicode dec": "129082",
      "Unicode hex": "1F83A"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "183",
      "Dingbat hex": "B7",
      "Unicode dec": "129081",
      "Unicode hex": "1F839"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "184",
      "Dingbat hex": "B8",
      "Unicode dec": "129083",
      "Unicode hex": "1F83B"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "185",
      "Dingbat hex": "B9",
      "Unicode dec": "129176",
      "Unicode hex": "1F898"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "186",
      "Dingbat hex": "BA",
      "Unicode dec": "129178",
      "Unicode hex": "1F89A"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "187",
      "Dingbat hex": "BB",
      "Unicode dec": "129177",
      "Unicode hex": "1F899"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "188",
      "Dingbat hex": "BC",
      "Unicode dec": "129179",
      "Unicode hex": "1F89B"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "189",
      "Dingbat hex": "BD",
      "Unicode dec": "129084",
      "Unicode hex": "1F83C"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "190",
      "Dingbat hex": "BE",
      "Unicode dec": "129086",
      "Unicode hex": "1F83E"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "191",
      "Dingbat hex": "BF",
      "Unicode dec": "129085",
      "Unicode hex": "1F83D"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "192",
      "Dingbat hex": "C0",
      "Unicode dec": "129087",
      "Unicode hex": "1F83F"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "193",
      "Dingbat hex": "C1",
      "Unicode dec": "129088",
      "Unicode hex": "1F840"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "194",
      "Dingbat hex": "C2",
      "Unicode dec": "129090",
      "Unicode hex": "1F842"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "195",
      "Dingbat hex": "C3",
      "Unicode dec": "129089",
      "Unicode hex": "1F841"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "196",
      "Dingbat hex": "C4",
      "Unicode dec": "129091",
      "Unicode hex": "1F843"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "197",
      "Dingbat hex": "C5",
      "Unicode dec": "129092",
      "Unicode hex": "1F844"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "198",
      "Dingbat hex": "C6",
      "Unicode dec": "129094",
      "Unicode hex": "1F846"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "199",
      "Dingbat hex": "C7",
      "Unicode dec": "129093",
      "Unicode hex": "1F845"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "200",
      "Dingbat hex": "C8",
      "Unicode dec": "129095",
      "Unicode hex": "1F847"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "201",
      "Dingbat hex": "C9",
      "Unicode dec": "11176",
      "Unicode hex": "2BA8"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "202",
      "Dingbat hex": "CA",
      "Unicode dec": "11177",
      "Unicode hex": "2BA9"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "203",
      "Dingbat hex": "CB",
      "Unicode dec": "11178",
      "Unicode hex": "2BAA"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "204",
      "Dingbat hex": "CC",
      "Unicode dec": "11179",
      "Unicode hex": "2BAB"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "205",
      "Dingbat hex": "CD",
      "Unicode dec": "11180",
      "Unicode hex": "2BAC"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "206",
      "Dingbat hex": "CE",
      "Unicode dec": "11181",
      "Unicode hex": "2BAD"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "207",
      "Dingbat hex": "CF",
      "Unicode dec": "11182",
      "Unicode hex": "2BAE"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "208",
      "Dingbat hex": "D0",
      "Unicode dec": "11183",
      "Unicode hex": "2BAF"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "209",
      "Dingbat hex": "D1",
      "Unicode dec": "129120",
      "Unicode hex": "1F860"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "210",
      "Dingbat hex": "D2",
      "Unicode dec": "129122",
      "Unicode hex": "1F862"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "211",
      "Dingbat hex": "D3",
      "Unicode dec": "129121",
      "Unicode hex": "1F861"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "212",
      "Dingbat hex": "D4",
      "Unicode dec": "129123",
      "Unicode hex": "1F863"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "213",
      "Dingbat hex": "D5",
      "Unicode dec": "129124",
      "Unicode hex": "1F864"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "214",
      "Dingbat hex": "D6",
      "Unicode dec": "129125",
      "Unicode hex": "1F865"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "215",
      "Dingbat hex": "D7",
      "Unicode dec": "129127",
      "Unicode hex": "1F867"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "216",
      "Dingbat hex": "D8",
      "Unicode dec": "129126",
      "Unicode hex": "1F866"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "217",
      "Dingbat hex": "D9",
      "Unicode dec": "129136",
      "Unicode hex": "1F870"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "218",
      "Dingbat hex": "DA",
      "Unicode dec": "129138",
      "Unicode hex": "1F872"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "219",
      "Dingbat hex": "DB",
      "Unicode dec": "129137",
      "Unicode hex": "1F871"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "220",
      "Dingbat hex": "DC",
      "Unicode dec": "129139",
      "Unicode hex": "1F873"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "221",
      "Dingbat hex": "DD",
      "Unicode dec": "129140",
      "Unicode hex": "1F874"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "222",
      "Dingbat hex": "DE",
      "Unicode dec": "129141",
      "Unicode hex": "1F875"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "223",
      "Dingbat hex": "DF",
      "Unicode dec": "129143",
      "Unicode hex": "1F877"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "224",
      "Dingbat hex": "E0",
      "Unicode dec": "129142",
      "Unicode hex": "1F876"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "225",
      "Dingbat hex": "E1",
      "Unicode dec": "129152",
      "Unicode hex": "1F880"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "226",
      "Dingbat hex": "E2",
      "Unicode dec": "129154",
      "Unicode hex": "1F882"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "227",
      "Dingbat hex": "E3",
      "Unicode dec": "129153",
      "Unicode hex": "1F881"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "228",
      "Dingbat hex": "E4",
      "Unicode dec": "129155",
      "Unicode hex": "1F883"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "229",
      "Dingbat hex": "E5",
      "Unicode dec": "129156",
      "Unicode hex": "1F884"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "230",
      "Dingbat hex": "E6",
      "Unicode dec": "129157",
      "Unicode hex": "1F885"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "231",
      "Dingbat hex": "E7",
      "Unicode dec": "129159",
      "Unicode hex": "1F887"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "232",
      "Dingbat hex": "E8",
      "Unicode dec": "129158",
      "Unicode hex": "1F886"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "233",
      "Dingbat hex": "E9",
      "Unicode dec": "129168",
      "Unicode hex": "1F890"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "234",
      "Dingbat hex": "EA",
      "Unicode dec": "129170",
      "Unicode hex": "1F892"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "235",
      "Dingbat hex": "EB",
      "Unicode dec": "129169",
      "Unicode hex": "1F891"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "236",
      "Dingbat hex": "EC",
      "Unicode dec": "129171",
      "Unicode hex": "1F893"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "237",
      "Dingbat hex": "ED",
      "Unicode dec": "129172",
      "Unicode hex": "1F894"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "238",
      "Dingbat hex": "EE",
      "Unicode dec": "129174",
      "Unicode hex": "1F896"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "239",
      "Dingbat hex": "EF",
      "Unicode dec": "129173",
      "Unicode hex": "1F895"
    }, {
      "Typeface name": "Wingdings 3",
      "Dingbat dec": "240",
      "Dingbat hex": "F0",
      "Unicode dec": "129175",
      "Unicode hex": "1F897"
    }];
    exports2.default = dingbats;
  }
});

// node_modules/dingbat-to-unicode/dist/index.js
var require_dist = __commonJS({
  "node_modules/dingbat-to-unicode/dist/index.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : {
        "default": mod
      };
    };
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.hex = exports2.dec = exports2.codePoint = void 0;
    var dingbats_1 = __importDefault(require_dingbats());
    var dingbatsByCodePoint = {};
    var fromCodePoint = String.fromCodePoint ? String.fromCodePoint : fromCodePointPolyfill;
    for (_i = 0, dingbats_2 = dingbats_1.default; _i < dingbats_2.length; _i++) {
      dingbat = dingbats_2[_i];
      codePoint_1 = parseInt(dingbat["Unicode dec"], 10);
      scalarValue = {
        codePoint: codePoint_1,
        string: fromCodePoint(codePoint_1)
      };
      dingbatsByCodePoint[dingbat["Typeface name"].toUpperCase() + "_" + dingbat["Dingbat dec"]] = scalarValue;
    }
    var dingbat;
    var codePoint_1;
    var scalarValue;
    var _i;
    var dingbats_2;
    function codePoint(typeface, codePoint2) {
      return dingbatsByCodePoint[typeface.toUpperCase() + "_" + codePoint2];
    }
    exports2.codePoint = codePoint;
    function dec(typeface, dec2) {
      return codePoint(typeface, parseInt(dec2, 10));
    }
    exports2.dec = dec;
    function hex(typeface, hex2) {
      return codePoint(typeface, parseInt(hex2, 16));
    }
    exports2.hex = hex;
    function fromCodePointPolyfill(codePoint2) {
      if (codePoint2 <= 65535) {
        return String.fromCharCode(codePoint2);
      } else {
        var highSurrogate = Math.floor((codePoint2 - 65536) / 1024) + 55296;
        var lowSurrogate = (codePoint2 - 65536) % 1024 + 56320;
        return String.fromCharCode(highSurrogate, lowSurrogate);
      }
    }
  }
});

// node_modules/mammoth/lib/docx/uris.js
var require_uris = __commonJS({
  "node_modules/mammoth/lib/docx/uris.js"(exports2) {
    exports2.uriToZipEntryName = uriToZipEntryName;
    exports2.replaceFragment = replaceFragment;
    function uriToZipEntryName(base, uri) {
      if (uri.charAt(0) === "/") {
        return uri.substr(1);
      } else {
        return base + "/" + uri;
      }
    }
    function replaceFragment(uri, fragment) {
      var hashIndex = uri.indexOf("#");
      if (hashIndex !== -1) {
        uri = uri.substring(0, hashIndex);
      }
      return uri + "#" + fragment;
    }
  }
});

// node_modules/mammoth/lib/docx/body-reader.js
var require_body_reader = __commonJS({
  "node_modules/mammoth/lib/docx/body-reader.js"(exports2) {
    exports2.createBodyReader = createBodyReader;
    exports2._readNumberingProperties = readNumberingProperties;
    var dingbatToUnicode = require_dist();
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var documents = require_documents();
    var Result = require_results().Result;
    var warning = require_results().warning;
    var xml = require_xml();
    var uris = require_uris();
    function createBodyReader(options) {
      return {
        readXmlElement: function(element) {
          return new BodyReader(options).readXmlElement(element);
        },
        readXmlElements: function(elements) {
          return new BodyReader(options).readXmlElements(elements);
        }
      };
    }
    function BodyReader(options) {
      var complexFieldStack = [];
      var currentInstrText = [];
      var deletedParagraphContents = [];
      var relationships = options.relationships;
      var contentTypes = options.contentTypes;
      var docxFile = options.docxFile;
      var files = options.files;
      var numbering = options.numbering;
      var styles = options.styles;
      function readXmlElements(elements) {
        var results = elements.map(readXmlElement);
        return combineResults(results);
      }
      function readXmlElement(element) {
        if (element.type === "element") {
          var handler = xmlElementReaders[element.name];
          if (handler) {
            return handler(element);
          } else if (!Object.prototype.hasOwnProperty.call(ignoreElements, element.name)) {
            var message = warning("An unrecognised element was ignored: " + element.name);
            return emptyResultWithMessages([message]);
          }
        }
        return emptyResult();
      }
      function readParagraphProperties(element) {
        return readParagraphStyle(element).map(function(style) {
          return {
            type: "paragraphProperties",
            styleId: style.styleId,
            styleName: style.name,
            alignment: element.firstOrEmpty("w:jc").attributes["w:val"],
            numbering: readNumberingProperties(style.styleId, element.firstOrEmpty("w:numPr"), numbering),
            indent: readParagraphIndent(element.firstOrEmpty("w:ind"))
          };
        });
      }
      function readParagraphIndent(element) {
        return {
          start: element.attributes["w:start"] || element.attributes["w:left"],
          end: element.attributes["w:end"] || element.attributes["w:right"],
          firstLine: element.attributes["w:firstLine"],
          hanging: element.attributes["w:hanging"]
        };
      }
      function readRunProperties(element) {
        return readRunStyle(element).map(function(style) {
          var fontSizeString = element.firstOrEmpty("w:sz").attributes["w:val"];
          var fontSize = /^[0-9]+$/.test(fontSizeString) ? parseInt(fontSizeString, 10) / 2 : null;
          return {
            type: "runProperties",
            styleId: style.styleId,
            styleName: style.name,
            verticalAlignment: element.firstOrEmpty("w:vertAlign").attributes["w:val"],
            font: element.firstOrEmpty("w:rFonts").attributes["w:ascii"],
            fontSize,
            isBold: readBooleanElement(element.first("w:b")),
            isUnderline: readUnderline(element.first("w:u")),
            isItalic: readBooleanElement(element.first("w:i")),
            isStrikethrough: readBooleanElement(element.first("w:strike")),
            isAllCaps: readBooleanElement(element.first("w:caps")),
            isSmallCaps: readBooleanElement(element.first("w:smallCaps")),
            highlight: readHighlightValue(element.firstOrEmpty("w:highlight").attributes["w:val"])
          };
        });
      }
      function readUnderline(element) {
        if (element) {
          var value = element.attributes["w:val"];
          return value !== void 0 && value !== "false" && value !== "0" && value !== "none";
        } else {
          return false;
        }
      }
      function readBooleanElement(element) {
        if (element) {
          var value = element.attributes["w:val"];
          return value !== "false" && value !== "0";
        } else {
          return false;
        }
      }
      function readBooleanAttributeValue(value) {
        return value !== "false" && value !== "0";
      }
      function readHighlightValue(value) {
        if (!value || value === "none") {
          return null;
        } else {
          return value;
        }
      }
      function readParagraphStyle(element) {
        return readStyle(element, "w:pStyle", "Paragraph", styles.findParagraphStyleById);
      }
      function readRunStyle(element) {
        return readStyle(element, "w:rStyle", "Run", styles.findCharacterStyleById);
      }
      function readTableStyle(element) {
        return readStyle(element, "w:tblStyle", "Table", styles.findTableStyleById);
      }
      function readStyle(element, styleTagName, styleType, findStyleById) {
        var messages = [];
        var styleElement = element.first(styleTagName);
        var styleId = null;
        var name = null;
        if (styleElement) {
          styleId = styleElement.attributes["w:val"];
          if (styleId) {
            var style = findStyleById(styleId);
            if (style) {
              name = style.name;
            } else {
              messages.push(undefinedStyleWarning(styleType, styleId));
            }
          }
        }
        return elementResultWithMessages({
          styleId,
          name
        }, messages);
      }
      function readFldChar(element) {
        var type = element.attributes["w:fldCharType"];
        if (type === "begin") {
          complexFieldStack.push({
            type: "begin",
            fldChar: element
          });
          currentInstrText = [];
        } else if (type === "end") {
          var complexFieldEnd = complexFieldStack.pop();
          if (complexFieldEnd.type === "begin") {
            complexFieldEnd = parseCurrentInstrText(complexFieldEnd);
          }
          if (complexFieldEnd.type === "checkbox") {
            return elementResult(documents.checkbox({
              checked: complexFieldEnd.checked
            }));
          }
        } else if (type === "separate") {
          var complexFieldSeparate = complexFieldStack.pop();
          var complexField = parseCurrentInstrText(complexFieldSeparate);
          complexFieldStack.push(complexField);
        }
        return emptyResult();
      }
      function currentHyperlinkOptions() {
        var topHyperlink = _3.last(complexFieldStack.filter(function(complexField) {
          return complexField.type === "hyperlink";
        }));
        return topHyperlink ? topHyperlink.options : null;
      }
      function parseCurrentInstrText(complexField) {
        return parseInstrText(currentInstrText.join(""), complexField.type === "begin" ? complexField.fldChar : xml.emptyElement);
      }
      function parseInstrText(instrText, fldChar) {
        var externalLinkResult = /\s*HYPERLINK "(.*)"/.exec(instrText);
        if (externalLinkResult) {
          return {
            type: "hyperlink",
            options: {
              href: externalLinkResult[1]
            }
          };
        }
        var internalLinkResult = /\s*HYPERLINK\s+\\l\s+"(.*)"/.exec(instrText);
        if (internalLinkResult) {
          return {
            type: "hyperlink",
            options: {
              anchor: internalLinkResult[1]
            }
          };
        }
        var checkboxResult = /\s*FORMCHECKBOX\s*/.exec(instrText);
        if (checkboxResult) {
          var checkboxElement = fldChar.firstOrEmpty("w:ffData").firstOrEmpty("w:checkBox");
          var checkedElement = checkboxElement.first("w:checked");
          var checked = checkedElement == null ? readBooleanElement(checkboxElement.first("w:default")) : readBooleanElement(checkedElement);
          return {
            type: "checkbox",
            checked
          };
        }
        return {
          type: "unknown"
        };
      }
      function readInstrText(element) {
        currentInstrText.push(element.text());
        return emptyResult();
      }
      function readSymbol(element) {
        var font = element.attributes["w:font"];
        var char = element.attributes["w:char"];
        var unicodeCharacter = dingbatToUnicode.hex(font, char);
        if (unicodeCharacter == null && /^F0..$/.test(char)) {
          unicodeCharacter = dingbatToUnicode.hex(font, char.substring(2));
        }
        if (unicodeCharacter == null) {
          return emptyResultWithMessages([warning("A w:sym element with an unsupported character was ignored: char " + char + " in font " + font)]);
        } else {
          return elementResult(new documents.Text(unicodeCharacter.string));
        }
      }
      function noteReferenceReader(noteType) {
        return function(element) {
          var noteId = element.attributes["w:id"];
          return elementResult(new documents.NoteReference({
            noteType,
            noteId
          }));
        };
      }
      function readCommentReference(element) {
        return elementResult(documents.commentReference({
          commentId: element.attributes["w:id"]
        }));
      }
      function readChildElements(element) {
        return readXmlElements(element.children);
      }
      var xmlElementReaders = {
        "w:p": function(element) {
          var paragraphPropertiesElement = element.firstOrEmpty("w:pPr");
          var isDeleted = !!paragraphPropertiesElement.firstOrEmpty("w:rPr").first("w:del");
          if (isDeleted) {
            element.children.forEach(function(child) {
              deletedParagraphContents.push(child);
            });
            return emptyResult();
          } else {
            var childrenXml = element.children;
            if (deletedParagraphContents.length > 0) {
              childrenXml = deletedParagraphContents.concat(childrenXml);
              deletedParagraphContents = [];
            }
            return ReadResult.map(readParagraphProperties(paragraphPropertiesElement), readXmlElements(childrenXml), function(properties, children) {
              return new documents.Paragraph(children, properties);
            }).insertExtra();
          }
        },
        "w:r": function(element) {
          return ReadResult.map(readRunProperties(element.firstOrEmpty("w:rPr")), readXmlElements(element.children), function(properties, children) {
            var hyperlinkOptions = currentHyperlinkOptions();
            if (hyperlinkOptions !== null) {
              children = [new documents.Hyperlink(children, hyperlinkOptions)];
            }
            return new documents.Run(children, properties);
          });
        },
        "w:fldChar": readFldChar,
        "w:instrText": readInstrText,
        "w:t": function(element) {
          return elementResult(new documents.Text(element.text()));
        },
        "w:tab": function(element) {
          return elementResult(new documents.Tab());
        },
        "w:noBreakHyphen": function() {
          return elementResult(new documents.Text("‑"));
        },
        "w:softHyphen": function(element) {
          return elementResult(new documents.Text("­"));
        },
        "w:sym": readSymbol,
        "w:hyperlink": function(element) {
          var relationshipId = element.attributes["r:id"];
          var anchor = element.attributes["w:anchor"];
          return readXmlElements(element.children).map(function(children) {
            function create2(options2) {
              var targetFrame = element.attributes["w:tgtFrame"] || null;
              return new documents.Hyperlink(children, _3.extend({
                targetFrame
              }, options2));
            }
            if (relationshipId) {
              var href = relationships.findTargetByRelationshipId(relationshipId);
              if (anchor) {
                href = uris.replaceFragment(href, anchor);
              }
              return create2({
                href
              });
            } else if (anchor) {
              return create2({
                anchor
              });
            } else {
              return children;
            }
          });
        },
        "w:tbl": readTable,
        "w:tr": readTableRow,
        "w:tc": readTableCell,
        "w:footnoteReference": noteReferenceReader("footnote"),
        "w:endnoteReference": noteReferenceReader("endnote"),
        "w:commentReference": readCommentReference,
        "w:br": function(element) {
          var breakType = element.attributes["w:type"];
          if (breakType == null || breakType === "textWrapping") {
            return elementResult(documents.lineBreak);
          } else if (breakType === "page") {
            return elementResult(documents.pageBreak);
          } else if (breakType === "column") {
            return elementResult(documents.columnBreak);
          } else {
            return emptyResultWithMessages([warning("Unsupported break type: " + breakType)]);
          }
        },
        "w:bookmarkStart": function(element) {
          var name = element.attributes["w:name"];
          if (name === "_GoBack") {
            return emptyResult();
          } else {
            return elementResult(new documents.BookmarkStart({
              name
            }));
          }
        },
        "mc:AlternateContent": function(element) {
          return readChildElements(element.firstOrEmpty("mc:Fallback"));
        },
        "w:sdt": function(element) {
          var checkbox = element.firstOrEmpty("w:sdtPr").first("wordml:checkbox");
          if (checkbox) {
            var checkedElement = checkbox.first("wordml:checked");
            var isChecked = !!checkedElement && readBooleanAttributeValue(checkedElement.attributes["wordml:val"]);
            return elementResult(documents.checkbox({
              checked: isChecked
            }));
          } else {
            return readXmlElements(element.firstOrEmpty("w:sdtContent").children);
          }
        },
        "w:ins": readChildElements,
        "w:object": readChildElements,
        "w:smartTag": readChildElements,
        "w:drawing": readChildElements,
        "w:pict": function(element) {
          return readChildElements(element).toExtra();
        },
        "v:roundrect": readChildElements,
        "v:shape": readChildElements,
        "v:textbox": readChildElements,
        "w:txbxContent": readChildElements,
        "wp:inline": readDrawingElement,
        "wp:anchor": readDrawingElement,
        "v:imagedata": readImageData,
        "v:group": readChildElements,
        "v:rect": readChildElements
      };
      return {
        readXmlElement,
        readXmlElements
      };
      function readTable(element) {
        var propertiesResult = readTableProperties(element.firstOrEmpty("w:tblPr"));
        return readXmlElements(element.children).flatMap(calculateRowSpans).flatMap(function(children) {
          return propertiesResult.map(function(properties) {
            return documents.Table(children, properties);
          });
        });
      }
      function readTableProperties(element) {
        return readTableStyle(element).map(function(style) {
          return {
            styleId: style.styleId,
            styleName: style.name
          };
        });
      }
      function readTableRow(element) {
        var properties = element.firstOrEmpty("w:trPr");
        var isHeader = !!properties.first("w:tblHeader");
        return readXmlElements(element.children).map(function(children) {
          return documents.TableRow(children, {
            isHeader
          });
        });
      }
      function readTableCell(element) {
        return readXmlElements(element.children).map(function(children) {
          var properties = element.firstOrEmpty("w:tcPr");
          var gridSpan = properties.firstOrEmpty("w:gridSpan").attributes["w:val"];
          var colSpan = gridSpan ? parseInt(gridSpan, 10) : 1;
          var cell = documents.TableCell(children, {
            colSpan
          });
          cell._vMerge = readVMerge(properties);
          return cell;
        });
      }
      function readVMerge(properties) {
        var element = properties.first("w:vMerge");
        if (element) {
          var val = element.attributes["w:val"];
          return val === "continue" || !val;
        } else {
          return null;
        }
      }
      function calculateRowSpans(rows) {
        var unexpectedNonRows = _3.any(rows, function(row) {
          return row.type !== documents.types.tableRow;
        });
        if (unexpectedNonRows) {
          return elementResultWithMessages(rows, [warning("unexpected non-row element in table, cell merging may be incorrect")]);
        }
        var unexpectedNonCells = _3.any(rows, function(row) {
          return _3.any(row.children, function(cell) {
            return cell.type !== documents.types.tableCell;
          });
        });
        if (unexpectedNonCells) {
          return elementResultWithMessages(rows, [warning("unexpected non-cell element in table row, cell merging may be incorrect")]);
        }
        var columns = {};
        rows.forEach(function(row) {
          var cellIndex = 0;
          row.children.forEach(function(cell) {
            if (cell._vMerge && columns[cellIndex]) {
              columns[cellIndex].rowSpan++;
            } else {
              columns[cellIndex] = cell;
              cell._vMerge = false;
            }
            cellIndex += cell.colSpan;
          });
        });
        rows.forEach(function(row) {
          row.children = row.children.filter(function(cell) {
            return !cell._vMerge;
          });
          row.children.forEach(function(cell) {
            delete cell._vMerge;
          });
        });
        return elementResult(rows);
      }
      function readDrawingElement(element) {
        var blips = element.getElementsByTagName("a:graphic").getElementsByTagName("a:graphicData").getElementsByTagName("pic:pic").getElementsByTagName("pic:blipFill").getElementsByTagName("a:blip");
        return combineResults(blips.map(readBlip.bind(null, element)));
      }
      function readBlip(element, blip) {
        var properties = element.first("wp:docPr").attributes;
        var altText = isBlank(properties.descr) ? properties.title : properties.descr;
        var blipImageFile = findBlipImageFile(blip);
        if (blipImageFile === null) {
          return emptyResultWithMessages([warning("Could not find image file for a:blip element")]);
        } else {
          return readImage(blipImageFile, altText);
        }
      }
      function isBlank(value) {
        return value == null || /^\s*$/.test(value);
      }
      function findBlipImageFile(blip) {
        var embedRelationshipId = blip.attributes["r:embed"];
        var linkRelationshipId = blip.attributes["r:link"];
        if (embedRelationshipId) {
          return findEmbeddedImageFile(embedRelationshipId);
        } else if (linkRelationshipId) {
          var imagePath = relationships.findTargetByRelationshipId(linkRelationshipId);
          return {
            path: imagePath,
            read: files.read.bind(files, imagePath)
          };
        } else {
          return null;
        }
      }
      function readImageData(element) {
        var relationshipId = element.attributes["r:id"];
        if (relationshipId) {
          return readImage(findEmbeddedImageFile(relationshipId), element.attributes["o:title"]);
        } else {
          return emptyResultWithMessages([warning("A v:imagedata element without a relationship ID was ignored")]);
        }
      }
      function findEmbeddedImageFile(relationshipId) {
        var path = uris.uriToZipEntryName("word", relationships.findTargetByRelationshipId(relationshipId));
        return {
          path,
          read: docxFile.read.bind(docxFile, path)
        };
      }
      function readImage(imageFile, altText) {
        var contentType = contentTypes.findContentType(imageFile.path);
        var image = documents.Image({
          readImage: imageFile.read,
          altText,
          contentType
        });
        var warnings = supportedImageTypes[contentType] ? [] : warning("Image of type " + contentType + " is unlikely to display in web browsers");
        return elementResultWithMessages(image, warnings);
      }
      function undefinedStyleWarning(type, styleId) {
        return warning(type + " style with ID " + styleId + " was referenced but not defined in the document");
      }
    }
    function readNumberingProperties(styleId, element, numbering) {
      var level = element.firstOrEmpty("w:ilvl").attributes["w:val"];
      var numId = element.firstOrEmpty("w:numId").attributes["w:val"];
      if (level !== void 0 && numId !== void 0) {
        return numbering.findLevel(numId, level);
      }
      if (styleId != null) {
        var levelByStyleId = numbering.findLevelByParagraphStyleId(styleId);
        if (levelByStyleId != null) {
          return levelByStyleId;
        }
      }
      return null;
    }
    var supportedImageTypes = {
      "image/png": true,
      "image/gif": true,
      "image/jpeg": true,
      "image/svg+xml": true,
      "image/tiff": true
    };
    var ignoreElements = {
      "office-word:wrap": true,
      "v:shadow": true,
      "v:shapetype": true,
      "w:annotationRef": true,
      "w:bookmarkEnd": true,
      "w:sectPr": true,
      "w:proofErr": true,
      "w:lastRenderedPageBreak": true,
      "w:commentRangeStart": true,
      "w:commentRangeEnd": true,
      "w:del": true,
      "w:footnoteRef": true,
      "w:endnoteRef": true,
      "w:pPr": true,
      "w:rPr": true,
      "w:tblPr": true,
      "w:tblGrid": true,
      "w:trPr": true,
      "w:tcPr": true
    };
    function emptyResultWithMessages(messages) {
      return new ReadResult(null, null, messages);
    }
    function emptyResult() {
      return new ReadResult(null);
    }
    function elementResult(element) {
      return new ReadResult(element);
    }
    function elementResultWithMessages(element, messages) {
      return new ReadResult(element, null, messages);
    }
    function ReadResult(element, extra, messages) {
      this.value = element || [];
      this.extra = extra || [];
      this._result = new Result({
        element: this.value,
        extra
      }, messages);
      this.messages = this._result.messages;
    }
    ReadResult.prototype.toExtra = function() {
      return new ReadResult(null, joinElements(this.extra, this.value), this.messages);
    };
    ReadResult.prototype.insertExtra = function() {
      var extra = this.extra;
      if (extra && extra.length) {
        return new ReadResult(joinElements(this.value, extra), null, this.messages);
      } else {
        return this;
      }
    };
    ReadResult.prototype.map = function(func) {
      var result2 = this._result.map(function(value) {
        return func(value.element);
      });
      return new ReadResult(result2.value, this.extra, result2.messages);
    };
    ReadResult.prototype.flatMap = function(func) {
      var result2 = this._result.flatMap(function(value) {
        return func(value.element)._result;
      });
      return new ReadResult(result2.value.element, joinElements(this.extra, result2.value.extra), result2.messages);
    };
    ReadResult.map = function(first2, second, func) {
      return new ReadResult(func(first2.value, second.value), joinElements(first2.extra, second.extra), first2.messages.concat(second.messages));
    };
    function combineResults(results) {
      var result2 = Result.combine(_3.pluck(results, "_result"));
      return new ReadResult(_3.flatten(_3.pluck(result2.value, "element")), _3.filter(_3.flatten(_3.pluck(result2.value, "extra")), identity2), result2.messages);
    }
    function joinElements(first2, second) {
      return _3.flatten([first2, second]);
    }
    function identity2(value) {
      return value;
    }
  }
});

// node_modules/mammoth/lib/docx/document-xml-reader.js
var require_document_xml_reader = __commonJS({
  "node_modules/mammoth/lib/docx/document-xml-reader.js"(exports2) {
    exports2.DocumentXmlReader = DocumentXmlReader;
    var documents = require_documents();
    var Result = require_results().Result;
    function DocumentXmlReader(options) {
      var bodyReader = options.bodyReader;
      function convertXmlToDocument(element) {
        var body = element.first("w:body");
        if (body == null) {
          throw new Error("Could not find the body element: are you sure this is a docx file?");
        }
        var result2 = bodyReader.readXmlElements(body.children).map(function(children) {
          return new documents.Document(children, {
            notes: options.notes,
            comments: options.comments
          });
        });
        return new Result(result2.value, result2.messages);
      }
      return {
        convertXmlToDocument
      };
    }
  }
});

// node_modules/mammoth/lib/docx/relationships-reader.js
var require_relationships_reader = __commonJS({
  "node_modules/mammoth/lib/docx/relationships-reader.js"(exports2) {
    exports2.readRelationships = readRelationships;
    exports2.defaultValue = new Relationships([]);
    exports2.Relationships = Relationships;
    function readRelationships(element) {
      var relationships = [];
      element.children.forEach(function(child) {
        if (child.name === "relationships:Relationship") {
          var relationship = {
            relationshipId: child.attributes.Id,
            target: child.attributes.Target,
            type: child.attributes.Type
          };
          relationships.push(relationship);
        }
      });
      return new Relationships(relationships);
    }
    function Relationships(relationships) {
      var targetsByRelationshipId = {};
      relationships.forEach(function(relationship) {
        targetsByRelationshipId[relationship.relationshipId] = relationship.target;
      });
      var targetsByType = {};
      relationships.forEach(function(relationship) {
        if (!targetsByType[relationship.type]) {
          targetsByType[relationship.type] = [];
        }
        targetsByType[relationship.type].push(relationship.target);
      });
      return {
        findTargetByRelationshipId: function(relationshipId) {
          return targetsByRelationshipId[relationshipId];
        },
        findTargetsByType: function(type) {
          return targetsByType[type] || [];
        }
      };
    }
  }
});

// node_modules/mammoth/lib/docx/content-types-reader.js
var require_content_types_reader = __commonJS({
  "node_modules/mammoth/lib/docx/content-types-reader.js"(exports2) {
    exports2.readContentTypesFromXml = readContentTypesFromXml;
    var fallbackContentTypes = {
      "png": "png",
      "gif": "gif",
      "jpeg": "jpeg",
      "jpg": "jpeg",
      "tif": "tiff",
      "tiff": "tiff",
      "bmp": "bmp"
    };
    exports2.defaultContentTypes = contentTypes({}, {});
    function readContentTypesFromXml(element) {
      var extensionDefaults = {};
      var overrides = {};
      element.children.forEach(function(child) {
        if (child.name === "content-types:Default") {
          extensionDefaults[child.attributes.Extension] = child.attributes.ContentType;
        }
        if (child.name === "content-types:Override") {
          var name = child.attributes.PartName;
          if (name.charAt(0) === "/") {
            name = name.substring(1);
          }
          overrides[name] = child.attributes.ContentType;
        }
      });
      return contentTypes(overrides, extensionDefaults);
    }
    function contentTypes(overrides, extensionDefaults) {
      return {
        findContentType: function(path) {
          var overrideContentType = overrides[path];
          if (overrideContentType) {
            return overrideContentType;
          } else {
            var pathParts = path.split(".");
            var extension = pathParts[pathParts.length - 1];
            if (extensionDefaults.hasOwnProperty(extension)) {
              return extensionDefaults[extension];
            } else {
              var fallback = fallbackContentTypes[extension.toLowerCase()];
              if (fallback) {
                return "image/" + fallback;
              } else {
                return null;
              }
            }
          }
        }
      };
    }
  }
});

// node_modules/mammoth/lib/docx/numbering-xml.js
var require_numbering_xml = __commonJS({
  "node_modules/mammoth/lib/docx/numbering-xml.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    exports2.readNumberingXml = readNumberingXml;
    exports2.Numbering = Numbering;
    exports2.defaultNumbering = new Numbering({}, {});
    function Numbering(nums, abstractNums, styles) {
      var allLevels = _3.flatten(_3.values(abstractNums).map(function(abstractNum) {
        return _3.values(abstractNum.levels);
      }));
      var levelsByParagraphStyleId = _3.indexBy(allLevels.filter(function(level) {
        return level.paragraphStyleId != null;
      }), "paragraphStyleId");
      function findLevel(numId, level) {
        var num = nums[numId];
        if (num) {
          var abstractNum = abstractNums[num.abstractNumId];
          if (!abstractNum) {
            return null;
          } else if (abstractNum.numStyleLink == null) {
            return abstractNums[num.abstractNumId].levels[level];
          } else {
            var style = styles.findNumberingStyleById(abstractNum.numStyleLink);
            return findLevel(style.numId, level);
          }
        } else {
          return null;
        }
      }
      function findLevelByParagraphStyleId(styleId) {
        return levelsByParagraphStyleId[styleId] || null;
      }
      return {
        findLevel,
        findLevelByParagraphStyleId
      };
    }
    function readNumberingXml(root2, options) {
      if (!options || !options.styles) {
        throw new Error("styles is missing");
      }
      var abstractNums = readAbstractNums(root2);
      var nums = readNums(root2, abstractNums);
      return new Numbering(nums, abstractNums, options.styles);
    }
    function readAbstractNums(root2) {
      var abstractNums = {};
      root2.getElementsByTagName("w:abstractNum").forEach(function(element) {
        var id = element.attributes["w:abstractNumId"];
        abstractNums[id] = readAbstractNum(element);
      });
      return abstractNums;
    }
    function readAbstractNum(element) {
      var levels = {};
      element.getElementsByTagName("w:lvl").forEach(function(levelElement) {
        var levelIndex = levelElement.attributes["w:ilvl"];
        var numFmt = levelElement.firstOrEmpty("w:numFmt").attributes["w:val"];
        var paragraphStyleId = levelElement.firstOrEmpty("w:pStyle").attributes["w:val"];
        levels[levelIndex] = {
          isOrdered: numFmt !== "bullet",
          level: levelIndex,
          paragraphStyleId
        };
      });
      var numStyleLink = element.firstOrEmpty("w:numStyleLink").attributes["w:val"];
      return {
        levels,
        numStyleLink
      };
    }
    function readNums(root2) {
      var nums = {};
      root2.getElementsByTagName("w:num").forEach(function(element) {
        var numId = element.attributes["w:numId"];
        var abstractNumId = element.first("w:abstractNumId").attributes["w:val"];
        nums[numId] = {
          abstractNumId
        };
      });
      return nums;
    }
  }
});

// node_modules/mammoth/lib/docx/styles-reader.js
var require_styles_reader = __commonJS({
  "node_modules/mammoth/lib/docx/styles-reader.js"(exports2) {
    exports2.readStylesXml = readStylesXml;
    exports2.Styles = Styles;
    exports2.defaultStyles = new Styles({}, {});
    function Styles(paragraphStyles, characterStyles, tableStyles, numberingStyles) {
      return {
        findParagraphStyleById: function(styleId) {
          return paragraphStyles[styleId];
        },
        findCharacterStyleById: function(styleId) {
          return characterStyles[styleId];
        },
        findTableStyleById: function(styleId) {
          return tableStyles[styleId];
        },
        findNumberingStyleById: function(styleId) {
          return numberingStyles[styleId];
        }
      };
    }
    Styles.EMPTY = new Styles({}, {}, {}, {});
    function readStylesXml(root2) {
      var paragraphStyles = {};
      var characterStyles = {};
      var tableStyles = {};
      var numberingStyles = {};
      var styles = {
        "paragraph": paragraphStyles,
        "character": characterStyles,
        "table": tableStyles
      };
      root2.getElementsByTagName("w:style").forEach(function(styleElement) {
        var style = readStyleElement(styleElement);
        if (style.type === "numbering") {
          numberingStyles[style.styleId] = readNumberingStyleElement(styleElement);
        } else {
          var styleSet = styles[style.type];
          if (styleSet) {
            styleSet[style.styleId] = style;
          }
        }
      });
      return new Styles(paragraphStyles, characterStyles, tableStyles, numberingStyles);
    }
    function readStyleElement(styleElement) {
      var type = styleElement.attributes["w:type"];
      var styleId = styleElement.attributes["w:styleId"];
      var name = styleName(styleElement);
      return {
        type,
        styleId,
        name
      };
    }
    function styleName(styleElement) {
      var nameElement = styleElement.first("w:name");
      return nameElement ? nameElement.attributes["w:val"] : null;
    }
    function readNumberingStyleElement(styleElement) {
      var numId = styleElement.firstOrEmpty("w:pPr").firstOrEmpty("w:numPr").firstOrEmpty("w:numId").attributes["w:val"];
      return {
        numId
      };
    }
  }
});

// node_modules/mammoth/lib/docx/notes-reader.js
var require_notes_reader = __commonJS({
  "node_modules/mammoth/lib/docx/notes-reader.js"(exports2) {
    var documents = require_documents();
    var Result = require_results().Result;
    exports2.createFootnotesReader = createReader.bind(exports2, "footnote");
    exports2.createEndnotesReader = createReader.bind(exports2, "endnote");
    function createReader(noteType, bodyReader) {
      function readNotesXml(element) {
        return Result.combine(element.getElementsByTagName("w:" + noteType).filter(isFootnoteElement).map(readFootnoteElement));
      }
      function isFootnoteElement(element) {
        var type = element.attributes["w:type"];
        return type !== "continuationSeparator" && type !== "separator";
      }
      function readFootnoteElement(footnoteElement) {
        var id = footnoteElement.attributes["w:id"];
        return bodyReader.readXmlElements(footnoteElement.children).map(function(body) {
          return documents.Note({
            noteType,
            noteId: id,
            body
          });
        });
      }
      return readNotesXml;
    }
  }
});

// node_modules/mammoth/lib/docx/comments-reader.js
var require_comments_reader = __commonJS({
  "node_modules/mammoth/lib/docx/comments-reader.js"(exports2) {
    var documents = require_documents();
    var Result = require_results().Result;
    function createCommentsReader(bodyReader) {
      function readCommentsXml(element) {
        return Result.combine(element.getElementsByTagName("w:comment").map(readCommentElement));
      }
      function readCommentElement(element) {
        var id = element.attributes["w:id"];
        function readOptionalAttribute(name) {
          return (element.attributes[name] || "").trim() || null;
        }
        return bodyReader.readXmlElements(element.children).map(function(body) {
          return documents.comment({
            commentId: id,
            body,
            authorName: readOptionalAttribute("w:author"),
            authorInitials: readOptionalAttribute("w:initials")
          });
        });
      }
      return readCommentsXml;
    }
    exports2.createCommentsReader = createCommentsReader;
  }
});

// node_modules/mammoth/browser/docx/files.js
var require_files = __commonJS({
  "node_modules/mammoth/browser/docx/files.js"(exports2) {
    var promises = require_promises();
    exports2.Files = Files;
    function Files() {
      function read(uri) {
        return promises.reject(new Error("could not open external image: '" + uri + "'\ncannot open linked files from a web browser"));
      }
      return {
        read
      };
    }
  }
});

// node_modules/mammoth/lib/docx/docx-reader.js
var require_docx_reader = __commonJS({
  "node_modules/mammoth/lib/docx/docx-reader.js"(exports2) {
    exports2.read = read;
    exports2._findPartPaths = findPartPaths;
    var promises = require_promises();
    var documents = require_documents();
    var Result = require_results().Result;
    var zipfile = require_zipfile();
    var readXmlFromZipFile = require_office_xml_reader().readXmlFromZipFile;
    var createBodyReader = require_body_reader().createBodyReader;
    var DocumentXmlReader = require_document_xml_reader().DocumentXmlReader;
    var relationshipsReader = require_relationships_reader();
    var contentTypesReader = require_content_types_reader();
    var numberingXml = require_numbering_xml();
    var stylesReader = require_styles_reader();
    var notesReader = require_notes_reader();
    var commentsReader = require_comments_reader();
    var Files = require_files().Files;
    function read(docxFile, input) {
      input = input || {};
      return promises.props({
        contentTypes: readContentTypesFromZipFile(docxFile),
        partPaths: findPartPaths(docxFile),
        docxFile,
        files: input.path ? Files.relativeToFile(input.path) : new Files(null)
      }).also(function(result2) {
        return {
          styles: readStylesFromZipFile(docxFile, result2.partPaths.styles)
        };
      }).also(function(result2) {
        return {
          numbering: readNumberingFromZipFile(docxFile, result2.partPaths.numbering, result2.styles)
        };
      }).also(function(result2) {
        return {
          footnotes: readXmlFileWithBody(result2.partPaths.footnotes, result2, function(bodyReader, xml) {
            if (xml) {
              return notesReader.createFootnotesReader(bodyReader)(xml);
            } else {
              return new Result([]);
            }
          }),
          endnotes: readXmlFileWithBody(result2.partPaths.endnotes, result2, function(bodyReader, xml) {
            if (xml) {
              return notesReader.createEndnotesReader(bodyReader)(xml);
            } else {
              return new Result([]);
            }
          }),
          comments: readXmlFileWithBody(result2.partPaths.comments, result2, function(bodyReader, xml) {
            if (xml) {
              return commentsReader.createCommentsReader(bodyReader)(xml);
            } else {
              return new Result([]);
            }
          })
        };
      }).also(function(result2) {
        return {
          notes: result2.footnotes.flatMap(function(footnotes) {
            return result2.endnotes.map(function(endnotes) {
              return new documents.Notes(footnotes.concat(endnotes));
            });
          })
        };
      }).then(function(result2) {
        return readXmlFileWithBody(result2.partPaths.mainDocument, result2, function(bodyReader, xml) {
          return result2.notes.flatMap(function(notes) {
            return result2.comments.flatMap(function(comments) {
              var reader = new DocumentXmlReader({
                bodyReader,
                notes,
                comments
              });
              return reader.convertXmlToDocument(xml);
            });
          });
        });
      });
    }
    function findPartPaths(docxFile) {
      return readPackageRelationships(docxFile).then(function(packageRelationships) {
        var mainDocumentPath = findPartPath({
          docxFile,
          relationships: packageRelationships,
          relationshipType: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
          basePath: "",
          fallbackPath: "word/document.xml"
        });
        if (!docxFile.exists(mainDocumentPath)) {
          throw new Error("Could not find main document part. Are you sure this is a valid .docx file?");
        }
        return xmlFileReader({
          filename: relationshipsFilename(mainDocumentPath),
          readElement: relationshipsReader.readRelationships,
          defaultValue: relationshipsReader.defaultValue
        })(docxFile).then(function(documentRelationships) {
          function findPartRelatedToMainDocument(name) {
            return findPartPath({
              docxFile,
              relationships: documentRelationships,
              relationshipType: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/" + name,
              basePath: zipfile.splitPath(mainDocumentPath).dirname,
              fallbackPath: "word/" + name + ".xml"
            });
          }
          return {
            mainDocument: mainDocumentPath,
            comments: findPartRelatedToMainDocument("comments"),
            endnotes: findPartRelatedToMainDocument("endnotes"),
            footnotes: findPartRelatedToMainDocument("footnotes"),
            numbering: findPartRelatedToMainDocument("numbering"),
            styles: findPartRelatedToMainDocument("styles")
          };
        });
      });
    }
    function findPartPath(options) {
      var docxFile = options.docxFile;
      var relationships = options.relationships;
      var relationshipType = options.relationshipType;
      var basePath = options.basePath;
      var fallbackPath = options.fallbackPath;
      var targets = relationships.findTargetsByType(relationshipType);
      var normalisedTargets = targets.map(function(target) {
        return stripPrefix(zipfile.joinPath(basePath, target), "/");
      });
      var validTargets = normalisedTargets.filter(function(target) {
        return docxFile.exists(target);
      });
      if (validTargets.length === 0) {
        return fallbackPath;
      } else {
        return validTargets[0];
      }
    }
    function stripPrefix(value, prefix) {
      if (value.substring(0, prefix.length) === prefix) {
        return value.substring(prefix.length);
      } else {
        return value;
      }
    }
    function xmlFileReader(options) {
      return function(zipFile) {
        return readXmlFromZipFile(zipFile, options.filename).then(function(element) {
          return element ? options.readElement(element) : options.defaultValue;
        });
      };
    }
    function readXmlFileWithBody(filename, options, func) {
      var readRelationshipsFromZipFile = xmlFileReader({
        filename: relationshipsFilename(filename),
        readElement: relationshipsReader.readRelationships,
        defaultValue: relationshipsReader.defaultValue
      });
      return readRelationshipsFromZipFile(options.docxFile).then(function(relationships) {
        var bodyReader = new createBodyReader({
          relationships,
          contentTypes: options.contentTypes,
          docxFile: options.docxFile,
          numbering: options.numbering,
          styles: options.styles,
          files: options.files
        });
        return readXmlFromZipFile(options.docxFile, filename).then(function(xml) {
          return func(bodyReader, xml);
        });
      });
    }
    function relationshipsFilename(filename) {
      var split = zipfile.splitPath(filename);
      return zipfile.joinPath(split.dirname, "_rels", split.basename + ".rels");
    }
    var readContentTypesFromZipFile = xmlFileReader({
      filename: "[Content_Types].xml",
      readElement: contentTypesReader.readContentTypesFromXml,
      defaultValue: contentTypesReader.defaultContentTypes
    });
    function readNumberingFromZipFile(zipFile, path, styles) {
      return xmlFileReader({
        filename: path,
        readElement: function(element) {
          return numberingXml.readNumberingXml(element, {
            styles
          });
        },
        defaultValue: numberingXml.defaultNumbering
      })(zipFile);
    }
    function readStylesFromZipFile(zipFile, path) {
      return xmlFileReader({
        filename: path,
        readElement: stylesReader.readStylesXml,
        defaultValue: stylesReader.defaultStyles
      })(zipFile);
    }
    var readPackageRelationships = xmlFileReader({
      filename: "_rels/.rels",
      readElement: relationshipsReader.readRelationships,
      defaultValue: relationshipsReader.defaultValue
    });
  }
});

// node_modules/mammoth/lib/docx/style-map.js
var require_style_map = __commonJS({
  "node_modules/mammoth/lib/docx/style-map.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var promises = require_promises();
    var xml = require_xml();
    exports2.writeStyleMap = writeStyleMap;
    exports2.readStyleMap = readStyleMap;
    var schema = "http://schemas.zwobble.org/mammoth/style-map";
    var styleMapPath = "mammoth/style-map";
    var styleMapAbsolutePath = "/" + styleMapPath;
    function writeStyleMap(docxFile, styleMap) {
      docxFile.write(styleMapPath, styleMap);
      return updateRelationships(docxFile).then(function() {
        return updateContentTypes(docxFile);
      });
    }
    function updateRelationships(docxFile) {
      var path = "word/_rels/document.xml.rels";
      var relationshipsUri = "http://schemas.openxmlformats.org/package/2006/relationships";
      var relationshipElementName = "{" + relationshipsUri + "}Relationship";
      return docxFile.read(path, "utf8").then(xml.readString).then(function(relationshipsContainer) {
        var relationships = relationshipsContainer.children;
        addOrUpdateElement(relationships, relationshipElementName, "Id", {
          "Id": "rMammothStyleMap",
          "Type": schema,
          "Target": styleMapAbsolutePath
        });
        var namespaces = {
          "": relationshipsUri
        };
        return docxFile.write(path, xml.writeString(relationshipsContainer, namespaces));
      });
    }
    function updateContentTypes(docxFile) {
      var path = "[Content_Types].xml";
      var contentTypesUri = "http://schemas.openxmlformats.org/package/2006/content-types";
      var overrideName = "{" + contentTypesUri + "}Override";
      return docxFile.read(path, "utf8").then(xml.readString).then(function(typesElement) {
        var children = typesElement.children;
        addOrUpdateElement(children, overrideName, "PartName", {
          "PartName": styleMapAbsolutePath,
          "ContentType": "text/prs.mammoth.style-map"
        });
        var namespaces = {
          "": contentTypesUri
        };
        return docxFile.write(path, xml.writeString(typesElement, namespaces));
      });
    }
    function addOrUpdateElement(elements, name, identifyingAttribute, attributes) {
      var existingElement = _3.find(elements, function(element) {
        return element.name === name && element.attributes[identifyingAttribute] === attributes[identifyingAttribute];
      });
      if (existingElement) {
        existingElement.attributes = attributes;
      } else {
        elements.push(xml.element(name, attributes));
      }
    }
    function readStyleMap(docxFile) {
      if (docxFile.exists(styleMapPath)) {
        return docxFile.read(styleMapPath, "utf8");
      } else {
        return promises.resolve(null);
      }
    }
  }
});

// node_modules/mammoth/lib/html/ast.js
var require_ast = __commonJS({
  "node_modules/mammoth/lib/html/ast.js"(exports2) {
    var htmlPaths = require_html_paths();
    function nonFreshElement(tagName, attributes, children) {
      return elementWithTag(htmlPaths.element(tagName, attributes, {
        fresh: false
      }), children);
    }
    function freshElement(tagName, attributes, children) {
      var tag = htmlPaths.element(tagName, attributes, {
        fresh: true
      });
      return elementWithTag(tag, children);
    }
    function elementWithTag(tag, children) {
      return {
        type: "element",
        tag,
        children: children || []
      };
    }
    function text(value) {
      return {
        type: "text",
        value
      };
    }
    var forceWrite = {
      type: "forceWrite"
    };
    exports2.freshElement = freshElement;
    exports2.nonFreshElement = nonFreshElement;
    exports2.elementWithTag = elementWithTag;
    exports2.text = text;
    exports2.forceWrite = forceWrite;
    var voidTagNames = {
      "br": true,
      "hr": true,
      "img": true,
      "input": true
    };
    function isVoidElement(node) {
      return node.children.length === 0 && voidTagNames[node.tag.tagName];
    }
    exports2.isVoidElement = isVoidElement;
  }
});

// node_modules/mammoth/lib/html/simplify.js
var require_simplify = __commonJS({
  "node_modules/mammoth/lib/html/simplify.js"(exports2, module2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var ast = require_ast();
    function simplify(nodes) {
      return collapse(removeEmpty(nodes));
    }
    function collapse(nodes) {
      var children = [];
      nodes.map(collapseNode).forEach(function(child) {
        appendChild(children, child);
      });
      return children;
    }
    function collapseNode(node) {
      return collapsers[node.type](node);
    }
    var collapsers = {
      element: collapseElement,
      text: identity2,
      forceWrite: identity2
    };
    function collapseElement(node) {
      return ast.elementWithTag(node.tag, collapse(node.children));
    }
    function identity2(value) {
      return value;
    }
    function appendChild(children, child) {
      var lastChild = children[children.length - 1];
      if (child.type === "element" && !child.tag.fresh && lastChild && lastChild.type === "element" && child.tag.matchesElement(lastChild.tag)) {
        if (child.tag.separator) {
          appendChild(lastChild.children, ast.text(child.tag.separator));
        }
        child.children.forEach(function(grandChild) {
          appendChild(lastChild.children, grandChild);
        });
      } else {
        children.push(child);
      }
    }
    function removeEmpty(nodes) {
      return flatMap(nodes, function(node) {
        return emptiers[node.type](node);
      });
    }
    function flatMap(values2, func) {
      return _3.flatten(_3.map(values2, func), true);
    }
    var emptiers = {
      element: elementEmptier,
      text: textEmptier,
      forceWrite: neverEmpty
    };
    function neverEmpty(node) {
      return [node];
    }
    function elementEmptier(element) {
      var children = removeEmpty(element.children);
      if (children.length === 0 && !ast.isVoidElement(element)) {
        return [];
      } else {
        return [ast.elementWithTag(element.tag, children)];
      }
    }
    function textEmptier(node) {
      if (node.value.length === 0) {
        return [];
      } else {
        return [node];
      }
    }
    module2.exports = simplify;
  }
});

// node_modules/mammoth/lib/html/index.js
var require_html = __commonJS({
  "node_modules/mammoth/lib/html/index.js"(exports2) {
    var ast = require_ast();
    exports2.freshElement = ast.freshElement;
    exports2.nonFreshElement = ast.nonFreshElement;
    exports2.elementWithTag = ast.elementWithTag;
    exports2.text = ast.text;
    exports2.forceWrite = ast.forceWrite;
    exports2.simplify = require_simplify();
    function write(writer, nodes) {
      nodes.forEach(function(node) {
        writeNode(writer, node);
      });
    }
    function writeNode(writer, node) {
      toStrings[node.type](writer, node);
    }
    var toStrings = {
      element: generateElementString,
      text: generateTextString,
      forceWrite: function() {
      }
    };
    function generateElementString(writer, node) {
      if (ast.isVoidElement(node)) {
        writer.selfClosing(node.tag.tagName, node.tag.attributes);
      } else {
        writer.open(node.tag.tagName, node.tag.attributes);
        write(writer, node.children);
        writer.close(node.tag.tagName);
      }
    }
    function generateTextString(writer, node) {
      writer.text(node.value);
    }
    exports2.write = write;
  }
});

// node_modules/mammoth/lib/styles/html-paths.js
var require_html_paths = __commonJS({
  "node_modules/mammoth/lib/styles/html-paths.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var html = require_html();
    exports2.topLevelElement = topLevelElement;
    exports2.elements = elements;
    exports2.element = element;
    function topLevelElement(tagName, attributes) {
      return elements([element(tagName, attributes, {
        fresh: true
      })]);
    }
    function elements(elementStyles) {
      return new HtmlPath(elementStyles.map(function(elementStyle) {
        if (_3.isString(elementStyle)) {
          return element(elementStyle);
        } else {
          return elementStyle;
        }
      }));
    }
    function HtmlPath(elements2) {
      this._elements = elements2;
    }
    HtmlPath.prototype.wrap = function wrap2(children) {
      var result2 = children();
      for (var index = this._elements.length - 1; index >= 0; index--) {
        result2 = this._elements[index].wrapNodes(result2);
      }
      return result2;
    };
    function element(tagName, attributes, options) {
      options = options || {};
      return new Element(tagName, attributes, options);
    }
    function Element(tagName, attributes, options) {
      var tagNames = {};
      if (_3.isArray(tagName)) {
        tagName.forEach(function(tagName2) {
          tagNames[tagName2] = true;
        });
        tagName = tagName[0];
      } else {
        tagNames[tagName] = true;
      }
      this.tagName = tagName;
      this.tagNames = tagNames;
      this.attributes = attributes || {};
      this.fresh = options.fresh;
      this.separator = options.separator;
    }
    Element.prototype.matchesElement = function(element2) {
      return this.tagNames[element2.tagName] && _3.isEqual(this.attributes || {}, element2.attributes || {});
    };
    Element.prototype.wrap = function wrap2(generateNodes) {
      return this.wrapNodes(generateNodes());
    };
    Element.prototype.wrapNodes = function wrapNodes(nodes) {
      return [html.elementWithTag(this, nodes)];
    };
    exports2.empty = elements([]);
    exports2.ignore = {
      wrap: function() {
        return [];
      }
    };
  }
});

// node_modules/mammoth/lib/images.js
var require_images = __commonJS({
  "node_modules/mammoth/lib/images.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var promises = require_promises();
    var Html = require_html();
    exports2.imgElement = imgElement;
    function imgElement(func) {
      return function(element, messages) {
        return promises.when(func(element)).then(function(result2) {
          var attributes = {};
          if (element.altText) {
            attributes.alt = element.altText;
          }
          _3.extend(attributes, result2);
          return [Html.freshElement("img", attributes)];
        });
      };
    }
    exports2.inline = exports2.imgElement;
    exports2.dataUri = imgElement(function(element) {
      return element.readAsBase64String().then(function(imageBuffer) {
        return {
          src: "data:" + element.contentType + ";base64," + imageBuffer
        };
      });
    });
  }
});

// node_modules/mammoth/lib/writers/html-writer.js
var require_html_writer = __commonJS({
  "node_modules/mammoth/lib/writers/html-writer.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    exports2.writer = writer;
    function writer(options) {
      options = options || {};
      if (options.prettyPrint) {
        return prettyWriter();
      } else {
        return simpleWriter();
      }
    }
    var indentedElements = {
      div: true,
      p: true,
      ul: true,
      li: true
    };
    function prettyWriter() {
      var indentationLevel = 0;
      var indentation = "  ";
      var stack = [];
      var start = true;
      var inText = false;
      var writer2 = simpleWriter();
      function open(tagName, attributes) {
        if (indentedElements[tagName]) {
          indent();
        }
        stack.push(tagName);
        writer2.open(tagName, attributes);
        if (indentedElements[tagName]) {
          indentationLevel++;
        }
        start = false;
      }
      function close(tagName) {
        if (indentedElements[tagName]) {
          indentationLevel--;
          indent();
        }
        stack.pop();
        writer2.close(tagName);
      }
      function text(value) {
        startText();
        var text2 = isInPre() ? value : value.replace("\n", "\n" + indentation);
        writer2.text(text2);
      }
      function selfClosing(tagName, attributes) {
        indent();
        writer2.selfClosing(tagName, attributes);
      }
      function insideIndentedElement() {
        return stack.length === 0 || indentedElements[stack[stack.length - 1]];
      }
      function startText() {
        if (!inText) {
          indent();
          inText = true;
        }
      }
      function indent() {
        inText = false;
        if (!start && insideIndentedElement() && !isInPre()) {
          writer2._append("\n");
          for (var i = 0; i < indentationLevel; i++) {
            writer2._append(indentation);
          }
        }
      }
      function isInPre() {
        return _3.some(stack, function(tagName) {
          return tagName === "pre";
        });
      }
      return {
        asString: writer2.asString,
        open,
        close,
        text,
        selfClosing
      };
    }
    function simpleWriter() {
      var fragments = [];
      function open(tagName, attributes) {
        var attributeString = generateAttributeString(attributes);
        fragments.push("<" + tagName + attributeString + ">");
      }
      function close(tagName) {
        fragments.push("</" + tagName + ">");
      }
      function selfClosing(tagName, attributes) {
        var attributeString = generateAttributeString(attributes);
        fragments.push("<" + tagName + attributeString + " />");
      }
      function generateAttributeString(attributes) {
        return _3.map(attributes, function(value, key) {
          return " " + key + '="' + escapeHtmlAttribute(value) + '"';
        }).join("");
      }
      function text(value) {
        fragments.push(escapeHtmlText(value));
      }
      function append(html) {
        fragments.push(html);
      }
      function asString() {
        return fragments.join("");
      }
      return {
        asString,
        open,
        close,
        text,
        selfClosing,
        _append: append
      };
    }
    function escapeHtmlText(value) {
      return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    function escapeHtmlAttribute(value) {
      return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
  }
});

// node_modules/mammoth/lib/writers/markdown-writer.js
var require_markdown_writer = __commonJS({
  "node_modules/mammoth/lib/writers/markdown-writer.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    function symmetricMarkdownElement(end) {
      return markdownElement(end, end);
    }
    function markdownElement(start, end) {
      return function() {
        return {
          start,
          end
        };
      };
    }
    function markdownLink(attributes) {
      var href = attributes.href || "";
      if (href) {
        return {
          start: "[",
          end: "](" + href + ")",
          anchorPosition: "before"
        };
      } else {
        return {};
      }
    }
    function markdownImage(attributes) {
      var src = attributes.src || "";
      var altText = attributes.alt || "";
      if (src || altText) {
        return {
          start: "![" + altText + "](" + src + ")"
        };
      } else {
        return {};
      }
    }
    function markdownList(options) {
      return function(attributes, list) {
        return {
          start: list ? "\n" : "",
          end: list ? "" : "\n",
          list: {
            isOrdered: options.isOrdered,
            indent: list ? list.indent + 1 : 0,
            count: 0
          }
        };
      };
    }
    function markdownListItem(attributes, list, listItem) {
      list = list || {
        indent: 0,
        isOrdered: false,
        count: 0
      };
      list.count++;
      listItem.hasClosed = false;
      var bullet = list.isOrdered ? list.count + "." : "-";
      var start = repeatString("	", list.indent) + bullet + " ";
      return {
        start,
        end: function() {
          if (!listItem.hasClosed) {
            listItem.hasClosed = true;
            return "\n";
          }
        }
      };
    }
    var htmlToMarkdown = {
      "p": markdownElement("", "\n\n"),
      "br": markdownElement("", "  \n"),
      "ul": markdownList({
        isOrdered: false
      }),
      "ol": markdownList({
        isOrdered: true
      }),
      "li": markdownListItem,
      "strong": symmetricMarkdownElement("__"),
      "em": symmetricMarkdownElement("*"),
      "a": markdownLink,
      "img": markdownImage
    };
    (function() {
      for (var i = 1; i <= 6; i++) {
        htmlToMarkdown["h" + i] = markdownElement(repeatString("#", i) + " ", "\n\n");
      }
    })();
    function repeatString(value, count) {
      return new Array(count + 1).join(value);
    }
    function markdownWriter() {
      var fragments = [];
      var elementStack = [];
      var list = null;
      var listItem = {};
      function open(tagName, attributes) {
        attributes = attributes || {};
        var createElement = htmlToMarkdown[tagName] || function() {
          return {};
        };
        var element = createElement(attributes, list, listItem);
        elementStack.push({
          end: element.end,
          list
        });
        if (element.list) {
          list = element.list;
        }
        var anchorBeforeStart = element.anchorPosition === "before";
        if (anchorBeforeStart) {
          writeAnchor(attributes);
        }
        fragments.push(element.start || "");
        if (!anchorBeforeStart) {
          writeAnchor(attributes);
        }
      }
      function writeAnchor(attributes) {
        if (attributes.id) {
          fragments.push('<a id="' + attributes.id + '"></a>');
        }
      }
      function close(tagName) {
        var element = elementStack.pop();
        list = element.list;
        var end = _3.isFunction(element.end) ? element.end() : element.end;
        fragments.push(end || "");
      }
      function selfClosing(tagName, attributes) {
        open(tagName, attributes);
        close(tagName);
      }
      function text(value) {
        fragments.push(escapeMarkdown(value));
      }
      function asString() {
        return fragments.join("");
      }
      return {
        asString,
        open,
        close,
        text,
        selfClosing
      };
    }
    exports2.writer = markdownWriter;
    function escapeMarkdown(value) {
      return value.replace(/\\/g, "\\\\").replace(/([\`\*_\{\}\[\]\(\)\#\+\-\.\!])/g, "\\$1");
    }
  }
});

// node_modules/mammoth/lib/writers/index.js
var require_writers = __commonJS({
  "node_modules/mammoth/lib/writers/index.js"(exports2) {
    var htmlWriter = require_html_writer();
    var markdownWriter = require_markdown_writer();
    exports2.writer = writer;
    function writer(options) {
      options = options || {};
      if (options.outputFormat === "markdown") {
        return markdownWriter.writer();
      } else {
        return htmlWriter.writer(options);
      }
    }
  }
});

// node_modules/mammoth/lib/document-to-html.js
var require_document_to_html = __commonJS({
  "node_modules/mammoth/lib/document-to-html.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var promises = require_promises();
    var documents = require_documents();
    var htmlPaths = require_html_paths();
    var results = require_results();
    var images = require_images();
    var Html = require_html();
    var writers = require_writers();
    exports2.DocumentConverter = DocumentConverter;
    function DocumentConverter(options) {
      return {
        convertToHtml: function(element) {
          var comments = _3.indexBy(element.type === documents.types.document ? element.comments : [], "commentId");
          var conversion = new DocumentConversion(options, comments);
          return conversion.convertToHtml(element);
        }
      };
    }
    function DocumentConversion(options, comments) {
      var noteNumber = 1;
      var noteReferences = [];
      var referencedComments = [];
      options = _3.extend({
        ignoreEmptyParagraphs: true
      }, options);
      var idPrefix = options.idPrefix === void 0 ? "" : options.idPrefix;
      var ignoreEmptyParagraphs = options.ignoreEmptyParagraphs;
      var defaultParagraphStyle = htmlPaths.topLevelElement("p");
      var styleMap = options.styleMap || [];
      function convertToHtml(document2) {
        var messages = [];
        var html = elementToHtml(document2, messages, {});
        var deferredNodes = [];
        walkHtml(html, function(node) {
          if (node.type === "deferred") {
            deferredNodes.push(node);
          }
        });
        var deferredValues = {};
        return promises.mapSeries(deferredNodes, function(deferred) {
          return deferred.value().then(function(value) {
            deferredValues[deferred.id] = value;
          });
        }).then(function() {
          function replaceDeferred(nodes) {
            return flatMap(nodes, function(node) {
              if (node.type === "deferred") {
                return deferredValues[node.id];
              } else if (node.children) {
                return [_3.extend({}, node, {
                  children: replaceDeferred(node.children)
                })];
              } else {
                return [node];
              }
            });
          }
          var writer = writers.writer({
            prettyPrint: options.prettyPrint,
            outputFormat: options.outputFormat
          });
          Html.write(writer, Html.simplify(replaceDeferred(html)));
          return new results.Result(writer.asString(), messages);
        });
      }
      function convertElements(elements, messages, options2) {
        return flatMap(elements, function(element) {
          return elementToHtml(element, messages, options2);
        });
      }
      function elementToHtml(element, messages, options2) {
        if (!options2) {
          throw new Error("options not set");
        }
        var handler = elementConverters[element.type];
        if (handler) {
          return handler(element, messages, options2);
        } else {
          return [];
        }
      }
      function convertParagraph(element, messages, options2) {
        return htmlPathForParagraph(element, messages).wrap(function() {
          var content = convertElements(element.children, messages, options2);
          if (ignoreEmptyParagraphs) {
            return content;
          } else {
            return [Html.forceWrite].concat(content);
          }
        });
      }
      function htmlPathForParagraph(element, messages) {
        var style = findStyle(element);
        if (style) {
          return style.to;
        } else {
          if (element.styleId) {
            messages.push(unrecognisedStyleWarning("paragraph", element));
          }
          return defaultParagraphStyle;
        }
      }
      function convertRun(run, messages, options2) {
        var nodes = function() {
          return convertElements(run.children, messages, options2);
        };
        var paths = [];
        if (run.highlight !== null) {
          var path = findHtmlPath({
            type: "highlight",
            color: run.highlight
          });
          if (path) {
            paths.push(path);
          }
        }
        if (run.isSmallCaps) {
          paths.push(findHtmlPathForRunProperty("smallCaps"));
        }
        if (run.isAllCaps) {
          paths.push(findHtmlPathForRunProperty("allCaps"));
        }
        if (run.isStrikethrough) {
          paths.push(findHtmlPathForRunProperty("strikethrough", "s"));
        }
        if (run.isUnderline) {
          paths.push(findHtmlPathForRunProperty("underline"));
        }
        if (run.verticalAlignment === documents.verticalAlignment.subscript) {
          paths.push(htmlPaths.element("sub", {}, {
            fresh: false
          }));
        }
        if (run.verticalAlignment === documents.verticalAlignment.superscript) {
          paths.push(htmlPaths.element("sup", {}, {
            fresh: false
          }));
        }
        if (run.isItalic) {
          paths.push(findHtmlPathForRunProperty("italic", "em"));
        }
        if (run.isBold) {
          paths.push(findHtmlPathForRunProperty("bold", "strong"));
        }
        var stylePath = htmlPaths.empty;
        var style = findStyle(run);
        if (style) {
          stylePath = style.to;
        } else if (run.styleId) {
          messages.push(unrecognisedStyleWarning("run", run));
        }
        paths.push(stylePath);
        paths.forEach(function(path2) {
          nodes = path2.wrap.bind(path2, nodes);
        });
        return nodes();
      }
      function findHtmlPathForRunProperty(elementType, defaultTagName) {
        var path = findHtmlPath({
          type: elementType
        });
        if (path) {
          return path;
        } else if (defaultTagName) {
          return htmlPaths.element(defaultTagName, {}, {
            fresh: false
          });
        } else {
          return htmlPaths.empty;
        }
      }
      function findHtmlPath(element, defaultPath) {
        var style = findStyle(element);
        return style ? style.to : defaultPath;
      }
      function findStyle(element) {
        for (var i = 0; i < styleMap.length; i++) {
          if (styleMap[i].from.matches(element)) {
            return styleMap[i];
          }
        }
      }
      function recoveringConvertImage(convertImage) {
        return function(image, messages) {
          return promises.attempt(function() {
            return convertImage(image, messages);
          }).caught(function(error) {
            messages.push(results.error(error));
            return [];
          });
        };
      }
      function noteHtmlId(note) {
        return referentHtmlId(note.noteType, note.noteId);
      }
      function noteRefHtmlId(note) {
        return referenceHtmlId(note.noteType, note.noteId);
      }
      function referentHtmlId(referenceType, referenceId) {
        return htmlId(referenceType + "-" + referenceId);
      }
      function referenceHtmlId(referenceType, referenceId) {
        return htmlId(referenceType + "-ref-" + referenceId);
      }
      function htmlId(suffix) {
        return idPrefix + suffix;
      }
      var defaultTablePath = htmlPaths.elements([htmlPaths.element("table", {}, {
        fresh: true
      })]);
      function convertTable(element, messages, options2) {
        return findHtmlPath(element, defaultTablePath).wrap(function() {
          return convertTableChildren(element, messages, options2);
        });
      }
      function convertTableChildren(element, messages, options2) {
        var bodyIndex = _3.findIndex(element.children, function(child) {
          return !child.type === documents.types.tableRow || !child.isHeader;
        });
        if (bodyIndex === -1) {
          bodyIndex = element.children.length;
        }
        var children;
        if (bodyIndex === 0) {
          children = convertElements(element.children, messages, _3.extend({}, options2, {
            isTableHeader: false
          }));
        } else {
          var headRows = convertElements(element.children.slice(0, bodyIndex), messages, _3.extend({}, options2, {
            isTableHeader: true
          }));
          var bodyRows = convertElements(element.children.slice(bodyIndex), messages, _3.extend({}, options2, {
            isTableHeader: false
          }));
          children = [Html.freshElement("thead", {}, headRows), Html.freshElement("tbody", {}, bodyRows)];
        }
        return [Html.forceWrite].concat(children);
      }
      function convertTableRow(element, messages, options2) {
        var children = convertElements(element.children, messages, options2);
        return [Html.freshElement("tr", {}, [Html.forceWrite].concat(children))];
      }
      function convertTableCell(element, messages, options2) {
        var tagName = options2.isTableHeader ? "th" : "td";
        var children = convertElements(element.children, messages, options2);
        var attributes = {};
        if (element.colSpan !== 1) {
          attributes.colspan = element.colSpan.toString();
        }
        if (element.rowSpan !== 1) {
          attributes.rowspan = element.rowSpan.toString();
        }
        return [Html.freshElement(tagName, attributes, [Html.forceWrite].concat(children))];
      }
      function convertCommentReference(reference, messages, options2) {
        return findHtmlPath(reference, htmlPaths.ignore).wrap(function() {
          var comment = comments[reference.commentId];
          var count = referencedComments.length + 1;
          var label = "[" + commentAuthorLabel(comment) + count + "]";
          referencedComments.push({
            label,
            comment
          });
          return [Html.freshElement("a", {
            href: "#" + referentHtmlId("comment", reference.commentId),
            id: referenceHtmlId("comment", reference.commentId)
          }, [Html.text(label)])];
        });
      }
      function convertComment(referencedComment, messages, options2) {
        var label = referencedComment.label;
        var comment = referencedComment.comment;
        var body = convertElements(comment.body, messages, options2).concat([Html.nonFreshElement("p", {}, [Html.text(" "), Html.freshElement("a", {
          "href": "#" + referenceHtmlId("comment", comment.commentId)
        }, [Html.text("↑")])])]);
        return [Html.freshElement("dt", {
          "id": referentHtmlId("comment", comment.commentId)
        }, [Html.text("Comment " + label)]), Html.freshElement("dd", {}, body)];
      }
      function convertBreak(element, messages, options2) {
        return htmlPathForBreak(element).wrap(function() {
          return [];
        });
      }
      function htmlPathForBreak(element) {
        var style = findStyle(element);
        if (style) {
          return style.to;
        } else if (element.breakType === "line") {
          return htmlPaths.topLevelElement("br");
        } else {
          return htmlPaths.empty;
        }
      }
      var elementConverters = {
        "document": function(document2, messages, options2) {
          var children = convertElements(document2.children, messages, options2);
          var notes = noteReferences.map(function(noteReference) {
            return document2.notes.resolve(noteReference);
          });
          var notesNodes = convertElements(notes, messages, options2);
          return children.concat([Html.freshElement("ol", {}, notesNodes), Html.freshElement("dl", {}, flatMap(referencedComments, function(referencedComment) {
            return convertComment(referencedComment, messages, options2);
          }))]);
        },
        "paragraph": convertParagraph,
        "run": convertRun,
        "text": function(element, messages, options2) {
          return [Html.text(element.value)];
        },
        "tab": function(element, messages, options2) {
          return [Html.text("	")];
        },
        "hyperlink": function(element, messages, options2) {
          var href = element.anchor ? "#" + htmlId(element.anchor) : element.href;
          var attributes = {
            href
          };
          if (element.targetFrame != null) {
            attributes.target = element.targetFrame;
          }
          var children = convertElements(element.children, messages, options2);
          return [Html.nonFreshElement("a", attributes, children)];
        },
        "checkbox": function(element) {
          var attributes = {
            type: "checkbox"
          };
          if (element.checked) {
            attributes["checked"] = "checked";
          }
          return [Html.freshElement("input", attributes)];
        },
        "bookmarkStart": function(element, messages, options2) {
          var anchor = Html.freshElement("a", {
            id: htmlId(element.name)
          }, [Html.forceWrite]);
          return [anchor];
        },
        "noteReference": function(element, messages, options2) {
          noteReferences.push(element);
          var anchor = Html.freshElement("a", {
            href: "#" + noteHtmlId(element),
            id: noteRefHtmlId(element)
          }, [Html.text("[" + noteNumber++ + "]")]);
          return [Html.freshElement("sup", {}, [anchor])];
        },
        "note": function(element, messages, options2) {
          var children = convertElements(element.body, messages, options2);
          var backLink = Html.elementWithTag(htmlPaths.element("p", {}, {
            fresh: false
          }), [Html.text(" "), Html.freshElement("a", {
            href: "#" + noteRefHtmlId(element)
          }, [Html.text("↑")])]);
          var body = children.concat([backLink]);
          return Html.freshElement("li", {
            id: noteHtmlId(element)
          }, body);
        },
        "commentReference": convertCommentReference,
        "comment": convertComment,
        "image": deferredConversion(recoveringConvertImage(options.convertImage || images.dataUri)),
        "table": convertTable,
        "tableRow": convertTableRow,
        "tableCell": convertTableCell,
        "break": convertBreak
      };
      return {
        convertToHtml
      };
    }
    var deferredId = 1;
    function deferredConversion(func) {
      return function(element, messages, options) {
        return [{
          type: "deferred",
          id: deferredId++,
          value: function() {
            return func(element, messages, options);
          }
        }];
      };
    }
    function unrecognisedStyleWarning(type, element) {
      return results.warning("Unrecognised " + type + " style: '" + element.styleName + "' (Style ID: " + element.styleId + ")");
    }
    function flatMap(values2, func) {
      return _3.flatten(values2.map(func), true);
    }
    function walkHtml(nodes, callback) {
      nodes.forEach(function(node) {
        callback(node);
        if (node.children) {
          walkHtml(node.children, callback);
        }
      });
    }
    var commentAuthorLabel = exports2.commentAuthorLabel = function commentAuthorLabel2(comment) {
      return comment.authorInitials || "";
    };
  }
});

// node_modules/mammoth/lib/raw-text.js
var require_raw_text = __commonJS({
  "node_modules/mammoth/lib/raw-text.js"(exports2) {
    var documents = require_documents();
    function convertElementToRawText(element) {
      if (element.type === "text") {
        return element.value;
      } else if (element.type === documents.types.tab) {
        return "	";
      } else {
        var tail = element.type === "paragraph" ? "\n\n" : "";
        return (element.children || []).map(convertElementToRawText).join("") + tail;
      }
    }
    exports2.convertElementToRawText = convertElementToRawText;
  }
});

// node_modules/lop/lib/TokenIterator.js
var require_TokenIterator = __commonJS({
  "node_modules/lop/lib/TokenIterator.js"(exports2, module2) {
    var TokenIterator = module2.exports = function(tokens, startIndex) {
      this._tokens = tokens;
      this._startIndex = startIndex || 0;
    };
    TokenIterator.prototype.head = function() {
      return this._tokens[this._startIndex];
    };
    TokenIterator.prototype.tail = function(startIndex) {
      return new TokenIterator(this._tokens, this._startIndex + 1);
    };
    TokenIterator.prototype.toArray = function() {
      return this._tokens.slice(this._startIndex);
    };
    TokenIterator.prototype.end = function() {
      return this._tokens[this._tokens.length - 1];
    };
    TokenIterator.prototype.to = function(end) {
      var start = this.head().source;
      var endToken = end.head() || end.end();
      return start.to(endToken.source);
    };
  }
});

// node_modules/lop/lib/parser.js
var require_parser = __commonJS({
  "node_modules/lop/lib/parser.js"(exports2) {
    var TokenIterator = require_TokenIterator();
    exports2.Parser = function(options) {
      var parseTokens = function(parser, tokens) {
        return parser(new TokenIterator(tokens));
      };
      return {
        parseTokens
      };
    };
  }
});

// node_modules/option/index.js
var require_option = __commonJS({
  "node_modules/option/index.js"(exports2) {
    exports2.none = /* @__PURE__ */ Object.create({
      value: function() {
        throw new Error("Called value on none");
      },
      isNone: function() {
        return true;
      },
      isSome: function() {
        return false;
      },
      map: function() {
        return exports2.none;
      },
      flatMap: function() {
        return exports2.none;
      },
      filter: function() {
        return exports2.none;
      },
      toArray: function() {
        return [];
      },
      orElse: callOrReturn,
      valueOrElse: callOrReturn
    });
    function callOrReturn(value) {
      if (typeof value == "function") {
        return value();
      } else {
        return value;
      }
    }
    exports2.some = function(value) {
      return new Some(value);
    };
    var Some = function(value) {
      this._value = value;
    };
    Some.prototype.value = function() {
      return this._value;
    };
    Some.prototype.isNone = function() {
      return false;
    };
    Some.prototype.isSome = function() {
      return true;
    };
    Some.prototype.map = function(func) {
      return new Some(func(this._value));
    };
    Some.prototype.flatMap = function(func) {
      return func(this._value);
    };
    Some.prototype.filter = function(predicate) {
      return predicate(this._value) ? this : exports2.none;
    };
    Some.prototype.toArray = function() {
      return [this._value];
    };
    Some.prototype.orElse = function(value) {
      return this;
    };
    Some.prototype.valueOrElse = function(value) {
      return this._value;
    };
    exports2.isOption = function(value) {
      return value === exports2.none || value instanceof Some;
    };
    exports2.fromNullable = function(value) {
      if (value == null) {
        return exports2.none;
      }
      return new Some(value);
    };
  }
});

// node_modules/lop/lib/parsing-results.js
var require_parsing_results = __commonJS({
  "node_modules/lop/lib/parsing-results.js"(exports2, module2) {
    module2.exports = {
      failure: function(errors, remaining) {
        if (errors.length < 1) {
          throw new Error("Failure must have errors");
        }
        return new Result({
          status: "failure",
          remaining,
          errors
        });
      },
      error: function(errors, remaining) {
        if (errors.length < 1) {
          throw new Error("Failure must have errors");
        }
        return new Result({
          status: "error",
          remaining,
          errors
        });
      },
      success: function(value, remaining, source) {
        return new Result({
          status: "success",
          value,
          source,
          remaining,
          errors: []
        });
      },
      cut: function(remaining) {
        return new Result({
          status: "cut",
          remaining,
          errors: []
        });
      }
    };
    var Result = function(options) {
      this._value = options.value;
      this._status = options.status;
      this._hasValue = options.value !== void 0;
      this._remaining = options.remaining;
      this._source = options.source;
      this._errors = options.errors;
    };
    Result.prototype.map = function(func) {
      if (this._hasValue) {
        return new Result({
          value: func(this._value, this._source),
          status: this._status,
          remaining: this._remaining,
          source: this._source,
          errors: this._errors
        });
      } else {
        return this;
      }
    };
    Result.prototype.changeRemaining = function(remaining) {
      return new Result({
        value: this._value,
        status: this._status,
        remaining,
        source: this._source,
        errors: this._errors
      });
    };
    Result.prototype.isSuccess = function() {
      return this._status === "success" || this._status === "cut";
    };
    Result.prototype.isFailure = function() {
      return this._status === "failure";
    };
    Result.prototype.isError = function() {
      return this._status === "error";
    };
    Result.prototype.isCut = function() {
      return this._status === "cut";
    };
    Result.prototype.value = function() {
      return this._value;
    };
    Result.prototype.remaining = function() {
      return this._remaining;
    };
    Result.prototype.source = function() {
      return this._source;
    };
    Result.prototype.errors = function() {
      return this._errors;
    };
  }
});

// node_modules/lop/lib/errors.js
var require_errors2 = __commonJS({
  "node_modules/lop/lib/errors.js"(exports2) {
    exports2.error = function(options) {
      return new Error2(options);
    };
    var Error2 = function(options) {
      this.expected = options.expected;
      this.actual = options.actual;
      this._location = options.location;
    };
    Error2.prototype.describe = function() {
      var locationDescription = this._location ? this._location.describe() + ":\n" : "";
      return locationDescription + "Expected " + this.expected + "\nbut got " + this.actual;
    };
    Error2.prototype.lineNumber = function() {
      return this._location.lineNumber();
    };
    Error2.prototype.characterNumber = function() {
      return this._location.characterNumber();
    };
  }
});

// node_modules/lop/lib/lazy-iterators.js
var require_lazy_iterators = __commonJS({
  "node_modules/lop/lib/lazy-iterators.js"(exports2) {
    var fromArray = exports2.fromArray = function(array) {
      var index = 0;
      var hasNext = function() {
        return index < array.length;
      };
      return new LazyIterator({
        hasNext,
        next: function() {
          if (!hasNext()) {
            throw new Error("No more elements");
          } else {
            return array[index++];
          }
        }
      });
    };
    var LazyIterator = function(iterator) {
      this._iterator = iterator;
    };
    LazyIterator.prototype.map = function(func) {
      var iterator = this._iterator;
      return new LazyIterator({
        hasNext: function() {
          return iterator.hasNext();
        },
        next: function() {
          return func(iterator.next());
        }
      });
    };
    LazyIterator.prototype.filter = function(condition) {
      var iterator = this._iterator;
      var moved = false;
      var hasNext = false;
      var next;
      var moveIfNecessary = function() {
        if (moved) {
          return;
        }
        moved = true;
        hasNext = false;
        while (iterator.hasNext() && !hasNext) {
          next = iterator.next();
          hasNext = condition(next);
        }
      };
      return new LazyIterator({
        hasNext: function() {
          moveIfNecessary();
          return hasNext;
        },
        next: function() {
          moveIfNecessary();
          var toReturn = next;
          moved = false;
          return toReturn;
        }
      });
    };
    LazyIterator.prototype.first = function() {
      var iterator = this._iterator;
      if (this._iterator.hasNext()) {
        return iterator.next();
      } else {
        return null;
      }
    };
    LazyIterator.prototype.toArray = function() {
      var result2 = [];
      while (this._iterator.hasNext()) {
        result2.push(this._iterator.next());
      }
      return result2;
    };
  }
});

// node_modules/lop/lib/rules.js
var require_rules = __commonJS({
  "node_modules/lop/lib/rules.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var options = require_option();
    var results = require_parsing_results();
    var errors = require_errors2();
    var lazyIterators = require_lazy_iterators();
    exports2.token = function(tokenType, value) {
      var matchValue = value !== void 0;
      return function(input) {
        var token = input.head();
        if (token && token.name === tokenType && (!matchValue || token.value === value)) {
          return results.success(token.value, input.tail(), token.source);
        } else {
          var expected = describeToken({
            name: tokenType,
            value
          });
          return describeTokenMismatch(input, expected);
        }
      };
    };
    exports2.tokenOfType = function(tokenType) {
      return exports2.token(tokenType);
    };
    exports2.firstOf = function(name, parsers) {
      if (!_3.isArray(parsers)) {
        parsers = Array.prototype.slice.call(arguments, 1);
      }
      return function(input) {
        return lazyIterators.fromArray(parsers).map(function(parser) {
          return parser(input);
        }).filter(function(result2) {
          return result2.isSuccess() || result2.isError();
        }).first() || describeTokenMismatch(input, name);
      };
    };
    exports2.then = function(parser, func) {
      return function(input) {
        var result2 = parser(input);
        if (!result2.map) {
          console.log(result2);
        }
        return result2.map(func);
      };
    };
    exports2.sequence = function() {
      var parsers = Array.prototype.slice.call(arguments, 0);
      var rule = function(input) {
        var result2 = _3.foldl(parsers, function(memo, parser) {
          var result3 = memo.result;
          var hasCut = memo.hasCut;
          if (!result3.isSuccess()) {
            return {
              result: result3,
              hasCut
            };
          }
          var subResult = parser(result3.remaining());
          if (subResult.isCut()) {
            return {
              result: result3,
              hasCut: true
            };
          } else if (subResult.isSuccess()) {
            var values2;
            if (parser.isCaptured) {
              values2 = result3.value().withValue(parser, subResult.value());
            } else {
              values2 = result3.value();
            }
            var remaining = subResult.remaining();
            var source2 = input.to(remaining);
            return {
              result: results.success(values2, remaining, source2),
              hasCut
            };
          } else if (hasCut) {
            return {
              result: results.error(subResult.errors(), subResult.remaining()),
              hasCut
            };
          } else {
            return {
              result: subResult,
              hasCut
            };
          }
        }, {
          result: results.success(new SequenceValues(), input),
          hasCut: false
        }).result;
        var source = input.to(result2.remaining());
        return result2.map(function(values2) {
          return values2.withValue(exports2.sequence.source, source);
        });
      };
      rule.head = function() {
        var firstCapture = _3.find(parsers, isCapturedRule);
        return exports2.then(rule, exports2.sequence.extract(firstCapture));
      };
      rule.map = function(func) {
        return exports2.then(rule, function(result2) {
          return func.apply(this, result2.toArray());
        });
      };
      function isCapturedRule(subRule) {
        return subRule.isCaptured;
      }
      return rule;
    };
    var SequenceValues = function(values2, valuesArray) {
      this._values = values2 || {};
      this._valuesArray = valuesArray || [];
    };
    SequenceValues.prototype.withValue = function(rule, value) {
      if (rule.captureName && rule.captureName in this._values) {
        throw new Error('Cannot add second value for capture "' + rule.captureName + '"');
      } else {
        var newValues = _3.clone(this._values);
        newValues[rule.captureName] = value;
        var newValuesArray = this._valuesArray.concat([value]);
        return new SequenceValues(newValues, newValuesArray);
      }
    };
    SequenceValues.prototype.get = function(rule) {
      if (rule.captureName in this._values) {
        return this._values[rule.captureName];
      } else {
        throw new Error('No value for capture "' + rule.captureName + '"');
      }
    };
    SequenceValues.prototype.toArray = function() {
      return this._valuesArray;
    };
    exports2.sequence.capture = function(rule, name) {
      var captureRule = function() {
        return rule.apply(this, arguments);
      };
      captureRule.captureName = name;
      captureRule.isCaptured = true;
      return captureRule;
    };
    exports2.sequence.extract = function(rule) {
      return function(result2) {
        return result2.get(rule);
      };
    };
    exports2.sequence.applyValues = function(func) {
      var rules = Array.prototype.slice.call(arguments, 1);
      return function(result2) {
        var values2 = rules.map(function(rule) {
          return result2.get(rule);
        });
        return func.apply(this, values2);
      };
    };
    exports2.sequence.source = {
      captureName: "☃source☃"
    };
    exports2.sequence.cut = function() {
      return function(input) {
        return results.cut(input);
      };
    };
    exports2.optional = function(rule) {
      return function(input) {
        var result2 = rule(input);
        if (result2.isSuccess()) {
          return result2.map(options.some);
        } else if (result2.isFailure()) {
          return results.success(options.none, input);
        } else {
          return result2;
        }
      };
    };
    exports2.zeroOrMoreWithSeparator = function(rule, separator) {
      return repeatedWithSeparator(rule, separator, false);
    };
    exports2.oneOrMoreWithSeparator = function(rule, separator) {
      return repeatedWithSeparator(rule, separator, true);
    };
    var zeroOrMore = exports2.zeroOrMore = function(rule) {
      return function(input) {
        var values2 = [];
        var result2;
        while ((result2 = rule(input)) && result2.isSuccess()) {
          input = result2.remaining();
          values2.push(result2.value());
        }
        if (result2.isError()) {
          return result2;
        } else {
          return results.success(values2, input);
        }
      };
    };
    exports2.oneOrMore = function(rule) {
      return exports2.oneOrMoreWithSeparator(rule, noOpRule);
    };
    function noOpRule(input) {
      return results.success(null, input);
    }
    var repeatedWithSeparator = function(rule, separator, isOneOrMore) {
      return function(input) {
        var result2 = rule(input);
        if (result2.isSuccess()) {
          var mainRule = exports2.sequence.capture(rule, "main");
          var remainingRule = zeroOrMore(exports2.then(exports2.sequence(separator, mainRule), exports2.sequence.extract(mainRule)));
          var remainingResult = remainingRule(result2.remaining());
          return results.success([result2.value()].concat(remainingResult.value()), remainingResult.remaining());
        } else if (isOneOrMore || result2.isError()) {
          return result2;
        } else {
          return results.success([], input);
        }
      };
    };
    exports2.leftAssociative = function(leftRule, rightRule, func) {
      var rights;
      if (func) {
        rights = [{
          func,
          rule: rightRule
        }];
      } else {
        rights = rightRule;
      }
      rights = rights.map(function(right) {
        return exports2.then(right.rule, function(rightValue) {
          return function(leftValue, source) {
            return right.func(leftValue, rightValue, source);
          };
        });
      });
      var repeatedRule = exports2.firstOf.apply(null, ["rules"].concat(rights));
      return function(input) {
        var start = input;
        var leftResult = leftRule(input);
        if (!leftResult.isSuccess()) {
          return leftResult;
        }
        var repeatedResult = repeatedRule(leftResult.remaining());
        while (repeatedResult.isSuccess()) {
          var remaining = repeatedResult.remaining();
          var source = start.to(repeatedResult.remaining());
          var right = repeatedResult.value();
          leftResult = results.success(right(leftResult.value(), source), remaining, source);
          repeatedResult = repeatedRule(leftResult.remaining());
        }
        if (repeatedResult.isError()) {
          return repeatedResult;
        }
        return leftResult;
      };
    };
    exports2.leftAssociative.firstOf = function() {
      return Array.prototype.slice.call(arguments, 0);
    };
    exports2.nonConsuming = function(rule) {
      return function(input) {
        return rule(input).changeRemaining(input);
      };
    };
    var describeToken = function(token) {
      if (token.value) {
        return token.name + ' "' + token.value + '"';
      } else {
        return token.name;
      }
    };
    function describeTokenMismatch(input, expected) {
      var error;
      var token = input.head();
      if (token) {
        error = errors.error({
          expected,
          actual: describeToken(token),
          location: token.source
        });
      } else {
        error = errors.error({
          expected,
          actual: "end of tokens"
        });
      }
      return results.failure([error], input);
    }
  }
});

// node_modules/lop/lib/StringSource.js
var require_StringSource = __commonJS({
  "node_modules/lop/lib/StringSource.js"(exports2, module2) {
    var StringSource = module2.exports = function(string, description) {
      var self2 = {
        asString: function() {
          return string;
        },
        range: function(startIndex, endIndex) {
          return new StringSourceRange(string, description, startIndex, endIndex);
        }
      };
      return self2;
    };
    var StringSourceRange = function(string, description, startIndex, endIndex) {
      this._string = string;
      this._description = description;
      this._startIndex = startIndex;
      this._endIndex = endIndex;
    };
    StringSourceRange.prototype.to = function(otherRange) {
      return new StringSourceRange(this._string, this._description, this._startIndex, otherRange._endIndex);
    };
    StringSourceRange.prototype.describe = function() {
      var position = this._position();
      var description = this._description ? this._description + "\n" : "";
      return description + "Line number: " + position.lineNumber + "\nCharacter number: " + position.characterNumber;
    };
    StringSourceRange.prototype.lineNumber = function() {
      return this._position().lineNumber;
    };
    StringSourceRange.prototype.characterNumber = function() {
      return this._position().characterNumber;
    };
    StringSourceRange.prototype._position = function() {
      var self2 = this;
      var index = 0;
      var nextNewLine = function() {
        return self2._string.indexOf("\n", index);
      };
      var lineNumber = 1;
      while (nextNewLine() !== -1 && nextNewLine() < this._startIndex) {
        index = nextNewLine() + 1;
        lineNumber += 1;
      }
      var characterNumber = this._startIndex - index + 1;
      return {
        lineNumber,
        characterNumber
      };
    };
  }
});

// node_modules/lop/lib/Token.js
var require_Token = __commonJS({
  "node_modules/lop/lib/Token.js"(exports2, module2) {
    module2.exports = function(name, value, source) {
      this.name = name;
      this.value = value;
      if (source) {
        this.source = source;
      }
    };
  }
});

// node_modules/lop/lib/bottom-up.js
var require_bottom_up = __commonJS({
  "node_modules/lop/lib/bottom-up.js"(exports2) {
    var rules = require_rules();
    var results = require_parsing_results();
    exports2.parser = function(name, prefixRules, infixRuleBuilders) {
      var self2 = {
        rule,
        leftAssociative,
        rightAssociative
      };
      var infixRules = new InfixRules(infixRuleBuilders.map(createInfixRule));
      var prefixRule = rules.firstOf(name, prefixRules);
      function createInfixRule(infixRuleBuilder) {
        return {
          name: infixRuleBuilder.name,
          rule: lazyRule(infixRuleBuilder.ruleBuilder.bind(null, self2))
        };
      }
      function rule() {
        return createRule(infixRules);
      }
      function leftAssociative(name2) {
        return createRule(infixRules.untilExclusive(name2));
      }
      function rightAssociative(name2) {
        return createRule(infixRules.untilInclusive(name2));
      }
      function createRule(infixRules2) {
        return apply.bind(null, infixRules2);
      }
      function apply(infixRules2, tokens) {
        var leftResult = prefixRule(tokens);
        if (leftResult.isSuccess()) {
          return infixRules2.apply(leftResult);
        } else {
          return leftResult;
        }
      }
      return self2;
    };
    function InfixRules(infixRules) {
      function untilExclusive(name) {
        return new InfixRules(infixRules.slice(0, ruleNames().indexOf(name)));
      }
      function untilInclusive(name) {
        return new InfixRules(infixRules.slice(0, ruleNames().indexOf(name) + 1));
      }
      function ruleNames() {
        return infixRules.map(function(rule) {
          return rule.name;
        });
      }
      function apply(leftResult) {
        var currentResult;
        var source;
        while (true) {
          currentResult = applyToTokens(leftResult.remaining());
          if (currentResult.isSuccess()) {
            source = leftResult.source().to(currentResult.source());
            leftResult = results.success(currentResult.value()(leftResult.value(), source), currentResult.remaining(), source);
          } else if (currentResult.isFailure()) {
            return leftResult;
          } else {
            return currentResult;
          }
        }
      }
      function applyToTokens(tokens) {
        return rules.firstOf("infix", infixRules.map(function(infix) {
          return infix.rule;
        }))(tokens);
      }
      return {
        apply,
        untilExclusive,
        untilInclusive
      };
    }
    exports2.infix = function(name, ruleBuilder) {
      function map2(func) {
        return exports2.infix(name, function(parser) {
          var rule = ruleBuilder(parser);
          return function(tokens) {
            var result2 = rule(tokens);
            return result2.map(function(right) {
              return function(left, source) {
                return func(left, right, source);
              };
            });
          };
        });
      }
      return {
        name,
        ruleBuilder,
        map: map2
      };
    };
    var lazyRule = function(ruleBuilder) {
      var rule;
      return function(input) {
        if (!rule) {
          rule = ruleBuilder();
        }
        return rule(input);
      };
    };
  }
});

// node_modules/lop/lib/regex-tokeniser.js
var require_regex_tokeniser = __commonJS({
  "node_modules/lop/lib/regex-tokeniser.js"(exports2) {
    var Token = require_Token();
    var StringSource = require_StringSource();
    exports2.RegexTokeniser = RegexTokeniser;
    function RegexTokeniser(rules) {
      rules = rules.map(function(rule) {
        return {
          name: rule.name,
          regex: new RegExp(rule.regex.source, "g")
        };
      });
      function tokenise(input, description) {
        var source = new StringSource(input, description);
        var index = 0;
        var tokens = [];
        while (index < input.length) {
          var result2 = readNextToken(input, index, source);
          index = result2.endIndex;
          tokens.push(result2.token);
        }
        tokens.push(endToken(input, source));
        return tokens;
      }
      function readNextToken(string, startIndex, source) {
        for (var i = 0; i < rules.length; i++) {
          var regex = rules[i].regex;
          regex.lastIndex = startIndex;
          var result2 = regex.exec(string);
          if (result2) {
            var endIndex = startIndex + result2[0].length;
            if (result2.index === startIndex && endIndex > startIndex) {
              var value = result2[1];
              var token = new Token(rules[i].name, value, source.range(startIndex, endIndex));
              return {
                token,
                endIndex
              };
            }
          }
        }
        var endIndex = startIndex + 1;
        var token = new Token("unrecognisedCharacter", string.substring(startIndex, endIndex), source.range(startIndex, endIndex));
        return {
          token,
          endIndex
        };
      }
      function endToken(input, source) {
        return new Token("end", null, source.range(input.length, input.length));
      }
      return {
        tokenise
      };
    }
  }
});

// node_modules/lop/index.js
var require_lop = __commonJS({
  "node_modules/lop/index.js"(exports2) {
    exports2.Parser = require_parser().Parser;
    exports2.rules = require_rules();
    exports2.errors = require_errors2();
    exports2.results = require_parsing_results();
    exports2.StringSource = require_StringSource();
    exports2.Token = require_Token();
    exports2.bottomUp = require_bottom_up();
    exports2.RegexTokeniser = require_regex_tokeniser().RegexTokeniser;
    exports2.rule = function(ruleBuilder) {
      var rule;
      return function(input) {
        if (!rule) {
          rule = ruleBuilder();
        }
        return rule(input);
      };
    };
  }
});

// node_modules/mammoth/lib/styles/document-matchers.js
var require_document_matchers = __commonJS({
  "node_modules/mammoth/lib/styles/document-matchers.js"(exports2) {
    exports2.paragraph = paragraph;
    exports2.run = run;
    exports2.table = table;
    exports2.bold = new Matcher("bold");
    exports2.italic = new Matcher("italic");
    exports2.underline = new Matcher("underline");
    exports2.strikethrough = new Matcher("strikethrough");
    exports2.allCaps = new Matcher("allCaps");
    exports2.smallCaps = new Matcher("smallCaps");
    exports2.highlight = highlight;
    exports2.commentReference = new Matcher("commentReference");
    exports2.lineBreak = new BreakMatcher({
      breakType: "line"
    });
    exports2.pageBreak = new BreakMatcher({
      breakType: "page"
    });
    exports2.columnBreak = new BreakMatcher({
      breakType: "column"
    });
    exports2.equalTo = equalTo;
    exports2.startsWith = startsWith;
    function paragraph(options) {
      return new Matcher("paragraph", options);
    }
    function run(options) {
      return new Matcher("run", options);
    }
    function table(options) {
      return new Matcher("table", options);
    }
    function highlight(options) {
      return new HighlightMatcher(options);
    }
    function Matcher(elementType, options) {
      options = options || {};
      this._elementType = elementType;
      this._styleId = options.styleId;
      this._styleName = options.styleName;
      if (options.list) {
        this._listIndex = options.list.levelIndex;
        this._listIsOrdered = options.list.isOrdered;
      }
    }
    Matcher.prototype.matches = function(element) {
      return element.type === this._elementType && (this._styleId === void 0 || element.styleId === this._styleId) && (this._styleName === void 0 || element.styleName && this._styleName.operator(this._styleName.operand, element.styleName)) && (this._listIndex === void 0 || isList(element, this._listIndex, this._listIsOrdered)) && (this._breakType === void 0 || this._breakType === element.breakType);
    };
    function HighlightMatcher(options) {
      options = options || {};
      this._color = options.color;
    }
    HighlightMatcher.prototype.matches = function(element) {
      return element.type === "highlight" && (this._color === void 0 || element.color === this._color);
    };
    function BreakMatcher(options) {
      options = options || {};
      this._breakType = options.breakType;
    }
    BreakMatcher.prototype.matches = function(element) {
      return element.type === "break" && (this._breakType === void 0 || element.breakType === this._breakType);
    };
    function isList(element, levelIndex, isOrdered) {
      return element.numbering && element.numbering.level == levelIndex && element.numbering.isOrdered == isOrdered;
    }
    function equalTo(value) {
      return {
        operator: operatorEqualTo,
        operand: value
      };
    }
    function startsWith(value) {
      return {
        operator: operatorStartsWith,
        operand: value
      };
    }
    function operatorEqualTo(first2, second) {
      return first2.toUpperCase() === second.toUpperCase();
    }
    function operatorStartsWith(first2, second) {
      return second.toUpperCase().indexOf(first2.toUpperCase()) === 0;
    }
  }
});

// node_modules/mammoth/lib/styles/parser/tokeniser.js
var require_tokeniser = __commonJS({
  "node_modules/mammoth/lib/styles/parser/tokeniser.js"(exports2) {
    var lop = require_lop();
    var RegexTokeniser = lop.RegexTokeniser;
    exports2.tokenise = tokenise;
    var stringPrefix = "'((?:\\\\.|[^'])*)";
    function tokenise(string) {
      var identifierCharacter = "(?:[a-zA-Z\\-_]|\\\\.)";
      var tokeniser = new RegexTokeniser([{
        name: "identifier",
        regex: new RegExp("(" + identifierCharacter + "(?:" + identifierCharacter + "|[0-9])*)")
      }, {
        name: "dot",
        regex: /\./
      }, {
        name: "colon",
        regex: /:/
      }, {
        name: "gt",
        regex: />/
      }, {
        name: "whitespace",
        regex: /\s+/
      }, {
        name: "arrow",
        regex: /=>/
      }, {
        name: "equals",
        regex: /=/
      }, {
        name: "startsWith",
        regex: /\^=/
      }, {
        name: "open-paren",
        regex: /\(/
      }, {
        name: "close-paren",
        regex: /\)/
      }, {
        name: "open-square-bracket",
        regex: /\[/
      }, {
        name: "close-square-bracket",
        regex: /\]/
      }, {
        name: "string",
        regex: new RegExp(stringPrefix + "'")
      }, {
        name: "unterminated-string",
        regex: new RegExp(stringPrefix)
      }, {
        name: "integer",
        regex: /([0-9]+)/
      }, {
        name: "choice",
        regex: /\|/
      }, {
        name: "bang",
        regex: /(!)/
      }]);
      return tokeniser.tokenise(string);
    }
  }
});

// node_modules/mammoth/lib/style-reader.js
var require_style_reader = __commonJS({
  "node_modules/mammoth/lib/style-reader.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var lop = require_lop();
    var documentMatchers = require_document_matchers();
    var htmlPaths = require_html_paths();
    var tokenise = require_tokeniser().tokenise;
    var results = require_results();
    exports2.readHtmlPath = readHtmlPath;
    exports2.readDocumentMatcher = readDocumentMatcher;
    exports2.readStyle = readStyle;
    function readStyle(string) {
      return parseString(styleRule, string);
    }
    function createStyleRule() {
      return lop.rules.sequence(lop.rules.sequence.capture(documentMatcherRule()), lop.rules.tokenOfType("whitespace"), lop.rules.tokenOfType("arrow"), lop.rules.sequence.capture(lop.rules.optional(lop.rules.sequence(lop.rules.tokenOfType("whitespace"), lop.rules.sequence.capture(htmlPathRule())).head())), lop.rules.tokenOfType("end")).map(function(documentMatcher, htmlPath) {
        return {
          from: documentMatcher,
          to: htmlPath.valueOrElse(htmlPaths.empty)
        };
      });
    }
    function readDocumentMatcher(string) {
      return parseString(documentMatcherRule(), string);
    }
    function documentMatcherRule() {
      var sequence = lop.rules.sequence;
      var identifierToConstant = function(identifier, constant2) {
        return lop.rules.then(lop.rules.token("identifier", identifier), function() {
          return constant2;
        });
      };
      var paragraphRule = identifierToConstant("p", documentMatchers.paragraph);
      var runRule = identifierToConstant("r", documentMatchers.run);
      var elementTypeRule = lop.rules.firstOf("p or r or table", paragraphRule, runRule);
      var styleIdRule = lop.rules.sequence(lop.rules.tokenOfType("dot"), lop.rules.sequence.cut(), lop.rules.sequence.capture(identifierRule)).map(function(styleId) {
        return {
          styleId
        };
      });
      var styleNameMatcherRule = lop.rules.firstOf("style name matcher", lop.rules.then(lop.rules.sequence(lop.rules.tokenOfType("equals"), lop.rules.sequence.cut(), lop.rules.sequence.capture(stringRule)).head(), function(styleName) {
        return {
          styleName: documentMatchers.equalTo(styleName)
        };
      }), lop.rules.then(lop.rules.sequence(lop.rules.tokenOfType("startsWith"), lop.rules.sequence.cut(), lop.rules.sequence.capture(stringRule)).head(), function(styleName) {
        return {
          styleName: documentMatchers.startsWith(styleName)
        };
      }));
      var styleNameRule = lop.rules.sequence(lop.rules.tokenOfType("open-square-bracket"), lop.rules.sequence.cut(), lop.rules.token("identifier", "style-name"), lop.rules.sequence.capture(styleNameMatcherRule), lop.rules.tokenOfType("close-square-bracket")).head();
      var listTypeRule = lop.rules.firstOf("list type", identifierToConstant("ordered-list", {
        isOrdered: true
      }), identifierToConstant("unordered-list", {
        isOrdered: false
      }));
      var listRule = sequence(lop.rules.tokenOfType("colon"), sequence.capture(listTypeRule), sequence.cut(), lop.rules.tokenOfType("open-paren"), sequence.capture(integerRule), lop.rules.tokenOfType("close-paren")).map(function(listType, levelNumber) {
        return {
          list: {
            isOrdered: listType.isOrdered,
            levelIndex: levelNumber - 1
          }
        };
      });
      function createMatcherSuffixesRule(rules) {
        var matcherSuffix = lop.rules.firstOf.apply(lop.rules.firstOf, ["matcher suffix"].concat(rules));
        var matcherSuffixes = lop.rules.zeroOrMore(matcherSuffix);
        return lop.rules.then(matcherSuffixes, function(suffixes) {
          var matcherOptions = {};
          suffixes.forEach(function(suffix) {
            _3.extend(matcherOptions, suffix);
          });
          return matcherOptions;
        });
      }
      var paragraphOrRun = sequence(sequence.capture(elementTypeRule), sequence.capture(createMatcherSuffixesRule([styleIdRule, styleNameRule, listRule]))).map(function(createMatcher, matcherOptions) {
        return createMatcher(matcherOptions);
      });
      var table = sequence(lop.rules.token("identifier", "table"), sequence.capture(createMatcherSuffixesRule([styleIdRule, styleNameRule]))).map(function(options) {
        return documentMatchers.table(options);
      });
      var bold = identifierToConstant("b", documentMatchers.bold);
      var italic = identifierToConstant("i", documentMatchers.italic);
      var underline = identifierToConstant("u", documentMatchers.underline);
      var strikethrough = identifierToConstant("strike", documentMatchers.strikethrough);
      var allCaps = identifierToConstant("all-caps", documentMatchers.allCaps);
      var smallCaps = identifierToConstant("small-caps", documentMatchers.smallCaps);
      var highlight = sequence(lop.rules.token("identifier", "highlight"), lop.rules.sequence.capture(lop.rules.optional(lop.rules.sequence(lop.rules.tokenOfType("open-square-bracket"), lop.rules.sequence.cut(), lop.rules.token("identifier", "color"), lop.rules.tokenOfType("equals"), lop.rules.sequence.capture(stringRule), lop.rules.tokenOfType("close-square-bracket")).head()))).map(function(color) {
        return documentMatchers.highlight({
          color: color.valueOrElse(void 0)
        });
      });
      var commentReference = identifierToConstant("comment-reference", documentMatchers.commentReference);
      var breakMatcher = sequence(lop.rules.token("identifier", "br"), sequence.cut(), lop.rules.tokenOfType("open-square-bracket"), lop.rules.token("identifier", "type"), lop.rules.tokenOfType("equals"), sequence.capture(stringRule), lop.rules.tokenOfType("close-square-bracket")).map(function(breakType) {
        switch (breakType) {
          case "line":
            return documentMatchers.lineBreak;
          case "page":
            return documentMatchers.pageBreak;
          case "column":
            return documentMatchers.columnBreak;
          default:
        }
      });
      return lop.rules.firstOf("element type", paragraphOrRun, table, bold, italic, underline, strikethrough, allCaps, smallCaps, highlight, commentReference, breakMatcher);
    }
    function readHtmlPath(string) {
      return parseString(htmlPathRule(), string);
    }
    function htmlPathRule() {
      var capture = lop.rules.sequence.capture;
      var whitespaceRule = lop.rules.tokenOfType("whitespace");
      var freshRule = lop.rules.then(lop.rules.optional(lop.rules.sequence(lop.rules.tokenOfType("colon"), lop.rules.token("identifier", "fresh"))), function(option) {
        return option.map(function() {
          return true;
        }).valueOrElse(false);
      });
      var separatorRule = lop.rules.then(lop.rules.optional(lop.rules.sequence(lop.rules.tokenOfType("colon"), lop.rules.token("identifier", "separator"), lop.rules.tokenOfType("open-paren"), capture(stringRule), lop.rules.tokenOfType("close-paren")).head()), function(option) {
        return option.valueOrElse("");
      });
      var tagNamesRule = lop.rules.oneOrMoreWithSeparator(identifierRule, lop.rules.tokenOfType("choice"));
      var styleElementRule = lop.rules.sequence(capture(tagNamesRule), capture(lop.rules.zeroOrMore(attributeOrClassRule)), capture(freshRule), capture(separatorRule)).map(function(tagName, attributesList, fresh, separator) {
        var attributes = {};
        var options = {};
        attributesList.forEach(function(attribute) {
          if (attribute.append && attributes[attribute.name]) {
            attributes[attribute.name] += " " + attribute.value;
          } else {
            attributes[attribute.name] = attribute.value;
          }
        });
        if (fresh) {
          options.fresh = true;
        }
        if (separator) {
          options.separator = separator;
        }
        return htmlPaths.element(tagName, attributes, options);
      });
      return lop.rules.firstOf("html path", lop.rules.then(lop.rules.tokenOfType("bang"), function() {
        return htmlPaths.ignore;
      }), lop.rules.then(lop.rules.zeroOrMoreWithSeparator(styleElementRule, lop.rules.sequence(whitespaceRule, lop.rules.tokenOfType("gt"), whitespaceRule)), htmlPaths.elements));
    }
    var identifierRule = lop.rules.then(lop.rules.tokenOfType("identifier"), decodeEscapeSequences);
    var integerRule = lop.rules.tokenOfType("integer");
    var stringRule = lop.rules.then(lop.rules.tokenOfType("string"), decodeEscapeSequences);
    var escapeSequences = {
      "n": "\n",
      "r": "\r",
      "t": "	"
    };
    function decodeEscapeSequences(value) {
      return value.replace(/\\(.)/g, function(match, code) {
        return escapeSequences[code] || code;
      });
    }
    var attributeRule = lop.rules.sequence(lop.rules.tokenOfType("open-square-bracket"), lop.rules.sequence.cut(), lop.rules.sequence.capture(identifierRule), lop.rules.tokenOfType("equals"), lop.rules.sequence.capture(stringRule), lop.rules.tokenOfType("close-square-bracket")).map(function(name, value) {
      return {
        name,
        value,
        append: false
      };
    });
    var classRule = lop.rules.sequence(lop.rules.tokenOfType("dot"), lop.rules.sequence.cut(), lop.rules.sequence.capture(identifierRule)).map(function(className) {
      return {
        name: "class",
        value: className,
        append: true
      };
    });
    var attributeOrClassRule = lop.rules.firstOf("attribute or class", attributeRule, classRule);
    function parseString(rule, string) {
      var tokens = tokenise(string);
      var parser = lop.Parser();
      var parseResult = parser.parseTokens(rule, tokens);
      if (parseResult.isSuccess()) {
        return results.success(parseResult.value());
      } else {
        return new results.Result(null, [results.warning(describeFailure(string, parseResult))]);
      }
    }
    function describeFailure(input, parseResult) {
      return "Did not understand this style mapping, so ignored it: " + input + "\n" + parseResult.errors().map(describeError).join("\n");
    }
    function describeError(error) {
      return "Error was at character number " + error.characterNumber() + ": Expected " + error.expected + " but got " + error.actual;
    }
    var styleRule = createStyleRule();
  }
});

// node_modules/mammoth/lib/options-reader.js
var require_options_reader = __commonJS({
  "node_modules/mammoth/lib/options-reader.js"(exports2) {
    exports2.readOptions = readOptions;
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var defaultStyleMap = exports2._defaultStyleMap = [
      "p.Heading1 => h1:fresh",
      "p.Heading2 => h2:fresh",
      "p.Heading3 => h3:fresh",
      "p.Heading4 => h4:fresh",
      "p.Heading5 => h5:fresh",
      "p.Heading6 => h6:fresh",
      "p[style-name='Heading 1'] => h1:fresh",
      "p[style-name='Heading 2'] => h2:fresh",
      "p[style-name='Heading 3'] => h3:fresh",
      "p[style-name='Heading 4'] => h4:fresh",
      "p[style-name='Heading 5'] => h5:fresh",
      "p[style-name='Heading 6'] => h6:fresh",
      "p[style-name='heading 1'] => h1:fresh",
      "p[style-name='heading 2'] => h2:fresh",
      "p[style-name='heading 3'] => h3:fresh",
      "p[style-name='heading 4'] => h4:fresh",
      "p[style-name='heading 5'] => h5:fresh",
      "p[style-name='heading 6'] => h6:fresh",
      "r[style-name='Strong'] => strong",
      "p[style-name='footnote text'] => p:fresh",
      "r[style-name='footnote reference'] =>",
      "p[style-name='endnote text'] => p:fresh",
      "r[style-name='endnote reference'] =>",
      "p[style-name='annotation text'] => p:fresh",
      "r[style-name='annotation reference'] =>",
      // LibreOffice
      "p[style-name='Footnote'] => p:fresh",
      "r[style-name='Footnote anchor'] =>",
      "p[style-name='Endnote'] => p:fresh",
      "r[style-name='Endnote anchor'] =>",
      "p:unordered-list(1) => ul > li:fresh",
      "p:unordered-list(2) => ul|ol > li > ul > li:fresh",
      "p:unordered-list(3) => ul|ol > li > ul|ol > li > ul > li:fresh",
      "p:unordered-list(4) => ul|ol > li > ul|ol > li > ul|ol > li > ul > li:fresh",
      "p:unordered-list(5) => ul|ol > li > ul|ol > li > ul|ol > li > ul|ol > li > ul > li:fresh",
      "p:ordered-list(1) => ol > li:fresh",
      "p:ordered-list(2) => ul|ol > li > ol > li:fresh",
      "p:ordered-list(3) => ul|ol > li > ul|ol > li > ol > li:fresh",
      "p:ordered-list(4) => ul|ol > li > ul|ol > li > ul|ol > li > ol > li:fresh",
      "p:ordered-list(5) => ul|ol > li > ul|ol > li > ul|ol > li > ul|ol > li > ol > li:fresh",
      "r[style-name='Hyperlink'] =>",
      "p[style-name='Normal'] => p:fresh"
    ];
    var standardOptions = exports2._standardOptions = {
      transformDocument: identity2,
      includeDefaultStyleMap: true,
      includeEmbeddedStyleMap: true
    };
    function readOptions(options) {
      options = options || {};
      return _3.extend({}, standardOptions, options, {
        customStyleMap: readStyleMap(options.styleMap),
        readStyleMap: function() {
          var styleMap = this.customStyleMap;
          if (this.includeEmbeddedStyleMap) {
            styleMap = styleMap.concat(readStyleMap(this.embeddedStyleMap));
          }
          if (this.includeDefaultStyleMap) {
            styleMap = styleMap.concat(defaultStyleMap);
          }
          return styleMap;
        }
      });
    }
    function readStyleMap(styleMap) {
      if (!styleMap) {
        return [];
      } else if (_3.isString(styleMap)) {
        return styleMap.split("\n").map(function(line) {
          return line.trim();
        }).filter(function(line) {
          return line !== "" && line.charAt(0) !== "#";
        });
      } else {
        return styleMap;
      }
    }
    function identity2(value) {
      return value;
    }
  }
});

// node_modules/mammoth/browser/unzip.js
var require_unzip = __commonJS({
  "node_modules/mammoth/browser/unzip.js"(exports2) {
    var promises = require_promises();
    var zipfile = require_zipfile();
    exports2.openZip = openZip;
    function openZip(options) {
      if (options.arrayBuffer) {
        return promises.resolve(zipfile.openArrayBuffer(options.arrayBuffer));
      } else {
        return promises.reject(new Error("Could not find file in options"));
      }
    }
  }
});

// node_modules/mammoth/lib/transforms.js
var require_transforms = __commonJS({
  "node_modules/mammoth/lib/transforms.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    exports2.paragraph = paragraph;
    exports2.run = run;
    exports2._elements = elements;
    exports2.getDescendantsOfType = getDescendantsOfType;
    exports2.getDescendants = getDescendants;
    function paragraph(transform) {
      return elementsOfType("paragraph", transform);
    }
    function run(transform) {
      return elementsOfType("run", transform);
    }
    function elementsOfType(elementType, transform) {
      return elements(function(element) {
        if (element.type === elementType) {
          return transform(element);
        } else {
          return element;
        }
      });
    }
    function elements(transform) {
      return function transformElement(element) {
        if (element.children) {
          var children = _3.map(element.children, transformElement);
          element = _3.extend(element, {
            children
          });
        }
        return transform(element);
      };
    }
    function getDescendantsOfType(element, type) {
      return getDescendants(element).filter(function(descendant) {
        return descendant.type === type;
      });
    }
    function getDescendants(element) {
      var descendants = [];
      visitDescendants(element, function(descendant) {
        descendants.push(descendant);
      });
      return descendants;
    }
    function visitDescendants(element, visit) {
      if (element.children) {
        element.children.forEach(function(child) {
          visitDescendants(child, visit);
          visit(child);
        });
      }
    }
  }
});

// node_modules/mammoth/lib/underline.js
var require_underline = __commonJS({
  "node_modules/mammoth/lib/underline.js"(exports2) {
    var htmlPaths = require_html_paths();
    var Html = require_html();
    exports2.element = element;
    function element(name) {
      return function(html) {
        return Html.elementWithTag(htmlPaths.element(name), [html]);
      };
    }
  }
});

// node_modules/mammoth/lib/index.js
var require_lib3 = __commonJS({
  "node_modules/mammoth/lib/index.js"(exports2) {
    var _3 = (init_index_all(), __toCommonJS(index_all_exports));
    var docxReader = require_docx_reader();
    var docxStyleMap = require_style_map();
    var DocumentConverter = require_document_to_html().DocumentConverter;
    var convertElementToRawText = require_raw_text().convertElementToRawText;
    var readStyle = require_style_reader().readStyle;
    var readOptions = require_options_reader().readOptions;
    var unzip2 = require_unzip();
    var Result = require_results().Result;
    exports2.convertToHtml = convertToHtml;
    exports2.convertToMarkdown = convertToMarkdown;
    exports2.convert = convert;
    exports2.extractRawText = extractRawText;
    exports2.images = require_images();
    exports2.transforms = require_transforms();
    exports2.underline = require_underline();
    exports2.embedStyleMap = embedStyleMap;
    exports2.readEmbeddedStyleMap = readEmbeddedStyleMap;
    function convertToHtml(input, options) {
      return convert(input, options);
    }
    function convertToMarkdown(input, options) {
      var markdownOptions = Object.create(options || {});
      markdownOptions.outputFormat = "markdown";
      return convert(input, markdownOptions);
    }
    function convert(input, options) {
      options = readOptions(options);
      return unzip2.openZip(input).tap(function(docxFile) {
        return docxStyleMap.readStyleMap(docxFile).then(function(styleMap) {
          options.embeddedStyleMap = styleMap;
        });
      }).then(function(docxFile) {
        return docxReader.read(docxFile, input).then(function(documentResult) {
          return documentResult.map(options.transformDocument);
        }).then(function(documentResult) {
          return convertDocumentToHtml(documentResult, options);
        });
      });
    }
    function readEmbeddedStyleMap(input) {
      return unzip2.openZip(input).then(docxStyleMap.readStyleMap);
    }
    function convertDocumentToHtml(documentResult, options) {
      var styleMapResult = parseStyleMap(options.readStyleMap());
      var parsedOptions = _3.extend({}, options, {
        styleMap: styleMapResult.value
      });
      var documentConverter = new DocumentConverter(parsedOptions);
      return documentResult.flatMapThen(function(document2) {
        return styleMapResult.flatMapThen(function(styleMap) {
          return documentConverter.convertToHtml(document2);
        });
      });
    }
    function parseStyleMap(styleMap) {
      return Result.combine((styleMap || []).map(readStyle)).map(function(styleMap2) {
        return styleMap2.filter(function(styleMapping) {
          return !!styleMapping;
        });
      });
    }
    function extractRawText(input) {
      return unzip2.openZip(input).then(docxReader.read).then(function(documentResult) {
        return documentResult.map(convertElementToRawText);
      });
    }
    function embedStyleMap(input, styleMap) {
      return unzip2.openZip(input).tap(function(docxFile) {
        return docxStyleMap.writeStyleMap(docxFile, styleMap);
      }).then(function(docxFile) {
        return docxFile.toArrayBuffer();
      }).then(function(arrayBuffer) {
        return {
          toArrayBuffer: function() {
            return arrayBuffer;
          },
          toBuffer: function() {
            return Buffer.from(arrayBuffer);
          }
        };
      });
    }
    exports2.styleMapping = function() {
      throw new Error(`Use a raw string instead of mammoth.styleMapping e.g. "p[style-name='Title'] => h1" instead of mammoth.styleMapping("p[style-name='Title'] => h1")`);
    };
  }
});
export default require_lib3();
/*! Bundled license information:

jszip/dist/jszip.min.js:
  (*!
  
  JSZip v3.10.1 - A JavaScript class for generating and reading zip files
  <http://stuartk.com/jszip>
  
  (c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
  Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.
  
  JSZip uses the library pako released under the MIT license :
  https://github.com/nodeca/pako/blob/main/LICENSE
  *)
*/
//# sourceMappingURL=mammoth.js.map
