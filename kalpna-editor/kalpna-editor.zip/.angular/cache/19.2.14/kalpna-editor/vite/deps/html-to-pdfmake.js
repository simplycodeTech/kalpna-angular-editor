import {
  __commonJS
} from "./chunk-WXPTAMPH.js";

// node_modules/html-to-pdfmake/index.js
var require_html_to_pdfmake = __commonJS({
  "node_modules/html-to-pdfmake/index.js"(exports, module) {
    function htmlToPdfMake(htmlText, options) {
      "use strict";
      this.wndw = options && options.window ? options.window : window;
      this.tableAutoSize = options && typeof options.tableAutoSize === "boolean" ? options.tableAutoSize : false;
      this.imagesByReference = options && typeof options.imagesByReference === "boolean" ? options.imagesByReference : false;
      this.removeExtraBlanks = options && typeof options.removeExtraBlanks === "boolean" ? options.removeExtraBlanks : false;
      this.showHidden = options && typeof options.showHidden === "boolean" ? options.showHidden : false;
      this.removeTagClasses = options && typeof options.removeTagClasses === "boolean" ? options.removeTagClasses : false;
      this.ignoreStyles = options && Array.isArray(options.ignoreStyles) ? options.ignoreStyles : [];
      var imagesByReferenceSuffix = Math.random().toString(36).slice(2, 8);
      this.fontSizes = options && Array.isArray(options.fontSizes) ? options.fontSizes : [10, 14, 16, 18, 20, 24, 28];
      this.defaultStyles = {
        b: {
          bold: true
        },
        strong: {
          bold: true
        },
        u: {
          decoration: "underline"
        },
        del: {
          decoration: "lineThrough"
        },
        s: {
          decoration: "lineThrough"
        },
        em: {
          italics: true
        },
        i: {
          italics: true
        },
        h1: {
          fontSize: 24,
          bold: true,
          marginBottom: 5
        },
        h2: {
          fontSize: 22,
          bold: true,
          marginBottom: 5
        },
        h3: {
          fontSize: 20,
          bold: true,
          marginBottom: 5
        },
        h4: {
          fontSize: 18,
          bold: true,
          marginBottom: 5
        },
        h5: {
          fontSize: 16,
          bold: true,
          marginBottom: 5
        },
        h6: {
          fontSize: 14,
          bold: true,
          marginBottom: 5
        },
        a: {
          color: "blue",
          decoration: "underline"
        },
        strike: {
          decoration: "lineThrough"
        },
        p: {
          margin: [0, 5, 0, 10]
        },
        ul: {
          marginBottom: 5,
          marginLeft: 5
        },
        table: {
          marginBottom: 5
        },
        th: {
          bold: true,
          fillColor: "#EEEEEE"
        }
      };
      this.imagesRef = [];
      this.changeDefaultStyles = function() {
        for (var keyStyle in options.defaultStyles) {
          if (this.defaultStyles.hasOwnProperty(keyStyle)) {
            if (options.defaultStyles.hasOwnProperty(keyStyle) && !options.defaultStyles[keyStyle]) {
              delete this.defaultStyles[keyStyle];
            } else {
              for (var k in options.defaultStyles[keyStyle]) {
                if (options.defaultStyles[keyStyle][k] === "") delete this.defaultStyles[keyStyle][k];
                else this.defaultStyles[keyStyle][k] = options.defaultStyles[keyStyle][k];
              }
            }
          } else {
            this.defaultStyles[keyStyle] = {};
            for (var ks in options.defaultStyles[keyStyle]) {
              this.defaultStyles[keyStyle][ks] = options.defaultStyles[keyStyle][ks];
            }
          }
        }
      };
      if (options && options.defaultStyles) {
        this.changeDefaultStyles();
      }
      this.convertHtml = function(htmlText2) {
        var parser = new this.wndw.DOMParser();
        if (this.removeExtraBlanks) htmlText2 = htmlText2.replace(/(<\/?(div|p|h1|h2|h3|h4|h5|h6|ol|ul|li)([^>]+)?>)\s+(<\/?(div|p|h1|h2|h3|h4|h5|h6|ol|ul|li))/gi, "$1$4").replace(/(<\/?(div|p|h1|h2|h3|h4|h5|h6|ol|ul|li)([^>]+)?>)\s+(<\/?(div|p|h1|h2|h3|h4|h5|h6|ol|ul|li))/gi, "$1$4").replace(/(<td([^>]+)?>)\s+(<table)/gi, "$1$3").replace(/(<\/table>)\s+(<\/td>)/gi, "$1$2");
        var parsedHtml = parser.parseFromString(htmlText2, "text/html");
        var docDef = this.parseElement(parsedHtml.body, []);
        return docDef.stack || docDef.text;
      };
      this.parseElement = function(element, parents) {
        var nodeName = element.nodeName.toUpperCase();
        var nodeNameLowerCase = nodeName.toLowerCase();
        var ret = {
          text: []
        };
        var text, needStack = false;
        var dataset, i, key, _this = this;
        if (["COLGROUP", "COL"].indexOf(nodeName) > -1) return "";
        switch (element.nodeType) {
          case 3: {
            if (element.textContent) {
              text = element.textContent;
              var styleParentTextNode = this.parseStyle(parents[parents.length - 1], true);
              var hasWhiteSpace = parents.findIndex(function(p) {
                return p.nodeName === "PRE";
              }) > -1;
              for (i = 0; i < styleParentTextNode.length; i++) {
                if (styleParentTextNode[i].key === "preserveLeadingSpaces") {
                  hasWhiteSpace = styleParentTextNode[i].value;
                  break;
                }
              }
              if (!hasWhiteSpace) text = text.replace(/\s*\n\s*/g, " ");
              if (options && typeof options.replaceText === "function") text = options.replaceText(text, parents);
              if (["TABLE", "THEAD", "TBODY", "TFOOT", "TR", "UL", "OL"].indexOf(parents[parents.length - 1].nodeName) > -1) text = text.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
              if (text) {
                ret = {
                  "text": text
                };
                ret = this.applyStyle({
                  ret,
                  parents
                });
                return ret;
              }
            }
            return "";
          }
          case 1: {
            if (!this.showHidden && element.style.display && element.style.display === "none" || element.style.visibility && element.style.visibility === "hidden") {
              return;
            }
            ret.nodeName = nodeName;
            if (element.id) ret.id = element.id;
            parents.push(element);
            if (element.childNodes && element.childNodes.length > 0) {
              [].forEach.call(element.childNodes, function(child2) {
                var res = _this.parseElement(child2, parents);
                if (res) {
                  if (Array.isArray(res.text) && res.text.length === 0) res.text = "";
                  ret.text.push(res);
                }
              });
              needStack = this.searchForStack(ret);
              if (needStack) {
                ret.stack = ret.text.slice(0);
                delete ret.text;
              } else {
                ret = this.applyStyle({
                  ret,
                  parents
                });
              }
            }
            parents.pop();
            switch (nodeName) {
              case "TABLE": {
                var rowIndex;
                ret.table = {
                  body: []
                };
                var tbodies = ret.stack || ret.text;
                if (Array.isArray(tbodies)) {
                  rowIndex = 0;
                  var hasRowSpan = false;
                  tbodies.forEach(function(tbody) {
                    var rows = tbody.stack || tbody.text;
                    if (Array.isArray(rows)) {
                      rows.forEach(function(row2) {
                        var cells = row2.stack || row2.text;
                        if (Array.isArray(cells)) {
                          ret.table.body[rowIndex] = [];
                          cells.forEach(function(cell2) {
                            ret.table.body[rowIndex].push(cell2);
                            if (cell2.colSpan > 1) {
                              i = cell2.colSpan;
                              while (--i > 0) {
                                ret.table.body[rowIndex].push({
                                  text: ""
                                });
                              }
                            }
                            if (cell2.rowSpan > 1) hasRowSpan = true;
                          });
                          rowIndex++;
                        }
                      });
                    }
                  });
                  if (hasRowSpan) {
                    var header = ret.table.body[0];
                    if (Array.isArray(header)) {
                      var columnsCount = header.length;
                      var rowsCount = ret.table.body.length;
                      for (var columnInd = 0; columnInd < columnsCount; columnInd++) {
                        for (var rowInd = 0; rowInd < rowsCount; rowInd++) {
                          var row = ret.table.body[rowInd];
                          if (Array.isArray(row)) {
                            var cell = row[columnInd];
                            if (cell.rowSpan > 1) {
                              var len = cell.rowSpan;
                              var cs, colspan = cell.colSpan ? cell.colSpan : 1;
                              for (var j = 1; j <= len - 1; j++) {
                                cs = colspan;
                                if (ret.table.body[rowInd + j]) {
                                  while (cs--) ret.table.body[rowInd + j].splice(columnInd, 0, {
                                    text: ""
                                  });
                                } else {
                                  cell.rowSpan--;
                                }
                              }
                              rowInd += len - 1;
                            }
                          }
                        }
                      }
                    }
                  }
                }
                delete ret.stack;
                delete ret.text;
                ret = this.applyStyle({
                  ret,
                  parents: parents.concat([element])
                });
                if (this.tableAutoSize) {
                  var cellsWidths = [];
                  var cellsHeights = [];
                  var tableWidths = [];
                  var tableHeights = [];
                  var fullWidth = element.getAttribute("width") === "100%" || element.style.width === "100%";
                  var elementAttrWidth = element.getAttribute("width") || "";
                  var tableHaveWidth = (element.style.width || elementAttrWidth).endsWith("%");
                  if (tableHaveWidth) {
                    var tableWidth = (element.style.width || elementAttrWidth).replace(/[^0-9.]/g, "");
                  }
                  var tableHaveColgroup = false;
                  var tableColgroupIndex = -1;
                  for (var x = 0; x < element.children.length; x++) {
                    var child = element.children[x];
                    if (!tableHaveColgroup) tableColgroupIndex++;
                    if (child.nodeName.toUpperCase() === "COLGROUP") tableHaveColgroup = true;
                  }
                  ;
                  ret.table.body.forEach(function(row2, rowIndex2) {
                    cellsWidths.push([]);
                    cellsHeights.push([]);
                    row2.forEach(function(cell2, cellIndex) {
                      var width = typeof cell2.width !== "undefined" ? cell2.width : "auto";
                      if (width === "*") width = "auto";
                      var height = typeof cell2.height !== "undefined" ? cell2.height : "auto";
                      if (height === "*") height = "auto";
                      if (width !== "auto" && cell2.colSpan > 1) {
                        if (!isNaN(width)) width /= cell2.colSpan;
                        else width = "auto";
                      }
                      if (height !== "auto" && cell2.rowSpan > 1) {
                        if (!isNaN(height)) height /= cell2.rowSpan;
                        else height = "auto";
                      }
                      if (tableHaveColgroup) {
                        var colGroups = element.children[tableColgroupIndex];
                        var colElement = colGroups.children[cellIndex];
                        if (colElement) {
                          var colAttrWidth = colElement.getAttribute("width") || "";
                          var colStyleWidth = colElement.style.width;
                          if ((colAttrWidth || colStyleWidth).endsWith("%")) {
                            width = colAttrWidth || colStyleWidth;
                          }
                        }
                      }
                      cellsWidths[rowIndex2].push(width);
                      cellsHeights[rowIndex2].push(height);
                    });
                  });
                  cellsWidths.forEach(function(row2) {
                    row2.forEach(function(cellWidth, cellIndex) {
                      var type = typeof tableWidths[cellIndex];
                      if (type === "undefined" || cellWidth !== "auto" && type === "number" && cellWidth > tableWidths[cellIndex] || cellWidth !== "auto" && tableWidths[cellIndex] === "auto") {
                        if (tableHaveWidth) {
                          var cellPercentage = cellWidth === "auto" ? tableWidth / row2.length : cellWidth.toString().replace("%", "") * tableWidth / 100;
                          cellWidth = String(cellPercentage) + "%";
                        }
                        tableWidths[cellIndex] = cellWidth;
                      }
                    });
                  });
                  cellsHeights.forEach(function(row2, rowIndex2) {
                    row2.forEach(function(cellHeight) {
                      var type = typeof tableHeights[rowIndex2];
                      if (type === "undefined" || cellHeight !== "auto" && type === "number" && cellHeight > tableHeights[rowIndex2] || cellHeight !== "auto" && tableHeights[rowIndex2] === "auto") {
                        tableHeights[rowIndex2] = cellHeight;
                      }
                    });
                  });
                  if (tableWidths.length > 0) {
                    if (fullWidth) tableWidths = tableWidths.map(function(w) {
                      return w === "auto" ? "*" : w;
                    });
                    ret.table.widths = tableWidths;
                  }
                  if (tableHeights.length > 0) ret.table.heights = tableHeights;
                }
                if (element.dataset && element.dataset.pdfmake) {
                  dataset = element.dataset.pdfmake.replace(/'/g, '"');
                  try {
                    dataset = JSON.parse(dataset);
                    for (key in dataset) {
                      if (key === "layout") {
                        ret.layout = dataset[key];
                      } else {
                        ret.table[key] = dataset[key];
                      }
                    }
                  } catch (e) {
                    console.error(e);
                  }
                }
                break;
              }
              case "TH":
              case "TD": {
                if (element.getAttribute("rowspan")) ret.rowSpan = element.getAttribute("rowspan") * 1;
                if (element.getAttribute("colspan")) ret.colSpan = element.getAttribute("colspan") * 1;
                ret = this.applyStyle({
                  ret,
                  parents: parents.concat([element])
                });
                break;
              }
              case "SVG": {
                ret = {
                  svg: element.outerHTML.replace(/\n(\s+)?/g, ""),
                  nodeName: "SVG"
                };
                if (!this.removeTagClasses) ret.style = ["html-svg"];
                break;
              }
              case "BR": {
                ret.text = [{
                  text: "\n"
                }];
                break;
              }
              case "SUB":
              case "SUP": {
                ret[nodeName.toLowerCase()] = {
                  offset: "30%",
                  fontSize: 8
                };
                break;
              }
              case "HR": {
                var styleHR = {
                  width: 514,
                  type: "line",
                  margin: [0, 12, 0, 12],
                  thickness: 0.5,
                  color: "#000000",
                  left: 0
                };
                if (element.dataset && element.dataset.pdfmake) {
                  dataset = element.dataset.pdfmake.replace(/'/g, '"');
                  try {
                    dataset = JSON.parse(dataset);
                    for (key in dataset) {
                      styleHR[key] = dataset[key];
                    }
                  } catch (e) {
                    console.error(e);
                  }
                }
                ret.margin = styleHR.margin;
                ret.canvas = [{
                  type: styleHR.type,
                  x1: styleHR.left,
                  y1: 0,
                  x2: styleHR.width,
                  y2: 0,
                  lineWidth: styleHR.thickness,
                  lineColor: styleHR.color
                }];
                delete ret.text;
                break;
              }
              case "OL":
              case "UL": {
                ret[nodeNameLowerCase] = (ret.stack || ret.text).slice(0);
                delete ret.stack;
                delete ret.text;
                ret = this.applyStyle({
                  ret,
                  parents: parents.concat([element])
                });
                if (element.getAttribute("start")) {
                  ret.start = element.getAttribute("start") * 1;
                }
                switch (element.getAttribute("type")) {
                  case "A":
                    ret.type = "upper-alpha";
                    break;
                  case "a":
                    ret.type = "lower-alpha";
                    break;
                  case "I":
                    ret.type = "upper-roman";
                    break;
                  case "i":
                    ret.type = "lower-roman";
                    break;
                }
                if (ret.listStyle || ret.listStyleType) ret.type = ret.listStyle || ret.listStyleType;
                break;
              }
              case "LI": {
                if (ret.stack && !ret.stack[ret.stack.length - 1].text) {
                  text = ret.stack.slice(0, -1);
                  ret = [
                    {
                      "text": text
                    },
                    // (Array.isArray(text) ? {"stack": text} : {"text": text}),
                    ret.stack[ret.stack.length - 1]
                  ];
                }
                if (Array.isArray(ret)) {
                  ret = {
                    stack: ret
                  };
                }
                break;
              }
              case "PRE": {
                ret.preserveLeadingSpaces = true;
                break;
              }
              case "IMG": {
                if (this.imagesByReference) {
                  var src = element.getAttribute("data-src") || element.getAttribute("src");
                  var index = this.imagesRef.indexOf(src);
                  if (index > -1) ret.image = "img_ref_" + imagesByReferenceSuffix + index;
                  else {
                    ret.image = "img_ref_" + imagesByReferenceSuffix + this.imagesRef.length;
                    this.imagesRef.push(src);
                  }
                } else {
                  ret.image = element.getAttribute("src");
                }
                delete ret.stack;
                delete ret.text;
                ret = this.applyStyle({
                  ret,
                  parents: parents.concat([element])
                });
                break;
              }
              case "A": {
                var setLink = function(pointer, href) {
                  pointer = pointer || {
                    text: ""
                  };
                  if (Array.isArray(pointer.text)) {
                    pointer.text = pointer.text.map(function(text2) {
                      return setLink(text2, href);
                    });
                    return pointer;
                  } else if (Array.isArray(pointer.stack)) {
                    pointer.stack = pointer.stack.map(function(stack) {
                      return setLink(stack, href);
                    });
                    return pointer;
                  }
                  if (href.indexOf("#") === 0) pointer.linkToDestination = href.slice(1);
                  else pointer.link = href;
                  return pointer;
                };
                if (element.getAttribute("href")) {
                  ret = setLink(ret, element.getAttribute("href"));
                  if (Array.isArray(ret.text) && ret.text.length === 1) ret = ret.text[0];
                  ret.nodeName = "A";
                }
                break;
              }
              default: {
                if (nodeName === "DIV" && element.dataset && element.dataset.pdfmakeType === "columns") {
                  if (ret.stack) {
                    ret.columns = ret.stack;
                    delete ret.stack;
                  }
                } else if (options && typeof options.customTag === "function") {
                  ret = options.customTag.call(this, {
                    element,
                    parents,
                    ret
                  });
                }
              }
            }
            if (Array.isArray(ret.text) && ret.text.length === 1 && ret.text[0].text && !ret.text[0].nodeName) {
              ret.text = ret.text[0].text;
            }
            if (["HR", "TABLE"].indexOf(nodeName) === -1 && element.dataset && element.dataset.pdfmake) {
              dataset = element.dataset.pdfmake.replace(/'/g, '"');
              try {
                dataset = JSON.parse(dataset);
                for (key in dataset) {
                  ret[key] = dataset[key];
                }
              } catch (e) {
                console.error(e);
              }
            }
            return ret;
          }
        }
      };
      this.searchForStack = function(ret) {
        if (Array.isArray(ret.text)) {
          for (var i = 0; i < ret.text.length; i++) {
            if (ret.text[i].stack || ["P", "DIV", "TABLE", "SVG", "UL", "OL", "IMG", "H1", "H2", "H3", "H4", "H5", "H6"].indexOf(ret.text[i].nodeName) > -1) return true;
            if (this.searchForStack(ret.text[i]) === true) return true;
          }
        }
        return false;
      };
      this.applyStyle = function(params) {
        var cssClass = [];
        var lastIndex = params.parents.length - 1;
        var _this = this;
        params.parents.forEach(function(parent, parentIndex) {
          var parentNodeName = parent.nodeName.toLowerCase();
          if (!_this.removeTagClasses) {
            var htmlClass = "html-" + parentNodeName;
            if (htmlClass !== "html-body" && cssClass.indexOf(htmlClass) === -1) cssClass.unshift(htmlClass);
          }
          var parentClass = (parent.getAttribute("class") || "").split(" ");
          parentClass.forEach(function(p) {
            if (p) cssClass.push(p);
          });
          var style;
          var ignoreNonDescendentProperties = parentIndex !== lastIndex;
          if (_this.defaultStyles[parentNodeName]) {
            for (style in _this.defaultStyles[parentNodeName]) {
              if (_this.defaultStyles[parentNodeName].hasOwnProperty(style)) {
                if (!ignoreNonDescendentProperties || ignoreNonDescendentProperties && style.indexOf("margin") === -1 && style.indexOf("border") === -1) {
                  if (style === "decoration") {
                    if (!Array.isArray(params.ret[style])) params.ret[style] = [];
                    if (params.ret[style].indexOf(_this.defaultStyles[parentNodeName][style]) === -1) {
                      params.ret[style].push(_this.defaultStyles[parentNodeName][style]);
                    }
                  } else {
                    params.ret[style] = JSON.parse(JSON.stringify(_this.defaultStyles[parentNodeName][style]));
                  }
                }
              }
            }
          }
          if (parentNodeName === "tr") ignoreNonDescendentProperties = false;
          style = _this.parseStyle(parent, ignoreNonDescendentProperties);
          style.forEach(function(stl) {
            if (stl.key === "decoration") {
              if (!Array.isArray(params.ret[stl.key])) params.ret[stl.key] = [];
              params.ret[stl.key].push(stl.value);
            } else if (["UL", "OL"].includes(params.ret.nodeName) && stl.key === "alignment") {
            } else {
              if (params.ret.margin && stl.key.indexOf("margin") === 0) {
                switch (stl.key) {
                  case "marginLeft":
                    params.ret.margin[0] = stl.value;
                    break;
                  case "marginTop":
                    params.ret.margin[1] = stl.value;
                    break;
                  case "marginRight":
                    params.ret.margin[2] = stl.value;
                    break;
                  case "marginBottom":
                    params.ret.margin[3] = stl.value;
                    break;
                }
              } else {
                params.ret[stl.key] = stl.value;
              }
            }
          });
        });
        if (cssClass.length > 0) params.ret.style = cssClass;
        return params.ret;
      };
      this.borderValueRearrange = function(styleStr) {
        try {
          var styleArray = styleStr.split(" ");
          if (styleArray.length !== 3) return styleStr;
          var v1 = "0px", v2 = "none", v3 = "transparent";
          var style = ["dotted", "dashed", "solid", "double", "groove", "ridge", "inset", "outset", "none", "hidden", "mix"];
          styleArray.forEach(function(v) {
            if (v.match(/^\d/)) {
              v1 = v;
            } else if (style.indexOf(v) > -1) {
              v2 = v;
            } else {
              v3 = v;
            }
          });
          return v1 + " " + v2 + " " + v3;
        } catch (e) {
          return styleStr;
        }
      };
      this.parseStyle = function(element, ignoreProperties) {
        var style = element.getAttribute("style") || "";
        var ret = [];
        style = style.replace(/!important/g, "").split(";");
        var width = element.getAttribute("width");
        var height = element.getAttribute("height");
        if (width) {
          style.unshift("width:" + this.convertToUnit(width + (isNaN(width) ? "" : "px")));
        }
        if (height) {
          style.unshift("height:" + this.convertToUnit(height + (isNaN(height) ? "" : "px")));
        }
        var color = element.getAttribute("color");
        if (color) {
          ret.push({
            key: "color",
            value: this.parseColor(color).color
          });
        }
        var size = element.getAttribute("size");
        if (size !== null) {
          size = Math.min(Math.max(1, parseInt(size)), 7);
          ret.push({
            key: "fontSize",
            value: Math.max(this.fontSizes[0], this.fontSizes[size - 1])
          });
        }
        var styleDefs = style.map(function(style2) {
          return style2.toLowerCase().split(":");
        });
        var borders = [];
        var nodeName = element.nodeName.toUpperCase();
        var _this = this;
        styleDefs.forEach(function(styleDef) {
          if (styleDef.length === 2) {
            var key = styleDef[0].trim().toLowerCase();
            var value = styleDef[1].trim();
            var res;
            if (_this.ignoreStyles.indexOf(key) === -1) {
              switch (key) {
                case "margin": {
                  if (ignoreProperties) break;
                  value = value.split(" ");
                  if (value.length === 1) value = [value[0], value[0], value[0], value[0]];
                  else if (value.length === 2) value = [value[1], value[0]];
                  else if (value.length === 3) value = [value[1], value[0], value[1], value[2]];
                  else if (value.length === 4) value = [value[3], value[0], value[1], value[2]];
                  value.forEach(function(val, i2) {
                    if (val === "auto") value[i2] = "";
                    else value[i2] = _this.convertToUnit(val);
                  });
                  if (value.indexOf(false) === -1) ret.push({
                    key,
                    value
                  });
                  break;
                }
                case "line-height": {
                  if (typeof value === "string" && value.slice(-1) === "%") {
                    value = value.slice(0, -1) / 100;
                  } else {
                    value = _this.convertToUnit(value);
                  }
                  ret.push({
                    key: "lineHeight",
                    value
                  });
                  break;
                }
                case "text-align": {
                  ret.push({
                    key: "alignment",
                    value
                  });
                  break;
                }
                case "font-weight": {
                  if (value === "bold") ret.push({
                    key: "bold",
                    value: true
                  });
                  break;
                }
                case "text-decoration": {
                  value = _this.toCamelCase(value);
                  if (["underline", "lineThrough", "overline"].includes(value)) {
                    ret.push({
                      key: "decoration",
                      value
                    });
                  }
                  break;
                }
                case "font-style": {
                  if (value === "italic") ret.push({
                    key: "italics",
                    value: true
                  });
                  break;
                }
                case "font-family": {
                  ret.push({
                    key: "font",
                    value: value.split(",")[0].replace(/"|^'|^\s*|\s*$|'$/g, "").replace(/^([a-z])/g, function(g) {
                      return g[0].toUpperCase();
                    }).replace(/ ([a-z])/g, function(g) {
                      return g[1].toUpperCase();
                    })
                  });
                  break;
                }
                case "color": {
                  res = _this.parseColor(value);
                  ret.push({
                    key: "color",
                    value: res.color
                  });
                  if (res.opacity < 1) ret.push({
                    key: "opacity",
                    value: res.opacity
                  });
                  break;
                }
                case "background-color": {
                  res = _this.parseColor(value);
                  ret.push({
                    key: nodeName === "TD" || nodeName === "TH" ? "fillColor" : "background",
                    value: res.color
                  });
                  if (res.opacity < 1) ret.push({
                    key: nodeName === "TD" || nodeName === "TH" ? "fillOpacity" : "opacity",
                    value: res.opacity
                  });
                  break;
                }
                case "text-indent": {
                  ret.push({
                    key: "leadingIndent",
                    value: _this.convertToUnit(value)
                  });
                  break;
                }
                case "white-space": {
                  if (value === "nowrap") {
                    ret.push({
                      key: "noWrap",
                      value: true
                    });
                  } else {
                    ret.push({
                      key: "preserveLeadingSpaces",
                      value: value === "break-spaces" || value.slice(0, 3) === "pre"
                    });
                  }
                  break;
                }
                default: {
                  if (key.indexOf("border") === 0) {
                    if (!ignoreProperties) borders.push({
                      key,
                      value
                    });
                  } else {
                    if (ignoreProperties && (key.indexOf("margin-") === 0 || key === "width" || key === "height")) break;
                    if (nodeName === "IMG" && (key === "width" || key === "height")) {
                      ret.push({
                        key,
                        value: _this.convertToUnit(value)
                      });
                      break;
                    }
                    if (key.indexOf("padding") === 0) break;
                    if (key.indexOf("-") > -1) key = _this.toCamelCase(key);
                    if (value) {
                      var parsedValue = _this.convertToUnit(value);
                      if (key === "fontSize" && parsedValue === false) {
                        if (["xx-small", "x-small", "small", "medium", "large", "x-large", "xx-large", "xxx-large"].includes(value)) {
                          switch (value) {
                            case "xx-small":
                              value = 7.2;
                              break;
                            // 60%
                            case "x-small":
                              value = 9;
                              break;
                            // 75%
                            case "small":
                              value = 10.7;
                              break;
                            // 89%
                            case "medium":
                              value = 12;
                              break;
                            case "large":
                              value = 14.4;
                              break;
                            // 120%
                            case "x-large":
                              value = 18;
                              break;
                            // 150%
                            case "xx-large":
                              value = 24;
                              break;
                            // 200%
                            case "xxx-large":
                              value = 36;
                              break;
                          }
                        } else {
                          break;
                        }
                      }
                      if (key.indexOf("margin") === 0 && value === "auto") break;
                      ret.push({
                        key,
                        value: parsedValue === false ? value : parsedValue
                      });
                    }
                  }
                }
              }
            }
          }
        });
        if (borders.length > 0) {
          var border = [];
          var borderColor = [];
          borders.forEach(function(b) {
            var index = -1, i2;
            if (b.key.indexOf("-left") > -1) index = 0;
            else if (b.key.indexOf("-top") > -1) index = 1;
            else if (b.key.indexOf("-right") > -1) index = 2;
            else if (b.key.indexOf("-bottom") > -1) index = 3;
            var splitKey = b.key.split("-"), properties, width2;
            if (splitKey.length === 1 || splitKey.length === 2 && index >= 0) {
              b.value = _this.borderValueRearrange(b.value);
              properties = b.value.split(" ");
              width2 = properties[0].replace(/(\d*)(\.\d+)?([^\d]+)/g, "$1$2 ").trim();
              if (index > -1) {
                border[index] = width2 > 0;
              } else {
                for (i2 = 0; i2 < 4; i2++) border[i2] = width2 > 0;
              }
              if (properties.length > 2) {
                var color2 = properties.slice(2).join(" ");
                if (index > -1) {
                  borderColor[index] = _this.parseColor(color2).color;
                } else {
                  for (i2 = 0; i2 < 4; i2++) borderColor[i2] = _this.parseColor(color2).color;
                }
              }
            } else if (index >= 0 && splitKey[2] === "color") {
              borderColor[index] = _this.parseColor(b.value).color;
            } else if (index >= 0 && splitKey[2] === "width") {
              border[index] = !/^0[a-z%]*$/.test(String(b.value));
            } else if (b.key === "border-color") {
              properties = _this.topRightBottomLeftToObject(b.value);
              borderColor = [_this.parseColor(properties.left).color, _this.parseColor(properties.top).color, _this.parseColor(properties.right).color, _this.parseColor(properties.bottom).color];
            } else if (b.key === "border-width") {
              properties = _this.topRightBottomLeftToObject(b.value);
              border = [!/^0[a-z%]*$/.test(properties.left), !/^0[a-z%]*$/.test(properties.top), !/^0[a-z%]*$/.test(properties.right), !/^0[a-z%]*$/.test(properties.bottom)];
            }
          });
          for (var i = 0; i < 4; i++) {
            if (border.length > 0 && typeof border[i] === "undefined") border[i] = true;
            if (borderColor.length > 0 && typeof borderColor[i] === "undefined") borderColor[i] = "#000000";
          }
          if (border.length > 0) ret.push({
            key: "border",
            value: border
          });
          if (borderColor.length > 0) ret.push({
            key: "borderColor",
            value: borderColor
          });
        }
        return ret;
      };
      this.toCamelCase = function(str) {
        return str.replace(/-([a-z])/g, function(g) {
          return g[1].toUpperCase();
        });
      };
      this.topRightBottomLeftToObject = function(props) {
        var colorRegex = /#[0-9a-fA-F]{3,6}|\b(?:rgba?|hsla?)\([^)]*\)|\b[a-zA-Z]+\b/g;
        var colors = props.match(colorRegex) || [];
        var top = colors[0], right = colors[1], bottom = colors[2], left = colors[3];
        switch (colors.length) {
          case 1:
            right = bottom = left = top;
            break;
          case 2:
            bottom = top;
            left = right;
            break;
          case 3:
            left = right;
            break;
        }
        return {
          top,
          right,
          bottom,
          left
        };
      };
      this.hsl2rgb = function(h, s, l) {
        var a = s * Math.min(l, 1 - l);
        var f = function(n) {
          var k = (n + h / 30) % 12;
          return Math.min(Math.floor((l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1)) * 256), 255);
        };
        return "rgb(" + f(0) + "," + f(8) + "," + f(4) + ")";
      };
      this.parseColor = function(color) {
        var opacity = 1;
        var haxRegex = new RegExp("^#([0-9a-f]{3}|[0-9a-f]{6})$", "i");
        var rgbRegex = /^rgba?\(\s*(\d+(\.\d+)?%?),\s*(\d+(\.\d+)?%?),\s*(\d+(\.\d+)?%?)(,\s*\d+(\.\d+)?)?\)$/;
        var hslRegex = new RegExp("^hsl\\((\\d+(\\.\\d+)?%?),\\s*(\\d+(\\.\\d+)?%?),\\s*(\\d+(\\.\\d+)?%?)\\)$");
        var nameRegex = new RegExp("^[a-z]+$", "i");
        var decimalColors, decimalValue, hexString, ret = [];
        if (haxRegex.test(color)) {
          return {
            color,
            opacity
          };
        }
        if (hslRegex.test(color)) {
          decimalColors = hslRegex.exec(color).slice(1);
          if (decimalColors[0].endsWith("%")) decimalValue = decimalColors[0].slice(0, -1) * 360 / 100;
          else decimalValue = decimalColors[0] * 1;
          ret.push(decimalValue);
          ret.push(decimalColors[2].slice(0, -1) / 100);
          ret.push(decimalColors[4].slice(0, -1) / 100);
          color = this.hsl2rgb(ret[0], ret[1], ret[2]);
          ret = [];
        }
        if (rgbRegex.test(color)) {
          decimalColors = rgbRegex.exec(color).slice(1).filter(function(v, i) {
            return i % 2 === 0 && typeof v !== "undefined";
          });
          decimalColors.forEach(function(decimalValue2, i) {
            if (i === 3) {
              opacity = decimalValue2.slice(1) * 1;
            } else {
              if (decimalValue2.endsWith("%")) {
                decimalValue2 = Math.round(decimalValue2.slice(0, -1) * 255 / 100);
              } else decimalValue2 = decimalValue2 * 1;
              if (decimalValue2 > 255) {
                decimalValue2 = 255;
              }
              hexString = "0" + decimalValue2.toString(16);
              hexString = hexString.slice(-2);
              ret.push(hexString);
            }
          });
          return {
            color: "#" + ret.join(""),
            opacity
          };
        }
        if (nameRegex.test(color)) return {
          color,
          opacity
        };
        console.error('Could not parse color "' + color + '"');
        return {
          color,
          opacity
        };
      };
      this.convertToUnit = function(val) {
        if (!isNaN(parseFloat(val)) && isFinite(val)) return val * 1;
        var mtch = (val + "").trim().match(/^(-?\d*(\.\d+)?)(pt|px|r?em|cm|in)$/);
        if (!mtch) return false;
        val = mtch[1];
        switch (mtch[3]) {
          case "px": {
            val = Math.round(val * 0.75292857248934);
            break;
          }
          case "em":
          case "rem": {
            val *= 12;
            break;
          }
          case "cm": {
            val = Math.round(val * 28.34646);
            break;
          }
          case "in": {
            val *= 72;
            break;
          }
        }
        return val * 1;
      };
      var result = this.convertHtml(htmlText);
      if (typeof result === "string") result = {
        text: result
      };
      if (this.imagesByReference) {
        result = {
          content: result,
          images: {}
        };
        this.imagesRef.forEach(function(src, i) {
          result.images["img_ref_" + imagesByReferenceSuffix + i] = src.startsWith("{") ? JSON.parse(src) : src;
        });
      }
      return result;
    }
    module.exports = function(htmlText, options) {
      return new htmlToPdfMake(htmlText, options);
    };
  }
});
export default require_html_to_pdfmake();
//# sourceMappingURL=html-to-pdfmake.js.map
