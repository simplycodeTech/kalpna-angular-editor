declare module 'js-beautify';
declare module '*.js';
declare module 'pdfmake/build/pdfmake';
declare module 'pdfmake/build/vfs_fonts';
declare var window: any;
declare module 'html-to-pdfmake';
declare module 'mammoth';